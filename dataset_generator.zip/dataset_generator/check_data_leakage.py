"""
Data Leakage Checker for Train/Val/Test Splits

This standalone script checks if there are any environments that appear
in multiple splits, which would cause data leakage and invalid evaluation.

Can be used independently to verify dataset integrity.

Author: Selma
Date: 2025
"""

import os
from typing import List, Set, Tuple

import numpy as np


def extract_environment_id(filename: str, delimiter: str = "_patch_") -> str:
    """
    Extract the environment/map ID from a patch filename.
    
    For example:
    - Input: "00a8c96e2d1960d561a4661638c2bd87_90_0_2_patch_007.png"
    - Output: "00a8c96e2d1960d561a4661638c2bd87_90_0_2"
    
    Args:
        filename: Patch filename
        delimiter: Delimiter that separates map name from patch number
    
    Returns:
        Environment ID (the unique identifier for the source map)
    """
    # Remove extension
    name_without_ext = os.path.splitext(filename)[0]
    
    # Split by delimiter and take the first part
    if delimiter in name_without_ext:
        return name_without_ext.split(delimiter)[0]
    
    # If delimiter not found, return the whole name
    return name_without_ext


def check_environment_overlap_between_splits(
    patches_base_dir: str,
    splits: List[str] = ["train", "val", "test"],
    file_extension: str = ".png"
) -> bool:
    """
    Check if there are any environments that appear in multiple splits.
    
    This detects data leakage where patches from the same environment/map
    appear in both training and test/validation sets.
    
    Args:
        patches_base_dir: Base directory containing split folders
        splits: List of split names to check
        file_extension: File extension of patch files
    
    Returns:
        True if no overlap detected (good), False if overlap found (data leakage!)
    """
    print("="*70)
    print("CHECKING FOR DATA LEAKAGE BETWEEN SPLITS")
    print("="*70)
    print("\nEnsuring no environment appears in multiple splits...")
    print()
    
    # Collect environment IDs from each split
    split_environments = {}
    split_file_counts = {}
    
    for split in splits:
        input_dir = os.path.join(patches_base_dir, split, "input")
        
        if not os.path.exists(input_dir):
            print(f"⚠️  Skipping {split}: directory not found")
            continue
        
        # Get all patch files
        files = [f for f in os.listdir(input_dir) if f.endswith(file_extension)]
        
        # Extract environment IDs
        env_ids = set()
        for filename in files:
            env_id = extract_environment_id(filename)
            env_ids.add(env_id)
        
        split_environments[split] = env_ids
        split_file_counts[split] = len(files)
        
        print(f"[{split.upper()}]")
        print(f"  Total patches: {len(files)}")
        print(f"  Unique environments: {len(env_ids)}")
    
    print()
    
    # Check for overlaps
    overlaps_found = False
    overlap_details = []
    
    # Check all pairs of splits
    split_list = list(split_environments.keys())
    for i in range(len(split_list)):
        for j in range(i + 1, len(split_list)):
            split1 = split_list[i]
            split2 = split_list[j]
            
            overlap = split_environments[split1].intersection(split_environments[split2])
            
            if overlap:
                overlaps_found = True
                overlap_details.append((split1, split2, overlap))
    
    # Report results
    print("="*70)
    
    if not overlaps_found:
        print("✅ NO DATA LEAKAGE DETECTED!")
        print("="*70)
        print("\nAll splits contain patches from different environments.")
        print("Your dataset is properly split with no overlap.")
        print("\n🎉 Your dataset is ready for training!")
        return True
    else:
        print("❌ DATA LEAKAGE DETECTED!")
        print("="*70)
        print("\n⚠️  WARNING: Some environments appear in multiple splits!")
        print("This will cause data leakage and invalid evaluation.\n")
        
        for split1, split2, overlap in overlap_details:
            print(f"Overlap between {split1.upper()} and {split2.upper()}:")
            print(f"  {len(overlap)} environments appear in both splits")
            
            # Show first few examples
            examples = list(overlap)[:5]
            print(f"  Examples:")
            for env_id in examples:
                # Count patches from this environment in each split
                count1 = sum(1 for f in os.listdir(os.path.join(patches_base_dir, split1, "input"))
                           if extract_environment_id(f) == env_id)
                count2 = sum(1 for f in os.listdir(os.path.join(patches_base_dir, split2, "input"))
                           if extract_environment_id(f) == env_id)
                
                print(f"    - {env_id}")
                print(f"      ({split1}: {count1} patches, {split2}: {count2} patches)")
            
            if len(overlap) > 5:
                print(f"    ... and {len(overlap) - 5} more environments")
            print()
        
        print("="*70)
        print("RECOMMENDATION:")
        print("  You need to re-split your dataset to ensure each environment")
        print("  appears in only ONE split (train, val, or test).")
        print("\n  Steps to fix:")
        print("  1. Go back to your original full maps")
        print("  2. Split the MAPS (not patches) into train/val/test")
        print("  3. Make sure each map only goes to one split")
        print("  4. Re-run patch extraction")
        print("="*70)
        
        return False


def get_split_statistics_by_environment(
    patches_base_dir: str,
    splits: List[str] = ["train", "val", "test"],
    file_extension: str = ".png"
) -> None:
    """
    Get detailed statistics about environments and patches in each split.
    
    Args:
        patches_base_dir: Base directory containing split folders
        splits: List of split names to analyze
        file_extension: File extension of patch files
    """
    print("\n" + "="*70)
    print("DATASET STATISTICS BY ENVIRONMENT")
    print("="*70)
    
    for split in splits:
        input_dir = os.path.join(patches_base_dir, split, "input")
        
        if not os.path.exists(input_dir):
            continue
        
        print(f"\n[{split.upper()} Split]")
        
        # Get all files and group by environment
        files = [f for f in os.listdir(input_dir) if f.endswith(file_extension)]
        
        env_patch_counts = {}
        for filename in files:
            env_id = extract_environment_id(filename)
            env_patch_counts[env_id] = env_patch_counts.get(env_id, 0) + 1
        
        # Calculate statistics
        total_patches = len(files)
        total_environments = len(env_patch_counts)
        patch_counts = list(env_patch_counts.values())
        
        print(f"  Total patches: {total_patches}")
        print(f"  Total environments: {total_environments}")
        print(f"  Patches per environment:")
        print(f"    Mean: {np.mean(patch_counts):.1f}")
        print(f"    Median: {np.median(patch_counts):.0f}")
        print(f"    Min: {min(patch_counts)}")
        print(f"    Max: {max(patch_counts)}")
        
        # Show top environments by patch count
        top_envs = sorted(env_patch_counts.items(), key=lambda x: -x[1])[:5]
        print(f"  Top 5 environments by patch count:")
        for env_id, count in top_envs:
            short_id = env_id if len(env_id) <= 40 else env_id[:37] + "..."
            print(f"    {short_id}: {count} patches")
    
    print("\n" + "="*70)


def list_environments_per_split(
    patches_base_dir: str,
    splits: List[str] = ["train", "val", "test"],
    file_extension: str = ".png",
    output_file: str = "environment_split_mapping.txt"
) -> None:
    """
    Create a text file listing which environments are in which splits.
    
    Args:
        patches_base_dir: Base directory containing split folders
        splits: List of split names
        file_extension: File extension of patch files
        output_file: Output filename for the mapping
    """
    output_path = os.path.join(patches_base_dir, output_file)
    
    with open(output_path, 'w') as f:
        f.write("Environment to Split Mapping\n")
        f.write("="*70 + "\n\n")
        
        for split in splits:
            input_dir = os.path.join(patches_base_dir, split, "input")
            
            if not os.path.exists(input_dir):
                continue
            
            f.write(f"\n[{split.upper()}]\n")
            f.write("-"*70 + "\n")
            
            # Get unique environments
            files = [f for f in os.listdir(input_dir) if f.endswith(file_extension)]
            env_ids = sorted(set(extract_environment_id(fn) for fn in files))
            
            for env_id in env_ids:
                patch_count = sum(1 for fn in files if extract_environment_id(fn) == env_id)
                f.write(f"{env_id} ({patch_count} patches)\n")
    
    print(f"\n✅ Environment mapping saved to: {output_path}")


def main():
    """
    Main function for checking data leakage.
    
    USAGE:
    ------
    This script checks if your train/val/test splits have any data leakage.
    
    Expected directory structure:
    /path/to/patches/
        ├── train/
        │   └── input/    (patches from training environments)
        ├── val/
        │   └── input/    (patches from validation environments)
        └── test/
            └── input/    (patches from test environments)
    
    What it checks:
    - No environment appears in multiple splits
    - Shows statistics about environment distribution
    - Helps identify data leakage issues
    """
    
    # ========== CONFIGURATION ==========
    
    # Directory containing your patches
    PATCHES_DIR = "/home/selma/dataset_patches"
    
    # File extension
    FILE_EXTENSION = ".png"
    
    # Whether to save detailed mapping to file
    SAVE_MAPPING = True
    
    
    # ========== CHECK FOR LEAKAGE ==========
    
    no_leakage = check_environment_overlap_between_splits(
        patches_base_dir=PATCHES_DIR,
        splits=["train", "val", "test"],
        file_extension=FILE_EXTENSION
    )
    
    # Show detailed statistics
    get_split_statistics_by_environment(
        patches_base_dir=PATCHES_DIR,
        splits=["train", "val", "test"],
        file_extension=FILE_EXTENSION
    )
    
    # Optionally save environment mapping to file
    if SAVE_MAPPING:
        list_environments_per_split(
            patches_base_dir=PATCHES_DIR,
            splits=["train", "val", "test"],
            file_extension=FILE_EXTENSION,
            output_file="environment_split_mapping.txt"
        )
    
    # Final verdict
    print("\n" + "="*70)
    if no_leakage:
        print("✅ VERDICT: Dataset is clean - no data leakage detected!")
        print("   You can proceed with training.")
    else:
        print("❌ VERDICT: Data leakage detected - dataset needs fixing!")
        print("   Do NOT train on this dataset as evaluation will be invalid.")
    print("="*70 + "\n")


if __name__ == "__main__":
    main()
