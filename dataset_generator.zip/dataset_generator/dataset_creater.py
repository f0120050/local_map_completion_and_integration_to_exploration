from pathlib import Path
import os
import re
import shutil
import cv2
import numpy as np
from PIL import Image
from scipy.ndimage import label, center_of_mass
import csv
from shutil import copy2

def save_unique_prefixes_before_patch(folder_path, output_file):
    unique_keys = {filename.split('_patch_')[0] for filename in os.listdir(folder_path) if '_patch_' in filename}
    with open(output_file, 'w') as f:
        f.write('\n'.join(sorted(unique_keys)))
    print(f"Saved {len(unique_keys)} unique keys to {output_file}")

def copy_original_files_by_prefix(base_folder, train_keys_file, test_keys_file):
    train_output_folder = os.path.join(base_folder, "train")
    test_output_folder = os.path.join(base_folder, "test")

    os.makedirs(train_output_folder, exist_ok=True)
    os.makedirs(test_output_folder, exist_ok=True)

    # Load prefix keys
    with open(train_keys_file, "r") as f:
        train_keys = set(line.strip() for line in f if line.strip())

    with open(test_keys_file, "r") as f:
        test_keys = set(line.strip() for line in f if line.strip())

    print(f"len(train_keys): {len(train_keys)}, len(test_keys): {len(test_keys)}")

    all_files = [f for f in os.listdir(base_folder) if f.endswith(".pgm")]

    print(f"\nFirst 5 .pgm files found in folder:")
    for f in all_files[:5]:
        print(f"  - {f}")

    copied_train = 0
    copied_test = 0

    for filename in all_files:
        prefix = os.path.splitext(filename)[0]  # remove .pgm extension
        src_path = os.path.join(base_folder, filename)

        if prefix in train_keys:
            copy2(src_path, os.path.join(train_output_folder, filename))
            copied_train += 1
        elif prefix in test_keys:
            print(f"[MATCH] Test key matched: {prefix}")
            copy2(src_path, os.path.join(test_output_folder, filename))
            copied_test += 1

    print(f"\n✅ Copied {copied_train} train files and {copied_test} test files.")

def match_and_copy_input_output(results_path, robot_yaw, patch_size):
    input_dir = os.path.join(results_path, f"input_{patch_size}")
    output_dir = os.path.join(results_path, f"output_{patch_size}")
    os.makedirs(input_dir, exist_ok=True)
    os.makedirs(output_dir, exist_ok=True)

    pattern = re.compile(rf"{robot_yaw}_(\d+)_(\d+)\.pgm")

    for folder_name in os.listdir(results_path):
        folder_path = os.path.join(results_path, folder_name)
        if not os.path.isdir(folder_path):
            continue

        file_dict = {tuple(map(int, re.match(pattern, f).groups())): f
                     for f in os.listdir(folder_path)
                     if f.endswith(".pgm") and re.match(pattern, f)}

        for (x, y), fname in file_dict.items():
            next_coords = (x + 3, y + 3)
            if next_coords in file_dict:
                f1 = os.path.join(folder_path, fname)
                f2 = os.path.join(folder_path, file_dict[next_coords])
                if all(os.path.exists(p) for p in [f1, f2]):
                    new_name = f"{folder_name}_{robot_yaw}_{x}_{y}.pgm"
                    shutil.copy(f1, os.path.join(input_dir, new_name))
                    shutil.copy(f2, os.path.join(output_dir, new_name))

def extract_and_log_patches(results_path, patch_size, size_threshold=10, train_test = "train"):

    input_dir = os.path.join(results_path, f"input_{patch_size}{train_test}")
    output_dir = os.path.join(results_path, f"output_{patch_size}{train_test}")
    thr_dir = os.path.join(results_path, f"thr{size_threshold}")
    results_path = thr_dir
    input_patches_dir = os.path.join(results_path, f"input_patches_{patch_size}{train_test}")
    output_patches_dir = os.path.join(results_path, f"output_patches_{patch_size}{train_test}")
    log_csv_path = os.path.join(results_path, f"patch_log_{patch_size}{train_test}.csv")

    os.makedirs(thr_dir, exist_ok=True)
    os.makedirs(input_patches_dir, exist_ok=True)
    os.makedirs(output_patches_dir, exist_ok=True)

    FREE, UNKNOWN = 254, 205
    HALF = patch_size // 2

    with open(log_csv_path, mode="w", newline="") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["patch_name", "source_file", "centroid_row", "centroid_col"])

        total_saved = 0
        file_names = set(os.listdir(input_dir)).intersection(set(os.listdir(output_dir)))

        for fname in file_names:
            input_path = os.path.join(input_dir, fname)
            output_path = os.path.join(output_dir, fname)

            input_img = np.array(Image.open(input_path))
            output_img = np.array(Image.open(output_path))
            H, W = input_img.shape

            padded = np.pad(input_img, 1, constant_values=0)
            frontier_mask = np.zeros_like(input_img, dtype=bool)

            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                neighbor = padded[1+dx:1+dx+H, 1+dy:1+dy+W]
                frontier_mask |= ((input_img == FREE) & (neighbor == UNKNOWN))

            structure = np.ones((3, 3), dtype=int)
            labeled, num_components = label(frontier_mask, structure=structure)

            component_sizes = np.bincount(labeled.ravel())[1:]
            valid_components = [i+1 for i, size in enumerate(component_sizes) if size >= size_threshold]

            centroids = center_of_mass(frontier_mask, labeled, valid_components)
            base_name = os.path.splitext(fname)[0]

            # Process and sort centroids
            valid_centroids = []
            for cy, cx in centroids:
                cy_int, cx_int = int(round(cy)), int(round(cx))
                if not (0 <= cy_int < labeled.shape[0] and 0 <= cx_int < labeled.shape[1]):
                    continue
                component_id = labeled[cy_int, cx_int]
                if component_id > 0:  # Valid component
                    valid_centroids.append((cy_int, cx_int, component_sizes[component_id - 1]))

            # Sort by component size (descending)
            sorted_centroids = sorted(valid_centroids, key=lambda x: -x[2])
            final_centroids = [(cy, cx) for cy, cx, _ in sorted_centroids]

            # Apply minimum distance filtering
            min_distance = patch_size // 6
            filtered_centroids = []
            # for cy, cx in final_centroids:
            #     if all(np.hypot(cy - y, cx - x) >= min_distance
            #            for y, x in filtered_centroids):
            #         filtered_centroids.append((cy, cx))
            filtered_centroids = final_centroids

            for idx, (cy, cx) in enumerate(filtered_centroids, start=1):
                cy, cx = int(round(cy)), int(round(cx))
                y1, y2 = cy - HALF, cy + HALF
                x1, x2 = cx - HALF, cx + HALF

                if y1 >= 0 and x1 >= 0 and y2 <= H and x2 <= W:
                    input_patch = input_img[y1:y2, x1:x2]
                    output_patch = output_img[y1:y2, x1:x2]

                    patch_name = f"{base_name}_patch_{idx:03d}.pgm"
                    Image.fromarray(input_patch.astype(np.uint8)).save(os.path.join(input_patches_dir, patch_name))
                    Image.fromarray(output_patch.astype(np.uint8)).save(os.path.join(output_patches_dir, patch_name))
                    writer.writerow([patch_name, fname, cy, cx])
                    total_saved += 1
                else:
                    print(f"⛔ Skipped patch {idx} in {fname}: out of bounds at ({cy}, {cx})")

        print(f"✅ Done. Saved {total_saved} patch pairs to:")
        print(f"   - Input patches: {input_patches_dir}")
        print(f"   - Output patches: {output_patches_dir}")
        print(f"   - Log file:       {log_csv_path}")


def check_missing_files(folder_path, txt_file_path, extension=".pgm"):
    # Load expected filenames from the text file
    with open(txt_file_path, "r") as f:
        expected_files = [line.strip() + extension for line in f if line.strip()]

    # Get actual filenames in the folder
    actual_files = set(os.listdir(folder_path))

    # Identify missing files
    missing_files = [f for f in expected_files if f not in actual_files]

    # Report
    print(f"Checked folder: {folder_path}")
    print(f"Total expected files: {len(expected_files)}")
    print(f"Missing files: {len(missing_files)}")

    for mf in missing_files:
        print(f"❌ Missing: {mf}")

    return missing_files


def move_files_by_prefix_list(source_folder, destination_folder, prefix_file):
        # Load prefixes from the file
        with open(prefix_file, "r") as f:
            prefixes = set(line.strip() for line in f if line.strip())

        os.makedirs(destination_folder, exist_ok=True)

        moved_files = 0
        all_files = os.listdir(source_folder)

        for file_name in all_files:
            file_prefix = os.path.splitext(file_name)[0]  # Remove file extension
            if any(file_prefix.startswith(prefix) for prefix in prefixes):
                src_path = os.path.join(source_folder, file_name)
                dst_path = os.path.join(destination_folder, file_name)
                shutil.move(src_path, dst_path)
                moved_files += 1

        print(f"✅ Moved {moved_files} files from {source_folder} to {destination_folder}")


import os
import csv
import numpy as np
from PIL import Image
from scipy.ndimage import label
from shutil import copy2

def filter_existing_patches_by_frontier(patch_input_dir, patch_output_dir,
                                         #train_keys_file, test_keys_file,
                                         output_base_dir, patch_size, threshold=10):
    FREE, UNKNOWN = 254, 205
    HALF = patch_size // 2

    # Load train/test keys
    # with open(train_keys_file, "r") as f:
    #     train_keys = set(line.strip() for line in f if line.strip())
    # with open(test_keys_file, "r") as f:
    #     test_keys = set(line.strip() for line in f if line.strip())

    # Create destination folders
    train_input_dir = os.path.join(output_base_dir, f"train_input_{patch_size}")
    train_output_dir = os.path.join(output_base_dir, f"train_output_{patch_size}")
    test_input_dir = os.path.join(output_base_dir, f"test_input_{patch_size}")
    test_output_dir = os.path.join(output_base_dir, f"test_output_{patch_size}")
    os.makedirs(train_input_dir, exist_ok=True)
    os.makedirs(train_output_dir, exist_ok=True)
    os.makedirs(test_input_dir, exist_ok=True)
    os.makedirs(test_output_dir, exist_ok=True)

    patch_names = set(os.listdir(patch_input_dir)).intersection(os.listdir(patch_output_dir))
    total_kept = 0

    for patch_name in patch_names:
        input_path = os.path.join(patch_input_dir, patch_name)
        output_path = os.path.join(patch_output_dir, patch_name)

        input_img = np.array(Image.open(input_path))
        H, W = input_img.shape
        padded = np.pad(input_img, 1, constant_values=0)

        frontier_mask = np.zeros_like(input_img, dtype=bool)
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            neighbor = padded[1+dx:1+dx+H, 1+dy:1+dy+W]
            frontier_mask |= ((input_img == FREE) & (neighbor == UNKNOWN))

        structure = np.ones((3, 3), dtype=int)
        labeled, num_components = label(frontier_mask, structure=structure)
        frontier_pixels = (labeled > 0).sum()

        if frontier_pixels >= threshold:
            prefix = patch_name.split('_patch_')[0]
            copy2(input_path, os.path.join(test_input_dir, patch_name))
            copy2(output_path, os.path.join(test_output_dir, patch_name))
            total_kept += 1
            # if prefix in train_keys:
            #     copy2(input_path, os.path.join(train_input_dir, patch_name))
            #     copy2(output_path, os.path.join(train_output_dir, patch_name))
            #     total_kept += 1
            # elif prefix in test_keys:
            #     copy2(input_path, os.path.join(test_input_dir, patch_name))
            #     copy2(output_path, os.path.join(test_output_dir, patch_name))
            #     total_kept += 1
            # else:
            #     print(f"⚠️  Prefix '{prefix}' not found in train/test keys")

    print(f"✅ Done. Kept {total_kept} patch pairs with frontier size ≥ {threshold}")


def filter_patches_by_centered_frontier(patch_input_dir, patch_output_dir,
                                      output_dir, patch_size,
                                      min_threshold=10, center_radius=5):
    FREE, UNKNOWN = 254, 205
    HALF = patch_size // 2

    # Load train/test keys
    # with open(train_keys_file, "r") as f:
    #     train_keys = set(line.strip() for line in f if line.strip())
    # with open(test_keys_file, "r") as f:
    #     test_keys = set(line.strip() for line in f if line.strip())

    # Create destination folders
    train_input_dir = os.path.join(output_dir, f"train_input_{patch_size}")
    train_output_dir = os.path.join(output_dir, f"train_output_{patch_size}")
    test_input_dir = os.path.join(output_dir, f"test_input_{patch_size}")
    test_output_dir = os.path.join(output_dir, f"test_output_{patch_size}")
    os.makedirs(train_input_dir, exist_ok=True)
    os.makedirs(train_output_dir, exist_ok=True)
    os.makedirs(test_input_dir, exist_ok=True)
    os.makedirs(test_output_dir, exist_ok=True)

    patch_names = set(os.listdir(patch_input_dir)).intersection(os.listdir(patch_output_dir))
    total_kept = 0

    for patch_name in patch_names:
        input_path = os.path.join(patch_input_dir, patch_name)
        output_path = os.path.join(patch_output_dir, patch_name)

        input_img = np.array(Image.open(input_path))
        H, W = input_img.shape
        padded = np.pad(input_img, 1, constant_values=0)

        # Create frontier mask (FREE adjacent to UNKNOWN)
        frontier_mask = np.zeros_like(input_img, dtype=bool)
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            neighbor = padded[1+dx:1+dx+H, 1+dy:1+dy+W]
            frontier_mask |= ((input_img == FREE) & (neighbor == UNKNOWN))

        # Create center region mask (circular area around center)
        center_y, center_x = HALF, HALF
        y, x = np.ogrid[:H, :W]
        center_mask = ((x - center_x)**2 + (y - center_y)**2) <= center_radius**2

        # Count frontier pixels ONLY in center region
        centered_frontier = frontier_mask & center_mask
        frontier_pixels = centered_frontier.sum()

        # Keep if frontier in center AND size is ABOVE threshold
        if frontier_pixels >= min_threshold:
            prefix = patch_name.split('_patch_')[0]
            copy2(input_path, os.path.join(test_input_dir, patch_name))
            copy2(output_path, os.path.join(test_output_dir, patch_name))
            total_kept += 1
            # if prefix in train_keys:
            #     copy2(input_path, os.path.join(train_input_dir, patch_name))
            #     copy2(output_path, os.path.join(train_output_dir, patch_name))
            #     total_kept += 1
            # elif prefix not in train_keys:
            #     copy2(input_path, os.path.join(test_input_dir, patch_name))
            #     copy2(output_path, os.path.join(test_output_dir, patch_name))
            #     total_kept += 1
            # else:
            #     print(f"⚠️  Prefix '{prefix}' not found in train/test keys")

    print(f"✅ Done. Kept {total_kept} patch pairs with centered frontier ≥ {min_threshold} pixels")



def filter_patches_by_centered_frontier_without_filename_check(patch_input_dir, patch_output_dir,
                                      output_dir, patch_size,
                                      min_threshold=10, center_radius=5):
    FREE, UNKNOWN = 254, 205
    HALF = patch_size // 2

    # Create destination folders
    input_dir = os.path.join(output_dir, f"input_{patch_size}")
    output_dir = os.path.join(output_dir, f"output_{patch_size}")
    os.makedirs(input_dir, exist_ok=True)
    os.makedirs(output_dir, exist_ok=True)

    patch_names = set(os.listdir(patch_input_dir)).intersection(os.listdir(patch_output_dir))
    total_kept = 0

    for patch_name in patch_names:
        input_path = os.path.join(patch_input_dir, patch_name)
        output_path = os.path.join(patch_output_dir, patch_name)

        input_img = np.array(Image.open(input_path))
        H, W = input_img.shape
        padded = np.pad(input_img, 1, constant_values=0)

        # Create frontier mask (FREE adjacent to UNKNOWN)
        frontier_mask = np.zeros_like(input_img, dtype=bool)
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            neighbor = padded[1+dx:1+dx+H, 1+dy:1+dy+W]
            frontier_mask |= ((input_img == FREE) & (neighbor == UNKNOWN))

        # Create center region mask (circular area around center)
        center_y, center_x = HALF, HALF
        y, x = np.ogrid[:H, :W]
        center_mask = ((x - center_x)**2 + (y - center_y)**2) <= center_radius**2

        # Count frontier pixels ONLY in center region
        centered_frontier = frontier_mask & center_mask
        frontier_pixels = centered_frontier.sum()

        # Keep if frontier in center AND size is ABOVE threshold
        if frontier_pixels >= min_threshold:
            copy2(input_path, os.path.join(input_dir, patch_name))
            copy2(output_path, os.path.join(output_dir, patch_name))
            total_kept += 1

    print(f"✅ Done. Kept {total_kept} patch pairs with centered frontier ≥ {min_threshold} pixels")

def filter_existing_patches_by_frontier_resolution(
    patch_input_dir, patch_output_dir,
    train_keys_file, test_keys_file,
    output_base_dir, patch_size,
    resolution, min_frontier_size_meters):

    threshold = int(np.ceil(min_frontier_size_meters / resolution))
    print(f"📐 Frontier pixel threshold (rounded up): {threshold}")

    return filter_existing_patches_by_frontier(
        patch_input_dir, patch_output_dir,
        train_keys_file, test_keys_file,
        output_base_dir, patch_size,
        threshold
    )

def find_same_nemd_folders_with_files(folder_with_files, folder_with_subfolders):

    # Get file names (without extension) from Folder A
    file_names = {os.path.splitext(f)[0] for f in os.listdir(folder_with_files)
                  if os.path.isfile(os.path.join(folder_with_files, f))}

    # Get subfolder names from Folder B
    subfolder_names = {name for name in os.listdir(folder_with_subfolders)
                       if os.path.isdir(os.path.join(folder_with_subfolders, name))}

    # Find matches
    matches = file_names.intersection(subfolder_names)

    # Print results
    if matches:
        print("Matching names (file names matching subfolder names):")
        for name in sorted(matches):
            print(name)
    else:
        print("No matching names found.")

def find_different_named_files(folder_with_files, folder_with_subfolders):
    # Get file names (without extension) from Folder A
    file_names = {os.path.splitext(f)[0] for f in os.listdir(folder_with_files)
                  if os.path.isfile(os.path.join(folder_with_files, f))}

    # Get subfolder names from Folder B
    subfolder_names = {name for name in os.listdir(folder_with_subfolders)
                       if os.path.isdir(os.path.join(folder_with_subfolders, name))}

    # Find non-matching (different) names
    different_names = file_names.difference(subfolder_names)

    # Print results
    if different_names:
        print("File names without matching subfolder names:")
        for name in sorted(different_names):
            print(name)
    else:
        print("All file names have matching subfolder names.")


import re

def copy_most_completed_maps(folder1, folder2):
    # Loop through subfolders in folder1
    for subfolder_name in os.listdir(folder1):
        subfolder_path = os.path.join(folder1, subfolder_name)
        if not os.path.isdir(subfolder_path):
            continue

        pgm_files = [f for f in os.listdir(subfolder_path) if f.endswith('.pgm')]

        # Parse filenames like 30_8_1.pgm → (8, 1)
        candidates = []
        for fname in pgm_files:
            match = re.match(r"(\d+)_(\d+)_(\d+)\.pgm", fname)
            if match:
                second = int(match.group(2))
                third = int(match.group(3))
                candidates.append((second, third, fname))

        if not candidates:
            continue

        # Get the one with highest (second, third)
        best = max(candidates)
        best_pgm = best[2]
        best_yaml = best_pgm.replace('.pgm', '.yaml')

        src_pgm_path = os.path.join(subfolder_path, best_pgm)
        src_yaml_path = os.path.join(subfolder_path, best_yaml)

        dest_subfolder = os.path.join(folder2, subfolder_name)
        if os.path.isdir(dest_subfolder):
            shutil.copy2(src_pgm_path, dest_subfolder)
            if os.path.exists(src_yaml_path):
                shutil.copy2(src_yaml_path, dest_subfolder)
            print(f"✅ Copied to {dest_subfolder}: {best_pgm} and {best_yaml}")
        else:
            print(f"⚠️ Destination subfolder missing: {dest_subfolder}")


def move_foldeers():
    # Paths
    source_dir = "/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar2/30"
    target_dir = "/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar2/0"
    reference_dir = "/home/selma/Downloads/0 (2)/0"

    # Get folder names in the reference directory
    reference_folders = {
        name for name in os.listdir(reference_dir)
        if os.path.isdir(os.path.join(reference_dir, name))
    }

    # Move matching folders
    for folder_name in os.listdir(source_dir):
        full_source_path = os.path.join(source_dir, folder_name)
        full_target_path = os.path.join(target_dir, folder_name)

        if os.path.isdir(full_source_path) and folder_name in reference_folders:
            print(f"Moving: {folder_name}")
            shutil.move(full_source_path, full_target_path)

    print("Done.")


if __name__ == "__main__":


    # folder_path ="/home/selma/PycharmProjects/comparison_of_generative_models/train/input"
    # output_file = "unique_train_filenames.txt"
    # save_unique_prefixes_before_patch(folder_path, output_file)
    #
    # folder_path = "/home/selma/PycharmProjects/comparison_of_generative_models/test/input"
    # output_file = "unique_test_filenames.txt"
    # save_unique_prefixes_before_patch(folder_path, output_file)

    # check_missing_files(
    #     folder_path="/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar/30/output_32",
    #     txt_file_path="unique_test_filenames.txt",
    #     extension=".pgm"  # Adjust if your files use another extension
    # )

    # base_folder = "/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar/input_32"
    # train_keys_file = "unique_train_filenames.txt"
    # test_keys_file = "unique_test_filenames.txt"
    # copy_original_files_by_prefix(base_folder, train_keys_file, test_keys_file)

    results_path = "/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar2/"
    patch_size = 32
    threshold = 3

    #match_and_copy_input_output(results_path, 30, patch_size)

    #extract_and_log_patches(results_path, patch_size, size_threshold=threshold, train_test="")

    # move_files_by_prefix_list(
    #     source_folder="/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar/input_patches_32",
    #     destination_folder="/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar/input_patches_32_test",
    #     prefix_file="unique_test_filenames.txt"
    # )
    #
    threshold = 3
    center_radius = 5
    dataset_type = "old"
    #
    # print(dataset_type)

    if dataset_type == "old":
        #original
        patch_input_dir = "/home/selma/PycharmProjects/comparison_of_generative_models/test/input"
        patch_output_dir = "/home/selma/PycharmProjects/comparison_of_generative_models/test/output"
    else:
        #new
        patch_input_dir = "/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar2/subfoldersunder30/input_patches_32"
        patch_output_dir = "/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar2/subfoldersunder30/input_patches_32"

    #
    filter_patches_by_centered_frontier(
        patch_input_dir=patch_input_dir,
        patch_output_dir=patch_output_dir,
        # train_keys_file="unique_train_filenames.txt",
        # test_keys_file="unique_test_filenames.txt",
        patch_size=32,
        min_threshold=threshold,
        center_radius = center_radius,
        output_dir=f"filtered_patches_{dataset_type}_output_size-{threshold}_dist-{center_radius}",
    )

    # filter_existing_patches_by_frontier_resolution(
    #     patch_input_dir="/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar/input_patches_32",
    #     patch_output_dir="/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar/output_patches_32",
    #     train_keys_file="unique_train_filenames.txt",
    #     test_keys_file="unique_test_filenames.txt",
    #     output_base_dir="filtered_patches_output",
    #     patch_size=32,
    #     resolution=0.05,
    #     min_frontier_size_meters=0.75
    # )

    # folder_with_files = "/home/selma/robotlar_ws/src/image2gazebo/houseexpo_ds"
    # folder_with_subfolders = "/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar2/30"
    # #find_same_nemd_folders_with_files(folder_with_files, folder_with_subfolders)
    # find_different_named_files(folder_with_files, folder_with_subfolders)


    # folder1 = "/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar2/30"
    # folder2 = "/home/selma/robotlar_ws/src/image2gazebo/exploration_test_env_results"
    # copy_most_completed_maps(folder1, folder2)



