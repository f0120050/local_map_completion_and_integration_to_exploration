"""
Frontier-Based Patch Extraction from Full Maps

This script extracts training patches from full-size maps by:
1. Detecting frontiers in input maps
2. Finding frontier centroids
3. Extracting patches around frontiers from both input and output maps
4. Saving paired patches for training

Compatible with:
- PNG files (not just PGM)
- Existing train/val/test split structure
- Paired input/output folders with matching filenames

Author: Selma
Date: 2025
"""

import os
import csv
from typing import Tuple, List, Optional
from shutil import copy2

import numpy as np
from PIL import Image
from scipy.ndimage import label, center_of_mass
from tqdm import tqdm


# ============================================================================
# CONSTANTS
# ============================================================================

FREE_SPACE = 254        # Pixel value for explored free space
UNKNOWN_SPACE = 205     # Pixel value for unexplored space
OCCUPIED_SPACE = 0      # Pixel value for obstacles/walls


# ============================================================================
# CORE FRONTIER DETECTION
# ============================================================================

def detect_frontiers(occupancy_map: np.ndarray) -> np.ndarray:
    """
    Detect frontier cells in an occupancy grid map.
    
    A frontier cell is a free space cell that is adjacent to at least one
    unknown space cell. These represent the boundary between explored and
    unexplored regions.
    
    Args:
        occupancy_map: 2D numpy array representing the occupancy grid
                      (FREE_SPACE=254, UNKNOWN_SPACE=205, OCCUPIED_SPACE=0)
    
    Returns:
        Boolean mask where True indicates frontier cells
    """
    height, width = occupancy_map.shape
    
    # Pad the map to handle border cases
    padded = np.pad(occupancy_map, 1, constant_values=0)
    
    # Initialize frontier mask
    frontier_mask = np.zeros_like(occupancy_map, dtype=bool)
    
    # Check all 4-connected neighbors (up, down, left, right)
    for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        neighbor = padded[1+dx:1+dx+height, 1+dy:1+dy+width]
        # Frontier = free space adjacent to unknown space
        frontier_mask |= ((occupancy_map == FREE_SPACE) & (neighbor == UNKNOWN_SPACE))
    
    return frontier_mask


def find_frontier_centroids(
    frontier_mask: np.ndarray,
    min_component_size: int = 10,
    sort_by_size: bool = True
) -> List[Tuple[int, int]]:
    """
    Find centroids of connected frontier components.
    
    Args:
        frontier_mask: Boolean mask of frontier cells
        min_component_size: Minimum number of pixels for a valid component
        sort_by_size: If True, sort centroids by component size (largest first)
    
    Returns:
        List of (row, col) tuples representing frontier centroids
    """
    # Label connected components using 8-connectivity
    structure = np.ones((3, 3), dtype=int)
    labeled, num_components = label(frontier_mask, structure=structure)
    
    # Count pixels in each component
    component_sizes = np.bincount(labeled.ravel())[1:]  # Skip background (0)
    
    # Filter components by size threshold
    valid_components = [
        i + 1 for i, size in enumerate(component_sizes)
        if size >= min_component_size
    ]
    
    if not valid_components:
        return []
    
    # Calculate centroids
    centroids = center_of_mass(frontier_mask, labeled, valid_components)
    
    # Convert to integer coordinates and validate
    valid_centroids = []
    for cy, cx in centroids:
        cy_int, cx_int = int(round(cy)), int(round(cx))
        
        # Ensure centroid is within bounds
        if not (0 <= cy_int < labeled.shape[0] and 0 <= cx_int < labeled.shape[1]):
            continue
            
        component_id = labeled[cy_int, cx_int]
        if component_id > 0:
            size = component_sizes[component_id - 1]
            valid_centroids.append((cy_int, cx_int, size))
    
    # Sort by component size if requested
    if sort_by_size:
        valid_centroids.sort(key=lambda x: -x[2])  # Descending by size
    
    # Return only coordinates (drop size)
    return [(cy, cx) for cy, cx, _ in valid_centroids]


# ============================================================================
# PATCH EXTRACTION
# ============================================================================

def extract_patch_around_point(
    image: np.ndarray,
    center_row: int,
    center_col: int,
    patch_size: int
) -> Optional[np.ndarray]:
    """
    Extract a square patch centered at the given point.
    
    Args:
        image: Source image
        center_row: Row coordinate of patch center
        center_col: Column coordinate of patch center
        patch_size: Side length of the square patch
    
    Returns:
        Extracted patch, or None if patch would be out of bounds
    """
    half = patch_size // 2
    height, width = image.shape
    
    # Calculate patch boundaries
    row_start = center_row - half
    row_end = center_row + half
    col_start = center_col - half
    col_end = center_col + half
    
    # Check bounds
    if row_start >= 0 and col_start >= 0 and row_end <= height and col_end <= width:
        return image[row_start:row_end, col_start:col_end]
    
    return None


def extract_patches_from_map_pair(
    input_map_path: str,
    output_map_path: str,
    patch_size: int,
    min_frontier_size: int = 10
) -> Tuple[List[np.ndarray], List[np.ndarray], List[Tuple[int, int]], str]:
    """
    Extract patches around frontiers from a pair of input/output maps.
    
    Args:
        input_map_path: Path to input (incomplete/SLAM) map
        output_map_path: Path to output (complete/GT) map
        patch_size: Size of patches to extract (e.g., 32x32)
        min_frontier_size: Minimum frontier component size in pixels
    
    Returns:
        Tuple of (input_patches, output_patches, centroids, base_filename)
    """
    # Load maps
    input_img = np.array(Image.open(input_map_path))
    output_img = np.array(Image.open(output_map_path))
    
    # Handle RGB images (convert to grayscale if needed)
    if len(input_img.shape) == 3:
        input_img = input_img[:, :, 0]  # Take first channel
    if len(output_img.shape) == 3:
        output_img = output_img[:, :, 0]
    
    # Detect frontiers in input map
    frontier_mask = detect_frontiers(input_img)
    
    # Find frontier centroids
    centroids = find_frontier_centroids(
        frontier_mask,
        min_component_size=min_frontier_size,
        sort_by_size=True
    )
    
    # Extract patches
    input_patches = []
    output_patches = []
    valid_centroids = []
    
    for cy, cx in centroids:
        # Extract patches from both maps
        input_patch = extract_patch_around_point(input_img, cy, cx, patch_size)
        output_patch = extract_patch_around_point(output_img, cy, cx, patch_size)
        
        if input_patch is not None and output_patch is not None:
            input_patches.append(input_patch)
            output_patches.append(output_patch)
            valid_centroids.append((cy, cx))
    
    # Get base filename (without extension)
    base_name = os.path.splitext(os.path.basename(input_map_path))[0]
    
    return input_patches, output_patches, valid_centroids, base_name


def save_patches(
    input_patches: List[np.ndarray],
    output_patches: List[np.ndarray],
    centroids: List[Tuple[int, int]],
    base_name: str,
    input_save_dir: str,
    output_save_dir: str,
    csv_writer: Optional[csv.writer] = None,
    file_extension: str = ".png"
) -> int:
    """
    Save extracted patches to disk.
    
    Args:
        input_patches: List of input patches
        output_patches: List of output/GT patches
        centroids: List of (row, col) centroids
        base_name: Base filename for patches
        input_save_dir: Directory to save input patches
        output_save_dir: Directory to save GT patches
        csv_writer: Optional CSV writer for logging
        file_extension: File extension (.png or .pgm)
    
    Returns:
        Number of patches saved
    """
    patches_saved = 0
    
    for idx, (input_patch, output_patch, (cy, cx)) in enumerate(
        zip(input_patches, output_patches, centroids), start=1
    ):
        # Generate patch filename
        patch_name = f"{base_name}_patch_{idx:03d}{file_extension}"
        
        # Save patches
        Image.fromarray(input_patch.astype(np.uint8)).save(
            os.path.join(input_save_dir, patch_name)
        )
        Image.fromarray(output_patch.astype(np.uint8)).save(
            os.path.join(output_save_dir, patch_name)
        )
        
        # Log metadata
        if csv_writer:
            csv_writer.writerow([patch_name, base_name, cy, cx])
        
        patches_saved += 1
    
    return patches_saved


# ============================================================================
# BATCH PROCESSING
# ============================================================================

def extract_patches_from_split(
    input_maps_dir: str,
    output_maps_dir: str,
    patches_output_dir: str,
    split_name: str,
    patch_size: int,
    min_frontier_size: int = 10,
    file_extension: str = ".png"
) -> Tuple[int, int]:
    """
    Extract patches from all maps in a dataset split (train/val/test).
    
    Args:
        input_maps_dir: Directory containing input maps
        output_maps_dir: Directory containing output/GT maps
        patches_output_dir: Base directory for saving patches
        split_name: Name of split ("train", "val", or "test")
        patch_size: Size of patches to extract
        min_frontier_size: Minimum frontier component size
        file_extension: File extension of maps (.png or .pgm)
    
    Returns:
        Tuple of (total_patches_extracted, total_maps_processed)
    """
    # Create output directories
    input_patches_dir = os.path.join(patches_output_dir, split_name, "input")
    output_patches_dir = os.path.join(patches_output_dir, split_name, "output")
    os.makedirs(input_patches_dir, exist_ok=True)
    os.makedirs(output_patches_dir, exist_ok=True)
    
    # Create log file
    log_csv_path = os.path.join(patches_output_dir, split_name, f"patch_log.csv")
    
    # Find matching input/output map pairs
    input_files = set(os.listdir(input_maps_dir))
    output_files = set(os.listdir(output_maps_dir))
    matching_files = input_files.intersection(output_files)
    
    # Filter by extension
    matching_files = [f for f in matching_files if f.endswith(file_extension)]
    
    print(f"\n[{split_name.upper()}] Processing {len(matching_files)} maps...")
    
    # Initialize CSV log
    with open(log_csv_path, mode='w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["patch_name", "source_map", "centroid_row", "centroid_col"])
        
        total_patches = 0
        maps_with_patches = 0
        
        # Process each map pair
        for filename in tqdm(matching_files, desc=f"  Extracting patches"):
            input_path = os.path.join(input_maps_dir, filename)
            output_path = os.path.join(output_maps_dir, filename)
            
            # Extract patches
            input_patches, output_patches, centroids, base_name = extract_patches_from_map_pair(
                input_path,
                output_path,
                patch_size,
                min_frontier_size
            )
            
            # Save patches
            if input_patches:
                patches_saved = save_patches(
                    input_patches,
                    output_patches,
                    centroids,
                    base_name,
                    input_patches_dir,
                    output_patches_dir,
                    writer,
                    file_extension
                )
                total_patches += patches_saved
                maps_with_patches += 1
    
    return total_patches, len(matching_files)


def extract_patches_from_complete_dataset(
    base_dir: str,
    output_dir: str,
    patch_size: int,
    splits: List[str] = ["train", "val", "test"],
    min_frontier_size: int = 10,
    file_extension: str = ".png"
) -> None:
    """
    Extract patches from all splits in a dataset.
    
    Args:
        base_dir: Base directory containing train/val/test folders with input/output
        output_dir: Output directory for extracted patches
        patch_size: Size of patches to extract
        splits: List of split names to process
        min_frontier_size: Minimum frontier component size
        file_extension: File extension of maps
    """
    print("="*70)
    print("FRONTIER-BASED PATCH EXTRACTION")
    print("="*70)
    print(f"\nSource: {base_dir}")
    print(f"Output: {output_dir}")
    print(f"\nParameters:")
    print(f"  - Patch size: {patch_size}x{patch_size}")
    print(f"  - Min frontier size: {min_frontier_size} pixels")
    print(f"  - File extension: {file_extension}")
    print()
    
    results = {}
    
    # Process each split
    for split in splits:
        input_maps_dir = os.path.join(base_dir, split, "input")
        output_maps_dir = os.path.join(base_dir, split, "output")
        
        # Check if directories exist
        if not os.path.exists(input_maps_dir) or not os.path.exists(output_maps_dir):
            print(f"\n⚠️  Skipping {split}: directories not found")
            continue
        
        total_patches, total_maps = extract_patches_from_split(
            input_maps_dir=input_maps_dir,
            output_maps_dir=output_maps_dir,
            patches_output_dir=output_dir,
            split_name=split,
            patch_size=patch_size,
            min_frontier_size=min_frontier_size,
            file_extension=file_extension
        )
        
        results[split] = (total_patches, total_maps)
        
        avg_patches = total_patches / total_maps if total_maps > 0 else 0
        print(f"  ✅ Extracted {total_patches} patches from {total_maps} maps")
        print(f"     (avg {avg_patches:.1f} patches per map)")
    
    # Print summary
    print("\n" + "="*70)
    print("EXTRACTION COMPLETE - SUMMARY")
    print("="*70)
    
    for split in splits:
        if split in results:
            patches, maps = results[split]
            avg = patches / maps if maps > 0 else 0
            print(f"{split.upper():10s}: {patches:5d} patches from {maps:4d} maps (avg {avg:.1f}/map)")
    
    total_patches = sum(r[0] for r in results.values())
    total_maps = sum(r[1] for r in results.values())
    total_avg = total_patches / total_maps if total_maps > 0 else 0
    
    print(f"{'TOTAL':10s}: {total_patches:5d} patches from {total_maps:4d} maps (avg {total_avg:.1f}/map)")
    print("\n" + "="*70)
    
    print(f"\n✅ Patches saved to: {output_dir}")
    print(f"\nNew directory structure:")
    for split in splits:
        if split in results:
            print(f"  {output_dir}/{split}/input/")
            print(f"  {output_dir}/{split}/output/")


# ============================================================================
# FILTERING FUNCTIONS (OPTIONAL)
# ============================================================================

def has_centered_frontier(
    patch: np.ndarray,
    min_pixels: int = 3,
    center_radius: int = 5
) -> bool:
    """
    Check if a patch has frontier pixels near its center.
    
    Args:
        patch: Input patch to check
        min_pixels: Minimum number of frontier pixels required in center
        center_radius: Radius (in pixels) defining the center region
    
    Returns:
        True if patch has sufficient centered frontier pixels
    """
    height, width = patch.shape
    half_h, half_w = height // 2, width // 2
    
    # Detect frontiers
    frontier_mask = detect_frontiers(patch)
    
    # Create circular center mask
    y, x = np.ogrid[:height, :width]
    center_mask = ((x - half_w)**2 + (y - half_h)**2) <= center_radius**2
    
    # Count frontier pixels in center region
    centered_frontier = frontier_mask & center_mask
    frontier_count = centered_frontier.sum()
    
    return frontier_count >= min_pixels


def filter_patches_in_directory(
    input_patches_dir: str,
    output_patches_dir: str,
    filtered_input_dir: str,
    filtered_output_dir: str,
    min_centered_frontier: int = 3,
    center_radius: int = 5,
    file_extension: str = ".png"
) -> Tuple[int, int]:
    """
    Filter extracted patches to keep only those with centered frontiers.
    
    Args:
        input_patches_dir: Directory with input patches
        output_patches_dir: Directory with output patches
        filtered_input_dir: Output directory for filtered input patches
        filtered_output_dir: Output directory for filtered output patches
        min_centered_frontier: Minimum frontier pixels in center
        center_radius: Radius defining center region
        file_extension: File extension
    
    Returns:
        Tuple of (patches_kept, patches_total)
    """
    os.makedirs(filtered_input_dir, exist_ok=True)
    os.makedirs(filtered_output_dir, exist_ok=True)
    
    # Find matching patches
    input_files = set(os.listdir(input_patches_dir))
    output_files = set(os.listdir(output_patches_dir))
    matching_files = input_files.intersection(output_files)
    matching_files = [f for f in matching_files if f.endswith(file_extension)]
    
    kept_count = 0
    
    for filename in tqdm(matching_files, desc="  Filtering"):
        input_path = os.path.join(input_patches_dir, filename)
        output_path = os.path.join(output_patches_dir, filename)
        
        # Load and check input patch
        input_patch = np.array(Image.open(input_path))
        if len(input_patch.shape) == 3:
            input_patch = input_patch[:, :, 0]
        
        if has_centered_frontier(input_patch, min_centered_frontier, center_radius):
            copy2(input_path, os.path.join(filtered_input_dir, filename))
            copy2(output_path, os.path.join(filtered_output_dir, filename))
            kept_count += 1
    
    return kept_count, len(matching_files)


# ============================================================================
# DATA LEAKAGE DETECTION
# ============================================================================

def extract_environment_id(filename: str, delimiter: str = "_patch_") -> str:
    """
    Extract the environment/map ID from a patch filename.

    Args:
        filename: Patch filename (e.g., "00a8c96e...87_90_0_2_patch_007.png")
        delimiter: Delimiter that separates map name from patch number

    Returns:
        Environment ID (e.g., "00a8c96e...87_90_0_2")
    """
    # Remove extension
    name_without_ext = os.path.splitext(filename)[0]

    # Split by delimiter and take the first part
    if delimiter in name_without_ext:
        return name_without_ext.split(delimiter)[0]

    # If delimiter not found, return the whole name (could be full map)
    return name_without_ext


def check_environment_overlap_between_splits(
    patches_base_dir: str,
    splits: List[str] = ["train", "val", "test"],
    file_extension: str = ".png"
) -> bool:
    """
    Check if there are any environments that appear in multiple splits.

    This detects data leakage where patches from the same environment/map
    appear in both training and test/validation sets.

    Args:
        patches_base_dir: Base directory containing split folders
        splits: List of split names to check
        file_extension: File extension of patch files

    Returns:
        True if no overlap detected (good), False if overlap found (data leakage!)
    """
    print("="*70)
    print("CHECKING FOR DATA LEAKAGE BETWEEN SPLITS")
    print("="*70)
    print("\nEnsuring no environment appears in multiple splits...")
    print()

    # Collect environment IDs from each split
    split_environments = {}
    split_file_counts = {}

    for split in splits:
        input_dir = os.path.join(patches_base_dir, split, "input")

        if not os.path.exists(input_dir):
            print(f"⚠️  Skipping {split}: directory not found")
            continue

        # Get all patch files
        files = [f for f in os.listdir(input_dir) if f.endswith(file_extension)]

        # Extract environment IDs
        env_ids = set()
        for filename in files:
            env_id = extract_environment_id(filename)
            env_ids.add(env_id)

        split_environments[split] = env_ids
        split_file_counts[split] = len(files)

        print(f"[{split.upper()}]")
        print(f"  Total patches: {len(files)}")
        print(f"  Unique environments: {len(env_ids)}")

    print()

    # Check for overlaps
    overlaps_found = False
    overlap_details = []

    # Check all pairs of splits
    split_list = list(split_environments.keys())
    for i in range(len(split_list)):
        for j in range(i + 1, len(split_list)):
            split1 = split_list[i]
            split2 = split_list[j]

            overlap = split_environments[split1].intersection(split_environments[split2])

            if overlap:
                overlaps_found = True
                overlap_details.append((split1, split2, overlap))

    # Report results
    print("="*70)

    if not overlaps_found:
        print("✅ NO DATA LEAKAGE DETECTED!")
        print("="*70)
        print("\nAll splits contain patches from different environments.")
        print("Your dataset is properly split with no overlap.")
        return True
    else:
        print("❌ DATA LEAKAGE DETECTED!")
        print("="*70)
        print("\n⚠️  WARNING: Some environments appear in multiple splits!")
        print("This will cause data leakage and invalid evaluation.\n")

        for split1, split2, overlap in overlap_details:
            print(f"Overlap between {split1.upper()} and {split2.upper()}:")
            print(f"  {len(overlap)} environments appear in both splits")

            # Show first few examples
            examples = list(overlap)[:5]
            print(f"  Examples:")
            for env_id in examples:
                # Count patches from this environment in each split
                count1 = sum(1 for f in os.listdir(os.path.join(patches_base_dir, split1, "input"))
                           if extract_environment_id(f) == env_id)
                count2 = sum(1 for f in os.listdir(os.path.join(patches_base_dir, split2, "input"))
                           if extract_environment_id(f) == env_id)

                print(f"    - {env_id}")
                print(f"      ({split1}: {count1} patches, {split2}: {count2} patches)")

            if len(overlap) > 5:
                print(f"    ... and {len(overlap) - 5} more environments")
            print()

        print("="*70)
        print("RECOMMENDATION:")
        print("  You need to re-split your dataset to ensure each environment")
        print("  appears in only ONE split (train, val, or test).")
        print("="*70)

        return False


def get_split_statistics_by_environment(
    patches_base_dir: str,
    splits: List[str] = ["train", "val", "test"],
    file_extension: str = ".png"
) -> None:
    """
    Get detailed statistics about environments and patches in each split.

    Args:
        patches_base_dir: Base directory containing split folders
        splits: List of split names to analyze
        file_extension: File extension of patch files
    """
    print("="*70)
    print("DATASET STATISTICS BY ENVIRONMENT")
    print("="*70)

    for split in splits:
        input_dir = os.path.join(patches_base_dir, split, "input")

        if not os.path.exists(input_dir):
            continue

        print(f"\n[{split.upper()} Split]")

        # Get all files and group by environment
        files = [f for f in os.listdir(input_dir) if f.endswith(file_extension)]

        env_patch_counts = {}
        for filename in files:
            env_id = extract_environment_id(filename)
            env_patch_counts[env_id] = env_patch_counts.get(env_id, 0) + 1

        # Calculate statistics
        total_patches = len(files)
        total_environments = len(env_patch_counts)
        patch_counts = list(env_patch_counts.values())

        print(f"  Total patches: {total_patches}")
        print(f"  Total environments: {total_environments}")
        print(f"  Patches per environment:")
        print(f"    Mean: {np.mean(patch_counts):.1f}")
        print(f"    Median: {np.median(patch_counts):.0f}")
        print(f"    Min: {min(patch_counts)}")
        print(f"    Max: {max(patch_counts)}")

        # Show top environments by patch count
        top_envs = sorted(env_patch_counts.items(), key=lambda x: -x[1])[:5]
        print(f"  Top 5 environments by patch count:")
        for env_id, count in top_envs:
            short_id = env_id if len(env_id) <= 40 else env_id[:37] + "..."
            print(f"    {short_id}: {count} patches")

    print("\n" + "="*70)


# ============================================================================
# VISUALIZATION FUNCTIONS
# ============================================================================

def create_patch_pair_visualization(
    input_patches_dir: str,
    output_patches_dir: str,
    split_name: str,
    num_samples: int = 5,
    save_path: str = None,
    file_extension: str = ".png"
) -> None:
    """
    Create a table-like visualization showing random patch pairs.

    Creates a grid where:
    - Each row shows one patch pair (input | output)
    - Left column: input patches (incomplete maps)
    - Right column: output patches (ground truth/more complete)

    Args:
        input_patches_dir: Directory with input patches
        output_patches_dir: Directory with output patches
        split_name: Name of split ("train", "val", or "test")
        num_samples: Number of random pairs to show
        save_path: Path to save the visualization (if None, auto-generate)
        file_extension: File extension of patches
    """
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    import random

    # Find matching patches
    input_files = set(os.listdir(input_patches_dir))
    output_files = set(os.listdir(output_patches_dir))
    matching_files = list(input_files.intersection(output_files))
    matching_files = [f for f in matching_files if f.endswith(file_extension)]

    if len(matching_files) == 0:
        print(f"⚠️  No matching patches found in {split_name} split")
        return

    # Sample random patches
    num_samples = min(num_samples, len(matching_files))
    sampled_files = random.sample(matching_files, num_samples)

    # Create figure
    fig, axes = plt.subplots(num_samples, 2, figsize=(8, 4*num_samples))

    # Handle single row case
    if num_samples == 1:
        axes = axes.reshape(1, -1)

    # Set main title
    fig.suptitle(f'{split_name.upper()} Split - Random Patch Pairs',
                 fontsize=16, fontweight='bold', y=0.995)

    # Load and display patches
    for idx, filename in enumerate(sampled_files):
        input_path = os.path.join(input_patches_dir, filename)
        output_path = os.path.join(output_patches_dir, filename)

        input_patch = np.array(Image.open(input_path))
        output_patch = np.array(Image.open(output_path))

        # Handle RGB if needed
        if len(input_patch.shape) == 3:
            input_patch = input_patch[:, :, 0]
        if len(output_patch.shape) == 3:
            output_patch = output_patch[:, :, 0]

        # Display input patch
        axes[idx, 0].imshow(input_patch, cmap='gray', vmin=0, vmax=255)
        axes[idx, 0].set_title('Input (Incomplete)', fontsize=12, fontweight='bold')
        axes[idx, 0].axis('off')

        # Add border to input
        for spine in axes[idx, 0].spines.values():
            spine.set_edgecolor('blue')
            spine.set_linewidth(3)

        # Display output patch
        axes[idx, 1].imshow(output_patch, cmap='gray', vmin=0, vmax=255)
        axes[idx, 1].set_title('Output (Ground Truth)', fontsize=12, fontweight='bold')
        axes[idx, 1].axis('off')

        # Add border to output
        for spine in axes[idx, 1].spines.values():
            spine.set_edgecolor('green')
            spine.set_linewidth(3)

        # Add row label with filename
        fig.text(0.01, 1 - (idx + 0.5) / num_samples, f'Pair {idx+1}:',
                rotation=90, va='center', fontsize=10, fontweight='bold')

    # Add legend
    blue_patch = mpatches.Patch(color='blue', label='Input (Incomplete)')
    green_patch = mpatches.Patch(color='green', label='Output (Ground Truth)')
    fig.legend(handles=[blue_patch, green_patch], loc='lower center',
              ncol=2, fontsize=11, frameon=True, fancybox=True)

    plt.tight_layout(rect=[0.02, 0.02, 1, 0.99])

    # Save figure
    if save_path is None:
        save_path = f"visualization_{split_name}_pairs.png"

    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"  ✅ Saved visualization: {save_path}")
    plt.close()


def create_all_split_visualizations(
    patches_base_dir: str,
    splits: List[str] = ["train", "val", "test"],
    num_samples: int = 5,
    output_dir: str = None,
    file_extension: str = ".png"
) -> None:
    """
    Create visualizations for all dataset splits.

    Args:
        patches_base_dir: Base directory containing split folders
        splits: List of split names to visualize
        num_samples: Number of random pairs to show per split
        output_dir: Directory to save visualizations (if None, use patches_base_dir)
        file_extension: File extension of patches
    """
    if output_dir is None:
        output_dir = patches_base_dir

    os.makedirs(output_dir, exist_ok=True)

    print("="*70)
    print("CREATING DATASET VISUALIZATIONS")
    print("="*70)
    print(f"\nShowing {num_samples} random pairs from each split")
    print()

    for split in splits:
        input_patches_dir = os.path.join(patches_base_dir, split, "input")
        output_patches_dir = os.path.join(patches_base_dir, split, "output")

        if not os.path.exists(input_patches_dir) or not os.path.exists(output_patches_dir):
            print(f"⚠️  Skipping {split}: directories not found")
            continue

        print(f"[{split.upper()}] Creating visualization...")

        save_path = os.path.join(output_dir, f"visualization_{split}_pairs.png")

        create_patch_pair_visualization(
            input_patches_dir=input_patches_dir,
            output_patches_dir=output_patches_dir,
            split_name=split,
            num_samples=num_samples,
            save_path=save_path,
            file_extension=file_extension
        )

    print("\n" + "="*70)
    print("VISUALIZATIONS COMPLETE")
    print("="*70)
    print(f"\nVisualization files saved to: {output_dir}/")
    for split in splits:
        viz_file = os.path.join(output_dir, f"visualization_{split}_pairs.png")
        if os.path.exists(viz_file):
            print(f"  - visualization_{split}_pairs.png")


# ============================================================================
# MAIN FUNCTION
# ============================================================================

def main():
    """
    Main function for extracting patches from full maps.

    USAGE:
    ------
    This script processes full-size maps and extracts patches around frontiers.

    Your dataset structure (INPUT - full maps):
    /home/selma/dataset_final/
        ├── train/
        │   ├── input/    (full maps: 00a8c96e2d1960d561a4661638c2bd87_90_0_2.png)
        │   └── output/   (full maps: 00a8c96e2d1960d561a4661638c2bd87_90_0_2.png)
        ├── val/
        │   ├── input/
        │   └── output/
        └── test/
            ├── input/
            └── output/

    Output structure (PATCHES):
    /home/selma/dataset_patches/
        ├── train/
        │   ├── input/    (patches: 00a8c96e...87_90_0_2_patch_001.png)
        │   ├── output/   (patches: 00a8c96e...87_90_0_2_patch_001.png)
        │   └── patch_log.csv
        ├── val/
        └── test/
    """

    # ========== CONFIGURATION ==========

    # Your full maps dataset
    BASE_DIR = "/home/selma/dataset_final"

    # Output directory for extracted patches
    OUTPUT_DIR = "/home/selma/dataset_patches_64"

    # Patch extraction parameters
    PATCH_SIZE = 64                    # Extract 32x32 patches
    MIN_FRONTIER_SIZE = 10             # Minimum frontier component size (pixels)
    FILE_EXTENSION = ".png"            # Your files are PNG

    # Optional filtering parameters (apply after extraction)
    APPLY_FILTERING = False            # Set to True to filter patches
    MIN_CENTERED_FRONTIER = 3          # Minimum frontier pixels in patch center
    CENTER_RADIUS = 5                  # Radius of center region


    # ========== STEP 1: EXTRACT PATCHES ==========

    extract_patches_from_complete_dataset(
        base_dir=BASE_DIR,
        output_dir=OUTPUT_DIR,
        patch_size=PATCH_SIZE,
        splits=["train", "val", "test"],
        min_frontier_size=MIN_FRONTIER_SIZE,
        file_extension=FILE_EXTENSION
    )


    # ========== STEP 2: OPTIONAL FILTERING ==========

    if APPLY_FILTERING:
        print("\n" + "="*70)
        print("FILTERING PATCHES BY CENTERED FRONTIER")
        print("="*70)

        filtered_output_dir = OUTPUT_DIR + "_filtered"

        for split in ["train", "val", "test"]:
            input_patches = os.path.join(OUTPUT_DIR, split, "input")
            output_patches = os.path.join(OUTPUT_DIR, split, "output")

            if not os.path.exists(input_patches):
                continue

            print(f"\n[{split.upper()}]")

            filtered_input = os.path.join(filtered_output_dir, split, "input")
            filtered_output = os.path.join(filtered_output_dir, split, "output")

            kept, total = filter_patches_in_directory(
                input_patches_dir=input_patches,
                output_patches_dir=output_patches,
                filtered_input_dir=filtered_input,
                filtered_output_dir=filtered_output,
                min_centered_frontier=MIN_CENTERED_FRONTIER,
                center_radius=CENTER_RADIUS,
                file_extension=FILE_EXTENSION
            )

            percentage = (kept / total * 100) if total > 0 else 0
            print(f"  ✅ Kept {kept}/{total} patches ({percentage:.1f}%)")

        print(f"\n✅ Filtered patches saved to: {filtered_output_dir}")


    # ========== STEP 3: CHECK FOR DATA LEAKAGE ==========

    final_dir = OUTPUT_DIR + "_filtered" if APPLY_FILTERING else OUTPUT_DIR

    print("\n" + "="*70)
    print("Checking for data leakage between splits...")
    print("="*70)

    # Check if any environments appear in multiple splits
    no_leakage = check_environment_overlap_between_splits(
        patches_base_dir=final_dir,
        splits=["train", "val", "test"],
        file_extension=FILE_EXTENSION
    )

    # Show detailed statistics
    if no_leakage:
        get_split_statistics_by_environment(
            patches_base_dir=final_dir,
            splits=["train", "val", "test"],
            file_extension=FILE_EXTENSION
        )


    # ========== STEP 4: CREATE VISUALIZATIONS ==========

    print("\n" + "="*70)
    print("Creating visualizations of random patch pairs...")
    print("="*70)

    # Create visualizations showing random samples
    create_all_split_visualizations(
        patches_base_dir=final_dir,
        splits=["train", "val", "test"],
        num_samples=5,  # Show 5 random pairs per split
        output_dir=final_dir,
        file_extension=FILE_EXTENSION
    )


    # ========== FINAL INFO ==========

    print("\n" + "="*70)
    print("ALL DONE!")
    print("="*70)

    print(f"\nYou can now update your training config to use:")
    print(f"  train_input: {final_dir}/train/input")
    print(f"  train_output: {final_dir}/train/output")
    print(f"  val_input: {final_dir}/val/input")
    print(f"  val_output: {final_dir}/val/output")
    print(f"  test_input: {final_dir}/test/input")
    print(f"  test_output: {final_dir}/test/output")

    print(f"\nVisualization files:")
    print(f"  {final_dir}/visualization_train_pairs.png")
    print(f"  {final_dir}/visualization_val_pairs.png")
    print(f"  {final_dir}/visualization_test_pairs.png")
    print()


if __name__ == "__main__":
    main()