# from PIL import Image
# import os
#
# # Configuration
# input_dir = '/home/selma/Downloads/not_processed'
# output_file = 'sorted_png_dimensions_not_processed.txt'
#
# # Get all PNG files
# png_files = [f for f in os.listdir(input_dir) if f.lower().endswith('.png')]
#
# # Process files and store dimensions
# image_data = []
# for png in png_files:
#     try:
#         img_path = os.path.join(input_dir, png)
#         with Image.open(img_path) as img:
#             width, height = img.size
#             total_pixels = width * height
#             image_data.append({
#                 'filename': png,
#                 'width': width,
#                 'height': height,
#                 'total_pixels': total_pixels,
#                 'aspect_ratio': width / height
#             })
#     except Exception as e:
#         print(f"Error processing {png}: {e}")
#
# # Sort by total pixels (descending)
# image_data.sort(key=lambda x: x['total_pixels'], reverse=True)
#
# # Write sorted results to file
# with open(output_file, 'w') as f:
#     f.write("PNG Files Sorted by Size (Largest to Smallest)\n")
#     f.write("=" * 60 + "\n")
#     f.write("{:<30} {:<10} {:<10} {:<15} {:<10}\n".format(
#         "Filename", "Width", "Height", "Total Pixels", "Aspect Ratio"))
#     f.write("-" * 60 + "\n")
#
#     for img in image_data:
#         f.write("{filename:<30} {width:<10} {height:<10} {total_pixels:<15,} {aspect_ratio:<10.2f}\n".format(**img))
#
# print(f"Successfully wrote sorted dimensions of {len(image_data)} PNG files to {output_file}")

import os
from PIL import Image

# Configuration
base_dir = '/home/selma/robotlar_ws/src/image2gazebo/exploration_test_env_results'
output_file = 'matching_folders_large.txt'
min_dimension = 3000  # Minimum width and height required

def has_large_png(folder):
    """Check if folder contains PNG > min_dimension x min_dimension"""
    for file in os.listdir(folder):
        if file.lower().endswith('.png'):
            try:
                with Image.open(os.path.join(folder, file)) as img:
                    width, height = img.size
                    if width > min_dimension and height> min_dimension:
                        return True
            except:
                continue
    return False

def has_pgm(folder):
    """Check if folder contains any PGM file"""
    return any(file.lower().endswith('.pgm') for file in os.listdir(folder))

# Find matching folders
matching_folders = []
for root, dirs, files in os.walk(base_dir):
    if has_large_png(root) and has_pgm(root):
        matching_folders.append(root)

# Write results to file
with open(output_file, 'w') as f:
    f.write(f"Folders containing PNG < {min_dimension}x{min_dimension} and PGM files:\n")
    f.write("="*70 + "\n\n")
    if matching_folders:
        for folder in matching_folders:
            f.write(f"{folder}\n")
    else:
        f.write("No matching folders found\n")

print(f"Found {len(matching_folders)} matching folders")
print(f"Results saved to {output_file}")