import os
from pathlib import Path

# Set your folder paths here
files_folder = Path("/home/selma/robotlar_ws/src/image2gazebo/houseexpo_ds/")
subfolders_parent = Path("/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar/30/")

# # Get all filenames (without extension)
# file_names = {f.stem for f in files_folder.glob("*") if f.is_file()}
#
# # Get all subfolder names
# subfolder_names = {f.name for f in subfolders_parent.iterdir() if f.is_dir()}
#
# # Find files whose names do not match any subfolder
# unmatched_files = file_names - subfolder_names
#
# # Print or return the result
# print("Files without matching subfolders:")
# for name in unmatched_files:
#     print(name)

# Get all filenames (without extension)
all_files = [f for f in files_folder.glob("*") if f.is_file()]
file_names = {f.stem for f in all_files}

# Get all subfolder names
subfolder_names = {f.name for f in subfolders_parent.iterdir() if f.is_dir()}

# Keep only files whose stem is NOT in unmatched list
unmatched_files = file_names - subfolder_names

# Delete the files that DO match subfolder names
for file in all_files:
    if file.stem in (file_names - unmatched_files):  # i.e., they have a matching subfolder
        file.unlink()
        print(f"Deleted: {file.name}")

print("Cleanup completed.")
