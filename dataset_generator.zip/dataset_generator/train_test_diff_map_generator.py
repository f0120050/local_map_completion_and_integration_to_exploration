import os
import shutil
import random
from collections import defaultdict

# Set seed for reproducibility
random.seed(42)

# Base paths
base_input = "/home/selma/PycharmProjects/map_completion2/filtered_patches_output_size-3_dist3/input_32"
base_output = "/home/selma/PycharmProjects/map_completion2/filtered_patches_output_size-3_dist3/output_32"
base_dest = "/home/selma/PycharmProjects/map_completion2/filtered_patches_output_size-3_dist3"

# Output folders
output_dirs = {
    'train_input': os.path.join(base_dest, 'train/input'),
    'train_output': os.path.join(base_dest, 'train/output'),
    'test_input': os.path.join(base_dest, 'test/input'),
    'test_output': os.path.join(base_dest, 'test/output'),
}

# Create output folders
for folder in output_dirs.values():
    os.makedirs(folder, exist_ok=True)

# Group files by map name (first segment before "_")
map_to_files = defaultdict(list)
for filename in os.listdir(base_input):
    if filename.endswith(".pgm"):
        map_name = filename.split('_')[0]
        map_to_files[map_name].append(filename)

# Split map names: 80% train, 20% test
map_names = list(map_to_files.keys())
random.shuffle(map_names)
split_idx = int(0.8 * len(map_names))
train_maps = set(map_names[:split_idx])
test_maps = set(map_names[split_idx:])

# Copy files to train/test folders
for map_name, files in map_to_files.items():
    target_set = "train" if map_name in train_maps else "test"
    for fname in files:
        # Input
        src_input = os.path.join(base_input, fname)
        dst_input = os.path.join(output_dirs[f"{target_set}_input"], fname)
        shutil.copy2(src_input, dst_input)

        # Output
        src_output = os.path.join(base_output, fname)
        dst_output = os.path.join(output_dirs[f"{target_set}_output"], fname)
        shutil.copy2(src_output, dst_output)

print("✅ Files split and copied successfully.")
print(f"Total maps: {len(map_names)}")
print(f"Train maps: {len(train_maps)}")
print(f"Test maps: {len(test_maps)}")
