import os
import shutil



def find_unprocessed_files(folder_dir, file_dir, output_file):
    # Get all subfolder names in folder_dir
    folder_names = [f for f in os.listdir(folder_dir) if os.path.isdir(os.path.join(folder_dir, f))]

    # Get all filenames (without extension) in file_dir
    file_names = [os.path.splitext(f)[0] for f in os.listdir(file_dir) if os.path.isfile(os.path.join(file_dir, f))]

    # Find files that do not have a corresponding folder
    unmatched_files = [f for f in file_names if f not  in folder_names]

    # Save results
    with open(output_file, 'w') as f:
        f.write("\n".join(sorted(unmatched_files)))

    print(f"Found {len(unmatched_files)} unprocessed files")
    print(f"Results saved to {output_file}")



def find_unprocessed_files2(processed_dir, source_dir, output_file):
    """
    Finds PNG files in source_dir that don't have corresponding processed PGM files.

    Args:
        processed_dir: Directory with processed PGM files (with _patch_ names)
        source_dir: Directory with source PNG files (simple names)
        output_file: File to save unprocessed PNG names
    """
    # Step 1: Get all processed base names from PGM files
    processed_names = set()
    for filename in os.listdir(processed_dir):
        if filename.endswith(".pgm"):
            # Extract base name before first underscore
            base_name = filename.split('_')[0]
            processed_names.add(base_name)

    # Step 2: Find unprocessed PNG files
    unprocessed = []

    for filename in os.listdir(source_dir):


        if filename.endswith(".png"):
            # PNG filenames don't have underscores
            png_base = filename.split('.')[0]
            if filename not in processed_names:
                unprocessed.append(filename)

    # Step 3: Save results
    with open(output_file, 'w') as f:
        f.write("\n".join(sorted(unprocessed)))

    print(f"Found {len(unprocessed)} unprocessed PNG files")
    print(f"Results saved to {output_file}")


def copy_unprocessed_files(processed_dir, source_dir, target_dir):
    """
    Finds and copies unprocessed PNG files from source to target directory.

    Args:
        processed_dir: Directory with processed PGM files (e.g., input_patches_32)
        source_dir: Directory with source PNG files
        target_dir: Where to copy unprocessed PNGs
    """
    # Ensure target directory exists
    os.makedirs(target_dir, exist_ok=True)

    # Step 1: Get processed base names (from PGM files)
    processed_names = set()
    for filename in os.listdir(processed_dir):
        if filename.endswith(".pgm"):
            base_name = filename.split('_')[0]
            processed_names.add(base_name)

    # Step 2: Find and copy unprocessed PNGs
    unprocessed_count = 0
    for filename in os.listdir(source_dir):
        if filename.endswith(".png"):
            png_base = os.path.splitext(filename)[0]  # Remove .png

            if png_base not in processed_names:
                src_path = os.path.join(source_dir, filename)
                dst_path = os.path.join(target_dir, filename)

                shutil.copy2(src_path, dst_path)
                unprocessed_count += 1
                print(f"Copied: {filename}")

    print(f"\n✅ Done! Copied {unprocessed_count} unprocessed PNGs to:")
    print(f"Target directory: {target_dir}")


def extract_and_save_unique_names(directory, output_file):
    """
    Extracts unique base names from PGM files and saves them to a text file.

    Args:
        directory (str): Path to directory containing PGM files
        output_file (str): Path to output text file
    """
    unique_names = set()

    # Extract unique names
    for filename in os.listdir(directory):
        if filename.endswith(".pgm"):
            # Split on first underscore
            base_name = filename.split('_')[0]
            unique_names.add(base_name)

    # Save to file
    with open(output_file, 'w') as f:
        for name in sorted(unique_names):
            f.write(f"{name}\n")

    print(f"Saved {len(unique_names)} unique names to {output_file}")


# Usage
# input_dir = "/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar/input_patches_32"
# output_file = "unique_base_names.txt"
#
# extract_and_save_unique_names(input_dir, output_file)


# Example usage
# processed_dir = "/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar/input_patches_32"
# source_dir = "/home/selma/Downloads/not_processed"
# target_dir = "/home/selma/robotlar_ws/src/image2gazebo/houseexpo_ds"
#
# copy_unprocessed_files(processed_dir, source_dir, target_dir)
#

# # Example usage
processed_dir = "/home/selma/robotlar_ws/src/map_saving/map_saving_sonuclar2/30"
source_dir = "/home/selma/robotlar_ws/src/image2gazebo/houseexpo_ds"
output_file = "unprocessed_folders.txt"

#find_unprocessed_files(processed_dir, source_dir, output_file)
find_unprocessed_files(processed_dir, source_dir, output_file)