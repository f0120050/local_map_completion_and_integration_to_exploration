"""
Dataset Patch Pair Visualizer

This standalone script creates table-like visualizations showing random
patch pairs from train/val/test splits.

Can be used independently after patches have been extracted.

Author: Selma
Date: 2025
"""

import os
import random
from typing import List

import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


def create_patch_pair_visualization(
    input_patches_dir: str,
    output_patches_dir: str,
    split_name: str,
    num_samples: int = 5,
    save_path: str = None,
    file_extension: str = ".png"
) -> None:
    """
    Create a table-like visualization showing random patch pairs.
    
    Creates a grid where:
    - Each row shows one patch pair (input | output)
    - Left column: input patches (incomplete maps)
    - Right column: output patches (ground truth/more complete)
    
    Args:
        input_patches_dir: Directory with input patches
        output_patches_dir: Directory with output patches
        split_name: Name of split ("train", "val", or "test")
        num_samples: Number of random pairs to show
        save_path: Path to save the visualization (if None, auto-generate)
        file_extension: File extension of patches
    """
    # Find matching patches
    input_files = set(os.listdir(input_patches_dir))
    output_files = set(os.listdir(output_patches_dir))
    matching_files = list(input_files.intersection(output_files))
    matching_files = [f for f in matching_files if f.endswith(file_extension)]
    
    if len(matching_files) == 0:
        print(f"⚠️  No matching patches found in {split_name} split")
        return
    
    # Sample random patches
    num_samples = min(num_samples, len(matching_files))
    sampled_files = random.sample(matching_files, num_samples)
    
    # Create figure
    fig, axes = plt.subplots(num_samples, 2, figsize=(8, 4*num_samples))
    
    # Handle single row case
    if num_samples == 1:
        axes = axes.reshape(1, -1)
    
    # Set main title
    fig.suptitle(f'{split_name.upper()} Split - Random Patch Pairs', 
                 fontsize=16, fontweight='bold', y=0.995)
    
    # Load and display patches
    for idx, filename in enumerate(sampled_files):
        input_path = os.path.join(input_patches_dir, filename)
        output_path = os.path.join(output_patches_dir, filename)
        
        input_patch = np.array(Image.open(input_path))
        output_patch = np.array(Image.open(output_path))
        
        # Handle RGB if needed
        if len(input_patch.shape) == 3:
            input_patch = input_patch[:, :, 0]
        if len(output_patch.shape) == 3:
            output_patch = output_patch[:, :, 0]
        
        # Display input patch
        axes[idx, 0].imshow(input_patch, cmap='gray', vmin=0, vmax=255)
        axes[idx, 0].set_title('Input (Incomplete)', fontsize=12, fontweight='bold')
        axes[idx, 0].axis('off')
        
        # Add border to input
        for spine in axes[idx, 0].spines.values():
            spine.set_edgecolor('blue')
            spine.set_linewidth(3)
        
        # Display output patch
        axes[idx, 1].imshow(output_patch, cmap='gray', vmin=0, vmax=255)
        axes[idx, 1].set_title('Output (Ground Truth)', fontsize=12, fontweight='bold')
        axes[idx, 1].axis('off')
        
        # Add border to output
        for spine in axes[idx, 1].spines.values():
            spine.set_edgecolor('green')
            spine.set_linewidth(3)
        
        # Add row label with filename (truncated for readability)
        short_name = filename if len(filename) <= 30 else filename[:27] + "..."
        fig.text(0.01, 1 - (idx + 0.5) / num_samples, f'#{idx+1}\n{short_name}', 
                rotation=90, va='center', fontsize=8, ha='center')
    
    # Add legend
    blue_patch = mpatches.Patch(color='blue', label='Input (Incomplete)')
    green_patch = mpatches.Patch(color='green', label='Output (Ground Truth)')
    fig.legend(handles=[blue_patch, green_patch], loc='lower center', 
              ncol=2, fontsize=11, frameon=True, fancybox=True)
    
    plt.tight_layout(rect=[0.03, 0.02, 1, 0.99])
    
    # Save figure
    if save_path is None:
        save_path = f"visualization_{split_name}_pairs.png"
    
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"  ✅ Saved: {save_path}")
    plt.close()


def create_all_split_visualizations(
    patches_base_dir: str,
    splits: List[str] = ["train", "val", "test"],
    num_samples: int = 5,
    output_dir: str = None,
    file_extension: str = ".png"
) -> None:
    """
    Create visualizations for all dataset splits.
    
    Args:
        patches_base_dir: Base directory containing split folders
        splits: List of split names to visualize
        num_samples: Number of random pairs to show per split
        output_dir: Directory to save visualizations (if None, use patches_base_dir)
        file_extension: File extension of patches
    """
    if output_dir is None:
        output_dir = patches_base_dir
    
    os.makedirs(output_dir, exist_ok=True)
    
    print("="*70)
    print("CREATING DATASET VISUALIZATIONS")
    print("="*70)
    print(f"\nSource: {patches_base_dir}")
    print(f"Output: {output_dir}")
    print(f"Showing {num_samples} random pairs from each split\n")
    
    for split in splits:
        input_patches_dir = os.path.join(patches_base_dir, split, "input")
        output_patches_dir = os.path.join(patches_base_dir, split, "output")
        
        if not os.path.exists(input_patches_dir) or not os.path.exists(output_patches_dir):
            print(f"⚠️  Skipping {split}: directories not found")
            continue
        
        print(f"[{split.upper()}] Creating visualization...")
        
        save_path = os.path.join(output_dir, f"visualization_{split}_pairs.png")
        
        create_patch_pair_visualization(
            input_patches_dir=input_patches_dir,
            output_patches_dir=output_patches_dir,
            split_name=split,
            num_samples=num_samples,
            save_path=save_path,
            file_extension=file_extension
        )
    
    print("\n" + "="*70)
    print("VISUALIZATIONS COMPLETE")
    print("="*70)
    print(f"\nVisualization files in: {output_dir}/")
    for split in splits:
        viz_file = os.path.join(output_dir, f"visualization_{split}_pairs.png")
        if os.path.exists(viz_file):
            print(f"  ✓ visualization_{split}_pairs.png")


def main():
    """
    Main function for creating visualizations.
    
    USAGE:
    ------
    This script creates table-like visualizations showing random patch pairs
    from your dataset.
    
    Expected directory structure:
    /path/to/patches/
        ├── train/
        │   ├── input/    (patches)
        │   └── output/   (patches)
        ├── val/
        │   ├── input/
        │   └── output/
        └── test/
            ├── input/
            └── output/
    
    Output:
    -------
    Creates three PNG files showing random pairs:
    - visualization_train_pairs.png
    - visualization_val_pairs.png
    - visualization_test_pairs.png
    """
    
    # ========== CONFIGURATION ==========
    
    # Directory containing your extracted patches
    PATCHES_DIR = "/home/selma/dataset_patches"
    
    # Where to save visualizations (None = save in PATCHES_DIR)
    OUTPUT_DIR = None
    
    # How many random pairs to show per split
    NUM_SAMPLES = 5
    
    # File extension
    FILE_EXTENSION = ".png"
    
    
    # ========== CREATE VISUALIZATIONS ==========
    
    create_all_split_visualizations(
        patches_base_dir=PATCHES_DIR,
        splits=["train", "val", "test"],
        num_samples=NUM_SAMPLES,
        output_dir=OUTPUT_DIR,
        file_extension=FILE_EXTENSION
    )
    
    print("\n✅ Done! Open the visualization PNG files to inspect your dataset.")


if __name__ == "__main__":
    main()
