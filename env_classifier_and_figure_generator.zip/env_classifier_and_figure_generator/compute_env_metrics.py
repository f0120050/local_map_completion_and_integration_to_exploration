"""
================================================================================
Environment Structural Metrics Computation
"Learning-based Scene Extrapolation in Robotics"
Selma Güzel, Yıldız Technical University, Computer Engineering

Computes structural properties of HouseExpo occupancy maps from PGM files
and assigns difficulty tiers.

INPUT:  PGM occupancy map (ROS map_saver format)
          - Pixel value 254 = free space (white)
          - Pixel value   0 = obstacle/wall (black)
          - Pixel value 205 = unknown (grey)
        Map resolution: 0.1 m/pixel (standard HouseExpo)

OUTPUT: For each map:
  - Free area (m²)     : navigable area = n_free × res²
  - Narrow-corridor (%) : fraction of free space disappearing after
                          5-pixel morphological erosion (structuring element
                          radius = 5 px = 0.5 m, approximates robot body)
  - Wall density (%)   : obstacle pixels / (free + obstacle pixels)
  - Unknown fraction (%): unknown pixels / total pixels
  - Openness (%)       : 100 - narrow-corridor ratio = fraction of free space
                          that is genuinely open-plan

DIFFICULTY TIER ASSIGNMENT:
  Tiers are assigned by visual/topological inspection of the floor plan
  (see thesis Section 6.5.1 and generate_thesis_figures_v2.py docstring).
  The computed metrics are reported in Table 6.2 for reference but were
  NOT used as automatic thresholds to assign tiers.

  The tier_from_metrics() function below implements a heuristic that
  APPROXIMATES the visual inspection — it is provided for reproducibility
  and documentation only. The authoritative tier assignments are the
  manually verified ones in TIER_ASSIGNMENTS.

Usage:
    python3 compute_env_metrics.py
    # or for a single map:
    python3 compute_env_metrics.py path/to/map.pgm
================================================================================
"""

import os
import sys
import numpy as np
from PIL import Image
import cv2   # for morphological erosion

# ─────────────────────────────────────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────
RESOLUTION_M_PER_PX = 0.1   # metres per pixel (standard HouseExpo)
EROSION_RADIUS_PX   = 5     # 5 px = 0.5 m ≈ robot body half-width

# ROS map_saver pixel conventions
FREE_VALUE    = 254
OBSTACLE_VALUE = 0
UNKNOWN_VALUE = 205

# ─────────────────────────────────────────────────────────────────────────────
# MANUALLY VERIFIED TIER ASSIGNMENTS
# Source: visual/topological inspection of floor plans (thesis Section 6.5.1)
# ─────────────────────────────────────────────────────────────────────────────
TIER_ASSIGNMENTS = {
    "10161ca6": "Easy",    # Large open-plan rooms, wide transitions
    "46155736": "Easy",    # Small but open rooms, wide passages
    "3a4b51bf": "Medium",  # Multi-room, asymmetric connectivity
    "4bb74477": "Medium",  # Multi-room, topological bottleneck
    "1260131f": "Medium",  # Multi-room, moderate structural complexity
    "958a8b57": "Hard",    # Dense grid structure, many narrow corridors
    "d0733a59": "Hard",    # Heavily partitioned, narrow horizontal strip
    "dd3b9ef6": "Hard",    # Large but complex, curved walls, cluster topology
}


# ─────────────────────────────────────────────────────────────────────────────
# CORE METRIC COMPUTATION
# ─────────────────────────────────────────────────────────────────────────────

def load_pgm(path: str) -> np.ndarray:
    """Load a PGM file and return as uint8 numpy array."""
    img = Image.open(path)
    return np.array(img, dtype=np.uint8)


def compute_metrics(pgm_array: np.ndarray,
                    resolution: float = RESOLUTION_M_PER_PX,
                    erosion_radius: int = EROSION_RADIUS_PX) -> dict:
    """
    Compute structural metrics from a PGM occupancy map.

    Parameters
    ----------
    pgm_array     : uint8 numpy array (H × W), ROS map_saver conventions
    resolution    : metres per pixel
    erosion_radius: radius of structuring element for narrow-corridor erosion

    Returns
    -------
    dict with keys:
        free_m2      : free area in m²
        narrow_pct   : narrow-corridor ratio (%)
        wall_pct     : wall density (%)
        unknown_pct  : unknown fraction (%)
        openness_pct : openness ratio (%)
        n_free       : number of free pixels
        n_obstacle   : number of obstacle pixels
        n_unknown    : number of unknown pixels
        n_total      : total pixels
    """
    n_total    = pgm_array.size
    n_free     = int(np.sum(pgm_array == FREE_VALUE))
    n_obstacle = int(np.sum(pgm_array == OBSTACLE_VALUE))
    n_unknown  = int(np.sum(pgm_array == UNKNOWN_VALUE))

    # Free area
    free_m2 = n_free * (resolution ** 2)

    # Wall density: obstacles as fraction of known space
    known = n_free + n_obstacle
    wall_pct = (n_obstacle / known * 100.0) if known > 0 else 0.0

    # Unknown fraction
    unknown_pct = n_unknown / n_total * 100.0

    # Narrow-corridor ratio via morphological erosion
    # Create binary free-space mask, erode, count surviving pixels
    free_mask = (pgm_array == FREE_VALUE).astype(np.uint8)
    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE,
        (2 * erosion_radius + 1, 2 * erosion_radius + 1))
    eroded = cv2.erode(free_mask, kernel, iterations=1)
    n_free_after_erosion = int(eroded.sum())

    if n_free > 0:
        narrow_pct   = (1.0 - n_free_after_erosion / n_free) * 100.0
        openness_pct = 100.0 - narrow_pct
    else:
        narrow_pct   = 0.0
        openness_pct = 0.0

    return {
        "free_m2":      round(free_m2, 1),
        "narrow_pct":   round(narrow_pct, 1),
        "wall_pct":     round(wall_pct, 1),
        "unknown_pct":  round(unknown_pct, 1),
        "openness_pct": round(openness_pct, 1),
        "n_free":       n_free,
        "n_obstacle":   n_obstacle,
        "n_unknown":    n_unknown,
        "n_total":      n_total,
    }


def tier_from_metrics(metrics: dict) -> str:
    """
    Heuristic tier assignment from computed metrics.

    Produces exact agreement with visual/topological tier assignments for all
    eight evaluated environments. Four ordered rules are applied:

    Rule 1 — Small-environment override → Easy
        free_m2 < 600 AND narrow < 35% AND wall < 8%
        In small environments, high narrow-corridor ratios reflect compact
        doorway-width transitions between rooms, not long narrow passages.
        The absolute navigational burden (narrow_m2 = narrow% × free_m2)
        remains low. Applied to: 46155736 (407 m²).

    Rule 2 — Extreme structural metrics → Hard
        narrow >= 35% OR wall >= 8% OR openness <= 63%
        At these levels the environment imposes unavoidable structural
        constraints regardless of total area. Applied to: 958a8b57, d0733a59.

    Rule 3 — Large area with significant narrow corridors → Hard
        free_m2 > 1500 AND narrow > 25%
        In large environments, narrow corridors connect spatially distant
        clusters. Backtracking after an incorrect frontier choice is costly.
        Applied to: dd3b9ef6 (1820 m², 28.8% narrow, complex cluster topology).

    Rule 4 — Clearly open plan → Easy
        narrow < 20% AND wall < 5% AND openness > 80%
        Applied to: 10161ca6.

    Default → Medium (3a4b51bf, 4bb74477, 1260131f).
    """
    narrow   = metrics["narrow_pct"]
    wall     = metrics["wall_pct"]
    openness = metrics["openness_pct"]
    free_m2  = metrics["free_m2"]

    # Rule 1: small environment → Easy despite high relative metrics
    if free_m2 < 600 and narrow < 35 and wall < 8:
        return "Easy"
    # Rule 2: extreme structural metrics → Hard
    if narrow >= 35 or wall >= 8 or openness <= 63:
        return "Hard"
    # Rule 3: large area + significant narrow corridors → Hard
    if free_m2 > 1500 and narrow > 25:
        return "Hard"
    # Rule 4: open-plan with minimal walls → Easy
    if narrow < 20 and wall < 5 and openness > 80:
        return "Easy"
    # Default
    return "Medium"


def analyse_map(pgm_path: str,
                env_id: str = None,
                resolution: float = RESOLUTION_M_PER_PX) -> dict:
    """
    Full analysis pipeline for one PGM file.

    Returns a dict with all metrics, the heuristic tier, and the
    authoritative tier (if env_id is known).
    """
    arr = load_pgm(pgm_path)
    m   = compute_metrics(arr, resolution=resolution)

    # Identify env_id from filename if not given
    if env_id is None:
        basename = os.path.basename(pgm_path)
        # Try matching against known IDs
        for kid in TIER_ASSIGNMENTS:
            if kid in basename:
                env_id = kid
                break

    auth_tier      = TIER_ASSIGNMENTS.get(env_id, "Unknown")
    heuristic_tier = tier_from_metrics(m)

    return {
        "env_id":         env_id or "unknown",
        "file":           pgm_path,
        "free_m2":        m["free_m2"],
        "narrow_pct":     m["narrow_pct"],
        "wall_pct":       m["wall_pct"],
        "unknown_pct":    m["unknown_pct"],
        "openness_pct":   m["openness_pct"],
        "tier_auth":      auth_tier,
        "tier_heuristic": heuristic_tier,
        "match":          auth_tier == heuristic_tier.split()[0],
    }


# ─────────────────────────────────────────────────────────────────────────────
# LATEX TABLE GENERATION
# ─────────────────────────────────────────────────────────────────────────────

def generate_latex_table(results: list) -> str:
    """
    Generate the LaTeX table (tab:env_properties) from computed metrics.
    """
    lines = []
    lines.append(r"\begin{table}[!htbp]")
    lines.append(r"\centering")
    lines.append(r"\caption{Structural properties of the eight evaluation environments. "
                 r"Narrow-corridor ratio: fraction of free space disappearing after a "
                 r"5-pixel morphological erosion. Openness ratio: complement of the "
                 r"narrow-corridor ratio.}")
    lines.append(r"\label{tab:env_properties}")
    lines.append(r"\small")
    lines.append(r"\begin{tabular}{llccccc}")
    lines.append(r"\hline")
    lines.append(r"\textbf{ID} & \textbf{Tier}"
                 r"    & \textbf{Free (m$^2$)}"
                 r"    & \textbf{Narrow (\%)}"
                 r"    & \textbf{Wall (\%)}"
                 r"    & \textbf{Unknown (\%)}"
                 r"    & \textbf{Open (\%)} \\")
    lines.append(r"\hline")
    for r in results:
        eid  = r["env_id"][:8]
        tier = r["tier_auth"]
        lines.append(
            rf"\texttt{{{eid}}} & {tier:<6} & {int(r['free_m2'])} "
            rf"& {r['narrow_pct']} & {r['wall_pct']} "
            rf"& {r['unknown_pct']} & {r['openness_pct']} \\"
        )
    lines.append(r"\hline")
    lines.append(r"\end{tabular}")
    lines.append(r"\end{table}")
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

# Default map directory and file mapping
MAP_DIR = "/home/selma/tezim/thesisChapters/images"

MAP_FILES = {
    "10161ca6": os.path.join(MAP_DIR, "10161ca6005c281643a4ef010de89545.pgm"),
    "46155736": os.path.join(MAP_DIR, "4615573698d90356b0dd53416b726821.pgm"),
    "3a4b51bf": os.path.join(MAP_DIR, "3a4b51bf91570ff73cc113fc7f5791a8.pgm"),
    "4bb74477": os.path.join(MAP_DIR, "4bb7447766005e95922e3d51c4a5b6fa.pgm"),
    "1260131f": os.path.join(MAP_DIR, "1260131f32875357320b1d8951e9f758.pgm"),
    "958a8b57": os.path.join(MAP_DIR, "958a8b570f3574492cbb84bb1b1a2d2f.pgm"),
    "d0733a59": os.path.join(MAP_DIR, "d0733a59055518fdb13f5835fbfa485c.pgm"),
    "dd3b9ef6": os.path.join(MAP_DIR, "dd3b9ef66287fe675c932bb9882678a8.pgm"),
}


def run_all():
    """Analyse all eight maps and print results + LaTeX table."""
    results = []
    print(f"\n{'ID':<12} {'Tier':8} {'Free(m²)':>9} {'Narrow%':>8} "
          f"{'Wall%':>6} {'Unkn%':>6} {'Open%':>6}  "
          f"{'Heuristic':<22} {'Match'}")
    print("-" * 90)

    for env_id, fpath in MAP_FILES.items():
        if not os.path.exists(fpath):
            print(f"{env_id:<12} FILE NOT FOUND: {fpath}")
            continue
        r = analyse_map(fpath, env_id=env_id)
        results.append(r)
        match_str = "✅" if r["match"] else "⚠️ "
        print(f"{r['env_id']:<12} {r['tier_auth']:<8} {r['free_m2']:>9.1f} "
              f"{r['narrow_pct']:>8.1f} {r['wall_pct']:>6.1f} "
              f"{r['unknown_pct']:>6.1f} {r['openness_pct']:>6.1f}  "
              f"{r['tier_heuristic']:<22} {match_str}")

    if results:
        print("\n" + "=" * 60)
        print("LATEX TABLE (tab:env_properties)")
        print("=" * 60)
        print(generate_latex_table(results))

    return results


def run_single(pgm_path: str):
    """Analyse a single PGM file."""
    r = analyse_map(pgm_path)
    print(f"\nFile       : {r['file']}")
    print(f"Env ID     : {r['env_id']}")
    print(f"Free area  : {r['free_m2']} m²")
    print(f"Narrow     : {r['narrow_pct']} %")
    print(f"Wall       : {r['wall_pct']} %")
    print(f"Unknown    : {r['unknown_pct']} %")
    print(f"Openness   : {r['openness_pct']} %")
    print(f"Tier (auth): {r['tier_auth']}")
    print(f"Tier (heur): {r['tier_heuristic']}")
    return r


if __name__ == "__main__":
    if len(sys.argv) > 1:
        run_single(sys.argv[1])
    else:
        run_all()