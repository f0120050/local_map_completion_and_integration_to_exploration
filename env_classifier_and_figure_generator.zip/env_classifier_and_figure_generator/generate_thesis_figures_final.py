"""
================================================================================
Thesis Figure Generation Script — FINAL
"Learning-based Scene Extrapolation in Robotics"
Selma Güzel, Yıldız Technical University, Computer Engineering

This script imports compute_env_metrics.py to obtain structural metrics
directly from the PGM map files. All figures are generated from these
computed values — no hardcoded metric numbers.

Usage:
    python3 generate_thesis_figures_final.py

Requirements:
    - compute_env_metrics.py in the same directory
    - PGM and PNG map files in MAP_DIR
    - pip install matplotlib pillow numpy opencv-python-headless
================================================================================
"""

import os, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from PIL import Image

# ─────────────────────────────────────────────────────────────────────────────
# DIRECTORIES — adjust to your system
# ─────────────────────────────────────────────────────────────────────────────
SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
MAP_DIR     = "/home/selma/tezim/thesisChapters/images"
OUTPUT_DIR  = "/home/selma/tezim/thesisChapters/images"

os.makedirs(OUTPUT_DIR, exist_ok=True)
sys.path.insert(0, SCRIPT_DIR)

# ─────────────────────────────────────────────────────────────────────────────
# STEP 1: Compute structural metrics from PGM files via compute_env_metrics.py
# ─────────────────────────────────────────────────────────────────────────────
import compute_env_metrics as cem

# Map files — order defines display order in all figures
MAP_FILES_ORDERED = [
    ("10161ca6", os.path.join(MAP_DIR, "10161ca6005c281643a4ef010de89545.pgm")),
    ("46155736", os.path.join(MAP_DIR, "4615573698d90356b0dd53416b726821.pgm")),
    ("3a4b51bf", os.path.join(MAP_DIR, "3a4b51bf91570ff73cc113fc7f5791a8.pgm")),
    ("4bb74477", os.path.join(MAP_DIR, "4bb7447766005e95922e3d51c4a5b6fa.pgm")),
    ("1260131f", os.path.join(MAP_DIR, "1260131f32875357320b1d8951e9f758.pgm")),
    ("958a8b57", os.path.join(MAP_DIR, "958a8b570f3574492cbb84bb1b1a2d2f.pgm")),
    ("d0733a59", os.path.join(MAP_DIR, "d0733a59055518fdb13f5835fbfa485c.pgm")),
    ("dd3b9ef6", os.path.join(MAP_DIR, "dd3b9ef66287fe675c932bb9882678a8.pgm")),
]

# Display label (short form used in figures)
DISPLAY_LABELS = {
    "10161ca6": "10161ca6",
    "46155736": "46155736",
    "3a4b51bf": "3a4b51bf",
    "4bb74477": "4bb74477",
    "1260131f": "12601317",
    "958a8b57": "958a8b57",
    "d0733a59": "d0733a59",
    "dd3b9ef6": "dd3b9ef6",
}

print("Computing structural metrics from PGM files...")
computed = {}
for eid, fpath in MAP_FILES_ORDERED:
    r = cem.analyse_map(fpath, env_id=eid)
    computed[eid] = r
    print(f"  {eid}: free={r['free_m2']}m² narrow={r['narrow_pct']}% "
          f"wall={r['wall_pct']}% unknown={r['unknown_pct']}% "
          f"open={r['openness_pct']}% → {r['tier_auth']}")

# Build ENVIRONMENTS tuple list from computed metrics
# (eid, display_label, tier, free_m2, narrow%, wall%, unknown%, openness%)
ENVIRONMENTS = [
    (eid,
     DISPLAY_LABELS[eid],
     computed[eid]["tier_auth"],
     int(computed[eid]["free_m2"]),
     computed[eid]["narrow_pct"],
     computed[eid]["wall_pct"],
     computed[eid]["unknown_pct"],
     computed[eid]["openness_pct"])
    for eid, _ in MAP_FILES_ORDERED
]

ENV_IDS    = [e[0] for e in ENVIRONMENTS]
ENV_LABELS = [e[1] for e in ENVIRONMENTS]
ENV_TIERS  = [e[2] for e in ENVIRONMENTS]
TIER_COLOR = {"Easy": "#2ca02c", "Medium": "#ff7f0e", "Hard": "#d62728"}
ROW_LABELS = [f"{ENV_LABELS[i][:8]}\n({ENV_TIERS[i]})" for i in range(len(ENVIRONMENTS))]

print(f"\nEnvironments loaded: {len(ENVIRONMENTS)}")
print("─" * 60)

# ─────────────────────────────────────────────────────────────────────────────
# STEP 2: Experimental data — 3-run averages (seconds / metres)
# These come from the robot exploration experiments, not from the maps.
# ─────────────────────────────────────────────────────────────────────────────
MILESTONES = ["70%", "75%", "80%", "85%", "90%", "95%", "Max"]

MC_TIMES = {
    "10161ca6": [ 628.3,  668.3,  805.0,  943.3, 1153.3, 1181.7, 1288.3],
    "46155736": [ 113.3,  236.7,  351.7,  353.3,  361.7,  390.0,  691.7],
    "3a4b51bf": [ 808.3,  818.3,  860.0, 1110.0, 1123.3, 1156.7, 1470.0],
    "4bb74477": [ 828.3,  976.7, 1125.0, 1216.7, 1268.3, 1360.0, 1633.3],
    "1260131f": [ 475.0,  541.7,  615.0,  631.7,  696.7,  793.3, 1076.7],
    "958a8b57": [ 940.0, 1001.7, 1123.3, 1438.3, 1501.7, 1540.0, 1928.3],
    "d0733a59": [ 990.0, 1165.0, 1275.0, 1301.7, 1411.7, 1581.7, 1678.3],
    "dd3b9ef6": [1450.0, 1581.7, 1763.3, 2036.7, 2201.7, 2291.7, 2796.7],
}
BASE_TIMES = {
    "10161ca6": [ 726.7,  760.0,  810.0,  956.7,  996.7, 1238.3, 1340.0],
    "46155736": [ 115.0,  345.0,  555.0,  563.3,  573.3,  611.7,  738.3],
    "3a4b51bf": [ 908.3,  921.7, 1013.3, 1075.0, 1086.7, 1211.7, 1493.3],
    "4bb74477": [ 695.0,  788.3, 1056.7, 1161.7, 1240.0, 1385.0, 1431.7],
    "1260131f": [ 633.3,  656.7,  670.0,  681.7,  753.3,  943.3, 1026.7],
    "958a8b57": [1020.0, 1106.7, 1390.0, 1458.3, 1535.0, 1583.3, 1733.3],
    "d0733a59": [1086.7, 1228.3, 1285.0, 1376.7, 1513.3, 1673.3, 1781.7],
    "dd3b9ef6": [1663.3, 1945.0, 2045.0, 2203.3, 2298.3, 2845.0, 2975.0],
}
MC_DIST = {
    "10161ca6": [127.10,135.22,163.83,192.63,236.21,242.46,264.65],
    "46155736": [ 20.79, 43.07, 67.19, 67.41, 69.00, 74.54,134.01],
    "3a4b51bf": [166.00,167.99,176.48,227.86,230.61,237.93,302.65],
    "4bb74477": [158.23,188.69,217.63,236.48,246.55,264.53,315.94],
    "1260131f": [ 95.14,107.75,123.33,126.59,139.07,158.68,217.42],
    "958a8b57": [189.79,202.65,227.71,292.40,304.30,312.14,389.66],
    "d0733a59": [192.22,228.16,250.39,255.82,277.56,311.98,331.81],
    "dd3b9ef6": [282.40,306.29,339.38,391.15,421.70,433.50,538.59],
}
BASE_DIST = {
    "10161ca6": [148.00,154.92,165.42,195.21,203.46,252.91,272.68],
    "46155736": [ 19.88, 61.22,102.68,103.91,105.43,112.78,136.46],
    "3a4b51bf": [184.71,187.53,206.50,218.99,221.33,247.67,296.83],
    "4bb74477": [136.15,154.52,209.34,223.07,238.36,268.00,276.75],
    "1260131f": [128.10,132.75,135.57,138.05,152.04,188.35,204.64],
    "958a8b57": [196.99,213.93,273.32,286.40,301.81,311.51,339.84],
    "d0733a59": [213.59,242.77,253.19,270.66,298.05,330.11,350.54],
    "dd3b9ef6": [282.51,337.10,354.58,384.21,404.06,509.73,535.35],
}

ADVANTAGE = np.array([
    [(BASE_TIMES[e][j]-MC_TIMES[e][j])/BASE_TIMES[e][j]*100
     for j in range(len(MILESTONES))] for e in ENV_IDS])

SIG_LABELS = ["**","**","**","*","ns","***","ns"]
CELL_SIG = {
    "10161ca6": [ 1,  1,  0,  0,  0,  0,  0],
    "46155736": [ 0,  2,  3,  3,  3,  3,  2],
    "3a4b51bf": [ 1,  1,  2, -1, -2,  2,  0],
    "4bb74477": [ 0,  0,  0,  0,  0,  0,  0],
    "1260131f": [ 2,  2,  2,  1,  2,  3, -1],
    "958a8b57": [ 3,  3,  3,  3,  2,  2, -2],
    "d0733a59": [ 0,  0,  0,  0,  0,  0,  0],
    "dd3b9ef6": [ 0,  0,  0,  0,  0,  0,  0],
}

def mc_wins(eid):
    return sum(1 for j in range(len(MILESTONES))
               if MC_TIMES[eid][j] < BASE_TIMES[eid][j])


# ─────────────────────────────────────────────────────────────────────────────
# STEP 3: Generate figures
# ─────────────────────────────────────────────────────────────────────────────

def save(name):
    for ext in ("pdf","png"):
        plt.savefig(os.path.join(OUTPUT_DIR, f"{name}.{ext}"),
                    bbox_inches='tight', dpi=150)
    plt.close()
    print(f"  {name} saved")


# FIG 1 — Heatmap
fig,ax=plt.subplots(figsize=(13,6.5))
im=ax.imshow(ADVANTAGE,cmap='RdYlGn',vmin=-40,vmax=40,aspect='auto')
ax.set_xticks(range(len(MILESTONES)));ax.set_xticklabels(MILESTONES,fontsize=12)
ax.set_yticks(range(len(ROW_LABELS)));ax.set_yticklabels(ROW_LABELS,fontsize=11)
ax.set_xlabel("Coverage Milestone",fontsize=12)
for i in range(ADVANTAGE.shape[0]):
    for j in range(ADVANTAGE.shape[1]):
        v=ADVANTAGE[i,j];txt=f"+{v:.1f}%" if v>=0 else f"{v:.1f}%"
        ax.text(j,i,txt,ha='center',va='center',fontsize=10,fontweight='bold',
                color='white' if abs(v)>20 else 'black')
plt.colorbar(im,ax=ax,label="MC Advantage (%)")
ax.set_title("MC Time Advantage (%) — Environment × Milestone\n"
             "(Green = MC faster,  Red = Baseline faster)",fontsize=13,fontweight='bold')
plt.tight_layout(); save("fig1_heatmap_avantaj")

# FIG 2 — Bar chart
n=len(MILESTONES)
mc_m=[np.mean([MC_TIMES[e][j] for e in ENV_IDS]) for j in range(n)]
bl_m=[np.mean([BASE_TIMES[e][j] for e in ENV_IDS]) for j in range(n)]
mc_s=[np.std([MC_TIMES[e][j] for e in ENV_IDS]) for j in range(n)]
bl_s=[np.std([BASE_TIMES[e][j] for e in ENV_IDS]) for j in range(n)]
x=np.arange(n);w=0.35
fig,ax=plt.subplots(figsize=(12,6))
ax.bar(x-w/2,mc_m,w,label="MC (use1_with1)",color="#4878cf",alpha=0.88)
ax.bar(x+w/2,bl_m,w,label="Baseline (use0_with0)",color="#d65f5f",alpha=0.88)
ax.errorbar(x-w/2,mc_m,yerr=mc_s,fmt='none',color='black',capsize=5)
ax.errorbar(x+w/2,bl_m,yerr=bl_s,fmt='none',color='black',capsize=5)
for j,sig in enumerate(SIG_LABELS):
    ymax=max(mc_m[j]+mc_s[j],bl_m[j]+bl_s[j])+30
    ax.text(x[j],ymax,sig,ha='center',va='bottom',fontsize=13,fontweight='bold',
            color='dimgray' if sig=='ns' else 'black')
ax.set_xticks(x);ax.set_xticklabels(MILESTONES,fontsize=12)
ax.set_xlabel("Coverage Milestone",fontsize=12)
ax.set_ylabel("Average Exploration Time (s)",fontsize=12)
ax.set_title("Average Exploration Time by Milestone — 8 Environments\n"
             "(Error bars: ±1 std,  * p<0.05,  ** p<0.01,  *** p<0.001,  ns: not significant)",
             fontsize=12,fontweight='bold')
ax.legend(fontsize=11);ax.grid(axis='y',linestyle='--',alpha=0.4)
plt.tight_layout(); save("fig2_bar_milestone_sure")

# FIG 3 & 4 — Per-environment line plots
for metric in ("time","dist"):
    mc_d=MC_TIMES if metric=="time" else MC_DIST
    bl_d=BASE_TIMES if metric=="time" else BASE_DIST
    ylabel="Time (s)" if metric=="time" else "Distance (m)"
    fname=f"fig{'3' if metric=='time' else '4'}_lines_per_ortam_{'sure' if metric=='time' else 'mesafe'}"
    title=("Coverage Milestone vs. Exploration Time — Per Environment\n(Blue=MC, Red=BL)"
           if metric=="time" else
           "Coverage Milestone vs. Distance Travelled — Per Environment\n(Blue=MC, Red=BL)")
    xp=np.arange(len(MILESTONES))
    fig,axes=plt.subplots(2,4,figsize=(22,10))
    fig.suptitle(title,fontsize=14,fontweight='bold')
    for idx,eid in enumerate(ENV_IDS):
        ax=axes[idx//4][idx%4];color=TIER_COLOR[ENV_TIERS[idx]]
        mc=np.array(mc_d[eid]);bl=np.array(bl_d[eid])
        ax.plot(xp,mc,'o-',color='#4878cf',linewidth=2,label='MC')
        ax.plot(xp,bl,'s--',color='#c44e52',linewidth=2,label='BL')
        ax.fill_between(xp,mc,bl,where=mc<=bl,alpha=0.18,color='#4878cf',interpolate=True)
        ax.fill_between(xp,mc,bl,where=mc>bl, alpha=0.18,color='#c44e52',interpolate=True)
        ax.set_xticks(xp);ax.set_xticklabels(MILESTONES,fontsize=8)
        ax.set_ylabel(ylabel,fontsize=9);ax.grid(linestyle='--',alpha=0.4)
        ax.set_title(f"{ENV_LABELS[idx][:8]}...\n[{ENV_TIERS[idx]}]",
                     color=color,fontsize=10,fontweight='bold')
        if metric=="time":
            ax.text(0.97,0.04,f"MC {mc_wins(eid)}/7",transform=ax.transAxes,
                    ha='right',va='bottom',fontsize=10,fontweight='bold',color='#4878cf')
        if idx==0: ax.legend(fontsize=8,loc='upper left')
    plt.tight_layout(rect=[0,0,1,0.95]); save(fname)

# FIG 5 — Scatter: difficulty TIER (ordinal) vs MC advantage
# X-axis: ordinal tier score matching the four-rule heuristic tier assignment
#   Easy=0.0, Medium=0.5, Hard=1.0
# Small per-environment jitter separates overlapping points within the same tier.
# No trendline — relationship is non-monotonic.
TIER_SCORE = {"Easy": 0.0, "Medium": 0.5, "Hard": 1.0}
JITTER = {
    "10161ca6":  0.00, "46155736":  0.04,
    "3a4b51bf": -0.03, "4bb74477":  0.03,
    "1260131f":  0.00, "958a8b57": -0.04,
    "d0733a59":  0.04, "dd3b9ef6":  0.00,
}
x_vals = np.array([TIER_SCORE[ENV_TIERS[i]] + JITTER[ENV_IDS[i]]
                   for i in range(len(ENVIRONMENTS))])
mc_avg_adv=ADVANTAGE.mean(axis=1)
fig,ax=plt.subplots(figsize=(9,6.5))
for i,eid in enumerate(ENV_IDS):
    color=TIER_COLOR[ENV_TIERS[i]]
    ax.scatter(x_vals[i],mc_avg_adv[i],color=color,s=200,zorder=3)
    ax.annotate(f"{ENV_LABELS[i][:8]}...",(x_vals[i],mc_avg_adv[i]),
                textcoords="offset points",xytext=(6,4),fontsize=9)

ax.axhline(0,color='black',linewidth=0.9,linestyle=':')
ax.set_xticks([0.0, 0.5, 1.0])
ax.set_xticklabels(["Easy", "Medium", "Hard"], fontsize=12)
ax.set_xlabel("Difficulty Tier",fontsize=12)
ax.set_ylabel("Average MC Advantage (%)",fontsize=12)
ax.set_title("Difficulty Tier vs. MC Performance Advantage\n"
             "(Average across all milestones)",fontsize=12,fontweight='bold')
ax.set_xlim(-0.2, 1.2)
patches=[mpatches.Patch(color=TIER_COLOR[t],label=t) for t in("Easy","Medium","Hard")]
ax.legend(handles=patches,loc='upper right',fontsize=11)
ax.grid(linestyle='--',alpha=0.35)
plt.tight_layout(); save("fig5_scatter_zorluk_avantaj")

# FIG 6 — p-value heatmap
mat=np.array([CELL_SIG[e] for e in ENV_IDS],dtype=float)
cmap=matplotlib.colors.LinearSegmentedColormap.from_list(
    "sig",[(0.7,0.05,0.05),(0.95,0.5,0.5),(0.85,0.85,0.85),
           (0.6,0.9,0.6),(0.0,0.6,0.2),(0.0,0.35,0.1)],N=256)
fig,ax=plt.subplots(figsize=(13,7))
ax.imshow(mat,cmap=cmap,vmin=-2.5,vmax=3.5,aspect='auto')
ax.set_xticks(range(len(MILESTONES)));ax.set_xticklabels(MILESTONES,fontsize=12)
ax.set_yticks(range(len(ROW_LABELS)));ax.set_yticklabels(ROW_LABELS,fontsize=11)
ax.set_xlabel("Coverage Milestone",fontsize=12)
SIG_TEXT={3:"p<.001",2:"p<.01",1:"p<.05",0:"ns",-1:"p<.05",-2:"p<.01"}
for i,eid in enumerate(ENV_IDS):
    for j in range(len(MILESTONES)):
        v=CELL_SIG[eid][j];fc='white' if abs(v)>=2 else 'black'
        ax.text(j,i,SIG_TEXT[v],ha='center',va='center',fontsize=9,
                fontweight='bold' if v!=0 else 'normal',color=fc)
ax.set_title("Statistical Significance Map (Paired t-test, n=3)\n"
             "Green = MC significantly better  |  Red = BL significantly better  "
             "|  Grey = Not significant",fontsize=11,fontweight='bold')
legend_items=[
    mpatches.Patch(color='#005c18',label='MC p<0.001'),
    mpatches.Patch(color='#2ca02c',label='MC p<0.01'),
    mpatches.Patch(color='#98df8a',label='MC p<0.05'),
    mpatches.Patch(color='#d9d9d9',label='Not significant (p≥0.05)'),
    mpatches.Patch(color='#f4a582',label='BL p<0.05'),
    mpatches.Patch(color='#a50026',label='BL p<0.01'),
]
ax.legend(handles=legend_items,loc='lower right',fontsize=9,
          bbox_to_anchor=(1.0,-0.02),ncol=3)
plt.tight_layout(); save("fig6_pvalue_heatmap")

# FIG 7 — Radar charts
axes_labels=["Narrow\nCorridor%","Wall\n%","Unknown\n%","Area\n(norm)","Openness\n%"]
N=len(axes_labels);angles=[n/float(N)*2*np.pi for n in range(N)]+[0]
# Use computed values from ENVIRONMENTS
raw=np.array([[e[4],e[5],e[6],e[3],e[7]] for e in ENVIRONMENTS],dtype=float)
mn=raw.min(axis=0);mx=raw.max(axis=0)
norm_raw=np.where(mx>mn,(raw-mn)/(mx-mn),0.0)
fig=plt.figure(figsize=(18,10))
fig.suptitle("Environment Structural Profile — Radar Charts\n"
             "(Normalised, 0 = minimum, 1 = maximum across environments)",
             fontsize=13,fontweight='bold',y=1.01)
for idx,eid in enumerate(ENV_IDS):
    ax=fig.add_subplot(2,4,idx+1,polar=True)
    vals=list(norm_raw[idx])+[norm_raw[idx][0]]
    color=TIER_COLOR[ENV_TIERS[idx]]
    ax.plot(angles,vals,color=color,linewidth=2)
    ax.fill(angles,vals,color=color,alpha=0.25)
    ax.set_xticks(angles[:-1]);ax.set_xticklabels(axes_labels,fontsize=8)
    ax.set_yticklabels([]);ax.set_ylim(0,1)
    ax.set_title(f"{ENV_LABELS[idx][:8]}...\n[{ENV_TIERS[idx]}] MC:{mc_wins(eid)}/7",
                 color=color,fontsize=9,fontweight='bold',pad=12)
patches=[mpatches.Patch(color=TIER_COLOR[t],label=t) for t in("Easy","Medium","Hard")]
fig.legend(handles=patches,loc='lower center',ncol=3,fontsize=11,bbox_to_anchor=(0.5,-0.02))
plt.tight_layout(); save("fig7_radar_ortam_profil")

# ENV MAPS
MAP_PNG = {
    "10161ca6": os.path.join(MAP_DIR,"map_10161ca6005c281643a4ef010de89545.png"),
    "46155736": os.path.join(MAP_DIR,"map_4615573698d90356b0dd53416b726821.png"),
    "3a4b51bf": os.path.join(MAP_DIR,"map_3a4b51bf91570ff73cc113fc7f5791a8.png"),
    "4bb74477": os.path.join(MAP_DIR,"map_4bb7447766005e95922e3d51c4a5b6fa.png"),
    "1260131f": os.path.join(MAP_DIR,"map_1260131f32875357320b1d8951e9f758.png"),
    "958a8b57": os.path.join(MAP_DIR,"map_958a8b570f3574492cbb84bb1b1a2d2f.png"),
    "d0733a59": os.path.join(MAP_DIR,"map_d0733a59055518fdb13f5835fbfa485c.png"),
    "dd3b9ef6": os.path.join(MAP_DIR,"map_dd3b9ef66287fe675c932bb9882678a8.png"),
}
fig,axes=plt.subplots(2,4,figsize=(22,11))
fig.suptitle("Ground-Truth Occupancy Maps of the Eight Evaluation Environments\n"
             "(Black = wall/obstacle,  White = free space,  Grey = unknown)",
             fontsize=13,fontweight='bold',y=1.01)
for idx,eid in enumerate(ENV_IDS):
    ax=axes[idx//4][idx%4];color=TIER_COLOR[ENV_TIERS[idx]]
    ax.imshow(np.array(Image.open(MAP_PNG[eid])));ax.axis('off')
    ax.set_title(f"{ENV_LABELS[idx][:8]}...\n[{ENV_TIERS[idx]}]",
                 color=color,fontsize=12,fontweight='bold',pad=6)
plt.tight_layout(pad=1.5); save("env_maps_8")

# Also print the LaTeX table with computed values
print("\n" + "="*60)
print("LaTeX table (tab:env_properties) — from computed metrics:")
print("="*60)
results = [computed[eid] for eid in ENV_IDS]
print(cem.generate_latex_table(results))
print("\nDone.")
