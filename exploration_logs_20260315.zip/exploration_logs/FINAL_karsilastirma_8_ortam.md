# Final Karşılaştırma: MC vs Baseline — 8 Ortam

## Özet

| Metrik | Değer |
|--------|-------|
| **Toplam milestone karşılaştırması** | 56 (8 ortam × 7 milestone) |
| **MC kazandığı milestone sayısı** | 45/56 (%80.4) |
| **Ortalama MC hızlanması (süre)** | **%7.2** (tüm ortam ve milestone'lar) |
| **Medyan MC hızlanması** | **%5.9** |
| **MC'nin kazandığı ortam sayısı (çoğunluk)** | 7/8 |

---

## Harita Özellikleri — 8 Ortam Karşılaştırması

| Ortam | Boyut | Serbest (m²) | Dar Koridor (%) | Duvar (%) | Bilinmeyen (%) | Açıklık (%) |
|-------|-------|:------------:|:---------------:|:---------:|:--------------:|:-----------:|
| 10161ca6... | 83.2×51.2 m | 1.781 | 14.5 | 3.6 | 56.6 | 85.5 |
| 46155736... | 44.8×48.0 m | 407 | 28.1 | 7.1 | 79.6 | 71.9 |
| 3a4b51bf... | 64.0×70.4 m | 1.438 | 19.9 | 5.4 | 66.2 | 80.1 |
| 4bb74477... | 76.8×57.6 m | 1.353 | 24.3 | 5.8 | 67.5 | 75.7 |
| 12601317... | 76.8×51.2 m | 1.077 | 20.1 | 5.0 | 71.2 | 79.9 |
| 958a8b57... | 44.8×73.6 m | 1.174 | 36.6 | 7.5 | 61.5 | 63.4 |
| d0733a59... | 76.8×44.8 m | 676 | 41.3 | 10.0 | 78.2 | 58.7 |
| dd3b9ef6... | 96.0×48.0 m | **1.820** | 27.8 | 6.3 | 57.9 | 72.2 |
| **Ortalama** | — | 1.091 | 26.6 | 6.3 | 67.6 | 73.4 |

---

## Milestone Bazında 3-Run Ortalamalar — Tüm Ortamlar

### 70% Kapsam Milestone

| Ortam | MC (s) | BL (s) | Δ (s) | MC Avantajı (%) |
|-------|-------:|-------:|------:|:---------------:|
| 10161... | 628.3 | 726.7 | -98.3 | +13.5% ✅ |
| 4615... | 113.3 | 115.0 | -1.7 | +1.5% ✅ |
| 3a4b... | 808.3 | 908.3 | -100.0 | +11.0% ✅ |
| 4bb7... | 828.3 | 695.0 | +133.3 | -19.2% ❌ |
| 1260... | 475.0 | 633.3 | -158.3 | +25.0% ✅ |
| 958a... | 940.0 | 1020.0 | -80.0 | +7.8% ✅ |
| d073... | 990.0 | 1086.7 | -96.7 | +8.9% ✅ |
| dd3b... | 1450.0 | 1663.3 | -213.3 | +12.8% ✅ |
| **Ort.** | **779.1** | **856.0** | **-76.9** | **+9.0% (7/8)** |

### 75% Kapsam Milestone

| Ortam | MC (s) | BL (s) | Δ (s) | MC Avantajı (%) |
|-------|-------:|-------:|------:|:---------------:|
| 10161... | 668.3 | 760.0 | -91.7 | +12.1% ✅ |
| 4615... | 236.7 | 345.0 | -108.3 | +31.4% ✅ |
| 3a4b... | 818.3 | 921.7 | -103.3 | +11.2% ✅ |
| 4bb7... | 976.7 | 788.3 | +188.3 | -23.9% ❌ |
| 1260... | 541.7 | 656.7 | -115.0 | +17.5% ✅ |
| 958a... | 1001.7 | 1106.7 | -105.0 | +9.5% ✅ |
| d073... | 1165.0 | 1228.3 | -63.3 | +5.2% ✅ |
| dd3b... | 1581.7 | 1945.0 | -363.3 | +18.7% ✅ |
| **Ort.** | **873.8** | **969.0** | **-95.2** | **+9.8% (7/8)** |

### 80% Kapsam Milestone

| Ortam | MC (s) | BL (s) | Δ (s) | MC Avantajı (%) |
|-------|-------:|-------:|------:|:---------------:|
| 10161... | 805.0 | 810.0 | -5.0 | +0.6% ✅ |
| 4615... | 351.7 | 555.0 | -203.3 | +36.6% ✅ |
| 3a4b... | 860.0 | 1013.3 | -153.3 | +15.1% ✅ |
| 4bb7... | 1125.0 | 1056.7 | +68.3 | -6.5% ❌ |
| 1260... | 615.0 | 670.0 | -55.0 | +8.2% ✅ |
| 958a... | 1123.3 | 1390.0 | -266.7 | +19.2% ✅ |
| d073... | 1275.0 | 1285.0 | -10.0 | +0.8% ✅ |
| dd3b... | 1763.3 | 2045.0 | -281.7 | +13.8% ✅ |
| **Ort.** | **989.8** | **1103.1** | **-113.3** | **+10.3% (7/8)** |

### 85% Kapsam Milestone

| Ortam | MC (s) | BL (s) | Δ (s) | MC Avantajı (%) |
|-------|-------:|-------:|------:|:---------------:|
| 10161... | 943.3 | 956.7 | -13.3 | +1.4% ✅ |
| 4615... | 353.3 | 563.3 | -210.0 | +37.3% ✅ |
| 3a4b... | 1110.0 | 1075.0 | +35.0 | -3.3% ❌ |
| 4bb7... | 1216.7 | 1161.7 | +55.0 | -4.7% ❌ |
| 1260... | 631.7 | 681.7 | -50.0 | +7.3% ✅ |
| 958a... | 1438.3 | 1458.3 | -20.0 | +1.4% ✅ |
| d073... | 1301.7 | 1376.7 | -75.0 | +5.4% ✅ |
| dd3b... | 2036.7 | 2203.3 | -166.7 | +7.6% ✅ |
| **Ort.** | **1129.0** | **1184.6** | **-55.6** | **+4.7% (6/8)** |

### 90% Kapsam Milestone

| Ortam | MC (s) | BL (s) | Δ (s) | MC Avantajı (%) |
|-------|-------:|-------:|------:|:---------------:|
| 10161... | 1153.3 | 996.7 | +156.7 | -15.7% ❌ |
| 4615... | 361.7 | 573.3 | -211.7 | +36.9% ✅ |
| 3a4b... | 1123.3 | 1086.7 | +36.7 | -3.4% ❌ |
| 4bb7... | 1268.3 | 1240.0 | +28.3 | -2.3% ❌ |
| 1260... | 696.7 | 753.3 | -56.7 | +7.5% ✅ |
| 958a... | 1501.7 | 1535.0 | -33.3 | +2.2% ✅ |
| d073... | 1411.7 | 1513.3 | -101.7 | +6.7% ✅ |
| dd3b... | 2201.7 | 2298.3 | -96.7 | +4.2% ✅ |
| **Ort.** | **1214.8** | **1249.6** | **-34.8** | **+2.8% (5/8)** |

### 95% Kapsam Milestone

| Ortam | MC (s) | BL (s) | Δ (s) | MC Avantajı (%) |
|-------|-------:|-------:|------:|:---------------:|
| 10161... | 1181.7 | 1238.3 | -56.7 | +4.6% ✅ |
| 4615... | 390.0 | 611.7 | -221.7 | +36.2% ✅ |
| 3a4b... | 1156.7 | 1211.7 | -55.0 | +4.5% ✅ |
| 4bb7... | 1360.0 | 1385.0 | -25.0 | +1.8% ✅ |
| 1260... | 793.3 | 943.3 | -150.0 | +15.9% ✅ |
| 958a... | 1540.0 | 1583.3 | -43.3 | +2.7% ✅ |
| d073... | 1581.7 | 1673.3 | -91.7 | +5.5% ✅ |
| dd3b... | 2291.7 | 2845.0 | -553.3 | +19.4% ✅ |
| **Ort.** | **1286.9** | **1436.4** | **-149.6** | **+10.4% (8/8)** |

### Max Kapsam Milestone

| Ortam | MC (s) | BL (s) | Δ (s) | MC Avantajı (%) |
|-------|-------:|-------:|------:|:---------------:|
| 10161... | 1288.3 | 1340.0 | -51.7 | +3.9% ✅ |
| 4615... | 691.7 | 738.3 | -46.7 | +6.3% ✅ |
| 3a4b... | 1470.0 | 1493.3 | -23.3 | +1.6% ✅ |
| 4bb7... | 1633.3 | 1431.7 | +201.7 | -14.1% ❌ |
| 1260... | 1076.7 | 1026.7 | +50.0 | -4.9% ❌ |
| 958a... | 1928.3 | 1733.3 | +195.0 | -11.3% ❌ |
| d073... | 1678.3 | 1781.7 | -103.3 | +5.8% ✅ |
| dd3b... | 2796.7 | 2975.0 | -178.3 | +6.0% ✅ |
| **Ort.** | **1570.4** | **1565.0** | **+5.4** | **-0.3% (5/8)** |

---

## Özet Tablo — Ortam Bazında MC Performansı

| Ortam | Serbest (m²) | Dar (%) | Açıklık (%) | MC Wins (7 MS) | Ort. Avantaj | Değerlendirme |
|-------|:------------:|:-------:|:-----------:|:--------------:|:------------:|:-------------:|
| 10161... | 1.781 | 14.5 | 85.5 | **6/7** | +3.2% | MC üstün |
| 4615... | 407 | 28.1 | 71.9 | **7/7** | +27.1% | MC çok güçlü |
| 3a4b... | 1.438 | 19.9 | 80.1 | **5/7** | +6.8% | MC üstün |
| 4bb7... | 1.353 | 24.3 | 75.7 | **1/7** | -10.5% | BL üstün ⚠️ |
| 1260... | 1.077 | 20.1 | 79.9 | **6/7** | +11.0% | MC üstün |
| 958a... | 1.174 | 36.6 | 63.4 | **6/7** | +1.8% | MC üstün |
| d073... | 676 | 41.3 | 58.7 | **7/7** | +5.6% | MC güçlü |
| dd3b... | 1.820 | 27.8 | 72.2 | **7/7** | +11.8% | MC güçlü |
| **Toplam** | — | — | — | **45/56 (%80.4)** | **+7.2%** | **MC genel üstün** |

---

## Milestone Bazında Genel Özet (8 Ortam Ortalaması)

| Milestone | MC Ort. (s) | BL Ort. (s) | Δ (s) | MC Avantajı | MC Kazanan |
|-----------|:-----------:|:-----------:|:-----:|:-----------:|:----------:|
| **70%** | 779.1 | 856.0 | -76.9 | +9.0% | 7/8 |
| **75%** | 873.8 | 969.0 | -95.2 | +9.8% | 7/8 |
| **80%** | 989.8 | 1103.1 | -113.3 | +10.3% | 7/8 |
| **85%** | 1129.0 | 1184.6 | -55.6 | +4.7% | 6/8 |
| **90%** | 1214.8 | 1249.6 | -34.8 | +2.8% | 5/8 |
| **95%** | 1286.9 | 1436.4 | -149.6 | **+10.4%** | **8/8** |
| **Max** | 1570.4 | 1565.0 | +5.4 | -0.3% | 5/8 |

> **Not:** 95% milestone'da MC **8/8 ortamda** kazanıyor — en tutarlı sonuç bu bantta elde ediliyor.

---

## Temel Bulgular

### 1. Genel MC Üstünlüğü
MC, 56 milestone karşılaştırmasının **%80.4'ünde** (45/56) süre bazında kazanıyor. Ortalama hızlanma **%7.2**, medyan **%5.9**. Bu sonuç, map completion yaklaşımının frontier tabanlı keşfi anlamlı biçimde iyileştirdiğini gösteriyor.

### 2. 95% Bandı — En Tutarlı Avantaj
95% milestone'da MC **8/8 ortamda** kazanıyor (ortalama +%10.4). Yüksek kapsam oranlarına ulaşmada MC'nin harita tamamlama tahmini kritik avantaj sağlıyor. Bu, son frontier'lara doğru etkili yönelimin temel katkısını ortaya koyuyor.

### 3. 70-80% Bandı — Güçlü Erken Avantaj
70-80% milestone aralığında MC 7/8 ortamda kazanıyor ve %9-10 ortalama avantaj sağlıyor. MC'nin keşfin erken aşamalarında daha verimli frontier seçimi yaptığı görülüyor.

### 4. 85-90% Bandı — En Çekişmeli Alan
85% ve 90% milestone'larda MC avantajı azalıyor (+%4.7, +%2.8) ve BL'nin kazandığı ortam sayısı artıyor (2/8 ve 3/8). Bu bantta bazı ortamlarda MC yanlış tahminli frontier'lara yönelip zaman kaybedebiliyor.

### 5. Max Kapsam — Nötr Sonuç
Max milestone'da MC ve BL neredeyse eşit (ortalama +5.4s MC aleyhine, yani istatistiksel olarak önemsiz). Max noktasında fark ortadan kalkıyor — her iki yöntem de nihayetinde benzer son kapsamlara ulaşıyor.

### 6. Outlier: 4bb7 Ortamı
4bb7 (%24.3 dar koridor, 1.353 m² alan) tek BL üstün ortam — 6/7 milestone'da BL kazanıyor, ortalama -%10.5. Bu ortamda MC'nin harita tahminlerinin frontier seçimini yanıltıcı yönlere çektiği görülüyor. Yüksek dar koridor oranı ile büyük alan kombinasyonu MC için olumsuz bir profil oluşturuyor.

### 7. En Güçlü MC Ortamı: 4615
%28.1 dar koridor, 407 m² küçük alan — MC 7/7, ortalama +%27.1 avantaj. Küçük ve görece izole bölümler içeren ortamlarda MC'nin tahmin gücü en yüksek etkiyi gösteriyor.

---

## Zaman/Mesafe Ayrışması Notu

Bazı ortamlarda (özellikle 958a ve dd3b 85-90% bandında) MC süre bazında kazanırken mesafede BL daha verimli. Bu fiziksel olarak tutarlı: MC daha az durarak daha hızlı hareket ediyor, ancak bazen daha uzun yollar kat ediyor. Süre metriği keşif verimliliği açısından birincil gösterge olduğundan bu durum MC avantajını geçersiz kılmıyor.
