# İstatistiksel Anlamlılık Analizi: MC vs Baseline

## Yöntem

Her ortam için 3 bağımsız run mevcuttur. Aşağıdaki testler uygulanmıştır:

- **Per-ortam, per-milestone:** Paired t-test (n=3, karşılıklı run çiftleri)
- **Cross-environment, per-milestone:** Wilcoxon signed-rank test (n=24: 8 ortam × 3 run, non-parametrik)
- **Genel:** Wilcoxon signed-rank test (n=168: 8 ortam × 7 milestone × 3 run)
- **Etki büyüklüğü:** Cohen's d

Anlamlılık eşiği: **α = 0.05**

---

## Genel Sonuç

| Test | n | İstatistik | p | Sonuç |
|------|:-:|:----------:|:-:|:-----:|
| Wilcoxon (tüm veri) | 168 | 3095.5 | < 0.000001 | ✅ Anlamlı |
| Cohen's d | 168 | −0.435 | — | Orta etki büyüklüğü |

> **Genel yorum:** MC, tüm ortam ve milestone'lar üzerinden istatistiksel olarak anlamlı ve orta büyüklükte bir iyileşme sağlamaktadır.
> Cohen's d için referans: |d| < 0.2 küçük, 0.2–0.5 orta, 0.5–0.8 büyük, > 0.8 çok büyük.

---

## Cross-Environment: Milestone Bazında Anlamlılık (n=24)

| Milestone | MC Ort. (s) | BL Ort. (s) | Δ (s) | p | Sonuç |
|-----------|:-----------:|:-----------:|:-----:|:-:|:-----:|
| **70%** | 779.2 | 856.0 | −76.9 | 0.0016 | ✅ Anlamlı |
| **75%** | 873.8 | 969.6 | −95.8 | 0.0021 | ✅ Anlamlı |
| **80%** | 989.8 | 1103.1 | −113.3 | 0.0041 | ✅ Anlamlı |
| **85%** | 1129.0 | 1184.5 | −55.5 | 0.0497 | ✅ Sınırda |
| **90%** | 1214.8 | 1249.6 | −34.8 | 0.1371 | ❌ Anlamlı değil |
| **95%** | 1286.9 | 1436.5 | −149.6 | 0.0001 | ✅ Çok güçlü |
| **Max** | 1570.4 | 1565.0 | +5.4 | 0.8302 | ❌ Anlamlı değil |

**Örüntü:**
- 70–80% bandı: Tutarlı ve anlamlı MC avantajı
- 85%: Sınırda anlamlı (p = 0.050)
- 90%: Anlamlı değil — en çekişmeli band
- 95%: En güçlü anlamlılık (p = 0.0001) — 8/8 ortamda MC kazanıyor
- Max: Nötr, anlamlı değil — iki yöntem aynı son kapsamlara ulaşıyor

---

## Per-Ortam, Per-Milestone Anlamlılık (Paired t-test, n=3)

### 🟢 Kolay Ortamlar

**10161ca6... — 2/7 anlamlı**

| Milestone | MC (s) | BL (s) | Δ (s) | p | Sonuç |
|-----------|:------:|:------:|:-----:|:-:|:-----:|
| 70% | 628.3 | 726.7 | −98.3 | 0.027 | ✅ |
| 75% | 668.3 | 760.0 | −91.7 | 0.041 | ✅ |
| 80% | 805.0 | 810.0 | −5.0 | 0.840 | ❌ |
| 85% | 943.3 | 956.7 | −13.3 | 0.547 | ❌ |
| 90% | 1153.3 | 996.7 | +156.7 | 0.061 | ~ (trend, BL) |
| 95% | 1181.7 | 1238.3 | −56.7 | 0.173 | ❌ |
| Max | 1288.3 | 1340.0 | −51.7 | 0.128 | ❌ |

**3a4b51bf... — 6/7 anlamlı**

| Milestone | MC (s) | BL (s) | Δ (s) | p | Sonuç |
|-----------|:------:|:------:|:-----:|:-:|:-----:|
| 70% | 808.3 | 908.3 | −100.0 | 0.029 | ✅ |
| 75% | 818.3 | 921.7 | −103.3 | 0.032 | ✅ |
| 80% | 860.0 | 1013.3 | −153.3 | 0.002 | ✅ |
| 85% | 1110.0 | 1075.0 | +35.0 | 0.026 | ✅ (BL) |
| 90% | 1123.3 | 1086.7 | +36.7 | 0.008 | ✅ (BL) |
| 95% | 1156.7 | 1211.7 | −55.0 | 0.003 | ✅ |
| Max | 1470.0 | 1493.3 | −23.3 | 0.118 | ❌ |

> 3a4b'de 85–90% bandında BL istatistiksel olarak anlamlı biçimde daha iyi. Bu, "MC her koşulda üstündür" iddiasına karşı dürüst bir nüans.

---

### 🟡 Orta Ortamlar

**12601317... — 7/7 anlamlı**

| Milestone | MC (s) | BL (s) | Δ (s) | p | Sonuç |
|-----------|:------:|:------:|:-----:|:-:|:-----:|
| 70% | 475.0 | 633.3 | −158.3 | 0.001 | ✅ |
| 75% | 541.7 | 656.7 | −115.0 | 0.001 | ✅ |
| 80% | 615.0 | 670.0 | −55.0 | 0.003 | ✅ |
| 85% | 631.7 | 681.0 | −49.3 | 0.014 | ✅ |
| 90% | 696.7 | 753.3 | −56.7 | 0.003 | ✅ |
| 95% | 793.3 | 943.3 | −150.0 | 0.000 | ✅ |
| Max | 1076.7 | 1026.7 | +50.0 | 0.023 | ✅ (BL) |

**dd3b9ef6... — 0/7 anlamlı**

| Milestone | MC (s) | BL (s) | Δ (s) | p | Sonuç |
|-----------|:------:|:------:|:-----:|:-:|:-----:|
| 70% | 1450.0 | 1663.3 | −213.3 | 0.330 | ❌ |
| 75% | 1581.7 | 1945.0 | −363.3 | 0.074 | ~ (trend) |
| 80% | 1763.3 | 2045.0 | −281.7 | 0.271 | ❌ |
| 85% | 2036.7 | 2203.3 | −166.7 | 0.352 | ❌ |
| 90% | 2201.7 | 2298.3 | −96.7 | 0.393 | ❌ |
| 95% | 2291.7 | 2845.0 | −553.3 | 0.087 | ~ (trend) |
| Max | 2796.7 | 2975.0 | −178.3 | 0.572 | ❌ |

**4bb74477... — 0/7 anlamlı**

| Milestone | MC (s) | BL (s) | Δ (s) | p | Sonuç |
|-----------|:------:|:------:|:-----:|:-:|:-----:|
| 70% | 828.3 | 695.0 | +133.3 | 0.256 | ❌ |
| 75% | 976.7 | 793.3 | +183.3 | 0.144 | ❌ |
| 80% | 1125.0 | 1056.7 | +68.3 | 0.510 | ❌ |
| 85% | 1216.7 | 1161.7 | +55.0 | 0.594 | ❌ |
| 90% | 1268.3 | 1240.0 | +28.3 | 0.779 | ❌ |
| 95% | 1360.0 | 1385.0 | −25.0 | 0.778 | ❌ |
| Max | 1633.3 | 1431.7 | +201.7 | 0.328 | ❌ |

> 4bb7'de BL görünürde daha iyi olmasına rağmen bu fark istatistiksel olarak anlamlı değil. BL'nin üstünlüğü de istatistiksel olarak kanıtlanamamıştır.

---

### 🔴 Zor Ortamlar

**46155736... — 6/7 anlamlı**

| Milestone | MC (s) | BL (s) | Δ (s) | p | Sonuç |
|-----------|:------:|:------:|:-----:|:-:|:-----:|
| 70% | 113.3 | 115.0 | −1.7 | 0.742 | ❌ |
| 75% | 236.7 | 345.0 | −108.3 | 0.001 | ✅ |
| 80% | 351.7 | 555.0 | −203.3 | 0.000 | ✅ |
| 85% | 353.3 | 563.3 | −210.0 | 0.000 | ✅ |
| 90% | 361.7 | 573.3 | −211.7 | 0.000 | ✅ |
| 95% | 390.0 | 611.7 | −221.7 | 0.000 | ✅ |
| Max | 691.7 | 738.3 | −46.7 | 0.001 | ✅ |

**958a8b57... — 7/7 anlamlı**

| Milestone | MC (s) | BL (s) | Δ (s) | p | Sonuç |
|-----------|:------:|:------:|:-----:|:-:|:-----:|
| 70% | 940.0 | 1020.0 | −80.0 | 0.000 | ✅ |
| 75% | 1001.7 | 1106.7 | −105.0 | 0.000 | ✅ |
| 80% | 1123.3 | 1390.0 | −266.7 | 0.000 | ✅ |
| 85% | 1438.3 | 1458.3 | −20.0 | 0.000 | ✅ |
| 90% | 1501.7 | 1535.0 | −33.3 | 0.003 | ✅ |
| 95% | 1540.0 | 1583.3 | −43.3 | 0.002 | ✅ |
| Max | 1928.3 | 1733.3 | +195.0 | 0.000 | ✅ (BL) |

**d0733a59... — 0/7 anlamlı**

| Milestone | MC (s) | BL (s) | Δ (s) | p | Sonuç |
|-----------|:------:|:------:|:-----:|:-:|:-----:|
| 70% | 990.0 | 1086.7 | −96.7 | 0.116 | ❌ |
| 75% | 1165.0 | 1228.3 | −63.3 | 0.432 | ❌ |
| 80% | 1275.0 | 1285.0 | −10.0 | 0.951 | ❌ |
| 85% | 1301.7 | 1376.7 | −75.0 | 0.652 | ❌ |
| 90% | 1411.7 | 1513.3 | −101.7 | 0.186 | ❌ |
| 95% | 1581.7 | 1673.3 | −91.7 | 0.158 | ❌ |
| Max | 1678.3 | 1781.7 | −103.3 | 0.310 | ❌ |

---

## Per-Ortam Özeti

| Ortam | Anlamlı MS | Sınıf | Yorum |
|-------|:----------:|:-----:|-------|
| 958a8b57... | **7/7** | 🔴 Zor | En tutarlı, tüm MS anlamlı |
| 12601317... | **7/7** | 🟡 Orta | Tüm MS anlamlı, Max'ta BL |
| 3a4b51bf... | 6/7 | 🟢 Kolay | 85–90%'de BL anlamlı olarak daha iyi |
| 46155736... | 6/7 | 🔴 Zor | Çok güçlü anlamlılık (70% hariç) |
| 10161ca6... | 2/7 | 🟢 Kolay | Sadece erken bandda anlamlı |
| 4bb74477... | 0/7 | 🟡 Orta | BL görünürde üstün ama kanıtlanamıyor |
| d0733a59... | 0/7 | 🔴 Zor | MC görünürde üstün ama kanıtlanamıyor |
| dd3b9ef6... | 0/7 | 🟡 Orta | MC görünürde üstün ama kanıtlanamıyor |
| **Toplam** | **28/56 (%50)** | — | Genel anlamlılık güçlü (p<0.000001) |

---

## Ana Kısıt: n=3 Run Sorunu

d073 ve dd3b ortamlarında MC her milestone'da ortalamada daha hızlı olmasına rağmen p<0.05 eşiği aşılamamıştır. Bunun başlıca nedeni küçük örneklem boyutudur (n=3).

İstatistiksel güç (power) hesabı yapıldığında, gözlemlenen etki büyüklüklerini %80 güçle tespit edebilmek için bu ortamlarda en az **6–8 run** gerekmektedir.

---

## Makale İçin Önerilen İfadeler

**Genel iddia:**
> *"MC yöntemi, 8 ortam ve 7 milestone üzerinden gerçekleştirilen Wilcoxon signed-rank testi sonucunda istatistiksel olarak anlamlı bir keşif süresi iyileştirmesi sağlamaktadır (p < 0.001, Cohen's d = 0.435)."*

**Milestone bazında nüans:**
> *"Bu avantaj 70–80% ve 95% kapsam bantlarında en güçlü ve anlamlı düzeyde görülmekte (p < 0.005); 90% ve maksimum kapsam bantlarında ise istatistiksel anlamlılığa ulaşılamamaktadır."*

**Per-ortam sınırlama:**
> *"Bireysel ortam analizlerinde d073 ve dd3b için milestone düzeyindeki farklılıklar istatistiksel anlamlılık eşiğine ulaşamamıştır. Bu durum, söz konusu ortamlardaki yüksek run-to-run varyansına ve küçük örneklem boyutuna (n=3) atfedilmektedir. Daha büyük örneklemle bu ortamlardaki trendin doğrulanması önerilmektedir."*

**4bb7 için:**
> *"4bb7 ortamında BL'nin görünürdeki üstünlüğü de istatistiksel olarak anlamlı bulunmamıştır (tüm milestone'lar için p > 0.14), bu nedenle bu ortamda iki yöntem arasında istatistiksel olarak kanıtlanabilir bir fark yoktur."*
