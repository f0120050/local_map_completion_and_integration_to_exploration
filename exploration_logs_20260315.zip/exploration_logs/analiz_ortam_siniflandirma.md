# Ortam Sınıflandırması: Zorluk Analizi

## Yöntem

Her ortam beş yapısal metrik üzerinden değerlendirilmiştir. Metrikler 0–1 aralığına normalize edilerek ağırlıklı bileşik skor hesaplanmıştır:

| Metrik | Ağırlık | Yön | Gerekçe |
|--------|:-------:|:---:|---------|
| Dar koridor oranı (%) | %30 | ↑ zor | Hem navigasyon hem MC tahmini güçleşiyor |
| Açıklık oranı (%) | %25 | ↓ zor | Düşük açıklık = kısıtlı hareket alanı |
| Bilinmeyen oran (%) | %20 | ↑ zor | Daha fazla belirsizlik → daha riskli frontier seçimi |
| Duvar yoğunluğu (%) | %15 | ↑ zor | Engel yoğunluğu navigasyonu güçleştiriyor |
| Serbest alan (m²) | %10 | ↓ zor | Küçük alan → izole bölümler ve az manevra imkânı |

---

## Zorluk Skorları

| Ortam | Dar (%) | Duvar (%) | Bilinm. (%) | Açıklık (%) | Alan (m²) | Skor | Sınıf |
|-------|:-------:|:---------:|:-----------:|:-----------:|:---------:|:----:|:-----:|
| 10161ca6... | 14.5 | 3.6 | 56.6 | 85.5 | 1.781 | 0.003 | 🟢 Kolay |
| 3a4b51bf... | 19.9 | 5.4 | 66.2 | 80.1 | 1.438 | 0.264 | 🟢 Kolay |
| 12601317... | 20.1 | 5.0 | 71.2 | 79.9 | 1.077 | 0.327 | 🟡 Orta |
| dd3b9ef6... | 27.8 | 6.3 | 57.9 | 72.2 | 1.820 | 0.348 | 🟡 Orta |
| 4bb74477... | 24.3 | 5.8 | 67.5 | 75.7 | 1.353 | 0.381 | 🟡 Orta |
| 958a8b57... | 36.6 | 7.5 | 61.5 | 63.4 | 1.174 | 0.633 | 🔴 Zor |
| 46155736... | 28.1 | 7.1 | 79.6 | 71.9 | 407 | 0.661 | 🔴 Zor |
| d0733a59... | 41.3 | 10.0 | 78.2 | 58.7 | 676 | 0.969 | 🔴 Zor |

---

## 🟢 Kolay Ortamlar

### 10161ca6... ve 3a4b51bf...

**Ortak özellikler:**
- Dar koridor oranı düşük (%14.5 ve %19.9) — robot geniş alanlarda serbestçe gezebiliyor
- Açıklık oranı yüksek (%85.5 ve %80.1) — hareket planlaması daha öngörülebilir
- Bilinmeyen oran görece düşük (%56.6 ve %66.2)
- Büyük serbest alan (1.781 ve 1.438 m²) — yeterli manevra alanı

**MC performansı:** 6/7 ve 5/7 milestone kazanımı. Kolay ortamlarda iki yöntem de iyi çalıştığı için farklar küçük, bazı bantlarda BL rekabetçi.

**Yorum:** Kolay ortamlarda MC avantajı istatistiksel olarak daha zayıf — frontier seçimi her iki yöntemde de benzer kalitede olduğundan harita tamamlama tahmini belirleyici olmuyor.

---

## 🟡 Orta Ortamlar

### 12601317..., dd3b9ef6..., 4bb74477...

**Ortak özellikler:**
- Dar koridor oranı orta düzey (%20–28)
- Açıklık oranı orta (%72–80)
- Heterojen sonuçlar — bu sınıfın en ilginç özelliği

**MC performansı:** 6/7 (1260), 7/7 (dd3b), 1/7 (4bb7) — geniş aralık.

**Kritik gözlem — 4bb7 anomalisi:**

4bb7, yapısal metrikler açısından bu sınıfın tam ortasında yer almasına karşın MC'nin en kötü sonucu sergilediği ortamdır (1/7). Bu çelişki önemli bir bulguya işaret ediyor:

> *Yapısal metrikler (dar koridor oranı, duvar yoğunluğu, vb.) tek başına MC performansını açıklamaya yetmiyor. Topolojik bağlantı yapısı — yani oda ve koridor düzenlemesinin mekansal örüntüsü — belirleyici bir rol oynuyor.*

4bb7'de MC'nin harita tamamlama tahminlerinin sistematik olarak yanlış frontier bölgelerine yönlendirdiği gözlemleniyor. Bu, modelin bu topoloji tipine genelleşemediğini gösteriyor.

---

## 🔴 Zor Ortamlar

### 958a8b57..., 46155736..., d0733a59...

**Ortak özellikler:**
- Dar koridor oranı yüksek (%28–41) — en kısıtlı navigasyon koşulları
- Açıklık oranı düşük (%58–72)
- d073: en yüksek duvar yoğunluğu (%10), en yüksek dar koridor (%41.3), en düşük açıklık (%58.7) — tüm metriklerde en zor ortam

**MC performansı:** 6/7, 7/7, 7/7 — **zor ortamlarda MC en güçlü sonuçları üretiyor.**

**Temel bulgu:**

Bu sınıflandırmanın en önemli çıkarımı şudur:

> *Dar koridor, yüksek duvar yoğunluğu ve düşük açıklık gibi yapısal zorluk göstergeleri MC'nin avantajını azaltmıyor; aksine bazı ortamlarda (özellikle 4615 ve d073) en yüksek kazanım oranları zor sınıfında elde ediliyor.*

Bu, MC'nin tam da belirsizliğin ve kısıtların yüksek olduğu koşullarda harita tamamlama tahmininden en fazla faydalandığını gösteriyor. Yüksek bilinmeyen oran ve dar koridorlar, akıllı frontier seçiminin değerini artırıyor.

---

## Sınıflandırma Özeti ve MC Performansı

| Sınıf | Ortam Sayısı | Ort. MC Kazanımı | Ort. MC Avantajı | Baskın Yön |
|-------|:------------:|:----------------:|:----------------:|:----------:|
| 🟢 Kolay | 2 | 5.5/7 | +%5.0 | MC üstün, fark küçük |
| 🟡 Orta | 3 | 4.7/7 | +%3.5 | Değişken, 4bb7 anomalisi |
| 🔴 Zor | 3 | 6.7/7 | +%16.5 | **MC en güçlü burada** |

---

## Önemli Not: "Zor = BL Daha İyi" Yanılgısı

Bu analizin en kritik bulgusu, sezgisel beklentinin tersine çıkmasıdır. Dar ve karmaşık ortamların BL'ye avantaj sağlayacağı düşünülebilir; ancak veriler bunun aksini gösteriyor.

Tek istisna (4bb7) için doğru ifade şudur:

> *"Orta zorluk kategorisindeki 4bb7, model tahminlerinin sistematik olarak yanlış frontier seçimine yol açtığı tek ortamdır. Bu durum belirli topolojik bağlantı yapılarında adaptif yöntem seçiminin araştırılmasını motive etmekte olup yapısal zorluk metriklerinin MC performansını açıklamak için tek başına yeterli olmadığını ortaya koymaktadır."*
