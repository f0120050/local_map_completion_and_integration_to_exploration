# Grafik Açıklamaları: MC vs Baseline — 8 Ortam Analizi

Bu dosya, üretilen 7 grafiğin her birinin ne gösterdiğini, nasıl okunduğunu ve makale/tez bağlamında nasıl kullanılabileceğini açıklamaktadır.

---

## Fig 1 — `fig1_heatmap_avantaj.png`
### MC Zaman Avantajı (%) — Ortam × Milestone Heatmap

**Ne gösteriyor:**
8 ortam (satır) × 7 milestone (sütun) matrisinde MC'nin BL'ye göre yüzde kaç daha hızlı (ya da yavaş) olduğunu gösterir. Her hücredeki değer `(BL - MC) / BL × 100` formülüyle hesaplanmıştır; pozitif değer MC'nin daha hızlı, negatif değer BL'nin daha hızlı olduğu anlamına gelir.

**Renk skalası:**
- Koyu yeşil → MC güçlü avantaj (+%30 ve üzeri)
- Açık yeşil → MC hafif avantaj
- Sarı → İki yöntem yakın
- Kırmızı → BL avantajı

**Nasıl okunur:**
- Satırlar: Yukarıdan aşağıya ortamlar zorluk sırasına göredir (kolay → zor).
- Sütunlar: Soldan sağa kapsam yüzdesi artar (70% → Max).
- 4bb7 satırının büyük ölçüde kırmızı, 4615/1260/958a satırlarının ise yoğun yeşil olduğu görülür.
- 95% sütununda tüm hücrelerin yeşil olduğu dikkat çeker — MC bu bantta 8/8 ortamda kazanıyor.

**Makale/tez kullanımı:**
Tek bakışta tüm bulguların özetini sunan en özlü figür. Sonuçlar bölümünde birincil özet figür olarak kullanılabilir. Hücre değerleri doğrudan tablo verisiyle örtüşmektedir.

---

## Fig 2 — `fig2_bar_milestone_sure.png`
### Milestone Bazında Ortalama Keşif Süresi — Bar Grafik + Anlamlılık

**Ne gösteriyor:**
Her milestone için 8 ortam üzerinden hesaplanan ortalama keşif sürelerini (saniye) MC ve BL için yan yana gösterir. Hata çubukları ±1 standart sapmayı, üst kısımdaki semboller istatistiksel anlamlılığı belirtir.

**Anlamlılık sembolleri:**
- `***` → p < 0.001 (Wilcoxon signed-rank, n=24)
- `**` → p < 0.01
- `*` → p < 0.05
- `~` → p < 0.10 (trend)
- `ns` → Anlamlı değil (p ≥ 0.10)

**Nasıl okunur:**
- 70–80% bandında MC çubukları tutarlı biçimde BL'nin altında ve fark anlamlı.
- 85% sınırda anlamlı (`*`), 90% anlamlı değil (`ns`).
- 95%'te en büyük fark ve en güçlü anlamlılık (`***`).
- Max milestone'da çubuklar neredeyse eşit, `ns` etiketi bunu doğruluyor.
- Hata çubuklarının uzunluğu ortamlar arası varyansı gösteriyor — büyük ortamlarda (dd3b, d073) varyans yüksek.

**Makale/tez kullanımı:**
İstatistiksel anlamlılık bölümünü destekleyen temel grafik. Wilcoxon test sonuçlarını görsel olarak destekler. "90% bandında anlamlılık kaybolmaktadır" argümanını desteklemek için doğrudan referans verilebilir.

---

## Fig 3 — `fig3_lines_per_ortam_sure.png`
### Ortam Bazında Süre Eğrileri (8 panel)

**Ne gösteriyor:**
Her ortam için ayrı bir panelde MC (mavi, daireli çizgi) ve BL'nin (kırmızı, kareli kesik çizgi) milestone bazında keşif süresi profilini gösterir. İki eğri arasındaki renkli alan, hangi yöntemin önde olduğunu görsel olarak vurgular.

**Panel başlığı rengi:**
- Yeşil → Kolay ortam
- Turuncu → Orta ortam
- Kırmızı → Zor ortam

**Sağ alt köşedeki "MC X/7" etiketi:**
O ortamda MC'nin kaç milestone'da kazandığını gösterir.

**Nasıl okunur:**
- 4bb7 panelinde mavi çizginin kırmızının üzerinde seyrettiği görülür — bu ortamda BL üstün.
- 1260 ve 4615 panellerinde mavi çizgi tutarlı biçimde altta — MC net avantaj.
- d073 panelinde eğriler birbirine yakın seyreder, bu yüksek varyansı yansıtır.
- 3a4b panelinde 85–90% aralığında çizgiler yer değiştirir — BL bu bantta önde geçiyor.
- 10161 panelinde 90% noktasında belirgin bir kesişme görülür.

**Makale/tez kullanımı:**
Ortam bazında ayrıntılı sonuç sunumu için kullanılır. Her ortamın bireysel davranışını göstermek, özellikle 4bb7 anomalisini ve 3a4b'nin 85–90% davranışını tartışmak için referans verilebilir.

---

## Fig 4 — `fig4_lines_per_ortam_mesafe.png`
### Ortam Bazında Mesafe Eğrileri (8 panel)

**Ne gösteriyor:**
Fig 3 ile aynı yapıda, ancak keşif süresi yerine kat edilen toplam mesafeyi (metre) gösterir.

**Nasıl okunur:**
- Çoğu ortamda süre ve mesafe eğrileri benzer örüntü sergiler.
- 958a ve dd3b ortamlarında 85–90% bandında ilginç bir ayrışma görülür: MC sürede kazanırken mesafede BL daha verimli. Bu, MC'nin daha hızlı ama daha fazla mesafe kat ederek keşif yaptığını gösterir.
- 4bb7'de mesafe eğrisi de süre eğrisine paralel biçimde BL lehine.

**Makale/tez kullanımı:**
Süre ve mesafe metriklerinin her zaman aynı yönde ilerlemediğini — yani "daha hızlı" ile "daha verimli" kavramlarının zaman zaman ayrıştığını — göstermek için Fig 3 ile birlikte sunulur. Özellikle "zaman/mesafe ayrışması" tartışmasını destekler.

---

## Fig 5 — `fig5_scatter_zorluk_avantaj.png`
### Ortam Zorluğu vs MC Performans Avantajı — Saçılım Grafiği

**Ne gösteriyor:**
Her ortamın zorluk skoru (x ekseni: 0=kolay, 1=zor) ile MC'nin o ortamdaki ortalama zaman avantajı yüzdesi (y ekseni) arasındaki ilişkiyi gösterir. Kesik gri çizgi regresyon trendini, renk ortam sınıfını temsil eder.

**Nasıl okunur:**
- Y ekseni sıfır çizgisinin üzeri MC avantajı, altı BL avantajı anlamına gelir.
- Regresyon çizgisi hafifçe yukarı eğilimlidir — daha zor ortamlarda MC avantajının artma eğilimi.
- 4bb7 (turuncu) sağa yakın konumda ama y ekseninde sıfırın altında — anomali olarak görsel vurgu yapar.
- d073 (kırmızı, en sağda) pozitif avantajda — "en zor ortam = en iyi MC sonucu" mesajını destekler.
- Korelasyon katsayısı (r) başlıkta görünür.

**Makale/tez kullanımı:**
Bu grafik tezin en güçlü argüman görselidir. "Zor ortamda BL daha iyi" önyargısını kıran, sezgiye aykırı ama veritabanlı bir bulguyu net biçimde sunar. Tartışma (Discussion) bölümünde, özellikle 4bb7 anomalisini topolojik açıdan ele alan paragrafın yanına konulabilir.

---

## Fig 6 — `fig6_pvalue_heatmap.png`
### İstatistiksel Anlamlılık Haritası (Paired t-test, n=3)

**Ne gösteriyor:**
Fig 1'in istatistiksel versiyonu. Her hücre, o ortam-milestone kombinasyonu için paired t-test p-değerini ve anlamlılık düzeyini renkle gösterir.

**Renk kodu:**
- Koyu yeşil → MC p < 0.001
- Orta yeşil → MC p < 0.01
- Açık yeşil → MC p < 0.05
- Gri → Anlamlı değil (p ≥ 0.05)
- Açık kırmızı → BL p < 0.05
- Koyu kırmızı → BL p < 0.01

**Nasıl okunur:**
- 958a ve 1260 satırları neredeyse tamamen yeşil — tüm milestone'larda anlamlı MC üstünlüğü.
- 4bb7, d073 ve dd3b satırları büyük ölçüde gri — farklar istatistiksel olarak kanıtlanamıyor (n=3 kısıtı).
- 3a4b'nin 85–90% hücrelerinde kırmızı görülür — bu bantta BL anlamlı olarak daha iyi.
- 95% sütunu en yoğun yeşil sütun — cross-env analizde de p=0.0001 ile en güçlü bulgu.
- Toplam 28/56 hücre yeşil (%50), 5 hücre kırmızı (3a4b 85-90%, 958a Max, 1260 Max).

**Makale/tez kullanımı:**
İstatistiksel bulgular bölümünde paired t-test sonuçlarını tablo yerine görsel olarak sunmak için kullanılır. "n=3 ile anlamlılığa ulaşılamayan ortamların trend gösterdiği" argümanını destekler.

---

## Fig 7 — `fig7_radar_ortam_profil.png`
### Ortam Yapısal Profili — Radar (Spider) Grafikleri

**Ne gösteriyor:**
Her ortam için beş yapısal metriğin (dar koridor oranı, duvar yoğunluğu, bilinmeyen oran, serbest alan, açıklık oranı) normalize edilmiş değerlerini beşgen radar grafik şeklinde gösterir. Her eksende 0=bu metrikte en düşük ortam, 1=en yüksek ortam.

**Panel rengi:**
- Yeşil → Kolay ortam
- Turuncu → Orta ortam
- Kırmızı → Zor ortam

**Nasıl okunur:**
- d073 (kırmızı): Dar koridor ve duvar eksenlerinde belirgin çıkıntı — yapısal olarak en zorlayıcı profil. Buna rağmen MC 7/7 kazanıyor.
- 4615 (kırmızı): Bilinmeyen oran ekseninde çok yüksek, alan ekseninde çok düşük — küçük ama belirsiz ortam. MC 7/7.
- 4bb7 (turuncu): Dengeli, orta profil — hiçbir eksende aşırı değer yok. Ama MC 1/7. Radar üzerinde bu görsel "normallik" ile performans anomalisi arasındaki zıtlık dikkat çekici.
- 10161 (yeşil): Açıklık ekseninde maksimuma yakın, dar koridor ve duvarda minimum — ideal keşif ortamı profili.

**Makale/tez kullanımı:**
Ortam karakterizasyonu bölümünde her ortamın "parmak izini" sunmak için kullanılır. Özellikle 4bb7'nin diğer zor ortamlardan yapısal olarak neden ayrılamadığını — yani topolojik faktörün radar grafiğe yansımadığını — görsel olarak destekler.

---

## Grafik Kullanım Önerileri (Makale/Tez Bölümlerine Göre)

| Bölüm | Önerilen Grafik(ler) |
|-------|---------------------|
| **Ortam Tanıtımı** | Fig 7 (radar profiller) |
| **Sonuçlar — Genel Özet** | Fig 1 (avantaj heatmap) |
| **Sonuçlar — Süre Karşılaştırması** | Fig 2 (bar + anlamlılık), Fig 3 (per-ortam çizgi) |
| **Sonuçlar — Mesafe Karşılaştırması** | Fig 4 (per-ortam çizgi) |
| **İstatistiksel Analiz** | Fig 2 (anlamlılık yıldızları), Fig 6 (p-value heatmap) |
| **Tartışma — Zorluk & MC İlişkisi** | Fig 5 (scatter), Fig 7 (radar) |
| **Tartışma — 4bb7 Anomalisi** | Fig 1 (kırmızı satır), Fig 5 (anomali noktası), Fig 3 (4bb7 paneli) |
