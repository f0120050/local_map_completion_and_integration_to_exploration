# 4615 Ortamı — Clustering Karşılaştırması (%70 ve Sonrası)

**Harita:** `4615573698d90356b0dd53416b726821`  
**Yöntem:** Euclidean  
**Run sayısı:** 3 (her koşul için)  
**Değerler:** Milestone'a ulaşma süresi ortalaması (saniye)

| Milestone | BASE (clustering=0) | CLUSTERING (clustering=1) | Fark (sn) | Fark (%) |
|-----------|---------------------|--------------------------|-----------|----------|
| %70 | 12.461 | 18.793 | +6.332 | +50.8% |
| %75 | 35.723 | 41.870 | +6.147 | +17.2% |
| %80 | 60.500 | 72.914 | +12.414 | +20.5% |
| %85 | 61.578 | 74.142 | +12.564 | +20.4% |
| %90 | 62.713 | 75.667 | +12.954 | +20.7% |
| %92 | 64.039 | 78.014 | +13.975 | +21.8% |
| %94 | 67.717 | 80.614 | +12.897 | +19.0% |
| %96 | 75.940 | 86.754 | +10.814 | +14.2% |
| %98 | 86.780 | 97.320 | +10.540 | +12.1% |

## Özet

- Negatif fark → CLUSTERING daha hızlı
- Pozitif fark → BASE daha hızlı

%98 tamamlanmada CLUSTERING, BASE'e göre **10.5 saniye (daha yavaş)** (12.1% kayıp).
