# Ortam Harita Analizi: 3a4b51bf91570ff73cc113fc7f5791a8

---

## Temel Bilgiler

| Özellik | Değer |
|---------|-------|
| **Dosya formatı** | PGM (Netpbm grayscale) |
| **Çözünürlük** | 0.1 m/piksel |
| **Harita boyutu** | 640 × 704 px → 64.0 × 70.4 m |
| **Aktif alan (bilinen)** | 56.8 × 49.5 m |
| **Koordinat sistemi** | ROS map_saver standart (254=serbest, 0=engel, 205=bilinmiyor) |

---

## Alan Dağılımı

| Alan Tipi | Piksel | Gerçek Alan (m²) | Oran |
|-----------|-------:|------------------:|------|
| **Serbest (beyaz)** | 143.819 | 1.438 | %31.9 |
| **Engel/Duvar (siyah)** | 8.270 | 82.7 | %1.8 |
| **Bilinmiyor (gri)** | 298.471 | — | %66.2 |
| **Toplam** | 450.560 | 4.506 | %100 |

> Bilinen alan içindeki duvar yoğunluğu: **%5.4** (serbest + engel toplamının).

---

## Yapısal Analiz

| Metrik | Değer |
|--------|-------|
| **Dar koridor alanı** (5px erozyon) | 286.3 m² (%19.9) |
| **Açık alan** (5px erozyon sonrası) | 1.151.9 m² (%80.1) |
| **Açıklık oranı** | **%80.1** → Ağırlıklı açık plan |
| **Bağlı serbest bölge sayısı** | 561 (1 ana bölge ~1.427 m², geri kalanlar çok küçük izole parçalar) |
| **Duvar yoğunluğu** | %5.4 |

---

## Ortam Karakterizasyonu

Bu harita, **HouseExpo** veri setinden alınmış simüle bir iç mekan ortamını temsil etmektedir.

**Yapısal özellikler:**
- Üç ortam arasında **en büyük harita**: aktif alan 56.8 × 49.5 m, serbest alan 1.438 m².
- Bilinmeyen oran **%66.2** — ilk ortamla (%56.6) benzer, ikinci ortamdan (%79.6) düşük.
- Dar koridor oranı **%19.9** — ortalar arasında; ilk ortamdan (%14.5) fazla, ikinci ortamdan (%28.1) az.
- Duvar yoğunluğu **%5.4** — üç ortam arasında orta değer (10161: %3.6, 4615: %7.1).
- Bağlı bölge sayısı 561 ile dikkat çekici biçimde yüksek — ancak bunların büyük çoğunluğu çok küçük izole fragmanlar; ana bölge tüm serbest alanın %99.3'ünü kaplıyor.

**Keşif açısından beklenen zorluklar:**
- Büyük alan nedeniyle keşif süreleri uzun (~1400-1700s) — diğer iki ortama göre belirgin biçimde daha fazla.
- Dar koridor oranı orta düzeyde (%19.9), bu da robotun zaman zaman dar geçitlerde yavaşladığını ama genel olarak akıcı ilerlediğini gösterir.
- Yüksek bilinmeyen oran MC'nin tahmin avantajından yararlanmasını sağlar; ancak büyük alanda bu tahminlerin doğruluğu kritik hale gelir.
- 85-90% bandında her iki ortamda (10161 ve bu ortam) gözlemlenen MC yavaşlaması, büyük açık alanlarda robotun frontier'leri bitirirken belirli bölgelere tekrar gitmek zorunda kalmasından kaynaklanıyor olabilir.

**Üç ortam karşılaştırması:**

| Özellik | 10161... | 4615... | 3a4b... |
|---------|----------|---------|---------|
| Aktif alan | 66.9×39.4 m | 25.3×26.6 m | 56.8×49.5 m |
| Serbest alan | 1.781 m² | 407 m² | 1.438 m² |
| Dar koridor oranı | %14.5 | %28.1 | %19.9 |
| Duvar yoğunluğu | %3.6 | %7.1 | %5.4 |
| Bilinmeyen oran | %56.6 | %79.6 | %66.2 |
| Ort. keşif süresi (MC) | ~1.288s | ~692s | ~1.470s |
| MC kazandığı MS sayısı | 6/7 | 7/7 | 5/7 |

---

## Görsel

![Harita Görseli](map_3a4b51bf91570ff73cc113fc7f5791a8.png)

> Siyah = Duvar/Engel | Açık gri = Serbest alan | Orta gri = Bilinmiyor
