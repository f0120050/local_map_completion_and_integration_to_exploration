# Ortam: 3a4b51bf91570ff73cc113fc7f5791a8
## MC vs Baseline — Tüm Run Detayları ve Ortalama

---

## Run 1

> MC: tek dosya (132244) | BL: tek dosya (173423)

| Milestone | MC Süre (s) | MC Dist (m) | BL Süre (s) | BL Dist (m) | Δ Süre (s) | Δ Dist (m) | Kazanan |
|-----------|------------:|------------:|------------:|------------:|-----------:|-----------:|---------|
| **70%**  |  865.0 | 175.85 |  860.0 | 179.23 |   +5.0 |  -3.38 | BL ✅ (süre) / MC ✅ (dist) |
| **75%**  |  875.0 | 177.78 |  875.0 | 182.44 |    0.0 |  -4.65 | = (süre) / MC ✅ (dist) |
| **80%**  |  930.0 | 188.80 |  980.0 | 204.13 |  -50.0 | -15.34 | **MC ✅** |
| **85%**  | 1025.0 | 208.96 |  995.0 | 207.40 |  +30.0 |  +1.55 | BL ✅ (yakın) |
| **90%**  | 1035.0 | 210.87 | 1010.0 | 210.59 |  +25.0 |  +0.28 | BL ✅ (çok yakın) |
| **95%**  | 1065.0 | 217.31 | 1240.0 | 259.02 | -175.0 | -41.71 | **MC ✅** |
| **Max**  | 1405.0 (96.79%) | 288.28 | 1245.0 (96.39%) | 259.66 | +160.0 | +28.62 | BL ✅ (süre) / MC ✅ (kapsam) |

---

## Run 2

> MC: tek dosya (141116) | BL: 3 dosya zinciri (182337 → 183126 → 183200)

| Milestone | MC Süre (s) | MC Dist (m) | BL Süre (s) | BL Dist (m) | Δ Süre (s) | Δ Dist (m) | Kazanan |
|-----------|------------:|------------:|------------:|------------:|-----------:|-----------:|---------|
| **70%**  |  960.0 | 200.48 |  985.0 | 190.86 |  -25.0 |  +9.62 | **MC ✅** (süre) / BL ✅ (dist) |
| **75%**  |  975.0 | 203.72 | 1000.0 | 194.14 |  -25.0 |  +9.59 | **MC ✅** (süre) / BL ✅ (dist) |
| **80%**  | 1030.0 | 214.94 | 1105.0 | 215.96 |  -75.0 |  -1.02 | **MC ✅** |
| **85%**  | 1115.0 | 232.51 | 1120.0 | 219.25 |   -5.0 | +13.27 | **MC ✅** (süre) / BL ✅ (dist) |
| **90%**  | 1130.0 | 235.68 | 1130.0 | 221.12 |    0.0 | +14.56 | = (süre) / BL ✅ (dist) |
| **95%**  | 1170.0 | 244.75 | 1205.0 | 236.86 |  -35.0 |  +7.89 | **MC ✅** (süre) / BL ✅ (dist) |
| **Max**  | 1505.0 (96.75%) | 313.93 | 1520.0 (96.06%) | 301.23 |  -15.0 | +12.70 | **MC ✅** (süre+kapsam) |

> ⚠️ Bu run'da MC süre bazında kazanıyor ancak birçok noktada Baseline daha az mesafe katediyor — MC daha hızlı ama daha dolaşık bir güzergah izliyor.

---

## Run 3

> MC: tek dosya (164049) | BL: tek dosya (194608)

| Milestone | MC Süre (s) | MC Dist (m) | BL Süre (s) | BL Dist (m) | Δ Süre (s) | Δ Dist (m) | Kazanan |
|-----------|------------:|------------:|------------:|------------:|-----------:|-----------:|---------|
| **70%**  |  600.0 | 121.68 |  880.0 | 184.06 | -280.0 | -62.38 | **MC ✅** |
| **75%**  |  605.0 | 122.46 |  890.0 | 186.02 | -285.0 | -63.56 | **MC ✅** |
| **80%**  |  620.0 | 125.70 |  955.0 | 199.42 | -335.0 | -73.72 | **MC ✅** |
| **85%**  | 1190.0 | 242.12 | 1110.0 | 230.33 |  +80.0 | +11.79 | BL ✅ |
| **90%**  | 1205.0 | 245.28 | 1120.0 | 232.26 |  +85.0 | +13.02 | BL ✅ |
| **95%**  | 1235.0 | 251.73 | 1190.0 | 247.13 |  +45.0 |  +4.60 | BL ✅ |
| **Max**  | 1500.0 (96.75%) | 305.75 | 1715.0 (96.33%) | 329.62 | -215.0 | -23.87 | **MC ✅** |

> ⚠️ MC'de 70-80% sonrası 85%'e ulaşmak için büyük sıçrama var (620s → 1190s). Bu run'da 80% sonrasında MC geçici olarak yavaşlamış.

---

## 3 Run Ortalaması

| Milestone | MC Süre (s) | MC Dist (m) | BL Süre (s) | BL Dist (m) | Δ Süre (s) | Δ Dist (m) | Kazanan |
|-----------|------------:|------------:|------------:|------------:|-----------:|-----------:|---------|
| **70%**  |  808.3 | 166.00 |  908.3 | 184.71 | -100.0 | -18.71 | **MC ✅** |
| **75%**  |  818.3 | 167.99 |  921.7 | 187.53 | -103.3 | -19.54 | **MC ✅** |
| **80%**  |  860.0 | 176.48 | 1013.3 | 206.50 | -153.3 | -30.02 | **MC ✅** |
| **85%**  | 1110.0 | 227.86 | 1075.0 | 218.99 |  +35.0 |  +8.87 | **BL ✅** |
| **90%**  | 1123.3 | 230.61 | 1086.7 | 221.33 |  +36.7 |  +9.28 | **BL ✅** |
| **95%**  | 1156.7 | 237.93 | 1211.7 | 247.67 |  -55.0 |  -9.74 | **MC ✅** |
| **Max**  | 1470.0 | 302.65 | 1493.3 | 296.83 |  -23.3 |  +5.82 | **MC ✅** (süre) / BL ✅ (dist) |

> Δ = MC − Baseline. Negatif değer MC'nin daha iyi olduğunu gösterir.

---

## Genel Değerlendirme

- MC **5/7 milestone'da** süre bazında kazanıyor.
- **70–80% bandı**: MC tutarlı biçimde daha hızlı ve daha az mesafe (Δ ≈ -100 ile -153s, -19 ile -30m). Bu üç run'un tamamında gözlemleniyor.
- **85–90% bandı**: Baseline hafif avantajlı (Δ ≈ +35-37s, +9m). İlk ortamla (%10161...) aynı pattern — MC bu geçiş bölgesinde her iki ortamda da geçici yavaşlama gösteriyor.
- **95% ve Max**: MC tekrar öne geçiyor; özellikle 95%'de belirgin (-55s, -9.7m).
- Mesafe bazında Max noktasında Baseline hafif daha az yol katiyor (+5.8m fark) ancak MC daha yüksek kapsama (96.75% vs ortalama 96.26%) ulaşıyor.
- Bu ortam büyük ölçekli (Run 1'deki 10161... ortamına benzer boyut), keşif süreleri ~1400-1700s ile diğer ortamlardan belirgin biçimde uzun.
