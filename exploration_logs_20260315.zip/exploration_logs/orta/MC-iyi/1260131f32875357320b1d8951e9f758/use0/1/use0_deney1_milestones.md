# use0 (Baseline) — Deney 1 Milestone Analizi

## Dosyalar
| Dosya | Ham Süre | Not |
|---|---|---|
| F1 (225731) | 234.016 sn | Temiz |
| F2 (230742) | 724.605 sn | Temiz |
| F3 (233155) | 84.972 sn | Temiz |
| **Toplam** | **1043.593 sn = 17.39 dk** | Takılma yok |

**Toplam Mesafe:** 210.340 m  
**Maksimum Tamamlanma:** %98.285

---

## Milestone Tablosu

| Milestone | Kümülatif Süre (sn) | Completion (%) | Kümülatif Mesafe (m) |
|---|---|---|---|
| %70 | 684.0 | 70.564 | 137.50 |
| %80 | 719.0 | 82.842 | 144.73 |
| %85 | 739.0 | 85.161 | 148.40 |
| %90 | 789.0 | 90.097 | 158.60 |
| %95 | 924.0 | 96.003 | 185.85 |
| %98 | 929.0 | 98.112 | 187.13 |
| **MAX** | **1038.6** | **98.273** | **209.38** |

---

## Hız Analizi
| | use0 (bu deney) | use1 Deney 4-6 |
|---|---|---|
| Ortalama hız | 0.204–0.218 m/s | 0.202–0.208 m/s |
| Medyan hız | 0.236–0.259 m/s | 0.252–0.257 m/s |

Hız farkı ihmal edilebilir düzeyde — deneyler arası performans farkı hızdan değil, algoritma kararlarından kaynaklanıyor.

---

## Notlar
- 3 dosyada da takılma tespit edilmedi, tüm tekrarlı hedefler normal navigasyon (mesafe düzenli azalmış).
- F3 temiz kapandı, geri dönüş davranışı yok.
