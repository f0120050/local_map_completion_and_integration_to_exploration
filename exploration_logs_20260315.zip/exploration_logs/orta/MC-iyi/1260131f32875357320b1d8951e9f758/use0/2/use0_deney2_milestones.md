# use0 (Baseline) — Deney 2 Milestone Analizi

## Dosyalar
| Dosya | Ham Süre | Not |
|---|---|---|
| F1 (234458) | 370.566 sn | Temiz |
| F2 (235831) | 450.306 sn | Temiz |
| F3 (001351) | 278.935 sn | Takılma: (-24.709,-13.660) elapsed 135→230 = 95 sn |
| **Toplam ham** | **1099.807 sn = 18.33 dk** | |
| **Toplam düzeltilmiş** | **1004.807 sn = 16.75 dk** | F3 takılma: -95 sn |

**Toplam Mesafe:** 222.384 m  
**Maksimum Tamamlanma:** %99.049

---

## Milestone Tablosu (Düzeltilmiş Kümülatif Süre)

| Milestone | Kümülatif Süre (sn) | Completion (%) | Kümülatif Mesafe (m) |
|---|---|---|---|
| %70 | 620.6 | 70.998 | 126.03 |
| %80 | 660.6 | 81.482 | 134.22 |
| %85 | 665.6 | 85.277 | 135.44 |
| %90 | 800.6 | 91.228 | 161.59 |
| %95 | 970.9 | 96.529 | 215.44 |
| %98 | 985.9 | 98.315 | 218.21 |
| **MAX** | **1000.9** | **99.045** | **221.16** |

---

## Notlar
- F1 ve F2 temiz, takılma yok.
- F3: (-24.709,-13.660) hedefine 95 sn takılma — mesafe azalıyor (22.22→7.13) ama yavaş, stagnant sayısı yüksek.
- %95 sonrası uzama var (800→971 sn = 170 sn) — geniş bir bölge kalmış olabilir.
