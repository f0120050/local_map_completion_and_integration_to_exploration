# use0 (Baseline) — Deney 3 Milestone Analizi

## Dosyalar
| Dosya | Ham Süre | Not |
|---|---|---|
| F1 (002812) | 461.648 sn | Temiz |
| F2 (005102) | 378.482 sn | Temiz |
| F3 (010403) | 122.151 sn | Temiz |
| **Toplam** | **962.281 sn = 16.04 dk** | Takılma yok |

**Toplam Mesafe:** 186.906 m  
**Maksimum Tamamlanma:** %98.352

---

## Milestone Tablosu

| Milestone | Kümülatif Süre (sn) | Completion (%) | Kümülatif Mesafe (m) |
|---|---|---|---|
| %70 | 601.7 | 71.974 | 122.28 |
| %80 | 636.6 | 82.943 | 129.27 |
| %85 | 646.7 | 85.533 | 131.81 |
| %90 | 676.6 | 91.025 | 137.42 |
| %95 | 900.1 | 95.057 | 175.73 |
| %98 | 915.1 | 98.236 | 178.56 |
| %MAX | 960.1 | 98.352 | 186.65 |

---

## Notlar
- 3 dosyada da takılma tespit edilmedi, tüm deneyler temiz.
- F3 temiz kapandı, geri dönüş davranışı gözlemlenmedi.
