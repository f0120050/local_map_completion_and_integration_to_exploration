# use1_with1 — Deney 4 Milestone Analizi (Düzeltilmiş)

## Dosyalar
| Dosya | Ham Süre | Not |
|---|---|---|
| F1 (200432) | 345.46 sn | Takılma: son hedef (-4.991,2.317) → efektif bitiş 330 sn |
| F2 (201903) | 562.01 sn | Temiz |
| F3 (203755) | 263.78 sn | Temiz |
| **Toplam ham** | **1171.24 sn = 19.52 dk** | |
| **Toplam düzeltilmiş** | **1155.78 sn = 19.26 dk** | F1 takılma: -15 sn |

**Toplam Mesafe:** 240.05 m  
**Maksimum Tamamlanma:** %98.004

---

## Milestone Tablosu (Düzeltilmiş Kümülatif Süre)

| Milestone | Kümülatif Süre (sn) | Completion (%) | Kümülatif Mesafe (m) |
|---|---|---|---|
| %70 | 255.0 | 70.880 | 51.08 |
| %80 | 595.0 | 81.262 | 123.19 |
| %85 | 615.0 | 85.095 | 127.18 |
| %90 | 660.0 | 90.812 | 136.09 |
| %95 | 690.0 | 96.334 | 142.28 |
| %98 | 1057.0 | 98.004 | 218.29 |
| **MAX** | **1152.0** | **98.004** | **238.74** |

---

## Notlar
- **%95 → %98 arası:** 367 sn — robot haritanın başında kalan boşluğa geri döndü.
- %95'e kadar (690 sn) temiz ve hızlı seyir.
- F1 takılması: navigasyon kaynaklı, duvar boşluğu. Efektif bitiş 330 sn alındı.
