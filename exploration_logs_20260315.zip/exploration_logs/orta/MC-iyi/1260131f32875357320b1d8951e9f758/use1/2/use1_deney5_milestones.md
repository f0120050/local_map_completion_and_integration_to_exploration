# use1_with1 — Deney 5 Milestone Analizi

## Dosyalar
| Dosya | Ham Süre | Not |
|---|---|---|
| F1 (205439) | 286.78 sn | Temiz |
| F2 (210518) | 824.41 sn | Temiz |
| **Toplam** | **1111.19 sn = 18.52 dk** | |

**Toplam Mesafe:** 223.68 m  
**Maksimum Tamamlanma:** %98.962

---

## Milestone Tablosu

| Milestone | Kümülatif Süre (sn) | Completion (%) | Kümülatif Mesafe (m) |
|---|---|---|---|
| %70 | 541.8 | 70.875 | 108.14 |
| %80 | 576.8 | 82.048 | 114.47 |
| %85 | 591.8 | 85.305 | 117.01 |
| %90 | 626.8 | 90.246 | 123.48 |
| %95 | 746.8 | 95.041 | 148.02 |
| %98 | 766.8 | 98.352 | 152.59 |
| **MAX** | **1106.8** | **98.962** | **222.83** |

---

## Notlar
- Başa dönüş davranışı gözlemlendi: %98 sonrası robot kalan boşluğu tamamlamak için eski bölgeye döndü.
- %95 → %98 arası: yalnızca 20 sn (766 - 746) — bu deneyde geri dönüş etkisi çok daha azdı.
- (4.950000,11.285295) hedefinin tekrar tekrar seçilmesi gerçek takılma değil, robot bu noktaya farklı yönlerden yaklaşırken mesafe arttı. Normal navigasyon.
