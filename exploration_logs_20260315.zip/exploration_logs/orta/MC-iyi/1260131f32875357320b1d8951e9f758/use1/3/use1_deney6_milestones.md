# use1_with1 — Deney 6 Milestone Analizi

## Dosyalar
| Dosya | Ham Süre | Not |
|---|---|---|
| F1 (214400) | 437.161 sn | Temiz |
| F2 (215912) | 234.812 sn | Takılma: (-5.358,-10.681) dosya başında, ~85 sn |
| F3 (220717) | 79.333 sn | Temiz |
| F4 (221133) | 236.491 sn | Temiz |
| **Toplam ham** | **987.80 sn = 16.46 dk** | |
| **Toplam düzeltilmiş** | **902.80 sn = 15.05 dk** | F2 takılma: -85 sn |

**Toplam Mesafe:** 194.374 m  
**Maksimum Tamamlanma:** %98.341

---

## Milestone Tablosu (Düzeltilmiş Kümülatif Süre)

| Milestone | Kümülatif Süre (sn) | Completion (%) | Kümülatif Mesafe (m) |
|---|---|---|---|
| %70 | 592.0 | 79.184 | 133.48 |
| %80 | 597.0 | 81.614 | 134.69 |
| %85 | 612.0 | 85.494 | 137.93 |
| %90 | 731.3 | 90.450 | 160.60 |
| %95 | 881.3 | 95.283 | 190.50 |
| %98 | 896.3 | 98.035 | 193.06 |
| %MAX | 901.3 | 98.340 | 194.31 |

---

## Notlar
- F2 takılması: dosya açılır açılmaz (-5.358,-10.681) hedefine yönelinmiş, ~85 sn boyunca completion ilerlememiş.
- F4 temiz tamamlandı, geri dönüş davranışı gözlemlenmedi.
- %98 sonrası robot hızla tamamladı (MAX %98.341 @ 901.3 sn).
