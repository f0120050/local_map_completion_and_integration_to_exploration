# 4bb7 Ortamı — Clustering Karşılaştırması (%70 ve Sonrası)

**Harita:** `4bb7447766005e95922e3d51c4a5b6fa`  
**Yöntem:** Euclidean  
**Run sayısı:** 3 (her koşul için)  
**Değerler:** Milestone'a ulaşma süresi ortalaması (saniye)

| Milestone | BASE (clustering=0) | CLUSTERING (clustering=1) | Fark (sn) | Fark (%) |
|-----------|---------------------|--------------------------|-----------|----------|
| %70 | 129.361 | 136.147 | +6.786 | +5.2% |
| %75 | 167.298 | 150.294 | -17.004 | -10.2% |
| %80 | 200.472 | 205.108 | +4.636 | +2.3% |
| %85 | 223.675 | 217.361 | -6.314 | -2.8% |
| %90 | 238.543 | 232.651 | -5.892 | -2.5% |
| %92 | 263.718 | 256.554 | -7.164 | -2.7% |
| %94 | 268.075 | 260.575 | -7.500 | -2.8% |
| %96 | 270.080 | 263.543 | -6.537 | -2.4% |
| %98 | 275.618 | 268.423 | -7.195 | -2.6% |

## Özet

- Negatif fark → CLUSTERING daha hızlı
- Pozitif fark → BASE daha hızlı

%98 tamamlanmada CLUSTERING, BASE'e göre **7.2 saniye (daha hızlı)** (2.6% kazanç).
