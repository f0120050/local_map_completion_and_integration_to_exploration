# Ortam Harita Analizi: dd3b9ef66287fe675c932bb9882678a8

---

## Temel Bilgiler

| Özellik | Değer |
|---------|-------|
| **Dosya formatı** | PGM (Netpbm grayscale) |
| **Çözünürlük** | 0.1 m/piksel |
| **Harita boyutu** | 960 × 480 px → 96.0 × 48.0 m |
| **Aktif alan (bilinen)** | 76.9 × 39.7 m |
| **Koordinat sistemi** | ROS map_saver standart (254=serbest, 0=engel, 205=bilinmiyor) |

---

## Alan Dağılımı

| Alan Tipi | Piksel | Gerçek Alan (m²) | Oran |
|-----------|-------:|------------------:|------|
| **Serbest (beyaz)** | 181.947 | 1.819.5 | %39.5 |
| **Engel/Duvar (siyah)** | 12.152 | 121.5 | %2.6 |
| **Bilinmiyor (gri)** | 266.701 | — | %57.9 |
| **Toplam** | 460.800 | 4.608 | %100 |

> Tüm analiz edilen ortamlar arasında **en büyük serbest alan: 1.819.5 m²** ve **en büyük harita boyutu: 96.0×48.0 m**.

---

## Yapısal Analiz

| Metrik | Değer |
|--------|-------|
| **Dar koridor alanı** (5px erozyon) | 506.1 m² (%27.8) |
| **Açık alan** (5px erozyon sonrası) | 1.313.4 m² (%72.2) |
| **Açıklık oranı** | **%72.2** |
| **Bağlı serbest bölge sayısı** | 180 (1 ana bölge ~1.816.2 m²) |
| **Duvar yoğunluğu** | **%6.26** |

---

## Ortam Karakterizasyonu

Bu harita, **HouseExpo** veri setinden alınmış simüle bir iç mekan ortamını temsil etmektedir.

**Yapısal özellikler:**
- Tüm analiz edilen 8 ortam arasında **en büyük ve en geniş**: 96.0×48.0 m boyut, 1.819.5 m² serbest alan.
- Dar koridor oranı **%27.8** — orta seviye (958a: %36.6, d073: %41.3'ün altında).
- Açıklık oranı **%72.2** — orta-yüksek açık yapı.
- Bilinmeyen oran **%57.9** — analiz edilen ortamlar arasında en düşük değerlerden biri; harita büyük ama görece daha az bilinmeyen bölge içeriyor.
- Duvar yoğunluğu **%6.26** — orta seviye.
- 180 bağlı bölge ve ana bölge ~1.816.2 m² — harita büyük ölçüde tek parça bağlı.

**Keşif açısından değerlendirme:**
- Bu ortam büyüklüğü nedeniyle en uzun keşif sürelerine yol açmış: MC ort. ~2797s, BL ~2975s — tüm ortamlar arasında en yüksek. Her run'da 3-8 dosya zinciri oluşturulması bu büyüklüğü teyit ediyor.
- MC **7/7 milestone'da** ortalamada süre bazında kazanıyor. Büyük açık ortamda MC'nin global tahmin avantajı belirgin şekilde işe yarıyor.
- **95% bandında -553.3s ortalama avantaj** dikkat çekici: büyük ve geniş ortamlarda son bölgelere ulaşmak için MC'nin harita tamamlama tahmini kritik fark yaratıyor.
- Run 2'deki 80-90% varyansı (BL kazanıyor), ortamın büyüklüğü nedeniyle MC'nin zaman zaman uzak ama yanlış tahminli bölgelere yöneldiğini gösteriyor. Bu büyük ortamlarda beklenen bir durum.
- Her üç run da **%98-99** düzeyinde başarıyla tamamlandı — bu ortamda tam keşif mümkün.

**Sekiz ortam tam karşılaştırması:**

| Özellik | 10161 | 4615 | 3a4b | 4bb7 | 1260 | 958a | d073 | dd3b |
|---------|-------|------|------|------|------|------|------|------|
| Serbest (m²) | 1.781 | 407 | 1.438 | 1.353 | 1.077 | 1.174 | 676 | **1.820** |
| Dar koridor (%) | 14.5 | 28.1 | 19.9 | 24.3 | 20.1 | 36.6 | 41.3 | 27.8 |
| Duvar yoğunluğu (%) | 3.6 | 7.1 | 5.4 | 5.8 | 5.0 | 7.5 | 10.0 | 6.3 |
| Bilinmeyen (%) | 56.6 | 79.6 | 66.2 | 67.5 | 71.2 | 61.5 | 78.2 | 57.9 |
| Açıklık (%) | 85.5 | 71.9 | 80.1 | 75.7 | 79.9 | 63.4 | 58.7 | 72.2 |
| MC kazandığı MS | 6/7 | 7/7 | 5/7 | 1/7 | 6/7 | 6/7 | 7/7 | **7/7** |

---

## Görsel

![Harita Görseli](map_dd3b9ef66287fe675c932bb9882678a8.png)

> Siyah = Duvar/Engel | Açık gri = Serbest alan | Orta gri = Bilinmiyor
