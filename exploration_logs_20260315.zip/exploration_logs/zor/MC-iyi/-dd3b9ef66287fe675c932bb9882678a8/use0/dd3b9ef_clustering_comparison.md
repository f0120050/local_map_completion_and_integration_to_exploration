# dd3b9ef — Clustering=1 vs Clustering=0 Karşılaştırması

**Ortam:** dd3b9ef66287fe675c932bb9882678a8  
**Yöntem:** Euclidean | use_map_completion=0 | use_live=0 | closing=0 | filtering=0  
**Run sayısı:** 3 run × 2 koşul

---

## Toplam Run Süreleri

| | Run 1 (sn) | Run 2 (sn) | Run 3 (sn) | **Ortalama (sn)** |
|---|---:|---:|---:|---:|
| clustering=1 | 348.7 | 467.7 | 499.3 | **438.6** |
| clustering=0 | 299.4 | 2965.0 | 2610.0 | **1958.1** |
| **İyileşme** | | | | **%77.6** |

---

## Milestone Bazlı Ortalama Elapsed (sn)

| MS% | C=1 Ort (sn) | C=0 Ort (sn) | Fark (sn) | İyileşme |
|----:|-------------:|-------------:|----------:|:--------:|
| 5 | 4.3 | 4.5 | +0.3 | +5.8% ✓ C=1 |
| 10 | 7.6 | 7.8 | +0.2 | +2.8% ✓ C=1 |
| 15 | 13.4 | 10.3 | -3.1 | -30.5% ✓ C=0 |
| 20 | 17.8 | 19.8 | +1.9 | +9.8% ✓ C=1 |
| 25 | 23.4 | 35.1 | +11.7 | +33.3% ✓ C=1 |
| 30 | 45.8 | 59.7 | +13.9 | +23.3% ✓ C=1 |
| 35 | 77.8 | 86.2 | +8.4 | +9.7% ✓ C=1 |
| 40 | 120.7 | 93.1 | -27.6 | -29.6% ✓ C=0 |
| 45 | 139.4 | 117.9 | -21.5 | -18.2% ✓ C=0 |
| 50 | 147.8 | 140.3 | -7.5 | -5.4% ✓ C=0 |
| 55 | 236.8 | 444.0 | +207.3 | +46.7% ✓ C=1 |
| 60 | 316.4 | 704.8 | +388.4 | +55.1% ✓ C=1 |
| 65 | 279.1 | 786.4 | +507.2 | +64.5% ✓ C=1 |
| 70 | 289.3 | 794.5 | +505.2 | +63.6% ✓ C=1 |
| 75 | 343.9 | 853.4 | +509.5 | +59.7% ✓ C=1 |
| 80 | 286.3 | 1027.2 | +740.9 | +72.1% ✓ C=1 |
| 85 | 298.1 | 1266.3 | +968.2 | +76.5% ✓ C=1 |
| 90 | 318.0 | 1286.4 | +968.4 | +75.3% ✓ C=1 |
| 92 | 335.2 | 1290.7 | +955.5 | +74.0% ✓ C=1 |
| 94 | 350.5 | 1493.0 | +1142.5 | +76.5% ✓ C=1 |
| 96 | 360.1 | 1563.7 | +1203.7 | +77.0% ✓ C=1 |
| 98 | 403.2 | 1761.8 | +1358.7 | +77.1% ✓ C=1 |

---

## Özet

- **%5–%50 arası:** Fark küçük ve karışık; C=0 bazı milestone'larda minimal avantajlı.
- **%55'ten itibaren:** C=1 belirgin üstün. C=0'ın Run 2 ve Run 3'te bu bölgede büyük tıkanmalar yaşadığı görülmektedir.
- **Genel:** C=1 daha tutarlı ve ortalamada ~4.5x daha hızlı tamamlıyor.

> Not: C=0 Run 2'de `000824` dosyasında 3 blacklist hedefi tespit edilmiş, ilk hedefin atanma anına (elapsed=135 sn) kadar olan süre kullanılmıştır.  
> C=0 Run 3'te `205609` dosyasında 1 blacklist hedefi tespit edilmiş, elapsed=930 sn olarak kesilmiştir.
