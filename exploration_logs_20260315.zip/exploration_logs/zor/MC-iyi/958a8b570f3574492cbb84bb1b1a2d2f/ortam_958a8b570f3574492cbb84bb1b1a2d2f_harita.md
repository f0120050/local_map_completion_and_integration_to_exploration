# Ortam Harita Analizi: 958a8b570f3574492cbb84bb1b1a2d2f

---

## Temel Bilgiler

| Özellik | Değer |
|---------|-------|
| **Dosya formatı** | PGM (Netpbm grayscale) |
| **Çözünürlük** | 0.1 m/piksel |
| **Harita boyutu** | 448 × 736 px → 44.8 × 73.6 m |
| **Aktif alan (bilinen)** | 25.6 × 50.8 m |
| **Koordinat sistemi** | ROS map_saver standart (254=serbest, 0=engel, 205=bilinmiyor) |

---

## Alan Dağılımı

| Alan Tipi | Piksel | Gerçek Alan (m²) | Oran |
|-----------|-------:|------------------:|------|
| **Serbest (beyaz)** | 117.387 | 1.173.9 | %35.6 |
| **Engel/Duvar (siyah)** | 9.554 | 95.5 | %2.9 |
| **Bilinmiyor (gri)** | 202.787 | — | %61.5 |
| **Toplam** | 329.728 | 3.297 | %100 |

> Bilinen alan içindeki duvar yoğunluğu: **%7.5**

---

## Yapısal Analiz

| Metrik | Değer |
|--------|-------|
| **Dar koridor alanı** (5px erozyon) | 429.2 m² (%36.6) |
| **Açık alan** (5px erozyon sonrası) | 744.6 m² (%63.4) |
| **Açıklık oranı** | **%63.4** → Düşük açık plan |
| **Bağlı serbest bölge sayısı** | 124 (1 ana bölge ~1.171 m²) |
| **Duvar yoğunluğu** | %7.5 |

---

## Ortam Karakterizasyonu

Bu harita, **HouseExpo** veri setinden alınmış simüle bir iç mekan ortamını temsil etmektedir.

**Yapısal özellikler:**
- **Uzun ve dar** bir harita: 44.8 × 73.6 m, aktif alan 25.6 × 50.8 m — dikey eksende çok uzun, yatay eksende dar.
- Dar koridor oranı **%36.6** — analiz edilen tüm ortamlar arasında **en yüksek** değer. Haritanın üçte birinden fazlası dar geçitlerden oluşuyor.
- Duvar yoğunluğu **%7.5** — en yüksek değer (4615: %7.1 ile yakın).
- Açıklık oranı **%63.4** — tüm ortamlar arasında **en düşük**; çok bölmeli, dar koridorlu yapı.
- Bilinmeyen oran **%61.5** — orta düzey.

**Keşif açısından değerlendirme:**
- **Dar koridor oranı %36.6** bu ortamı yapısal olarak en zorlu hale getiriyor. Robot sürekli dar geçitlerden geçmek zorunda; bu hem sıkışma riskini hem de geri dönüş maliyetini artırıyor.
- Uzun-dar geometri, frontier tabanlı yöntemlerde "yanlış yön" seçimini özellikle cezalandırıyor — yanlış yöne gidip geri dönmek çok mesafe demek.
- Buna karşın MC bu ortamda ortalamada 6/7 milestone'da kazandı. En dramatik avantaj **80%** bandında (-266.7s ortalama). Bu, MC'nin dar koridorlarda bile erken keşif aşamasında yön tahminiyle avantaj sağlayabildiğini gösteriyor.
- **85-95% bandındaki mesafe paradoksu** (MC sürede önde, BL mesafede önde) dar koridor yapısıyla da açıklanabilir: MC tahminiyle uzak bir dar koridora "koşarak" gidiyor (süre kazanıyor), BL ise kısa mesafeli adımlarla ilerliyor.
- Max noktasında BL 195s önce tamamlıyor — büyük olasılıkla son birkaç küçük bölgeyi temizlerken MC daha uzun dolaşıyor.

**Altı ortam karşılaştırması:**

| Özellik | 10161... | 4615... | 3a4b... | 4bb7... | 1260... | 958a... |
|---------|----------|---------|---------|---------|---------|---------|
| Serbest alan (m²) | 1.781 | 407 | 1.438 | 1.353 | 1.077 | 1.174 |
| Dar koridor oranı | %14.5 | %28.1 | %19.9 | %24.3 | %20.1 | **%36.6** |
| Duvar yoğunluğu | %3.6 | %7.1 | %5.4 | %5.8 | %5.0 | **%7.5** |
| Bilinmeyen oran | %56.6 | %79.6 | %66.2 | %67.5 | %71.2 | %61.5 |
| Açıklık oranı | %85.5 | %71.9 | %80.1 | %75.7 | %79.9 | **%63.4** |
| MC kazandığı MS sayısı | 6/7 | 7/7 | 5/7 | 1/7 | 6/7 | **6/7** |

> Bu ortam en yüksek dar koridor oranıyla (%36.6) yapısal açıdan en zorlu; buna rağmen MC 6/7 ile güçlü performans sergiledi.

---

## Görsel

![Harita Görseli](map_958a8b570f3574492cbb84bb1b1a2d2f.png)

> Siyah = Duvar/Engel | Açık gri = Serbest alan | Orta gri = Bilinmiyor
