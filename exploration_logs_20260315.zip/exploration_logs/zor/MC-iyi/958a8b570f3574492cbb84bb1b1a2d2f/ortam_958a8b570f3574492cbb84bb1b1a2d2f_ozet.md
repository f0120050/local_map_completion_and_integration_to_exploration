# Ortam: 958a8b570f3574492cbb84bb1b1a2d2f
## MC vs Baseline — Tüm Run Detayları ve Ortalama

---

## Run 1

> MC: 2 dosya zinciri (140932 → 150633) | BL: 3 dosya zinciri (131228 → 134952 → 140621)

| Milestone | MC Süre (s) | MC Dist (m) | BL Süre (s) | BL Dist (m) | Δ Süre (s) | Δ Dist (m) | Kazanan |
|-----------|------------:|------------:|------------:|------------:|-----------:|-----------:|---------|
| **70%**  |   925.0 | 184.302 |   965.0 | 190.320 |   -40.0 |   -6.02 | **MC ✅** |
| **75%**  |   990.0 | 197.413 |  1045.0 | 205.117 |   -55.0 |   -7.70 | **MC ✅** |
| **80%**  |  1030.0 | 205.666 |  1325.0 | 262.411 | **-295.0** | **-56.75** | **MC ✅** |
| **85%**  |  1455.0 | 293.043 |  1415.0 | 278.514 |   +40.0 |  +14.53 | BL ✅ |
| **90%**  |  1500.0 | 302.156 |  1485.0 | 293.674 |   +15.0 |   +8.48 | BL ✅ |
| **95%**  |  1530.0 | 308.064 |  1530.0 | 302.146 |    +0.0 |   +5.92 | = (süre) / BL ✅ (dist) |
| **Max**  | 2170.0 (99.20%) | 440.246 | 1635.0 (98.96%) | 318.129 | +535.0 | +122.12 | BL ✅ (süre) / MC ✅ (kapsam) |

> MC 70-80% bandında güçlü (-295s 80%'de); 85%'den itibaren sıkışma yaşamış. Max'ta BL 535s önde.

---

## Run 2

> MC: tek dosya (152716) | BL: tek dosya (162344)

| Milestone | MC Süre (s) | MC Dist (m) | BL Süre (s) | BL Dist (m) | Δ Süre (s) | Δ Dist (m) | Kazanan |
|-----------|------------:|------------:|------------:|------------:|-----------:|-----------:|---------|
| **70%**  |   930.0 | 187.866 |   930.0 | 185.371 |    +0.0 |   +2.50 | = (süre) / BL ✅ (dist) |
| **75%**  |   990.0 | 200.290 |  1065.0 | 212.794 |   -75.0 |  -12.50 | **MC ✅** |
| **80%**  |  1260.0 | 256.351 |  1335.0 | 270.412 |   -75.0 |  -14.06 | **MC ✅** |
| **85%**  |  1320.0 | 269.188 |  1400.0 | 283.095 |   -80.0 |  -13.91 | **MC ✅** |
| **90%**  |  1380.0 | 280.841 |  1470.0 | 297.674 |   -90.0 |  -16.83 | **MC ✅** |
| **95%**  |  1425.0 | 290.095 |  1525.0 | 309.434 |  -100.0 |  -19.34 | **MC ✅** |
| **Max**  | 1545.0 (98.83%) | 304.374 | 1635.0 (98.81%) | 329.116 |   -90.0 |  -24.74 | **MC ✅** |

> En temiz run: MC 70%'de berabere, 75%'den itibaren Max dahil tüm milestone'larda kazanıyor.

---

## Run 3

> MC: tek dosya (193203) | BL: tek dosya (172140)

| Milestone | MC Süre (s) | MC Dist (m) | BL Süre (s) | BL Dist (m) | Δ Süre (s) | Δ Dist (m) | Kazanan |
|-----------|------------:|------------:|------------:|------------:|-----------:|-----------:|---------|
| **70%**  |   965.0 | 197.198 |  1165.0 | 215.273 |  -200.0 |  -18.08 | **MC ✅** |
| **75%**  |  1025.0 | 210.239 |  1210.0 | 223.882 |  -185.0 |  -13.64 | **MC ✅** |
| **80%**  |  1080.0 | 221.101 |  1510.0 | 287.137 | **-430.0** | **-66.04** | **MC ✅** |
| **85%**  |  1540.0 | 314.980 |  1560.0 | 297.582 |   -20.0 |  +17.40 | MC ✅ (süre) / BL ✅ (dist) |
| **90%**  |  1625.0 | 329.911 |  1650.0 | 314.076 |   -25.0 |  +15.84 | MC ✅ (süre) / BL ✅ (dist) |
| **95%**  |  1665.0 | 338.265 |  1695.0 | 322.951 |   -30.0 |  +15.31 | MC ✅ (süre) / BL ✅ (dist) |
| **Max**  | 2070.0 (99.10%) | 424.359 | 1930.0 (99.19%) | 372.269 |  +140.0 |  +52.09 | BL ✅ |

> 80%'de en büyük tek-milestone farkı: -430s. 85-95% bandında MC sürede önde ama mesafede BL daha verimli.

---

## 3 Run Ortalaması

| Milestone | MC Süre (s) | MC Dist (m) | BL Süre (s) | BL Dist (m) | Δ Süre (s) | Δ Dist (m) | Kazanan |
|-----------|------------:|------------:|------------:|------------:|-----------:|-----------:|---------|
| **70%**  |   940.0 | 189.79 |  1020.0 | 196.99 |   -80.0 |   -7.20 | **MC ✅** |
| **75%**  |  1001.7 | 202.65 |  1106.7 | 213.93 |  -105.0 |  -11.28 | **MC ✅** |
| **80%**  |  1123.3 | 227.71 |  1390.0 | 273.32 | **-266.7** | **-45.61** | **MC ✅** |
| **85%**  |  1438.3 | 292.40 |  1458.3 | 286.40 |   -20.0 |   +6.01 | MC ✅ (süre) / BL ✅ (dist) |
| **90%**  |  1501.7 | 304.30 |  1535.0 | 301.81 |   -33.3 |   +2.49 | MC ✅ (süre) / BL ✅ (dist) |
| **95%**  |  1540.0 | 312.14 |  1583.3 | 311.51 |   -43.3 |   +0.63 | MC ✅ (süre) / BL ✅ (dist) |
| **Max**  |  1928.3 | 389.66 |  1733.3 | 339.84 |  +195.0 |  +49.82 | **BL ✅** |

> Δ = MC − Baseline. Negatif değer MC'nin daha iyi olduğunu gösterir.

---

## Genel Değerlendirme

- MC **6/7 milestone'da** süre bazında kazanıyor — tek istisna **Max** noktası (+195s).
- En belirgin avantaj **80%** bandında: ortalama -266.7s. Bu ortamın en karakteristik özelliği.
- **85-95% bandında ilginç bir ayrışma**: MC sürede önde (-20s/-33s/-43s) ancak mesafede BL daha verimli (+6/+2.5/+0.6m). MC daha kısa sürede bitiyor ama daha uzun yol kat ediyor — zigzag veya geri dönüşler söz konusu olabilir.
- Max noktasında BL 195s önce tamamlıyor; kapsam neredeyse aynı (~99.1% MC vs ~99.1% BL).
- **Run varyansı**: Run 1'de MC 85%+ bandında sıkıştı (BL kazandı), Run 2 MC'nin en temiz run'u (Max dahil 6/7), Run 3'te MC 80%'de 430s önde. Yüksek varyans var ama ortalamada MC tutarlı şekilde üstün.
- Bu ortam en uzun keşif sürelerinden birine sahip: ortalama ~1928s (MC) ve ~1733s (BL) — büyük ve zorlu bir harita.
