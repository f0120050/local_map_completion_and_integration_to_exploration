# Ortam Harita Analizi: d0733a59055518fdb13f5835fbfa485c

---

## Temel Bilgiler

| Özellik | Değer |
|---------|-------|
| **Dosya formatı** | PGM (Netpbm grayscale) |
| **Çözünürlük** | 0.1 m/piksel |
| **Harita boyutu** | 768 × 448 px → 76.8 × 44.8 m |
| **Aktif alan (bilinen)** | 52.8 × 22.2 m |
| **Koordinat sistemi** | ROS map_saver standart (254=serbest, 0=engel, 205=bilinmiyor) |

---

## Alan Dağılımı

| Alan Tipi | Piksel | Gerçek Alan (m²) | Oran |
|-----------|-------:|------------------:|------|
| **Serbest (beyaz)** | 67.572 | 675.7 | %19.6 |
| **Engel/Duvar (siyah)** | 7.499 | 75.0 | %2.2 |
| **Bilinmiyor (gri)** | 268.993 | — | %78.2 |
| **Toplam** | 344.064 | 3.441 | %100 |

> Bilinen alan içindeki duvar yoğunluğu: **%10.0** — analiz edilen tüm ortamlar arasında en yüksek değer.

---

## Yapısal Analiz

| Metrik | Değer |
|--------|-------|
| **Dar koridor alanı** (5px erozyon) | 278.8 m² (%41.3) |
| **Açık alan** (5px erozyon sonrası) | 396.9 m² (%58.7) |
| **Açıklık oranı** | **%58.7** → Tüm ortamlar arasında en düşük |
| **Bağlı serbest bölge sayısı** | 160 (1 ana bölge ~670.8 m²) |
| **Duvar yoğunluğu** | **%10.0** |

---

## Ortam Karakterizasyonu

Bu harita, **HouseExpo** veri setinden alınmış simüle bir iç mekan ortamını temsil etmektedir.

**Yapısal özellikler:**
- **Yatay açıdan uzun ve dar**: 76.8 × 44.8 m boyutunda ancak aktif alan yalnızca 52.8 × 22.2 m — çok dar bir şerit yapısı.
- Serbest alan **675.7 m²** ile analiz edilen ortamların en küçük ikincisi (4615: 407 m²'den sonra).
- Bilinmeyen oran **%78.2** — tüm ortamlar arasında **en yüksek** değer (4615: %79.6 ile yakın).
- Dar koridor oranı **%41.3** — tüm ortamlar arasında **en yüksek** değer (958a: %36.6'yı geride bırakıyor).
- Duvar yoğunluğu **%10.0** — tüm ortamlar arasında **en yüksek** değer.
- Açıklık oranı **%58.7** — tüm ortamlar arasında **en düşük** değer.

**Keşif açısından değerlendirme:**
- Bu ortam tüm metrikler açısından en zorlu yapıya sahip: en yüksek bilinmeyen oran, en yüksek dar koridor oranı, en yüksek duvar yoğunluğu, en düşük açıklık oranı.
- Buna rağmen MC ortalamada **7/7 milestone'da** kazandı — oldukça dikkat çekici bir sonuç. Yüksek bilinmeyen oran ve dar yapı, MC'nin tahmin avantajını doğru kullandığını gösteriyor.
- Her üç run'da da %95-96 civarında keşif durdu; %98 milestone'a ulaşılamadı. Bu ortamın bazı bölgelerinin robot için erişilmez olduğuna işaret ediyor — muhtemelen çok dar geçitler veya izole alanlar.
- Run 1'deki 75-85% bandı sıkışması (MC +275s) yüksek dar koridor oranıyla tutarlı: yanlış tahminle girilen dar bir bölgeden geri dönmek çok zaman alıyor.
- Run 2 ve 3'te bu sorun yaşanmadı — MC'nin doğru frontier seçiminde dar ortamlarda bile net avantaj sağlayabildiğini gösteriyor.

**Sekiz ortam tam karşılaştırması:**

| Özellik | 10161 | 4615 | 3a4b | 4bb7 | 1260 | 958a | d073 |
|---------|-------|------|------|------|------|------|------|
| Serbest (m²) | 1.781 | 407 | 1.438 | 1.353 | 1.077 | 1.174 | 676 |
| Dar koridor (%) | 14.5 | 28.1 | 19.9 | 24.3 | 20.1 | 36.6 | **41.3** |
| Duvar yoğunluğu (%) | 3.6 | 7.1 | 5.4 | 5.8 | 5.0 | 7.5 | **10.0** |
| Bilinmeyen (%) | 56.6 | 79.6 | 66.2 | 67.5 | 71.2 | 61.5 | **78.2** |
| Açıklık (%) | 85.5 | 71.9 | 80.1 | 75.7 | 79.9 | 63.4 | **58.7** |
| MC kazandığı MS | 6/7 | 7/7 | 5/7 | 1/7 | 6/7 | 6/7 | **7/7** |

> d073 ortamı yapısal olarak en zorlu profili taşımasına rağmen MC'nin en güçlü sonuçlarından birini ürettiği ortam.

---

## Görsel

![Harita Görseli](map_d0733a59055518fdb13f5835fbfa485c.png)

> Siyah = Duvar/Engel | Açık gri = Serbest alan | Orta gri = Bilinmiyor
