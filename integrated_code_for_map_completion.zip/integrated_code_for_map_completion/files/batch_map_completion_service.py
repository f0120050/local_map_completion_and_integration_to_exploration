#!/usr/bin/env python
"""
Batch Map Completion Service Node

This node provides a ROS service for batch map completion using a CVAE deep learning model.
It receives multiple partial map patches and returns completed patches in a single service call.

Service: /complete_map_batch
Type: explore_lite/MapCompletionBatch

Author: [Your Name]
Date: 2025
"""

import rospy
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import time
from explore_lite.srv import MapCompletionBatch, MapCompletionBatchResponse

# Map value constants
OBSTACLE = 0
UNKNOWN = 205
KNOWN = 254


class CVAEWithSkips(nn.Module):
    """
    Conditional Variational Autoencoder with skip connections for map completion.
    Architecture: Encoder-Decoder with optional skip connections and z-residual.
    """
    def __init__(self, input_dim=(1, 32, 32), hidden_dim=64, latent_dim=32, last_channel=1,
                 num_layers=3, use_skip_connections=False, use_z_residual=True):
        super(CVAEWithSkips, self).__init__()

        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.latent_dim = latent_dim
        self.last_channel = last_channel
        self.num_layers = num_layers
        self.use_skip_connections = use_skip_connections
        self.use_z_residual = use_z_residual

        # Encoder
        self.encoder_layers = nn.ModuleList()
        in_channels = input_dim[0]
        out_channels = 32
        current_size = input_dim[1]

        # Track skip channels for correct decoder setup
        self.skip_channels_list = []

        for _ in range(num_layers):
            if self.use_skip_connections:
                self.skip_channels_list.append(in_channels)

            self.encoder_layers.append(nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=4, stride=2, padding=1),
                nn.BatchNorm2d(out_channels),
                nn.ReLU()
            ))
            in_channels = out_channels
            out_channels *= 2
            current_size //= 2

            if current_size < 4:
                break

        self.skip_channels_list = list(reversed(self.skip_channels_list))

        self.encoded_channels = in_channels
        self.encoded_size = current_size
        fc_dim = self.encoded_channels * self.encoded_size ** 2
        self.fc_mu = nn.Linear(fc_dim, latent_dim)
        self.fc_log_var = nn.Linear(fc_dim, latent_dim)

        # Decoder input (latent + condition)
        condition_dim = input_dim[0] * input_dim[1] * input_dim[2]
        self.decoder_input = nn.Linear(latent_dim + condition_dim, fc_dim)

        # z residual
        self.z_residual_fc = nn.Linear(latent_dim + condition_dim, fc_dim)

        # Decoder layers
        self.decoder_layers = nn.ModuleList()
        current_channels = self.encoded_channels

        for i in range(len(self.skip_channels_list)):
            skip_channels = self.skip_channels_list[i] if self.use_skip_connections else 0
            in_ch = current_channels + skip_channels
            out_ch = current_channels // 2
            self.decoder_layers.append(nn.Sequential(
                nn.ConvTranspose2d(in_ch, out_ch, kernel_size=4, stride=2, padding=1),
                nn.BatchNorm2d(out_ch),
                nn.ReLU()
            ))
            current_channels = out_ch

        self.final_layer = nn.ConvTranspose2d(current_channels, last_channel, kernel_size=1)

    def encode(self, x):
        skip_connections = []
        for layer in self.encoder_layers:
            if self.use_skip_connections:
                skip_connections.append(x)
            x = layer(x)
        mu = self.fc_mu(x.view(x.size(0), -1))
        log_var = self.fc_log_var(x.view(x.size(0), -1))
        return mu, log_var, skip_connections

    def reparameterize(self, mu, log_var):
        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z, condition, skip_connections):
        condition = condition.view(condition.shape[0], -1)
        z_cond = torch.cat([z, condition], dim=1)
        x = self.decoder_input(z_cond)
        x = x.view(-1, self.encoded_channels, self.encoded_size, self.encoded_size)

        if self.use_z_residual:
            z_residual = self.z_residual_fc(z_cond).view(x.shape)
            x = x + z_residual

        for i, layer in enumerate(self.decoder_layers):
            if self.use_skip_connections and i < len(skip_connections):
                skip = skip_connections[-(i + 1)]

                if skip.shape[2:] != x.shape[2:]:
                    skip = F.interpolate(skip, size=x.shape[2:], mode='bilinear', align_corners=False)

                x = torch.cat([x, skip], dim=1)

            x = layer(x)

        x = self.final_layer(x)
        return x

    def forward(self, x, condition):
        mu, log_var, skip_connections = self.encode(x)
        z = self.reparameterize(mu, log_var)
        recon_x = self.decode(z, condition, skip_connections)
        return recon_x, mu, log_var


class BatchMapCompletionService:
    """
    ROS service node for batch map completion using CVAE.
    """
    
    def __init__(self):
        rospy.init_node('batch_map_completion_service', anonymous=False)
        
        # Parameters
        self.patch_size = rospy.get_param('~patch_size', 32)
        self.use_gpu = rospy.get_param('~use_gpu', True)
        self.model_path = rospy.get_param('~model_path', 
            '/home/selma/robotlar_ws/src/map_completion/scripts/cvae_full_32_64_3000.pth')
        self.max_batch_size = rospy.get_param('~max_batch_size', 50)
        
        # Device setup
        self.device = torch.device("cuda" if torch.cuda.is_available() and self.use_gpu else "cpu")
        rospy.loginfo(f"Using device: {self.device}")
        
        # Load model
        self.model = None
        self.load_model()
        
        # Statistics
        self.total_requests = 0
        self.total_patches = 0
        self.total_inference_time = 0.0
        
        # Create service
        self.service = rospy.Service('/complete_map_batch', 
                                     MapCompletionBatch, 
                                     self.handle_batch_completion)
        
        rospy.loginfo("✓ Batch Map Completion Service ready")
        rospy.loginfo(f"  - Model: {self.model_path}")
        rospy.loginfo(f"  - Device: {self.device}")
        rospy.loginfo(f"  - Patch size: {self.patch_size}x{self.patch_size}")
        rospy.loginfo(f"  - Max batch size: {self.max_batch_size}")
    
    def load_model(self):
        """Load the CVAE model from checkpoint."""
        try:
            # Model architecture parameters (must match training)
            use_skip = True
            last_channel = 1
            num_layers = 12
            latent_dim = 32
            
            rospy.loginfo("Loading CVAE model...")
            
            self.model = CVAEWithSkips(
                input_dim=(1, self.patch_size, self.patch_size),
                hidden_dim=64,
                latent_dim=latent_dim,
                last_channel=last_channel,
                num_layers=num_layers,
                use_skip_connections=use_skip,
                use_z_residual=use_skip
            )
            
            # Load weights
            self.model.load_state_dict(torch.load(self.model_path, map_location=self.device))
            self.model.to(self.device)
            self.model.eval()
            
            rospy.loginfo("✓ CVAE model loaded successfully")
            
        except Exception as e:
            rospy.logerr(f"Failed to load CVAE model: {e}")
            raise
    
    def quantize_to_discrete_values(self, tensor, values):
        """
        Quantize continuous tensor values to nearest discrete values.
        
        Args:
            tensor: Input tensor
            values: List of discrete values [0, 0.5, 1.0]
        
        Returns:
            Quantized tensor
        """
        values_tensor = torch.tensor(values, device=tensor.device, dtype=tensor.dtype)
        distances = torch.abs(tensor.unsqueeze(-1) - values_tensor)
        indices = torch.argmin(distances, dim=-1)
        return values_tensor[indices]
    
    def preprocess_patches(self, patches_flat, num_patches):
        """
        Convert flattened uint8 patches to normalized torch tensors.
        
        Args:
            patches_flat: Flattened numpy array of patches
            num_patches: Number of patches
        
        Returns:
            Preprocessed tensor (N, 1, H, W)
        """
        P = self.patch_size
        
        # Reshape to (N, H, W)
        patches = np.array(patches_flat, dtype=np.uint8).reshape(num_patches, P, P)
        
        # Convert to torch tensor
        patches_tensor = torch.from_numpy(patches).float()
        
        # Add channel dimension: (N, 1, H, W)
        patches_tensor = patches_tensor.unsqueeze(1).to(self.device)
        
        # Normalize: 0 (obstacle) → 0, 205 (unknown) → 0.5, 254 (known) → 1.0
        patches_tensor = torch.where(patches_tensor == UNKNOWN, 0.5, patches_tensor)
        patches_tensor = torch.where(patches_tensor == KNOWN, 1.0, patches_tensor)
        patches_tensor = torch.where(patches_tensor == OBSTACLE, 0.0, patches_tensor)
        
        return patches_tensor
    
    def postprocess_patches(self, completed_tensor):
        """
        Convert normalized tensor back to uint8 occupancy values.
        
        Args:
            completed_tensor: Network output (N, 1, H, W)
        
        Returns:
            Flattened numpy array of uint8 values
        """
        # Apply sigmoid
        completed_tensor = F.sigmoid(completed_tensor)
        
        # Quantize to discrete values [0, 0.5, 1.0]
        completed_tensor = self.quantize_to_discrete_values(completed_tensor, [0.0, 0.5, 1.0])
        
        # Convert back to occupancy values
        completed_tensor = torch.where(completed_tensor == 1.0, KNOWN, completed_tensor)
        completed_tensor = torch.where(completed_tensor == 0.5, UNKNOWN, completed_tensor)
        completed_tensor = torch.where(completed_tensor == 0.0, OBSTACLE, completed_tensor)
        
        # Remove channel dimension and convert to numpy
        completed_patches = completed_tensor.squeeze(1).cpu().numpy().astype(np.uint8)
        
        # Flatten all patches into 1D array
        return completed_patches.flatten().tolist()
    
    def handle_batch_completion(self, req):
        """
        Service callback for batch map completion.
        
        Args:
            req: MapCompletionBatchRequest
        
        Returns:
            MapCompletionBatchResponse
        """
        response = MapCompletionBatchResponse()
        
        try:
            start_time = time.time()
            
            # Validate request
            if req.num_patches <= 0:
                response.success = False
                response.message = "num_patches must be > 0"
                return response
            
            if req.num_patches > self.max_batch_size:
                response.success = False
                response.message = f"Batch size {req.num_patches} exceeds max {self.max_batch_size}"
                return response
            
            expected_size = req.num_patches * req.patch_size * req.patch_size
            if len(req.patches) != expected_size:
                response.success = False
                response.message = f"Expected {expected_size} values, got {len(req.patches)}"
                return response
            
            if len(req.frontier_x) != req.num_patches or len(req.frontier_y) != req.num_patches:
                response.success = False
                response.message = "Frontier coordinates length mismatch"
                return response
            
            # Log request info
            rospy.loginfo(f"Processing batch: {req.num_patches} patches of size {req.patch_size}x{req.patch_size}")
            
            # Preprocess patches
            patches_tensor = self.preprocess_patches(req.patches, req.num_patches)
            
            # Create mask (unknown pixels)
            unknown_value = 0.5
            mask = (patches_tensor == unknown_value).float()
            
            # Inference
            inference_start = time.time()
            
            with torch.no_grad():
                completed_tensor, _, _ = self.model(patches_tensor, mask)
            
            inference_time = (time.time() - inference_start) * 1000  # Convert to ms
            
            # Postprocess
            completed_patches_flat = self.postprocess_patches(completed_tensor)
            
            # Build response
            response.completed_patches = completed_patches_flat
            response.success = True
            response.message = f"Completed {req.num_patches} patches"
            response.inference_time_ms = inference_time
            
            # Update statistics
            total_time = (time.time() - start_time) * 1000
            self.total_requests += 1
            self.total_patches += req.num_patches
            self.total_inference_time += inference_time
            
            # Log timing
            rospy.loginfo(f"✓ Batch completion: {req.num_patches} patches in {inference_time:.1f}ms "
                         f"({inference_time/req.num_patches:.1f}ms/patch, total {total_time:.1f}ms)")
            
            # Log stats every 10 requests
            if self.total_requests % 10 == 0:
                avg_time = self.total_inference_time / self.total_patches
                rospy.loginfo(f"Stats: {self.total_requests} requests, {self.total_patches} patches, "
                             f"avg {avg_time:.1f}ms/patch")
            
            return response
            
        except Exception as e:
            rospy.logerr(f"Batch completion failed: {e}")
            import traceback
            traceback.print_exc()
            
            response.success = False
            response.message = f"Error: {str(e)}"
            return response


def main():
    """Main entry point."""
    try:
        service_node = BatchMapCompletionService()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
    except Exception as e:
        rospy.logerr(f"Fatal error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
