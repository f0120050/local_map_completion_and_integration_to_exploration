#!/usr/bin/env python
"""
Batch Map Completion Service Node - UNet Version

This node provides a ROS service for batch map completion using a UNet deep learning model.
It receives multiple partial map patches and returns completed patches in a single service call.

Service: /complete_map_batch
Type: explore_lite/MapCompletionBatch

Author: Selma
Date: 2025
"""

import rospy
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import time
from explore_lite.srv import MapCompletionBatch, MapCompletionBatchResponse

# Import UNet models
from unet import UNet33Res, UNet33ResAtt

# Map value constants
OBSTACLE = 0
UNKNOWN = 205
KNOWN = 254


class BatchMapCompletionService:
    """
    ROS service node for batch map completion using UNet.
    """
    
    def __init__(self):
        rospy.init_node('batch_map_completion_service', anonymous=False)
        
        # Parameters
        self.patch_size = rospy.get_param('~patch_size', 32)
        self.use_gpu = rospy.get_param('~use_gpu', True)
        self.model_path = rospy.get_param('~model_path', 
            '/home/selma/robotlar_ws/src/map_completion/scripts/unet_model.pth')
        self.max_batch_size = rospy.get_param('~max_batch_size', 50)
        
        # Model architecture parameters
        self.use_attention = rospy.get_param('~use_attention', False)  # True for UNet33ResAtt
        self.base_channels = rospy.get_param('~base_channels', 64)
        self.norm_type = rospy.get_param('~norm_type', 'instance')  # instance, batch, none
        self.activation = rospy.get_param('~activation', 'relu')     # relu, lrelu, gelu
        self.final_activation = rospy.get_param('~final_activation', 'sigmoid')  # sigmoid, none, tanh
        
        # Device setup
        self.device = torch.device("cuda" if torch.cuda.is_available() and self.use_gpu else "cpu")
        rospy.loginfo(f"Using device: {self.device}")
        
        # Load model
        self.model = None
        self.load_model()
        
        # Statistics
        self.total_requests = 0
        self.total_patches = 0
        self.total_inference_time = 0.0
        
        # Create service
        self.service = rospy.Service('/complete_map_batch', 
                                     MapCompletionBatch, 
                                     self.handle_batch_completion)
        
        model_type = "UNet33ResAtt (with attention)" if self.use_attention else "UNet33Res"
        rospy.loginfo("✓ Batch Map Completion Service ready")
        rospy.loginfo(f"  - Model type: {model_type}")
        rospy.loginfo(f"  - Model path: {self.model_path}")
        rospy.loginfo(f"  - Device: {self.device}")
        rospy.loginfo(f"  - Patch size: {self.patch_size}x{self.patch_size}")
        rospy.loginfo(f"  - Base channels: {self.base_channels}")
        rospy.loginfo(f"  - Normalization: {self.norm_type}")
        rospy.loginfo(f"  - Max batch size: {self.max_batch_size}")
    
    def load_model(self):
        """Load the UNet model from checkpoint."""
        try:
            rospy.loginfo("Loading UNet model...")
            
            # Choose model architecture based on attention parameter
            if self.use_attention:
                self.model = UNet33ResAtt(
                    in_ch=1,
                    out_ch=1,
                    base=self.base_channels,
                    norm=self.norm_type,
                    act=self.activation,
                    dropout=0.0,
                    final_activation=self.final_activation
                )
                rospy.loginfo("Using UNet33ResAtt (with attention gates)")
            else:
                self.model = UNet33Res(
                    in_ch=1,
                    out_ch=1,
                    base=self.base_channels,
                    norm=self.norm_type,
                    act=self.activation,
                    dropout=0.0,
                    final_activation=self.final_activation
                )
                rospy.loginfo("Using UNet33Res (without attention)")
            
            # Load weights
            checkpoint = torch.load(self.model_path, map_location=self.device)
            
            # Handle different checkpoint formats
            if isinstance(checkpoint, dict):
                if 'model_state_dict' in checkpoint:
                    self.model.load_state_dict(checkpoint['model_state_dict'])
                    rospy.loginfo(f"Loaded from checkpoint (epoch {checkpoint.get('epoch', 'unknown')})")
                elif 'state_dict' in checkpoint:
                    self.model.load_state_dict(checkpoint['state_dict'])
                else:
                    self.model.load_state_dict(checkpoint)
            else:
                self.model.load_state_dict(checkpoint)
            
            self.model.to(self.device)
            self.model.eval()
            
            rospy.loginfo("✓ UNet model loaded successfully")
            
        except Exception as e:
            rospy.logerr(f"Failed to load UNet model: {e}")
            import traceback
            traceback.print_exc()
            raise
    
    def quantize_to_discrete_values(self, tensor, values):
        """
        Quantize continuous tensor values to nearest discrete values.
        
        Args:
            tensor: Input tensor
            values: List of discrete values [0, 0.5, 1.0]
        
        Returns:
            Quantized tensor
        """
        values_tensor = torch.tensor(values, device=tensor.device, dtype=tensor.dtype)
        distances = torch.abs(tensor.unsqueeze(-1) - values_tensor)
        indices = torch.argmin(distances, dim=-1)
        return values_tensor[indices]
    
    def preprocess_patches(self, patches_flat, num_patches):
        """
        Convert flattened uint8 patches to normalized torch tensors.
        
        Args:
            patches_flat: Flattened numpy array of patches
            num_patches: Number of patches
        
        Returns:
            Preprocessed tensor (N, 1, H, W)
        """
        P = self.patch_size
        
        # Reshape to (N, H, W)
        patches = np.array(patches_flat, dtype=np.uint8).reshape(num_patches, P, P)
        
        # Convert to torch tensor
        patches_tensor = torch.from_numpy(patches).float()
        
        # Add channel dimension: (N, 1, H, W)
        patches_tensor = patches_tensor.unsqueeze(1).to(self.device)
        
        # Normalize: 0 (obstacle) → 0, 205 (unknown) → 0.5, 254 (known) → 1.0
        patches_tensor = torch.where(patches_tensor == UNKNOWN, 0.5, patches_tensor)
        patches_tensor = torch.where(patches_tensor == KNOWN, 1.0, patches_tensor)
        patches_tensor = torch.where(patches_tensor == OBSTACLE, 0.0, patches_tensor)
        
        return patches_tensor
    
    def postprocess_patches(self, completed_tensor):
        """
        Convert normalized tensor back to uint8 occupancy values.
        
        Args:
            completed_tensor: Network output (N, 1, H, W)
        
        Returns:
            Flattened numpy array of uint8 values
        """
        # If final_activation is 'none', apply sigmoid here
        if self.final_activation == 'none':
            completed_tensor = torch.sigmoid(completed_tensor)
        
        # Quantize to discrete values [0, 0.5, 1.0]
        completed_tensor = self.quantize_to_discrete_values(completed_tensor, [0.0, 0.5, 1.0])
        
        # Convert back to occupancy values
        completed_tensor = torch.where(completed_tensor == 1.0, KNOWN, completed_tensor)
        completed_tensor = torch.where(completed_tensor == 0.5, UNKNOWN, completed_tensor)
        completed_tensor = torch.where(completed_tensor == 0.0, OBSTACLE, completed_tensor)
        
        # Remove channel dimension and convert to numpy
        completed_patches = completed_tensor.squeeze(1).cpu().numpy().astype(np.uint8)
        
        # Flatten all patches into 1D array
        return completed_patches.flatten().tolist()
    
    def handle_batch_completion(self, req):
        """
        Service callback for batch map completion.
        
        Args:
            req: MapCompletionBatchRequest
        
        Returns:
            MapCompletionBatchResponse
        """
        response = MapCompletionBatchResponse()
        
        try:
            start_time = time.time()
            
            # Validate request
            if req.num_patches <= 0:
                response.success = False
                response.message = "num_patches must be > 0"
                return response
            
            if req.num_patches > self.max_batch_size:
                response.success = False
                response.message = f"Batch size {req.num_patches} exceeds max {self.max_batch_size}"
                return response
            
            expected_size = req.num_patches * req.patch_size * req.patch_size
            if len(req.patches) != expected_size:
                response.success = False
                response.message = f"Expected {expected_size} values, got {len(req.patches)}"
                return response
            
            if len(req.frontier_x) != req.num_patches or len(req.frontier_y) != req.num_patches:
                response.success = False
                response.message = "Frontier coordinates length mismatch"
                return response
            
            # Log request info
            rospy.loginfo(f"Processing batch: {req.num_patches} patches of size {req.patch_size}x{req.patch_size}")
            
            # Preprocess patches
            patches_tensor = self.preprocess_patches(req.patches, req.num_patches)
            
            # Inference (UNet is simpler than CVAE - no condition/mask needed)
            inference_start = time.time()
            
            with torch.no_grad():
                completed_tensor = self.model(patches_tensor)
            
            inference_time = (time.time() - inference_start) * 1000  # Convert to ms
            
            # Postprocess
            completed_patches_flat = self.postprocess_patches(completed_tensor)
            
            # Build response
            response.completed_patches = completed_patches_flat
            response.success = True
            response.message = f"Completed {req.num_patches} patches"
            response.inference_time_ms = inference_time
            
            # Update statistics
            total_time = (time.time() - start_time) * 1000
            self.total_requests += 1
            self.total_patches += req.num_patches
            self.total_inference_time += inference_time
            
            # Log timing
            rospy.loginfo(f"✓ Batch completion: {req.num_patches} patches in {inference_time:.1f}ms "
                         f"({inference_time/req.num_patches:.1f}ms/patch, total {total_time:.1f}ms)")
            
            # Log stats every 10 requests
            if self.total_requests % 10 == 0:
                avg_time = self.total_inference_time / self.total_patches
                rospy.loginfo(f"Stats: {self.total_requests} requests, {self.total_patches} patches, "
                             f"avg {avg_time:.1f}ms/patch")
            
            return response
            
        except Exception as e:
            rospy.logerr(f"Batch completion failed: {e}")
            import traceback
            traceback.print_exc()
            
            response.success = False
            response.message = f"Error: {str(e)}"
            return response


def main():
    """Main entry point."""
    try:
        service_node = BatchMapCompletionService()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
    except Exception as e:
        rospy.logerr(f"Fatal error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
