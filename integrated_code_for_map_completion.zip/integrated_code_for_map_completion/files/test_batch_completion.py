#!/usr/bin/env python
"""
Test client for batch map completion service.

This script tests the batch completion service by sending synthetic partial patches
and displaying the timing results.

Usage:
    rosrun map_completion test_batch_completion.py
"""

import rospy
import numpy as np
import time
from explore_lite.srv import MapCompletionBatch, MapCompletionBatchRequest

# Map constants
OBSTACLE = 0
UNKNOWN = 205
KNOWN = 254


def create_test_patch(patch_size=32, unknown_ratio=0.3):
    """
    Create a synthetic test patch with some known and unknown regions.
    
    Args:
        patch_size: Size of the patch (default 32x32)
        unknown_ratio: Fraction of pixels that are unknown
    
    Returns:
        Flattened patch as list
    """
    patch = np.zeros((patch_size, patch_size), dtype=np.uint8)
    
    # Create some structure
    # Add some walls (obstacles)
    patch[0:2, :] = OBSTACLE  # Top wall
    patch[-2:, :] = OBSTACLE  # Bottom wall
    patch[:, 0:2] = OBSTACLE  # Left wall
    patch[:, -2:] = OBSTACLE  # Right wall
    
    # Add a random internal wall
    mid = patch_size // 2
    patch[mid-1:mid+1, 5:-5] = OBSTACLE
    
    # Fill center with known space
    patch[5:mid-2, 5:-5] = KNOWN
    patch[mid+2:-5, 5:-5] = KNOWN
    
    # Add unknown regions
    num_unknown = int(patch_size * patch_size * unknown_ratio)
    unknown_indices = np.random.choice(patch_size * patch_size, num_unknown, replace=False)
    patch_flat = patch.flatten()
    patch_flat[unknown_indices] = UNKNOWN
    
    return patch_flat.tolist()


def test_batch_completion(num_patches=10, patch_size=32):
    """
    Test the batch completion service.
    
    Args:
        num_patches: Number of patches to send
        patch_size: Size of each patch
    """
    rospy.init_node('test_batch_completion', anonymous=True)
    
    # Wait for service
    service_name = '/complete_map_batch'
    rospy.loginfo(f"Waiting for service {service_name}...")
    rospy.wait_for_service(service_name, timeout=10.0)
    rospy.loginfo("✓ Service available")
    
    try:
        # Create service proxy
        complete_batch = rospy.ServiceProxy(service_name, MapCompletionBatch)
        
        # Prepare request
        req = MapCompletionBatchRequest()
        req.patch_size = patch_size
        req.num_patches = num_patches
        
        # Generate test patches
        rospy.loginfo(f"Generating {num_patches} test patches...")
        all_patches = []
        
        for i in range(num_patches):
            # Create test patch with 30% unknown pixels
            patch = create_test_patch(patch_size, unknown_ratio=0.3)
            all_patches.extend(patch)
            
            # Add frontier coordinates (dummy values)
            req.frontier_x.append(float(i) * 2.0)
            req.frontier_y.append(float(i) * 1.5)
        
        req.patches = all_patches
        
        rospy.loginfo(f"Sending {num_patches} patches ({len(all_patches)} values)...")
        
        # Call service
        start_time = time.time()
        response = complete_batch(req)
        total_time = (time.time() - start_time) * 1000
        
        # Check response
        if response.success:
            rospy.loginfo("✓ Batch completion SUCCESS")
            rospy.loginfo(f"  - Message: {response.message}")
            rospy.loginfo(f"  - Inference time: {response.inference_time_ms:.1f}ms")
            rospy.loginfo(f"  - Total time: {total_time:.1f}ms")
            rospy.loginfo(f"  - Avg per patch: {response.inference_time_ms/num_patches:.1f}ms")
            rospy.loginfo(f"  - Received {len(response.completed_patches)} values")
            
            # Verify response size
            expected_size = num_patches * patch_size * patch_size
            if len(response.completed_patches) == expected_size:
                rospy.loginfo("✓ Response size correct")
            else:
                rospy.logwarn(f"Response size mismatch: expected {expected_size}, got {len(response.completed_patches)}")
            
            # Print statistics
            completed_array = np.array(response.completed_patches, dtype=np.uint8)
            rospy.loginfo(f"  - Completed patches stats:")
            rospy.loginfo(f"    OBSTACLE pixels: {np.sum(completed_array == OBSTACLE)}")
            rospy.loginfo(f"    UNKNOWN pixels: {np.sum(completed_array == UNKNOWN)}")
            rospy.loginfo(f"    KNOWN pixels: {np.sum(completed_array == KNOWN)}")
            
        else:
            rospy.logerr(f"Batch completion FAILED: {response.message}")
        
        return response.success
        
    except rospy.ServiceException as e:
        rospy.logerr(f"Service call failed: {e}")
        return False
    except rospy.ROSException as e:
        rospy.logerr(f"ROS error: {e}")
        return False


def run_performance_test():
    """Run performance tests with different batch sizes."""
    rospy.loginfo("=" * 60)
    rospy.loginfo("Running performance tests...")
    rospy.loginfo("=" * 60)
    
    test_sizes = [1, 5, 10, 20, 30]
    
    for size in test_sizes:
        rospy.loginfo(f"\n--- Testing with {size} patches ---")
        success = test_batch_completion(num_patches=size, patch_size=32)
        if not success:
            rospy.logwarn(f"Test with {size} patches failed")
        rospy.sleep(1.0)  # Small delay between tests
    
    rospy.loginfo("\n" + "=" * 60)
    rospy.loginfo("Performance tests complete!")
    rospy.loginfo("=" * 60)


if __name__ == '__main__':
    try:
        # Run single test
        # test_batch_completion(num_patches=10, patch_size=32)
        
        # Or run performance test suite
        run_performance_test()
        
    except rospy.ROSInterruptException:
        pass
    except Exception as e:
        rospy.logerr(f"Test failed: {e}")
        import traceback
        traceback.print_exc()
