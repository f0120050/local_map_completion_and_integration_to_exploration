# engines/evaluator.py (imports)
from __future__ import annotations

import os
import json
import csv
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import torch
import torch.nn.functional as F
from tqdm import tqdm
import numpy as np

from metrics.classification import (
    compute_iou_macro,
    compute_f1_macro,
    multiclass_pixel_accuracy,
)
from metrics.image_quality import (
    compute_mse_rmse,
    compute_uqi,
    compute_ergas,
    compute_scc,
    compute_ssim_index,
)
from utils.tensor_ops import (
    quantize_three,
    denormalize_for_display,
    blend_generated_with_condition,
    build_eval_mask,
)

@torch.no_grad()
def evaluate(
    model,
    loader,
    device: torch.device,
    results_dir: str,
    blender: bool = True,
    sampler: Optional[object] = None,
    run_name: str = "eval",
    save_visuals_every_batches: int = 1,
) -> Dict[str, object]:
    """
    Generic evaluator for three families:
      - ViT/CVAE-style:     gen = sigmoid(model.sample/forward(cond))
      - RePaint (diffusion): gen = sampler.repaint_sample(model, cond, ...)
      - GAN generators:      gen = model(cond)  (already in [0,1])

    Steps:
      1) forward generation
      2) blended = copy known from cond, unknown from gen (if blender=True)
      3) compute FULL & MASKED metrics
      4) save per-image panels every K batches, write CSV + summary JSON

    Returns a small dict with file paths and summary.
    """
    os.makedirs(results_dir, exist_ok=True)
    img_dir = os.path.join(results_dir, "images")
    os.makedirs(img_dir, exist_ok=True)

    # ---- CSV header ----
    csv_path = os.path.join(results_dir, f"{run_name}_per_image_metrics.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "index",
            # full
            "full_IoU", "full_MSE", "full_RMSE", "full_UQI",
            "full_ERGAS", "full_SCC", "full_SSIM", "full_F1", "full_Accuracy",
            # masked
            "masked_IoU", "masked_MSE", "masked_RMSE", "masked_UQI",
            "masked_ERGAS", "masked_SCC", "masked_SSIM", "masked_F1", "masked_Accuracy",
        ])

    # ---- aggregators ----
    agg = {
        "full_IoU": [], "full_MSE": [], "full_RMSE": [], "full_UQI": [],
        "full_ERGAS": [], "full_SCC": [], "full_SSIM": [], "full_F1": [], "full_Accuracy": [],
        "masked_IoU": [], "masked_MSE": [], "masked_RMSE": [], "masked_UQI": [],
        "masked_ERGAS": [], "masked_SCC": [], "masked_SSIM": [], "masked_F1": [], "masked_Accuracy": [],
    }

    model.eval()
    idx_global = 0

    for bidx, (cond_b, tgt_b) in enumerate(tqdm(loader, desc="Evaluating", leave=True)):
        cond_b = cond_b.to(device, non_blocking=True)  # (B,1,H,W) in {0,.5,1}
        tgt_b  = tgt_b.to(device,  non_blocking=True)  # (B,1,H,W) in {0,.5,1}

        # ---------- 1) forward ----------
        if sampler is not None:
            # RePaint-style diffusion path
            # Expect sampler to expose repaint_sample(model, cond, **kwargs)
            if hasattr(sampler, "repaint_sample"):
                gen_b = sampler.repaint_sample(model, cond_b)
            elif callable(sampler):
                gen_b = sampler(model, cond_b)
            else:
                raise ValueError("Provided sampler is neither callable nor has `repaint_sample`.")
            gen_b = gen_b.clamp(0, 1)

        else:
            # ViT/CVAE or GAN generator
            if hasattr(model, "sample"):   # ViT/CVAE path
                out = model.sample(cond_b)
            else:                          # GAN / plain forward
                out = model(cond_b)

            # Decide if 'out' are logits (single channel) or class logits, or already probabilities
            if out.dim() == 4 and out.size(1) > 1:
                # Multi-class logits (e.g., 3 classes -> map by expectation to [0,1])
                probs = torch.softmax(out, dim=1)
                values = torch.tensor([0.0, 0.5, 1.0], device=device).view(1, 3, 1, 1)
                gen_b = (probs * values).sum(dim=1, keepdim=True)
            else:
                # Single channel; if not in [0,1], pass through sigmoid
                if out.min() < 0.0 or out.max() > 1.0:
                    gen_b = torch.sigmoid(out)
                else:
                    gen_b = out
            gen_b = gen_b.clamp(0, 1)

        # ---------- 2) (optional) blend ----------
        if blender:
            cond_q = quantize_three(cond_b)
            gen_q  = quantize_three(gen_b)
            blended_b = blend_generated_with_condition(cond_q, gen_q)  # stays in {0,.5,1}
        else:
            # evaluate raw generation
            blended_b = gen_b
            cond_q    = quantize_three(cond_b)

        tgt_q = quantize_three(tgt_b)

        # ---------- 3) metrics (FULL + MASKED unknown in condition) ----------
        # FULL (use blended vs tgt; both are in [0,1] or discrete)
        full_mse, full_rmse = compute_mse_rmse(blended_b, tgt_b, mask=None)
        full_uqi  = compute_uqi(blended_b, tgt_b, mask=None)
        full_ergas= compute_ergas(blended_b, tgt_b, mask=None, scale=1.0)
        full_scc  = compute_scc(blended_b, tgt_b, mask=None)
        full_ssim = compute_ssim_index(blended_b, tgt_b, mask=None)
        full_iou  = compute_iou_macro(quantize_three(blended_b), tgt_q, mask=None)
        full_f1   = compute_f1_macro(quantize_three(blended_b), tgt_q, mask=None)
        full_acc  = multiclass_pixel_accuracy(quantize_three(blended_b), tgt_q, mask=None)

        # MASKED region == unknown (=0.5) in condition
        unknown_mask = (cond_q - 0.5).abs() < 1e-6
        masked_mse, masked_rmse = compute_mse_rmse(blended_b, tgt_b, mask=unknown_mask)
        masked_uqi  = compute_uqi(blended_b, tgt_b, mask=unknown_mask)
        masked_ergas= compute_ergas(blended_b, tgt_b, mask=unknown_mask, scale=1.0)
        masked_scc  = compute_scc(blended_b, tgt_b, mask=unknown_mask)
        masked_ssim = compute_ssim_index(blended_b, tgt_b, mask=unknown_mask)
        masked_iou  = compute_iou_macro(quantize_three(blended_b), tgt_q, mask=unknown_mask)
        masked_f1   = compute_f1_macro(quantize_three(blended_b), tgt_q, mask=unknown_mask)
        masked_acc  = multiclass_pixel_accuracy(quantize_three(blended_b), tgt_q, mask=unknown_mask)

        # ---------- 4) write per-image CSV rows ----------
        with open(csv_path, "a", newline="") as f:
            w = csv.writer(f)
            for i in range(cond_b.size(0)):
                w.writerow([
                    idx_global + i,
                    # full
                    full_iou, full_mse, full_rmse, full_uqi, full_ergas, full_scc, full_ssim, full_f1, full_acc,
                    # masked
                    masked_iou, masked_mse, masked_rmse, masked_uqi, masked_ergas, masked_scc, masked_ssim, masked_f1, masked_acc,
                ])

        # aggregate
        for k, v in [
            ("full_IoU", full_iou), ("full_MSE", full_mse), ("full_RMSE", full_rmse), ("full_UQI", full_uqi),
            ("full_ERGAS", full_ergas), ("full_SCC", full_scc), ("full_SSIM", full_ssim), ("full_F1", full_f1),
            ("full_Accuracy", full_acc),
            ("masked_IoU", masked_iou), ("masked_MSE", masked_mse), ("masked_RMSE", masked_rmse), ("masked_UQI", masked_uqi),
            ("masked_ERGAS", masked_ergas), ("masked_SCC", masked_scc), ("masked_SSIM", masked_ssim), ("masked_F1", masked_f1),
            ("masked_Accuracy", masked_acc),
        ]:
            agg[k].append(v)

        # visuals
        if (bidx % save_visuals_every_batches) == 0:
            # for crisp figures, show quantized gen + blended
            gen_show  = quantize_three(gen_b)
            blend_show= quantize_three(blended_b)
            save_test_panel(cond_b, tgt_b, gen_show, blend_show, img_dir, prefix=f"batch{bidx:04d}")

        idx_global += cond_b.size(0)
        if device.type == "cuda":
            torch.cuda.empty_cache()

    # ---- summary JSON ----
    summary = {k: (float(sum(v) / len(v)) if len(v) > 0 else float("nan")) for k, v in agg.items()}
    summary["num_images"] = idx_global
    summary_path = os.path.join(results_dir, f"{run_name}_summary.json")
    with open(summary_path, "w") as jf:
        json.dump(summary, jf, indent=2)

    return {"csv": csv_path, "summary": summary, "images_dir": img_dir, "summary_path": summary_path}
