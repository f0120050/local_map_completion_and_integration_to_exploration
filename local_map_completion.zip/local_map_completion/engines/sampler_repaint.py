# samplers/sampler_repaint.py
import torch
from tqdm import tqdm

__all__ = ["repaint_sample"]


@torch.no_grad()
def repaint_sample(diffusion_model, masked_img, num_steps=1000, jump_interval=50, device="cuda"):
    """
    masked_img: [B, 1, H, W] — Normalized input with values [0.0, 0.5, 1.0].
    Returns: completed_img in normalized format [0.0, 0.5, 1.0].
    """
    # Safety check for batch size consistency
    if masked_img.ndim != 4:
        raise ValueError(f"masked_img should be 4D tensor (B,C,H,W), got {masked_img.shape}")

    # Create mask for unknown regions (where value == 0.5)
    mask = (torch.abs(masked_img - 0.5) < 1e-3).float()  # Unknown regions
    known_mask = 1.0 - mask  # Known regions


    # Initialize noisy image
    img = torch.randn_like(masked_img).to(device)


    # Get batch size from input
    B = masked_img.shape[0]

    for t in tqdm(reversed(range(num_steps)), desc="Sampling"):
        # Create timestep tensor for current step
        t_batch = torch.full((B,), t, device=device, dtype=torch.long)

        # Clone condition to avoid modifying input
        cond = masked_img.clone()

        # Safety check for batch sizes
        if img.shape[0] != cond.shape[0]:
            min_batch = min(img.shape[0], cond.shape[0])
            img = img[:min_batch]
            cond = cond[:min_batch]
            t_batch = t_batch[:min_batch]
            B = min_batch  # Update batch size

        # Predict noise using UNet
        predicted_noise = diffusion_model.unet(img, t_batch, cond)

        # Get diffusion parameters for current timestep
        alpha_t = diffusion_model.alphas[t]
        alpha_bar_t = diffusion_model.alpha_bars[t]
        beta_t = diffusion_model.betas[t]
        alpha_bar_prev = diffusion_model.alpha_bars[t - 1] if t > 0 else diffusion_model.alpha_bars[0]

        # Predict denoised image
        x_0_pred = (img - torch.sqrt(1 - alpha_bar_t) * predicted_noise) / torch.sqrt(alpha_bar_t)

        if t > 0:
            # Compute mean of posterior distribution
            mu_t = (torch.sqrt(alpha_bar_prev) * beta_t / (1 - alpha_bar_t)) * x_0_pred + \
                   (torch.sqrt(alpha_t) * (1 - alpha_bar_prev) / (1 - alpha_bar_t)) * img

            # Add noise
            posterior_variance = beta_t
            noise = torch.randn_like(img)
            img = mu_t + torch.sqrt(posterior_variance) * noise
        else:
            # Final step - just use the prediction
            img = x_0_pred

        # Apply mask to preserve known regions
        #img = img * (1 - mask) + masked_img * mask
        img = img * mask + masked_img * known_mask

        # Jump sampling - add noise at intervals
        if t % jump_interval == 0 and t > 0:
            noise = torch.randn_like(img)
            img = diffusion_model.q_sample(img, t - jump_interval, noise)

    # Ensure output is in valid range
    img = img.clamp(0.0, 1.0)
    return img
