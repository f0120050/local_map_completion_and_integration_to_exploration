# engines/trainer_base.py
from __future__ import annotations

import time
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Optional, Tuple, Union

import torch
from torch import nn, Tensor
from torch.cuda.amp import GradScaler, autocast
from tqdm import tqdm


def _to_device(x: Any, device: Optional[torch.device]) -> Any:
    """Recursively move tensors to device."""
    if device is None:
        return x
    if isinstance(x, Tensor):
        return x.to(device, non_blocking=True)
    if isinstance(x, Mapping):
        return {k: _to_device(v, device) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        xs = [_to_device(v, device) for v in x]
        return type(x)(xs)
    return x


class TrainerBase:
    """
    Minimal, extensible trainer:
      - Implement `compute_loss(batch)` in subclasses.
      - Optionally return (loss, aux_dict) where aux_dict has scalar tensors/floats.
      - Supports AMP, grad clipping, and NaN-safe updates.
      - Steps ReduceLROnPlateau on `after_val_epoch`.
    """

    def __init__(
        self,
        model: nn.Module,
        optimizer: Optional[torch.optim.Optimizer] = None,
        scheduler: Optional[torch.optim.lr_scheduler._LRScheduler] = None,
        device: Optional[torch.device] = None,
        use_amp: bool = False,
        grad_clip: Optional[float] = 1.0,
        log_interval: int = 100,
    ) -> None:
        self.model = model
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.device = device
        self.use_amp = bool(use_amp)
        self.grad_clip = grad_clip
        self.log_interval = int(log_interval)
        self.scaler: Optional[GradScaler] = GradScaler(enabled=self.use_amp)

        if self.device is not None:
            self.model.to(self.device)

    # ---------- hooks to override ----------
    def compute_loss(self, batch: Any) -> Union[Tensor, Tuple[Tensor, Dict[str, float]]]:
        """Return loss tensor, or (loss, aux_logs). Must be implemented by subclasses."""
        raise NotImplementedError

    def after_val_epoch(self, stats: Dict[str, float]) -> None:
        """Optional: react to val stats (e.g., extra logging)."""
        pass

    # ---------- epochs ----------
    def train_epoch(self, loader: Iterable) -> Dict[str, float]:
        assert self.optimizer is not None, "Optimizer is required for training."
        self.model.train()
        start = time.time()

        loss_sum = 0.0
        n_batches = 0
        aux_accum: Dict[str, float] = {}

        pbar = tqdm(loader, desc="Train", leave=False)
        for i, batch in enumerate(pbar):
            batch = _to_device(batch, self.device)

            self.optimizer.zero_grad(set_to_none=True)

            with autocast(enabled=self.use_amp):
                out = self.compute_loss(batch)
                if isinstance(out, tuple):
                    loss, aux = out
                    aux = {k: float(v.detach().item() if isinstance(v, Tensor) else v) for k, v in aux.items()}
                else:
                    loss, aux = out, {}

            if torch.isnan(loss) or torch.isinf(loss):
                # skip pathological batch
                continue

            if self.scaler is not None and self.use_amp:
                self.scaler.scale(loss).backward()
                if self.grad_clip is not None:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                loss.backward()
                if self.grad_clip is not None:
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)
                self.optimizer.step()

            loss_val = float(loss.detach().item())
            loss_sum += loss_val
            n_batches += 1

            for k, v in aux.items():
                aux_accum[k] = aux_accum.get(k, 0.0) + float(v)

            if (i % self.log_interval) == 0:
                pbar.set_postfix(loss=f"{loss_val:.4f}")

        elapsed = time.time() - start
        avg_loss = (loss_sum / n_batches) if n_batches > 0 else float("nan")
        stats = {"loss": avg_loss, "batches": n_batches, "time_sec": elapsed}

        # fold averaged aux metrics
        for k, s in aux_accum.items():
            stats[k] = s / max(1, n_batches)

        return stats

    @torch.no_grad()
    def val_epoch(self, loader: Iterable) -> Dict[str, float]:
        self.model.eval()
        start = time.time()

        loss_sum = 0.0
        n_batches = 0
        aux_accum: Dict[str, float] = {}

        pbar = tqdm(loader, desc="Val", leave=False)
        for i, batch in enumerate(pbar):
            batch = _to_device(batch, self.device)

            with autocast(enabled=self.use_amp):
                out = self.compute_loss(batch)
                if isinstance(out, tuple):
                    loss, aux = out
                    aux = {k: float(v.detach().item() if isinstance(v, Tensor) else v) for k, v in aux.items()}
                else:
                    loss, aux = out, {}

            if torch.isnan(loss) or torch.isinf(loss):
                continue

            loss_val = float(loss.detach().item())
            loss_sum += loss_val
            n_batches += 1

            for k, v in aux.items():
                aux_accum[k] = aux_accum.get(k, 0.0) + float(v)

            if (i % self.log_interval) == 0:
                pbar.set_postfix(loss=f"{loss_val:.4f}")

        elapsed = time.time() - start
        avg_loss = (loss_sum / n_batches) if n_batches > 0 else float("nan")
        stats = {"loss": avg_loss, "batches": n_batches, "time_sec": elapsed}

        for k, s in aux_accum.items():
            stats[k] = s / max(1, n_batches)

        # Common pattern: step ReduceLROnPlateau with val loss
        if isinstance(self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
            self.scheduler.step(avg_loss)

        # Callback
        self.after_val_epoch(stats)
        return stats
