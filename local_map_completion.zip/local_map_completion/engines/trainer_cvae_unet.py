# engines/trainer_cvae_unet.py
from __future__ import annotations

import os, csv, time
from typing import Union, Optional, Dict, Any
from types import SimpleNamespace as SN

import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm.auto import tqdm
from torch.amp import autocast, GradScaler
from torchvision.utils import save_image

from losses.vae_safer import masked_recon_loss, kld_normal_safe, vae_loss_ce_logits
from utils.io import save_checkpoint, load_checkpoint
from utils.tensor_ops import three_class_labels
from viz.panels import save_visuals
from utils.tensor_ops import quantize_three, blend_generated_with_condition


class CVAEUNetTrainer:
    """
    Memory-optimized trainer for ConditionalUNetVAE.
    """

    def __init__(self, model: nn.Module, cfg: SN, device: torch.device):
        self.model = model.to(device)
        self.cfg = cfg
        self.device = device

        train_ns = getattr(cfg, "train", SN())
        loss_ns = getattr(cfg, "loss", SN())

        lr = float(getattr(train_ns, "lr", 1e-4))
        self.opt = torch.optim.Adam(self.model.parameters(), lr=lr)

        self.beta = float(getattr(loss_ns, "beta", 1.0))
        self.loss_type = str(getattr(loss_ns, "type", "mse"))

        # KL anneal from YAML
        anneal = getattr(loss_ns, "kl_anneal", SN(start_epoch=0, end_epoch=50))
        self.kl_start = int(getattr(anneal, "start_epoch", 0))
        self.kl_end = int(getattr(anneal, "end_epoch", 50))

        def _beta_t(epoch: int) -> float:
            if epoch <= self.kl_start:  return 0.0
            if epoch >= self.kl_end:    return self.beta
            a = (epoch - self.kl_start) / max(1, (self.kl_end - self.kl_start))
            return self.beta * a

        self._beta_t = _beta_t
        self.kl_anneal = getattr(loss_ns, "kl_anneal", SN(start_epoch=0, end_epoch=0))
        self.use_mask = bool(getattr(loss_ns, "use_mask", False))
        self.lambda_unknown = float(getattr(loss_ns, "lambda_unknown", 1.0))
        self.lambda_known = float(getattr(loss_ns, "lambda_known", 1.0))
        self.label_smooth = float(getattr(loss_ns, "label_smooth", 0.0))
        self.alpha_bce = float(getattr(loss_ns, "alpha_bce", 1.0))

        # Scheduler
        sched_name = str(getattr(train_ns, "scheduler", "plateau"))
        patience = int(getattr(train_ns, "patience", 4))
        min_lr = float(getattr(train_ns, "min_lr", 1e-6))
        epochs = int(getattr(train_ns, "epochs", 100))

        if sched_name == "plateau":
            self.sched = torch.optim.lr_scheduler.ReduceLROnPlateau(
                self.opt, mode="min", factor=0.5, patience=patience, min_lr=min_lr
            )
        elif sched_name == "cosine":
            self.sched = torch.optim.lr_scheduler.CosineAnnealingLR(
                self.opt, T_max=epochs, eta_min=min_lr
            )
        else:
            self.sched = None

        # AMP scaler
        self.scaler = GradScaler('cuda', enabled=(device.type == "cuda"))

        # Memory optimization settings
        self.enable_memory_optimizations()

    def enable_memory_optimizations(self):
        """Enable various memory optimization techniques."""
        # Set memory allocation configuration
        os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'expandable_segments:True'

        # Enable memory efficient attention if available
        try:
            torch.backends.cuda.enable_flash_sdp(True)
        except:
            pass

        # Set memory format for better performance
        torch.backends.cudnn.benchmark = True

    def clear_memory(self):
        """Aggressive memory cleanup."""
        if self.device.type == "cuda":
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

    # ---------- helpers ----------

    @staticmethod
    def _append_metrics_csv(csv_path: str, epoch: int, train_loss: float, val_loss: float,
                            l1: float, mse: float) -> None:
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)
        new_file = not os.path.exists(csv_path)
        with open(csv_path, "a", newline="") as f:
            w = csv.writer(f)
            if new_file:
                w.writerow(["epoch", "train_loss", "val_loss", "L1", "MSE"])
            w.writerow([epoch, train_loss, val_loss, l1, mse])

    def _forward_train(self, target:torch.Tensor, partial: torch.Tensor):
        """Use PARTIAL image for both encoder input and condition."""
        return self.model(target, partial)

    def _forward_sample(self, target: torch.Tensor, partial: torch.Tensor):
        """
        Sampling / visualization helper.

        - For ce_logits:
            * ignore model.sample()
            * run model(...) to get logits
            * convert logits -> class map {0,1,2} -> levels {0,0.5,1}
            * this keeps pred_vis single-channel and compatible with quantize_three()
        - For bce_logits / mse:
            * prefer model.sample(condition=partial, ...)
            * fall back to forward + sigmoid if sample() is not defined
        """
        # ---- classification case: do NOT use model.sample() ----
        if self.loss_type == "ce_logits":
            # logits: [B,3,H,W]
            logits, mu, logvar = self.model(target, partial)

            # per-class probabilities
            probs = torch.softmax(logits, dim=1)  # [B,3,H,W]

            # predicted classes as a single-channel map {0,1,2}
            pred_classes = probs.argmax(dim=1, keepdim=True)  # [B,1,H,W]

            # map classes -> {0.0, 0.5, 1.0} so that quantize_three & panels work
            pred_levels = pred_classes.float() / 2.0  # [B,1,H,W] in {0,0.5,1}

            return logits, pred_levels, logvar

        # ---- regression case (BCE / MSE): keep using sample() if available ----
        if hasattr(self.model, "sample"):
            logits, probs = self.model.sample(
                condition=partial,
                mode="posterior",
                deterministic=True,
            )
            # probs is already sigmoid(logits) from ConditionalUNetVAE.sample()
            return logits, probs, None
        else:
            logits, mu, logvar = self.model(target, partial)
            probs = logits.sigmoid().clamp(0.0, 1.0)
            return logits, probs, logvar

    # ---------- checkpoint I/O ----------

    def restore(
            self,
            filename: Union[str, os.PathLike],
            *,
            strict: bool = True,
            map_location: Optional[Union[str, torch.device]] = None,
    ) -> Dict[str, Any]:
        if map_location is None:
            map_location = self.device

        result = load_checkpoint(
            filename=filename,
            objects={'model': self.model, 'opt': self.opt, 'sched': self.sched},
            map_location=map_location,
            strict=strict,
        )

        self._ckpt_meta = result.get("meta", {})
        self._ckpt_best_val = float(self._ckpt_meta.get("best_val_loss", float("inf")))
        self._ckpt_last_val = float(self._ckpt_meta.get("val_loss", float("nan")))
        self._ckpt_epoch = int(self._ckpt_meta.get("epoch", 0))

        print(
            f"[restore] loaded '{os.path.basename(str(filename))}' "
            f"(epoch={self._ckpt_epoch}, best_val={self._ckpt_best_val:.4f}, "
            f"val={self._ckpt_last_val:.4f})"
        )
        if result.get("restore_report"):
            print(f"[restore] report: {result['restore_report']}")

        return result

    # ---------- training loop ----------

    def fit(self, train_loader, val_loader, result=None):
        best = float("inf")
        start_epoch = 1

        if result:
            meta = result.get("meta", {})
            start_epoch = int(meta.get("epoch", 0)) + 1
            best = float(meta.get("best_val_loss", float("inf")))
            print(f"[fit] resuming from epoch {start_epoch} (best_val so far = {best:.6f})")
        elif hasattr(self, "_ckpt_epoch"):
            start_epoch = int(getattr(self, "_ckpt_epoch", 0)) + 1
            best = float(getattr(self, "_ckpt_best_val", float("inf")))
            print(f"[fit] resuming from epoch {start_epoch} (best_val so far = {best:.6f})")

        train_ns = getattr(self.cfg, "train", SN())
        epochs = int(getattr(train_ns, "epochs", 100))
        val_interval = int(getattr(train_ns, "val_interval", 100))

        if start_epoch > epochs:
            print(f"[fit] start_epoch {start_epoch} > configured epochs {epochs}; exiting.")
            return best

        # Initial memory cleanup
        self.clear_memory()

        for epoch in range(start_epoch, epochs + 1):



            t0 = time.perf_counter()
            self.model.train()
            loss_sum, n = 0.0, 0

            # Clear memory before each epoch
            self.clear_memory()

            pbar = tqdm(train_loader, desc=f"Train {epoch}/{epochs}", ncols=0)
            for batch_idx, (partial, complete) in enumerate(pbar):
                self.opt.zero_grad(set_to_none=True)



                # Use non_blocking and channels_last for better memory efficiency
                partial = partial.to(self.device, non_blocking=True, memory_format=torch.channels_last)
                complete = complete.to(self.device, non_blocking=True, memory_format=torch.channels_last)

                # print(f"epoch: {epoch}, batch_idx: {batch_idx}")
                #
                # if epoch == start_epoch and batch_idx == 0:
                #     print("partial range:", partial.min().item(), partial.max().item())
                #     print("complete range:", complete.min().item(), complete.max().item())

                # Ensure finite inputs
                if not (torch.isfinite(partial).all() and torch.isfinite(complete).all()):
                    print(f"[warn] non-finite inputs at batch {batch_idx}, skipping")
                    continue

                try:
                    with autocast('cuda', enabled=(self.device.type == "cuda")):
                        # Add condition noise if specified
                        cond = partial
                        noise_std = float(getattr(self.cfg.train, "cond_noise_std", 0.0))
                        if noise_std > 0.0:
                            cond = (cond + noise_std * torch.randn_like(cond)).clamp(0.0, 1.0)

                        logits, mu, logvar = self._forward_train(complete, cond)

                        if epoch % 20 == 0 and batch_idx == 0:
                            print("logits stats:", logits.min().item(), logits.max().item())

                        # Use the clean VAE loss functions from vae.py
                        beta_t = self._beta_t(epoch)

                        if self.loss_type == "ce_logits":
                            from losses.vae import vae_loss_ce_logits
                            # map complete (float) -> class indices
                            target_classes = three_class_labels(complete)  # [B,H,W] long
                            loss = vae_loss_ce_logits(logits, target_classes, mu.float(), logvar.float(), beta_t)

                        elif self.loss_type == "bce_logits":
                            from losses.vae import vae_loss_bce_logits
                            loss = vae_loss_bce_logits(logits, complete, mu.float(), logvar.float(), beta_t)

                        else:  # "mse"
                            from losses.vae import vae_loss_mse
                            pred = logits.sigmoid()
                            loss = vae_loss_mse(pred, complete, mu.float(), logvar.float(), beta_t)

                    if not torch.isfinite(loss):
                        print(f"[DEBUG] non-finite loss at epoch {epoch}, batch {batch_idx}")
                        print("  logits min/max:", float(logits.min()), float(logits.max()))
                        print("  mu min/max:", float(mu.min()), float(mu.max()))
                        print("  logvar min/max:", float(logvar.min()), float(logvar.max()))
                        print("  target min/max:", float(complete.min()), float(complete.max()))
                        break  # stop training here for inspection

                    # Check for finite loss
                    if not torch.isfinite(loss):
                        print(f"[warn] non-finite loss at batch {batch_idx}; loss={float(loss)}")
                        continue

                    # Backward pass with gradient scaling
                    self.scaler.scale(loss).backward()
                    self.scaler.unscale_(self.opt)

                    # Gradient clipping
                    #nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                    nn.utils.clip_grad_norm_(self.model.parameters(), 0.5)

                    self.scaler.step(self.opt)
                    self.scaler.update()

                    loss_sum += float(loss)
                    n += 1
                    pbar.set_postfix(loss=f"{loss_sum / max(1, n):.4f}")

                except RuntimeError as e:
                    if "out of memory" in str(e):
                        print(f"[warn] OOM at batch {batch_idx}, clearing cache and skipping")
                        self.clear_memory()
                        continue
                    else:
                        raise e

                # Periodic memory cleanup during training
                if batch_idx % 50 == 0:
                    self.clear_memory()

                # Delete intermediate tensors to free memory
                del logits, mu, logvar, loss
                if 'cond' in locals() and cond is not partial:
                    del cond

            train_mean = loss_sum / max(1, n)
            print(f"[Epoch {epoch}] loss {train_mean:.4f}")
            print(f"Elapsed time for 1 training epoch {time.perf_counter() - t0:.2f}s")

            # Step non-plateau schedulers every epoch
            if self.sched and not isinstance(self.sched, torch.optim.lr_scheduler.ReduceLROnPlateau):
                self.sched.step()

            # Clear memory before validation
            self.clear_memory()

            # ---- validation ----
            do_val = (epoch % val_interval == 0) or (epoch == epochs)
            if not do_val:
                continue

            t0 = time.perf_counter()
            self.model.eval()
            val_sum = l1_sum = mse_sum = 0.0

            with torch.no_grad():
                for batch_idx, (p, c) in enumerate(val_loader):
                    try:
                        p = p.to(self.device, non_blocking=True, memory_format=torch.channels_last)
                        c = c.to(self.device, non_blocking=True, memory_format=torch.channels_last)

                        with autocast('cuda', enabled=False):
                            # Always get mu, logvar for loss computation
                            logits, mu, logvar = self._forward_train(c, p)

                            # ---- validation loss + prediction reconstruction ----
                            beta_t = self._beta_t(epoch)

                            if self.loss_type == "ce_logits":
                                # logits: [B,3,H,W]
                                # classification target:
                                target_classes = three_class_labels(c)  # [B,H,W] long {0,1,2}

                                # CE-based VAE loss
                                val_loss = vae_loss_ce_logits(
                                    logits, target_classes, mu.float(), logvar.float(), beta_t
                                )

                                # For metrics (L1/MSE), convert logits -> predicted levels {0,0.5,1}
                                probs = torch.softmax(logits, dim=1)  # [B,3,H,W]
                                pred_classes = probs.argmax(dim=1, keepdim=True)  # [B,1,H,W] {0,1,2}
                                pred = (pred_classes.float() / 2.0)  # [B,1,H,W] {0,0.5,1}

                            elif self.loss_type == "bce_logits":
                                from losses.vae_safer import vae_loss_bce_logits
                                pred = logits.sigmoid()  # [B,1,H,W]
                                val_loss = vae_loss_bce_logits(
                                    logits, c, mu.float(), logvar.float(), beta_t
                                )

                            else:  # "mse"
                                from losses.vae_safer import vae_loss_mse
                                pred = logits.sigmoid()  # [B,1,H,W]
                                val_loss = vae_loss_mse(
                                    pred, c, mu.float(), logvar.float(), beta_t
                                )

                            val_sum += float(val_loss)

                            pred = pred.clamp(0, 1)
                            l1_sum += float(F.l1_loss(pred, c))
                            mse_sum += float(F.mse_loss(pred, c))

                        # Clean up tensors
                        del logits, pred, mu, logvar, val_loss

                    except RuntimeError as e:
                        if "out of memory" in str(e):
                            print(f"[warn] OOM during validation at batch {batch_idx}, clearing cache")
                            self.clear_memory()
                            continue
                        else:
                            raise e

                    # Periodic cleanup during validation
                    if batch_idx % 20 == 0:
                        self.clear_memory()

            val = val_sum / max(1, len(val_loader))
            l1 = l1_sum / max(1, len(val_loader))
            mse = mse_sum / max(1, len(val_loader))
            print(f"[Val @ {epoch}] loss {val:.4f} | L1 {l1:.4f} | MSE {mse:.4f}")
            print(f"Elapsed {time.perf_counter() - t0:.2f}s")

            # Step plateau scheduler on validation loss
            if self.sched and isinstance(self.sched, torch.optim.lr_scheduler.ReduceLROnPlateau):
                self.sched.step(val)

            # Clear memory before checkpointing
            self.clear_memory()

            # ---- checkpoints ----
            os.makedirs(self.cfg.paths.checkpoints, exist_ok=True)
            save_checkpoint(
                objects={'model': self.model, 'opt': self.opt, 'sched': self.sched},
                epoch=epoch, best_val=min(best, val), val_loss=val, cfg=self.cfg,
                path=self.cfg.paths.checkpoints, tag=f"epoch_{epoch:04d}"
            )
            if val < best:
                best = val
                save_checkpoint(
                    objects={'model': self.model, 'opt': self.opt, 'sched': self.sched},
                    epoch=epoch, best_val=best, val_loss=val, cfg=self.cfg,
                    path=self.cfg.paths.checkpoints, tag="best"
                )

            # ---- metrics CSV ----
            metrics_dir = os.path.join(self.cfg.paths.metric_results, "train")
            self._append_metrics_csv(os.path.join(metrics_dir, "metrics.csv"),
                                     epoch, train_mean, val, l1, mse)

            # ---- visuals (with memory-efficient approach) ----
            self._create_visualizations(epoch, val_loader, train_loader)

        return best

    def _create_visualizations(self, epoch, val_loader, train_loader):
        """Create visualizations with memory-efficient approach."""
        images_dir = os.path.join(self.cfg.paths.visual_results, "train")
        os.makedirs(images_dir, exist_ok=True)

        try:
            p_vis, c_vis = next(iter(val_loader))
        except StopIteration:
            p_vis, c_vis = next(iter(train_loader))

        # Use only 2 samples instead of 4 to save memory
        p_vis = p_vis[:2].to(self.device, non_blocking=True, memory_format=torch.channels_last)
        c_vis = c_vis[:2].to(self.device, non_blocking=True, memory_format=torch.channels_last)

        # Clear memory before visualization forward pass
        self.clear_memory()

        try:
            with torch.no_grad(), torch.amp.autocast('cuda', enabled=(self.device.type == "cuda")):
                logits_vis, pred_vis, _ = self._forward_sample(p_vis, p_vis)

            # Quick distribution check
            def _frac_mid(x, lo=0.4, hi=0.6):
                x = x.detach().float().cpu().view(-1)
                return float(((x > lo) & (x < hi)).float().mean())

            if self.loss_type == "ce_logits":
                print("[viz] pred mid(0.4..0.6) =", _frac_mid(pred_vis))
                print("[viz] ranges pred:", pred_vis.min().item(), pred_vis.max().item(),
                      "| tgt:", c_vis.min().item(), c_vis.max().item())
            else:
                print("[viz] pred mid(0.4..0.6) =", _frac_mid(logits_vis.sigmoid()))
                print("[viz] ranges pred:", logits_vis.sigmoid().min().item(), logits_vis.sigmoid().max().item(),
                      "| tgt:", c_vis.min().item(), c_vis.max().item())

            # Move to CPU immediately to free GPU memory
            p_cpu = p_vis.detach().cpu()
            c_cpu = c_vis.detach().cpu()
            g_cpu = pred_vis.detach().cpu()

            # Free GPU tensors immediately
            del p_vis, c_vis, logits_vis, pred_vis
            self.clear_memory()

            # Save visualizations
            base = f"epoch_{epoch:04d}"
            save_image(g_cpu, os.path.join(images_dir, f"{base}_raw_pred.png"))
            save_image(c_cpu, os.path.join(images_dir, f"{base}_raw_tgt.png"))

            # Quantization and blending (on CPU to save GPU memory)
            p_q = quantize_three(p_cpu)
            g_q = quantize_three(g_cpu)
            b_q = blend_generated_with_condition(p_q, g_q)

            save_visuals(p_q[0], c_cpu[0], g_q[0], b_q[0],
                         out_dir=images_dir, base_name=base)

            print(f"[viz] wrote {os.path.join(images_dir, base)}.png and raw *_raw_*.png")

        except RuntimeError as e:
            if "out of memory" in str(e):
                print("[warn] OOM during visualization, skipping")
                self.clear_memory()
            else:
                raise e