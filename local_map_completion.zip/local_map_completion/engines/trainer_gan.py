# trainers/trainer_gan.py
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from tqdm.auto import tqdm
import time

# --- NEW: typing for restore signature ---
from typing import Union, Optional, Dict, Any

from losses.gan import (
    d_hinge, g_hinge, d_lsgan, g_lsgan,
    masked_l1, make_ce, float01_to_classes, logits_to_recon
)
from utils.io import save_checkpoint, load_checkpoint
import os, csv
from viz.panels import save_visuals
from utils.tensor_ops import quantize_three, blend_generated_with_condition

class TrainerGAN:
    def __init__(self, G, D, cfg, device: torch.device):
        self.G, self.D, self.cfg, self.device = G.to(device), D.to(device), cfg, device
        self.optG = torch.optim.Adam(self.G.parameters(), lr=cfg.train.lr_g, betas=(0.5, 0.999))
        self.optD = torch.optim.Adam(self.D.parameters(), lr=cfg.train.lr_d, betas=(0.5, 0.999))
        self.schedG = (
            torch.optim.lr_scheduler.ReduceLROnPlateau(self.optG, mode="min", factor=0.5, patience=4)
            if getattr(cfg.train, "scheduler", None) == "plateau" else None
        )

    # --- NEW: restore() just like CVAETrainer.restore() ---

    def restore(
            self,
            filename: Union[str, os.PathLike],
            *,
            strict: bool = True,
            map_location: Optional[Union[str, torch.device]] = None,
    ) -> Dict[str, Any]:
        """
        Restore G/D/optimizers/scheduler state from a checkpoint created by `save_checkpoint`.

        Returns:
            The dict returned by `utils.io.load_checkpoint` with keys:
            'meta', 'config', 'extra', 'restore_report'.
        """
        if map_location is None:
            map_location = self.device

        result = load_checkpoint(
            filename=filename,
            objects={'G': self.G, 'D': self.D,
                     'optG': self.optG, 'optD': self.optD, 'schedG': self.schedG},
            map_location=map_location,
            strict=strict,
        )

        # Cache meta so fit() can resume even if caller doesn't pass `result`
        self._ckpt_meta = result.get("meta", {})
        self._ckpt_best_val = float(self._ckpt_meta.get("best_val_loss", float("inf")))
        self._ckpt_last_val = float(self._ckpt_meta.get("val_loss", float("nan")))
        self._ckpt_epoch = int(self._ckpt_meta.get("epoch", 0))

        print(
            f"[restore] loaded '{os.path.basename(str(filename))}' "
            f"(epoch={self._ckpt_epoch}, best_val={self._ckpt_best_val:.4f}, "
            f"val={self._ckpt_last_val:.4f})"
        )
        if result.get("restore_report"):
            print(f"[restore] report: {result['restore_report']}")
        return result

    # ------------------------------------------------------

    # ---- helpers ----
    @staticmethod
    def _set_requires_grad(model: nn.Module, flag: bool) -> None:
        for p in model.parameters():
            p.requires_grad = flag

    def _build_ce(self, out: torch.Tensor) -> nn.Module:
        """Return pixelwise CE loss (reduction='none').
        Accepts cfg.loss.ce_weights as:
          - list/tuple/tensor -> class weights
          - int -> num_classes (delegates to make_ce(num_classes))
          - None -> unweighted CE
        """
        w = getattr(self.cfg.loss, "ce_weights", None)
        if w is None:
            return nn.CrossEntropyLoss(reduction="none")
        if isinstance(w, int):
            return make_ce(w, device=out.device)  # your helper builds weighted CE safely
        if isinstance(w, (list, tuple)):
            w = torch.tensor(w, dtype=out.dtype, device=out.device)
        elif isinstance(w, torch.Tensor):
            w = w.to(device=out.device, dtype=out.dtype)
        return nn.CrossEntropyLoss(weight=w, reduction="none")

    # ---- steps ----
    def forward_G_raw(self, partial: torch.Tensor) -> torch.Tensor:
        """
        Runs G and adapts its head:
          - pix2pix: returns [B,1,H,W]
          - seg_gan (logits): converts [B,3,H,W] -> recon [B,1,H,W]
        """
        out = self.G(partial)
        if self.cfg.task == "seg_gan" and out.size(1) == 3:
            recon, _ = logits_to_recon(out)
            return recon
        return out

    def step_D(self, partial: torch.Tensor, complete: torch.Tensor) -> torch.Tensor:
        with torch.no_grad():
            fake = self.forward_G_raw(partial)
        d_real = self.D(partial, complete)
        d_fake = self.D(partial, fake)
        if self.cfg.gan.type == "hinge":
            lossD = d_hinge(d_real, d_fake)
        else:
            lossD = d_lsgan(d_real, d_fake)

        self.optD.zero_grad(set_to_none=True)
        lossD.backward()
        nn.utils.clip_grad_norm_(self.D.parameters(), 1.0)
        self.optD.step()
        return lossD.detach()

    def step_G(self, partial: torch.Tensor, complete: torch.Tensor) -> torch.Tensor:
        """One G update. Properly freezes D so its params don’t get grads."""
        self._set_requires_grad(self.D, False)

        out = self.G(partial)
        if self.cfg.task == "seg_gan":
            # segmentation head: CE (masked + full) + adversarial on recon
            target_cls = float01_to_classes(complete)              # [B,H,W]
            ce = self._build_ce(out)                               # CE(logits, target) -> [B,H,W]
            ce_per = ce(out, target_cls)

            unknown = (partial.sub(0.5).abs() < 1e-3).float().squeeze(1)  # [B,H,W]
            ce_mask = (ce_per * unknown).sum() / (unknown.sum() + 1e-6)
            ce_full = ce_per.mean()

            recon, _ = logits_to_recon(out)
            d_fake = self.D(partial, recon)
            adv = g_hinge(d_fake) if self.cfg.gan.type == "hinge" else g_lsgan(d_fake)

            lossG = (self.cfg.loss.lambda_ce_mask * ce_mask +
                     self.cfg.loss.lambda_ce_full * ce_full +
                     self.cfg.loss.lambda_adv * adv)
        else:
            # pix2pix head: L1 (full or masked) + adversarial
            fake = out.clamp(0, 1)
            d_fake = self.D(partial, fake)
            adv = g_hinge(d_fake) if self.cfg.gan.type == "hinge" else g_lsgan(d_fake)

            if getattr(self.cfg.loss, "use_masked_l1", False):
                l1m = masked_l1(fake, complete, partial)
                l1f = F.l1_loss(fake, complete)
                lossG = adv + self.cfg.loss.lambda_mask * l1m + self.cfg.loss.lambda_full * l1f
            else:
                l1 = F.l1_loss(fake, complete)
                lossG = adv + self.cfg.loss.lambda_l1 * l1

        self.optG.zero_grad(set_to_none=True)
        lossG.backward()
        nn.utils.clip_grad_norm_(self.G.parameters(), 1.0)
        self.optG.step()

        self._set_requires_grad(self.D, True)
        return lossG.detach()

    # use validation data
    # def fit(self, train_loader, val_loader, result: Optional[Dict[str, Any]] = None):
    #     # resume-aware init
    #     best = float("inf")
    #     start_epoch = 1
    #
    #     if result:  # dict returned by load_checkpoint/restore
    #         meta = result.get("meta", {})
    #         start_epoch = int(meta.get("epoch", 0)) + 1
    #         best = float(meta.get("best_val_loss", float("inf")))
    #         print(f"[fit] resuming from epoch {start_epoch} (best_val so far = {best:.6f})")
    #     elif hasattr(self, "_ckpt_epoch"):
    #         start_epoch = int(getattr(self, "_ckpt_epoch", 0)) + 1
    #         best = float(getattr(self, "_ckpt_best_val", float("inf")))
    #         print(f"[fit] resuming from epoch {start_epoch} (best_val so far = {best:.6f})")
    #
    #     epochs = int(getattr(self.cfg.train, "epochs", 100))
    #     val_interval = int(getattr(self.cfg.train, "val_interval", 100))  # run val/checkpoints/visuals every N epochs
    #
    #     # nothing to do if we're already past target epochs
    #     if start_epoch > epochs:
    #         print(f"[fit] start_epoch {start_epoch} > configured epochs {epochs}; exiting.")
    #         return best
    # # -------------------------------------------------------------------------
    #
    #     for epoch in range(start_epoch, epochs + 1):
    #         epoch_t0 = time.perf_counter()
    #
    #         self.G.train()
    #         self.D.train()
    #         g_sum = d_sum = 0.0
    #         g_steps = d_steps = 0
    #
    #         pbar = tqdm(train_loader, desc=f"Train {epoch}/{epochs}", ncols=0)
    #         for partial, complete in pbar:
    #             partial = partial.to(self.device, non_blocking=True)
    #             complete = complete.to(self.device, non_blocking=True)
    #
    #             # --- D step ---
    #             d_loss = self.step_D(partial, complete)
    #             d_sum += float(d_loss)
    #             d_steps += 1
    #
    #             # --- G steps ---
    #             g_loss = None
    #             for _ in range(self.cfg.train.g_updates):
    #                 g_loss = self.step_G(partial, complete)
    #                 g_sum += float(g_loss)
    #                 g_steps += 1
    #
    #             if g_loss is not None:
    #                 pbar.set_postfix(
    #                     d=f"{d_sum / max(1, d_steps):.4f}",
    #                     g=f"{g_sum / max(1, g_steps):.4f}"
    #                 )
    #
    #         # Train means (always print)
    #         g_mean = g_sum / max(1, g_steps)
    #         d_mean = d_sum / max(1, d_steps)
    #         print(f"[Epoch {epoch}] G {g_mean:.4f} | D {d_mean:.4f}")
    #
    #         elapsed = time.perf_counter() - epoch_t0
    #         print(f"Elapsed time for 1 training epoch {elapsed:.2f}s") # Elapsed 50.85s ~ 1000 training epochs
    #
    #         # ---- Run validation / checkpoint / visuals only at intervals (and final epoch) ----
    #         do_val = (epoch % val_interval == 0) or (epoch == epochs)
    #         if not do_val:
    #             continue
    #
    #         epoch_t0 = time.perf_counter()
    #         # Validation: L1 on generator output (seg: uses recon via forward_G_raw)
    #         self.G.eval()
    #         val_sum = 0.0
    #         with torch.no_grad():
    #             for p, c in val_loader:
    #                 p = p.to(self.device, non_blocking=True)
    #                 c = c.to(self.device, non_blocking=True)
    #                 pred = self.forward_G_raw(p).clamp(0, 1)
    #                 val_sum += float(F.l1_loss(pred, c))
    #         val = val_sum / max(1, len(val_loader))
    #         print(f"[Val @ {epoch}] L1 {val:.4f} | Best {best:.4f}")
    #         elapsed = time.perf_counter() - epoch_t0
    #         print(f"Elapsed {elapsed:.2f}s")  # Elapsed 31s ~ 1000 training epochs
    #
    #         if self.schedG:
    #             self.schedG.step(val)
    #
    #         # Periodic epoch checkpoint
    #         os.makedirs(self.cfg.paths.checkpoints, exist_ok=True)
    #         save_checkpoint(
    #             objects={'G': self.G, 'D': self.D,
    #                      'optG': self.optG, 'optD': self.optD, 'schedG': self.schedG},
    #             epoch=epoch, best_val=min(best, val), val_loss=val, cfg=self.cfg,
    #             path=self.cfg.paths.checkpoints, tag=f"epoch_{epoch:04d}"
    #         )
    #
    #         # Update & save best
    #         if val < best:
    #             best = val
    #             save_checkpoint(
    #                 objects={'G': self.G, 'D': self.D,
    #                          'optG': self.optG, 'optD': self.optD, 'schedG': self.schedG},
    #                 epoch=epoch, best_val=best, val_loss=val, cfg=self.cfg,
    #                 path=self.cfg.paths.checkpoints, tag="best"
    #             )
    #
    #         # Visuals (same interval)
    #         images_dir = os.path.join(self.cfg.paths.visual_results, "train")
    #         os.makedirs(images_dir, exist_ok=True)
    #
    #         try:
    #             p_vis, c_vis = next(iter(val_loader))
    #         except StopIteration:
    #             p_vis, c_vis = next(iter(train_loader))
    #
    #         p_vis = p_vis.to(self.device)
    #         c_vis = c_vis.to(self.device)
    #
    #         with torch.no_grad():
    #             pred_vis = self.forward_G_raw(p_vis).clamp(0, 1)
    #             p_q = quantize_three(p_vis)
    #             g_q = quantize_three(pred_vis)
    #             b_q = blend_generated_with_condition(p_q, g_q)
    #
    #         base = f"epoch_{epoch:04d}"
    #         save_visuals(p_q[0].cpu(), c_vis[0].cpu(), g_q[0].cpu(), b_q[0].cpu(),
    #                      out_dir=images_dir, base_name=base)
    #         print(f"[viz] wrote {os.path.join(images_dir, base)}.png")
    #
    #     return best


    def fit(self, train_loader, val_loader: Optional[DataLoader] = None, result: Optional[Dict[str, Any]] = None):
        """
        Train the GAN.

        Args:
            train_loader: Training data loader (required)
            val_loader: Validation data loader (optional, can be None)
            result: Resume dictionary from restore()
        """
        # resume-aware init
        best = float("inf") if val_loader is not None else None
        start_epoch = 1

        if result:
            meta = result.get("meta", {})
            start_epoch = int(meta.get("epoch", 0)) + 1
            if val_loader is not None:
                best = float(meta.get("best_val_loss", float("inf")))
                print(f"[fit] resuming from epoch {start_epoch} (best_val={best:.6f})")
            else:
                print(f"[fit] resuming from epoch {start_epoch} (no validation)")
        elif hasattr(self, "_ckpt_epoch"):
            start_epoch = int(getattr(self, "_ckpt_epoch", 0)) + 1
            if val_loader is not None:
                best = float(getattr(self, "_ckpt_best_val", float("inf")))

        epochs = int(getattr(self.cfg.train, "epochs", 100))
        save_interval = int(getattr(self.cfg.train, "val_interval", 100))

        if start_epoch > epochs:
            print(f"[fit] start_epoch {start_epoch} > configured epochs {epochs}; exiting.")
            return best

        for epoch in range(start_epoch, epochs + 1):
            epoch_t0 = time.perf_counter()

            self.G.train()
            self.D.train()
            g_sum = d_sum = 0.0
            g_steps = d_steps = 0

            pbar = tqdm(train_loader, desc=f"Train {epoch}/{epochs}", ncols=0)
            for partial, complete in pbar:
                partial = partial.to(self.device, non_blocking=True)
                complete = complete.to(self.device, non_blocking=True)

                d_loss = self.step_D(partial, complete)
                d_sum += float(d_loss)
                d_steps += 1

                g_loss = None
                for _ in range(self.cfg.train.g_updates):
                    g_loss = self.step_G(partial, complete)
                    g_sum += float(g_loss)
                    g_steps += 1

                if g_loss is not None:
                    pbar.set_postfix(
                        d=f"{d_sum / max(1, d_steps):.4f}",
                        g=f"{g_sum / max(1, g_steps):.4f}"
                    )

            g_mean = g_sum / max(1, g_steps)
            d_mean = d_sum / max(1, d_steps)
            print(f"[Epoch {epoch}] G {g_mean:.4f} | D {d_mean:.4f}")

            elapsed = time.perf_counter() - epoch_t0
            print(f"Elapsed time for 1 training epoch {elapsed:.2f}s")

            # ---- Checkpoint / visualization at intervals ----
            do_save = (epoch % save_interval == 0) or (epoch == epochs)
            if not do_save:
                continue

            # ---- VALIDATION (only if val_loader provided) ----
            val = float('nan')
            if val_loader is not None:
                epoch_t0 = time.perf_counter()
                self.G.eval()
                val_sum = 0.0
                with torch.no_grad():
                    for p, c in val_loader:
                        p = p.to(self.device, non_blocking=True)
                        c = c.to(self.device, non_blocking=True)
                        pred = self.forward_G_raw(p).clamp(0, 1)
                        val_sum += float(F.l1_loss(pred, c))
                val = val_sum / max(1, len(val_loader))
                print(f"[Val @ {epoch}] L1 {val:.4f} | Best {best:.4f}")
                elapsed = time.perf_counter() - epoch_t0
                print(f"Elapsed {elapsed:.2f}s")

                if self.schedG:
                    self.schedG.step(val)

            # ---- Save checkpoint ----
            os.makedirs(self.cfg.paths.checkpoints, exist_ok=True)
            save_checkpoint(
                objects={'G': self.G, 'D': self.D,
                         'optG': self.optG, 'optD': self.optD, 'schedG': self.schedG},
                epoch=epoch,
                best_val=best if best is not None else float('nan'),
                val_loss=val,
                cfg=self.cfg,
                path=self.cfg.paths.checkpoints,
                tag=f"epoch_{epoch:04d}"
            )

            # ---- Save "best" checkpoint (only with validation) ----
            if val_loader is not None and val < best:
                best = val
                save_checkpoint(
                    objects={'G': self.G, 'D': self.D,
                             'optG': self.optG, 'optD': self.optD, 'schedG': self.schedG},
                    epoch=epoch,
                    best_val=best,
                    val_loss=val,
                    cfg=self.cfg,
                    path=self.cfg.paths.checkpoints,
                    tag="best"
                )
                print(f"  → NEW BEST: {best:.6f}")

            # ---- Visuals ----
            images_dir = os.path.join(self.cfg.paths.visual_results, "train")
            os.makedirs(images_dir, exist_ok=True)

            # Use val_loader if available, otherwise train_loader
            if val_loader is not None:
                try:
                    p_vis, c_vis = next(iter(val_loader))
                except StopIteration:
                    p_vis, c_vis = next(iter(train_loader))
            else:
                p_vis, c_vis = next(iter(train_loader))

            p_vis = p_vis.to(self.device)
            c_vis = c_vis.to(self.device)

            with torch.no_grad():
                self.G.eval()
                pred_vis = self.forward_G_raw(p_vis).clamp(0, 1)
                p_q = quantize_three(p_vis)
                g_q = quantize_three(pred_vis)
                b_q = blend_generated_with_condition(p_q, g_q)

            base = f"epoch_{epoch:04d}"
            save_visuals(p_q[0].cpu(), c_vis[0].cpu(), g_q[0].cpu(), b_q[0].cpu(),
                         out_dir=images_dir, base_name=base)
            print(f"[viz] wrote {os.path.join(images_dir, base)}.png")

        return best