# engines/trainer_geom.py
from __future__ import annotations
import os, csv, time
from types import SimpleNamespace as SN

import torch
import torch.nn.functional as F
from tqdm.auto import tqdm

from models.geom import GeometricBaselineNet
from viz.panels import save_visuals
from utils.tensor_ops import quantize_three, blend_generated_with_condition

def _to_classes(q: torch.Tensor) -> torch.Tensor:
    # q: [B,1,H,W] in {0,.5,1} -> long {0,1,2}
    z = torch.zeros_like(q, dtype=torch.long)
    z = torch.where(torch.isclose(q, torch.tensor(0.5, device=q.device)), torch.ones_like(z), z)
    z = torch.where(torch.isclose(q, torch.tensor(1.0, device=q.device)), torch.full_like(z, 2), z)
    return z.squeeze(1)

@torch.no_grad()
def _iou_macro(pc: torch.Tensor, tc: torch.Tensor, num_classes=3, eps=1e-6):
    ious = []
    for c in range(num_classes):
        p = (pc == c); t = (tc == c)
        inter = (p & t).float().sum()
        union = (p | t).float().sum()
        ious.append(float(inter / (union + eps)) if union > 0 else 0.0)
    return sum(ious) / len(ious), ious

class GeomRunner:
    """
    Rule-based baseline “trainer”: no optimization — just runs on val loader,
    writes metrics/visuals to the same locations as other models.
    """
    def __init__(self, cfg: SN, device: torch.device):
        self.cfg = cfg
        self.device = device
        m = getattr(cfg, "model", SN())

        self.model = GeometricBaselineNet(
            method=cfg.model.method,
            wall_value=cfg.model.wall_value,
            wall_thickness=getattr(cfg.model, "wall_thickness", 0),
            max_fill=getattr(cfg.model, "max_fill", 30),
            verbose=getattr(cfg.model, "verbose", False),
            clamp_border=getattr(cfg.model, "clamp_border", True),

            # >>> NEW: pass-through of door/guides settings <<<
            door_space=getattr(cfg.model, "door_space", "both"),
            door_min_width=getattr(cfg.model, "door_min_width", 2),
            door_max_width=getattr(cfg.model, "door_max_width", 5),
            door_space_min_frac=getattr(cfg.model, "door_space_min_frac", 0.60),
            paint_guides_as_walls=getattr(cfg.model, "paint_guides_as_walls", True),
            # <<< ------------------------------------------------ >>>

            debug=getattr(cfg.model, "debug", False),
            debug_dir=getattr(cfg.model, "debug_dir", os.path.join(cfg.paths.save_dir, "debug")),
            debug_limit=getattr(cfg.model, "debug_limit", 0),
        )

    def fit(self, train_loader, val_loader):
        # one pass on val loader; mirror UNet logs
        t0 = time.perf_counter()
        l1_sum = mse_sum = 0.0
        miou_sum = 0.0
        n_batches = 0

        images_dir = os.path.join(self.cfg.paths.visual_results, "train")
        metrics_dir = os.path.join(self.cfg.paths.metric_results, "train")
        os.makedirs(images_dir, exist_ok=True)
        os.makedirs(metrics_dir, exist_ok=True)
        os.makedirs(self.cfg.paths.checkpoints, exist_ok=True)

        pbar = tqdm(val_loader, desc="Geom (val pass)", ncols=0)
        for b, (cond, tgt) in enumerate(pbar, 1):
            cond = cond.to(self.device, non_blocking=True)
            tgt  = tgt.to(self.device, non_blocking=True)

            recon = self.model(cond).clamp(0,1)        # [B,1,H,W]

            # scalars
            l1_sum  += float(F.l1_loss(recon, tgt))
            mse_sum += float(F.mse_loss(recon, tgt))

            # IoU macro over hard classes
            rq = quantize_three(recon)
            tq = quantize_three(tgt)
            pc = _to_classes(rq); tc = _to_classes(tq)
            miou, _ = _iou_macro(pc, tc)
            miou_sum += miou

            # save a few images
            if b == 1:
                cq = quantize_three(cond)
                bq = blend_generated_with_condition(cq, rq)
                save_visuals(cq[0].cpu(), tq[0].cpu(), rq[0].cpu(), bq[0].cpu(),
                             out_dir=images_dir, base_name="epoch_0000")
                # tiny “checkpoint” marker so your scripts look consistent
                with open(os.path.join(self.cfg.paths.checkpoints, "geom.info"), "w") as f:
                    f.write("geometrical baseline — no trainable weights\n")

            n_batches += 1

        l1  = l1_sum  / max(1, n_batches)
        mse = mse_sum / max(1, n_batches)
        miou = miou_sum / max(1, n_batches)
        print(f"[Geom] L1 {l1:.4f} | MSE {mse:.4f} | mIoU {miou:.4f}")
        # CSV like trainer_unet
        csv_path = os.path.join(metrics_dir, "metrics.csv")
        newf = not os.path.exists(csv_path)
        with open(csv_path, "a", newline="") as f:
            w = csv.writer(f)
            if newf: w.writerow(["epoch", "train_loss", "val_loss", "L1", "MSE"])
            w.writerow([0, 0.0, 0.0, l1, mse])

        print(f"Elapsed {time.perf_counter() - t0:.2f}s")
        return miou