from __future__ import annotations

import os, csv, time
from types import SimpleNamespace as SN
from typing import Dict, Any, Optional, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm.auto import tqdm

from utils.io import save_checkpoint, load_checkpoint
from viz.panels import save_visuals
from utils.tensor_ops import quantize_three, blend_generated_with_condition
from losses.diffusion import Diffusion

import contextlib



class RePaintTrainer:
    """
    CVAE-aligned trainer for RePaint-style diffusion with conditioning.
    Model must expose:
      - unet(x_t, t, cond)
      - q_sample(x0, t, noise)
      - alpha_bars: Tensor[T]
    cfg must have:
      - cfg.diff.timesteps (int)
      - cfg.loss: weights (passed to Diffusion.repaint_loss)
      - cfg.train: lr/epochs/val_interval/scheduler/patience/min_lr
      - cfg.paths: checkpoints / metric_results / visual_results (set by attach_default_paths)
    """

    def __init__(self, model: nn.Module, cfg: SN, device: torch.device):
        self.model = model.to(device)
        self.cfg = cfg
        self.device = device

        train_ns = getattr(cfg, "train", SN())
        lr = float(getattr(train_ns, "lr", 2e-4))
        self.opt = torch.optim.Adam(self.model.parameters(), lr=lr)

        # --- scheduler: same options as CVAE ---
        sched_name = str(getattr(train_ns, "scheduler", "plateau"))   # "plateau" | "cosine" | "none"
        patience   = int(getattr(train_ns, "patience", 4))
        min_lr     = float(getattr(train_ns, "min_lr", 1e-6))
        epochs     = int(getattr(train_ns, "epochs", 100))

        if sched_name == "plateau":
            self.sched = torch.optim.lr_scheduler.ReduceLROnPlateau(
                self.opt, mode="min", factor=0.5, patience=patience, min_lr=min_lr
            )
        elif sched_name == "cosine":
            self.sched = torch.optim.lr_scheduler.CosineAnnealingLR(
                self.opt, T_max=epochs, eta_min=min_lr
            )
        else:
            self.sched = None
        # ---------------------------------------

    @staticmethod
    def _append_metrics_csv(csv_path: str, epoch: int, train_loss: float, val_loss: float,
                            l1: float, mse: float) -> None:
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)
        new_file = not os.path.exists(csv_path)
        with open(csv_path, "a", newline="") as f:
            w = csv.writer(f)
            if new_file:
                w.writerow(["epoch", "train_loss", "val_loss", "L1", "MSE"])
            w.writerow([epoch, train_loss, val_loss, l1, mse])

    def restore(
        self,
        filename: Union[str, os.PathLike],
        *,
        strict: bool = True,
        map_location: Optional[Union[str, torch.device]] = None,
    ) -> Dict[str, Any]:
        if map_location is None:
            map_location = self.device

        result = load_checkpoint(
            filename=filename,
            objects={'model': self.model, 'opt': self.opt, 'sched': self.sched},
            map_location=map_location,
            strict=strict,
        )
        meta = result.get("meta", {})
        self._ckpt_meta = meta
        self._ckpt_best_val = float(meta.get("best_val_loss", float("inf")))
        self._ckpt_last_val = float(meta.get("val_loss", float("nan")))
        self._ckpt_epoch = int(meta.get("epoch", 0))

        print(
            f"[restore] loaded '{os.path.basename(str(filename))}' "
            f"(epoch={self._ckpt_epoch}, best_val={self._ckpt_best_val:.4f}, "
            f"val={self._ckpt_last_val:.4f})"
        )
        if result.get("restore_report"):
            print(f"[restore] report: {result['restore_report']}")
        return result

    # ---- core step helpers ----
    def _train_step(self, cond: torch.Tensor, tgt: torch.Tensor) -> torch.Tensor:
        self.model.train()
        B = tgt.size(0)
        T = int(getattr(self.cfg.diff, "timesteps", 0))
        t = torch.randint(0, T, (B,), device=tgt.device, dtype=torch.long)
        loss = self.model.p_losses(tgt, cond, t)
        return loss

    @torch.no_grad()
    def _val_step(self, cond: torch.Tensor, tgt: torch.Tensor):
        self.model.eval()
        B = tgt.size(0)
        T = int(getattr(self.cfg.diff, "timesteps", 0))
        t = torch.randint(0, T, (B,), device=tgt.device, dtype=torch.long)

        # Rebuild x0_pred for metrics (same as you had)
        noise = torch.randn_like(tgt)
        x_noisy = self.model.q_sample(tgt, t, noise)
        pred_noise = self.model.unet(x_noisy, t, cond)

        alpha_bars = self.model.alpha_bars
        alpha_bar_t = alpha_bars.gather(dim=0, index=t).view(-1, 1, 1, 1)
        x0_pred = (x_noisy - torch.sqrt(1.0 - alpha_bar_t) * pred_noise) / torch.sqrt(alpha_bar_t)
        x0_pred = x0_pred.clamp(0.0, 1.0)

        # VALIDATION LOSS (correct call)
        total = self.model.p_losses(tgt, cond, t)

        l1 = F.l1_loss(x0_pred, tgt)
        mse = F.mse_loss(x0_pred, tgt)
        return total, l1, mse, x0_pred

    # ---- fit loop (mirrors CVAE) ----
    def fit(self, train_loader, val_loader, result: Optional[Dict[str, Any]] = None):

        # -------- helpers --------
        @contextlib.contextmanager
        def preserve_rng():
            cpu_state = torch.random.get_rng_state()
            cuda_states = torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None
            try:
                yield
            finally:
                torch.random.set_rng_state(cpu_state)
                if cuda_states is not None:
                    torch.cuda.set_rng_state_all(cuda_states)

        def first_batch(dloader):
            try:
                return next(iter(dloader))
            except StopIteration:
                return None

        # -------- resume-aware init --------
        best = float("inf")
        start_epoch = 1
        if result:
            meta = result.get("meta", {})
            start_epoch = int(meta.get("epoch", 0)) + 1
            best = float(meta.get("best_val_loss", float("inf")))
            print(f"[fit] resuming from epoch {start_epoch} (best_val so far = {best:.6f})")
        elif hasattr(self, "_ckpt_epoch"):
            start_epoch = int(getattr(self, "_ckpt_epoch", 0)) + 1
            best = float(getattr(self, "_ckpt_best_val", float("inf")))
            print(f"[fit] resuming from epoch {start_epoch} (best_val so far = {best:.6f})")

        train_ns = getattr(self.cfg, "train", SN())
        epochs = int(getattr(train_ns, "epochs", 100))
        val_interval = int(getattr(train_ns, "val_interval", 100))
        use_amp = bool(getattr(train_ns, "amp", False))
        scaler = torch.cuda.amp.GradScaler(enabled=use_amp)

        if start_epoch > epochs:
            print(f"[fit] start_epoch {start_epoch} > configured epochs {epochs}; exiting.")
            return best

        # -------- sanity: warn if any norm tracks running stats --------
        for m in self.model.modules():
            if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d)):
                print("[fit][warn] BatchNorm present; eval() during validation is essential.")
            if isinstance(m, (nn.InstanceNorm1d, nn.InstanceNorm2d, nn.InstanceNorm3d)):
                # Default is track_running_stats=False; if True, call eval matters
                if getattr(m, "track_running_stats", False):
                    print("[fit][warn] InstanceNorm with running stats detected; eval() will freeze them.")

        for epoch in range(start_epoch, epochs + 1):
            t0 = time.perf_counter()
            self.model.train()  # <-- training mode

            # ---- train ----
            loss_sum, n = 0.0, 0
            pbar = tqdm(train_loader, desc=f"Train {epoch}/{epochs}", ncols=0)
            for cond, tgt in pbar:
                cond = cond.to(self.device, non_blocking=True)
                tgt = tgt.to(self.device, non_blocking=True)

                self.opt.zero_grad(set_to_none=True)
                if use_amp:
                    with torch.cuda.amp.autocast():
                        loss = self._train_step(cond, tgt)
                    scaler.scale(loss).backward()
                    nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                    scaler.step(self.opt)
                    scaler.update()
                else:
                    loss = self._train_step(cond, tgt)
                    loss.backward()
                    nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                    self.opt.step()

                loss_sum += float(loss);
                n += 1
                pbar.set_postfix(loss=f"{loss_sum / max(1, n):.4f}")

            train_mean = loss_sum / max(1, n)
            print(f"[Epoch {epoch}] loss {train_mean:.4f}")
            print(f"Elapsed time for 1 training epoch {time.perf_counter() - t0:.2f}s")

            # step non-plateau schedulers every epoch
            if self.sched and not isinstance(self.sched, torch.optim.lr_scheduler.ReduceLROnPlateau):
                self.sched.step()

            # ---- validation gate ----
            do_val = (epoch % val_interval == 0) or (epoch == epochs)
            if not do_val:
                continue

            with preserve_rng():  # don’t let val change training RNG sequence
                t0 = time.perf_counter()
                self.model.eval()  # <-- eval mode for norms/dropout/etc.
                val_sum = l1_sum = mse_sum = 0.0
                with torch.no_grad():
                    for cond, tgt in val_loader:
                        cond = cond.to(self.device, non_blocking=True)
                        tgt = tgt.to(self.device, non_blocking=True)
                        total, l1, mse, _ = self._val_step(cond, tgt)
                        val_sum += float(total)
                        l1_sum += float(l1)
                        mse_sum += float(mse)

                val = val_sum / max(1, len(val_loader))
                l1 = l1_sum / max(1, len(val_loader))
                mse = mse_sum / max(1, len(val_loader))
                print(f"[Val @ {epoch}] loss {val:.4f} | L1 {l1:.4f} | MSE {mse:.4f}")
                print(f"Elapsed {time.perf_counter() - t0:.2f}s")

                # step plateau on validation loss
                if self.sched and isinstance(self.sched, torch.optim.lr_scheduler.ReduceLROnPlateau):
                    self.sched.step(val)

                # ---- checkpoints ----
                os.makedirs(self.cfg.paths.checkpoints, exist_ok=True)
                save_checkpoint(
                    objects={'model': self.model, 'opt': self.opt, 'sched': self.sched},
                    epoch=epoch, best_val=min(best, val), val_loss=val, cfg=self.cfg,
                    path=self.cfg.paths.checkpoints, tag=f"epoch_{epoch:04d}"
                )
                if val < best:
                    best = val
                    save_checkpoint(
                        objects={'model': self.model, 'opt': self.opt, 'sched': self.sched},
                        epoch=epoch, best_val=best, val_loss=val, cfg=self.cfg,
                        path=self.cfg.paths.checkpoints, tag="best"
                    )

                # ---- metrics CSV ----
                metrics_dir = os.path.join(self.cfg.paths.metric_results, "train")
                self._append_metrics_csv(os.path.join(metrics_dir, "metrics.csv"),
                                         epoch, train_mean, val, l1, mse)

                # ---- visuals ----
                images_dir = os.path.join(self.cfg.paths.visual_results, "train")
                os.makedirs(images_dir, exist_ok=True)

                batch = first_batch(val_loader) or first_batch(train_loader)
                if batch is not None:
                    cond_vis, tgt_vis = batch
                    cond_vis = cond_vis.to(self.device, non_blocking=True)
                    tgt_vis = tgt_vis.to(self.device, non_blocking=True)

                    with torch.no_grad():
                        _, _, _, x0_pred_vis = self._val_step(cond_vis, tgt_vis)

                    # panel parity with your CVAE-style plots
                    p_q = quantize_three(cond_vis)
                    g_q = quantize_three(x0_pred_vis)
                    b_q = blend_generated_with_condition(p_q, g_q)

                    base = f"epoch_{epoch:04d}"
                    save_visuals(p_q[0].cpu(), tgt_vis[0].cpu(), g_q[0].cpu(), b_q[0].cpu(),
                                 out_dir=images_dir, base_name=base)
                    # Optional: also save an unquantized prediction to see true grays
                    try:
                        save_visuals(cond_vis[0].cpu(), tgt_vis[0].cpu(), x0_pred_vis[0].cpu(), b_q[0].cpu(),
                                     out_dir=images_dir, base_name=base + "_raw")
                    except Exception:
                        pass
                    print(f"[viz] wrote {os.path.join(images_dir, base)}.png")
