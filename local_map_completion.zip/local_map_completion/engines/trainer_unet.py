# engines/trainer_unet.py
from __future__ import annotations

import os, csv, time
from types import SimpleNamespace as SN
from typing import Dict, Any, Optional, Union
import contextlib

import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm.auto import tqdm

from utils.io import save_checkpoint, load_checkpoint
from viz.panels import save_visuals
from utils.tensor_ops import quantize_three, blend_generated_with_condition
from losses.unet import logits_to_gray, target_to_classes, gray_to_labels, soft_dice_loss, batch_iou_from_logits


class UNetTrainer:
    """
    Trainer for CNN-based U-Net baseline (3+3 with skips/residuals).
    - Matches CVAE trainer behavior: optimizer, LR, schedulers, logging, visuals, checkpoints.
    - Loss: reconstruction only (no KL). Use 'bce_logits' (preferred) or 'mse'.
    - Model is expected to take (partial) -> logits (if final_act='none'); we sigmoid for metrics/visuals.
    """

    def __init__(self, model: nn.Module, cfg: SN, device: torch.device):

        self.model = model.to(device)
        self.cfg = cfg
        self.device = device

        train_ns = getattr(cfg, "train", SN())


        lr = float(getattr(train_ns, "lr", 2e-4))
        self.opt = torch.optim.Adam(self.model.parameters(), lr=lr)

        # loss configuration (parity with CVAE)
        loss_ns = getattr(cfg, "loss", SN())
        self.loss_type = str(getattr(loss_ns, "type", "ce")).lower()  # "ce" or "l1"

        if self.loss_type == "l1":
            self.crit = torch.nn.L1Loss().to(self.device)
            assert getattr(model, "head").out_channels == 1, "L1 expects out_ch=1"
        else:
            from losses.unet import UNetCrossEntropyLoss
            weights = getattr(loss_ns, "class_weights", None)
            self.crit = UNetCrossEntropyLoss(
                ignore_unknown=bool(getattr(loss_ns, "ignore_unknown", False)),
                ignore_index=int(getattr(loss_ns, "ignore_index", 255)),
                class_weights=getattr(loss_ns, "class_weights", None),
                label_smoothing=float(getattr(loss_ns, "label_smoothing", 0.0)),
            ).to(self.device)

            assert getattr(model, "head").out_channels == 3, "CE expects out_ch=3"



        self.use_mask  = bool(getattr(loss_ns, "use_mask", False))

        # --- scheduler (same options/params as CVAE) ---
        sched_name = str(getattr(train_ns, "scheduler", "plateau"))   # "plateau" | "cosine" | "none"
        patience   = int(getattr(train_ns, "patience", 4))
        min_lr     = float(getattr(train_ns, "min_lr", 1e-6))
        epochs     = int(getattr(train_ns, "epochs", 100))

        if sched_name == "plateau":
            self.sched = torch.optim.lr_scheduler.ReduceLROnPlateau(
                self.opt, mode="min", factor=0.5, patience=patience, min_lr=min_lr
            )
        elif sched_name == "cosine":
            self.sched = torch.optim.lr_scheduler.CosineAnnealingLR(
                self.opt, T_max=epochs, eta_min=min_lr
            )
        else:
            self.sched = None

        self.dice_weight = float(getattr(loss_ns, "dice_weight", 0.0))

    @staticmethod
    def _append_metrics_csv(csv_path: str, epoch: int, train_loss: float, val_loss: float,
                            l1: float, mse: float) -> None:
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)
        new_file = not os.path.exists(csv_path)
        with open(csv_path, "a", newline="") as f:
            w = csv.writer(f)
            if new_file:
                w.writerow(["epoch", "train_loss", "val_loss", "L1", "MSE"])
            w.writerow([epoch, train_loss, val_loss, l1, mse])

    def _forward(self, partial: torch.Tensor):
        """
        Forward pass through U-Net baseline.
        Expected to return logits (if model.final_act = 'none'). If your model
        applies sigmoid inside, metrics will still work but 'bce_logits' loss
        would be suboptimal; switch 'loss.type' to 'mse' in that case.
        """
        logits = self.model(partial)
        return logits

    def restore(
        self,
        filename: Union[str, os.PathLike],
        *,
        strict: bool = True,
        map_location: Optional[Union[str, torch.device]] = None,
    ) -> Dict[str, Any]:
        """
        Restore model/optimizer/scheduler state from a checkpoint created by `save_checkpoint`.
        """
        if map_location is None:
            map_location = self.device

        result = load_checkpoint(
            filename=filename,
            objects={'model': self.model, 'opt': self.opt, 'sched': self.sched},
            map_location=map_location,
            strict=strict,
        )

        meta = result.get("meta", {})
        self._ckpt_meta = meta
        best_val = float(meta.get("best_val_loss", float("inf")))
        best_miou = float(meta.get("best_miou", float("-inf")))
        self._ckpt_best_val = best_val
        self._ckpt_best_miou = best_miou
        self._ckpt_last_val = float(meta.get("val_loss", float("nan")))
        self._ckpt_epoch = int(meta.get("epoch", 0))

        print(
            f"[restore] loaded '{os.path.basename(str(filename))}' "
            f"(epoch={self._ckpt_epoch}, best_val={self._ckpt_best_val:.4f}, "
            f"best_mIoU={self._ckpt_best_miou:.4f}, val={self._ckpt_last_val:.4f})"
        )

        if result.get("restore_report"):
            print(f"[restore] report: {result['restore_report']}")
        return result

    def _logits_to_gray(self, logits: torch.Tensor, hard: bool = False) -> torch.Tensor:
        """
        Map 3-class logits [B,3,H,W] to a single grayscale channel [B,1,H,W]
        with class centers {0.0, 0.5, 1.0}.
        - hard=False: expectation over softmax probs (smooth)
        - hard=True: argmax → {0,1,2} then /2 → {0,0.5,1}
        """
        if hard:
            cls = logits.argmax(dim=1, keepdim=True).float()  # {0,1,2}
            return (cls / 2.0).clamp(0, 1)  # {0,0.5,1}
        probs = torch.softmax(logits, dim=1)  # [B,3,H,W]
        centers = torch.tensor([0.0, 0.5, 1.0], device=logits.device).view(1, 3, 1, 1)
        gray = (probs * centers).sum(dim=1, keepdim=True)  # [B,1,H,W]
        return gray.clamp(0, 1)

    @torch.no_grad()
    def set_head_bias_from_priors(self, model: torch.nn.Module, priors: torch.Tensor):
        """
        priors: Tensor[3] with p0,p1,p2 (sum=1). Sets final 1x1 conv bias to log-priors.
        """
        head = None
        for m in model.modules():
            if isinstance(m, torch.nn.Conv2d) and m.out_channels == 3 and m.kernel_size == (1, 1):
                head = m
        if head is None or head.bias is None:
            print("[bias_init] WARNING: couldn't find final 3-ch 1x1 conv with bias=True")
            return
        head.bias.copy_(priors.log().clamp_(-4, 4))
        print(f"[bias_init] set final head bias to log priors: {priors.tolist()}")

    def fit(self, train_loader, val_loader, result=None):

        self._class_weights_initialized = getattr(self, "_class_weights_initialized", False)

        import contextlib, time

        # ---- resume-aware init ----
        # ---- resume-aware init ----
        best_loss = float("inf")  # still track best validation loss
        best_miou = float("-inf")  # new: track best validation mIoU
        start_epoch = 1

        if result:
            meta = result.get("meta", {})
            start_epoch = int(meta.get("epoch", 0)) + 1
            best_loss = float(meta.get("best_val_loss", float("inf")))
            best_miou = float(meta.get("best_miou", float("-inf")))
            print(f"[fit] resuming from epoch {start_epoch} "
                  f"(best_val_loss={best_loss:.6f}, best_mIoU={best_miou:.4f})")
        elif hasattr(self, "_ckpt_epoch"):
            start_epoch = int(getattr(self, "_ckpt_epoch", 0)) + 1
            best_loss = float(getattr(self, "_ckpt_best_val", float("inf")))
            # in older checkpoints best_miou might not exist → default
            best_miou = float(getattr(self, "_ckpt_best_miou", float("-inf")))
            print(f"[fit] resuming from epoch {start_epoch} "
                  f"(best_val_loss={best_loss:.6f}, best_mIoU={best_miou:.4f})")

        train_ns = getattr(self.cfg, "train", SN())
        epochs = int(getattr(train_ns, "epochs", 100))
        val_interval = int(getattr(train_ns, "val_interval", 100))

        if start_epoch > epochs:
            print(f"[fit] start_epoch {start_epoch} > configured epochs {epochs}; exiting.")
            return best_loss

        # sanity ping for normalization layers
        for m in self.model.modules():
            if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d)):
                print("[fit][warn] BatchNorm present; eval() during validation is essential.")
            if isinstance(m, (nn.InstanceNorm1d, nn.InstanceNorm2d, nn.InstanceNorm3d)):
                if getattr(m, "track_running_stats", False):
                    print("[fit][warn] InstanceNorm with running stats detected; eval() will freeze them.")

        @contextlib.contextmanager
        def preserve_rng():
            cpu_state = torch.random.get_rng_state()
            cuda_states = torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None
            try:
                yield
            finally:
                torch.random.set_rng_state(cpu_state)
                if cuda_states is not None:
                    torch.cuda.set_rng_state_all(cuda_states)

        self._head_bias_initialized = getattr(self, "_head_bias_initialized", False)

        for epoch in range(start_epoch, epochs + 1):
            t0 = time.perf_counter()

            # ---- train ----
            self.model.train()
            loss_sum, n = 0.0, 0

            # epoch-level GT class histogram (always from ground-truth)
            gt_hist_epoch = torch.zeros(3, dtype=torch.long, device=self.device)

            pbar = tqdm(train_loader, desc=f"Train {epoch}/{epochs}", ncols=0)
            for partial, complete in pbar:
                partial = partial.to(self.device, non_blocking=True)
                c = complete.to(self.device, non_blocking=True)

                logits = self._forward(partial)

                if self.loss_type == "l1":
                    # regression: 1-ch -> [0,1]
                    pred = torch.sigmoid(logits).clamp(0, 1)
                    loss = self.crit(pred, c)  # L1(pred, target)
                else:
                    # classification: 3-ch CE
                    ce = self.crit(logits, c)
                    loss = ce + self.dice_weight * soft_dice_loss(logits, c)

                self.opt.zero_grad(set_to_none=True)
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.opt.step()

                # accumulate GT histogram (from *ground truth*, not prediction)
                with torch.no_grad():
                    labels = gray_to_labels(c, tol=1e-3, ignore_unknown=False)  # [B,H,W], long {0,1,2}
                    gt_hist_epoch += torch.bincount(labels.reshape(-1), minlength=3)

                loss_sum += float(loss)
                n += 1
                pbar.set_postfix(loss=f"{loss_sum / max(1, n):.4f}")

            train_mean = loss_sum / max(1, n)
            print(f"[Epoch {epoch}] loss {train_mean:.4f}")
            print(f"[dbg][train@{epoch}] gt hist {gt_hist_epoch.tolist()}")
            print(f"Elapsed time for 1 training epoch {time.perf_counter() - t0:.2f}s")

            use_dynamic = bool(getattr(self.cfg.loss, "use_dynamic_class_weights", True))

            # --- NEW: auto-compute class weights from histogram (first time only) ---
            if use_dynamic and (not self._class_weights_initialized
                    and hasattr(self.crit, "set_class_weights")
                    and gt_hist_epoch.sum() > 0):
                total = gt_hist_epoch.sum().float().clamp_min(1.0)
                freqs = (gt_hist_epoch.float() / total).clamp_(1e-6, 1.0)  # p0, p1, p2

                # Inverse-frequency weights: w_k ∝ 1 / p_k
                inv = 1.0 / freqs
                weights = inv / inv.mean()  # normalize so mean(weight) ≈ 1

                # Move to correct device and set in the loss
                weights = weights.to(self.device)

                # # manually nudge unknown if needed (index 1):
                # weights[1] *= 0.7
                # weights = weights / weights.mean()

                self.crit.set_class_weights(weights)
                self._class_weights_initialized = True

                print(f"[cls_w] set class_weights from hist: {weights.tolist()}")
            # -----------------------------------------------------------------

            # step non-plateau schedulers every epoch
            if self.sched and not isinstance(self.sched, torch.optim.lr_scheduler.ReduceLROnPlateau):
                self.sched.step()

            # ---- validation gate ----
            do_val = (epoch % val_interval == 0) or (epoch == epochs)
            if not do_val:
                continue

            with preserve_rng():
                t0 = time.perf_counter()
                self.model.eval()
                val_sum = l1_sum = mse_sum = 0.0

                # CE-only aggregates
                if self.loss_type == "ce":
                    pred_hist_epoch = torch.zeros(3, dtype=torch.long, device=self.device)
                    conf_sum = 0.0
                    n_conf = 0
                    conf_max = 0.0
                    conf_p95_buf = []

                    inter_acc = torch.zeros(3, device=self.device)
                    union_acc = torch.zeros(3, device=self.device)

                with torch.no_grad():
                    for val_index, (p, c) in enumerate(val_loader):
                        p = p.to(self.device, non_blocking=True)
                        c = c.to(self.device, non_blocking=True)

                        logits = self._forward(p)

                        if self.loss_type == "l1":
                            # 1-ch regression: sigmoid to [0,1]
                            pred_gray = torch.sigmoid(logits).clamp(0, 1)  # [B,1,H,W]
                            val_sum += self.crit(pred_gray, c).item()

                            # sparse debug
                            if val_index % 100 == 0:
                                print(f"[dbg][val@{epoch}] pred stats mean {pred_gray.mean():.4f} "
                                      f"p95 {pred_gray.quantile(0.95):.4f} max {pred_gray.max():.4f}")
                        else:
                            # 3-ch CE: compute CE on logits; grayscale for metrics/viz
                            ce = self.crit(logits, c)
                            loss = ce + self.dice_weight * soft_dice_loss(logits, c)
                            val_sum += loss.item()

                            probs = logits.softmax(dim=1)  # [B,3,H,W]
                            pred_gray = (probs[:, 0:1] * 0.0 +
                                         probs[:, 1:2] * 0.5 +
                                         probs[:, 2:3] * 1.0).clamp(0, 1)

                            if val_index % 100 == 0:
                                conf = probs.max(1).values
                                print(f"[dbg][val@{epoch}] conf mean {conf.mean():.4f} "
                                      f"p95 {conf.quantile(0.95):.4f} max {conf.max():.4f}")

                            # aggregates (CE only)
                            # inside CE validation branch, under torch.no_grad()
                            pred = probs.argmax(dim=1)  # [B,H,W], long
                            pred_hist_epoch += torch.bincount(pred.reshape(-1), minlength=3)

                            conf = probs.max(1).values
                            conf_sum += float(conf.sum())
                            conf_max = max(conf_max, float(conf.max()))
                            n_conf += conf.numel()
                            if (val_index % 10) == 0:
                                conf_p95_buf.append(conf.flatten().cpu())

                        # common scalar metrics
                        l1_sum += float(F.l1_loss(pred_gray, c))
                        mse_sum += float(F.mse_loss(pred_gray, c))

                        inter, union = batch_iou_from_logits(
                            logits, c,
                            tol=1e-3,
                            ignore_unknown=bool(getattr(self.cfg.loss, "ignore_unknown", False)),
                            num_classes=3
                        )
                        inter_acc += inter
                        union_acc += union

                val = val_sum / max(1, len(val_loader))
                l1 = l1_sum / max(1, len(val_loader))
                mse = mse_sum / max(1, len(val_loader))

                metrics_dir = os.path.join(self.cfg.paths.metric_results, "train")

                if self.loss_type == "ce":
                    p95 = float(torch.cat(conf_p95_buf).quantile(0.95)) if conf_p95_buf else float('nan')
                    conf_mean = conf_sum / max(1, n_conf)
                    print(f"[dbg][val@{epoch}] pred hist {pred_hist_epoch.tolist()} "
                          f"| conf mean {conf_mean:.4f} p95 {p95:.4f} max {conf_max:.4f}")

                    ious = (inter_acc / union_acc.clamp_min(1.0)).tolist()
                    miou = sum(ious) / len(ious)
                    print(f"[dbg][val@{epoch}] IoU per class {ious} | mIoU {miou:.4f}")

                    iou_csv = os.path.join(metrics_dir, "iou.csv")
                    new_file = not os.path.exists(iou_csv)
                    with open(iou_csv, "a", newline="") as f:
                        w = csv.writer(f)
                        if new_file:
                            w.writerow(["epoch", "IoU_0", "IoU_1", "IoU_2", "mIoU"])
                        w.writerow([epoch, *[f"{x:.6f}" for x in ious], f"{miou:.6f}"])

                print(f"[Val @ {epoch}] loss {val:.4f} | L1 {l1:.4f} | MSE {mse:.4f}")
                print(f"Elapsed {time.perf_counter() - t0:.2f}s")

                # step plateau on validation loss
                if self.sched and isinstance(self.sched, torch.optim.lr_scheduler.ReduceLROnPlateau):
                    self.sched.step(val)

                # ---- checkpoints ----
                os.makedirs(self.cfg.paths.checkpoints, exist_ok=True)
                save_checkpoint(
                    objects={'model': self.model, 'opt': self.opt, 'sched': self.sched},
                    epoch=epoch,
                    best_val=min(best_loss, val),
                    best_miou=best_miou,
                    val_loss=val,
                    cfg=self.cfg,
                    path=self.cfg.paths.checkpoints,
                    tag=f"epoch_{epoch:04d}",
                )

                # ---- update best by mIoU (higher is better) ----
                if miou > best_miou:
                    best_miou = miou
                    print(f"[ckpt] new BEST mIoU at epoch {epoch} (mIoU={best_miou:.4f})")
                    save_checkpoint(
                        objects={'model': self.model, 'opt': self.opt, 'sched': self.sched},
                        epoch=epoch,
                        best_val=best_loss,
                        best_miou=best_miou,
                        val_loss=val,
                        cfg=self.cfg,
                        path=self.cfg.paths.checkpoints,
                        tag="best_miou",  # <--- different tag
                    )

                # ---- update best by validation loss (lower is better) ----
                if val < best_loss:
                    best_loss = val
                    print(f"[ckpt] new BEST loss at epoch {epoch} (loss={best_loss:.6f})")
                    save_checkpoint(
                        objects={'model': self.model, 'opt': self.opt, 'sched': self.sched},
                        epoch=epoch,
                        best_val=best_loss,
                        best_miou=best_miou,  # store current best_miou even here
                        val_loss=val,
                        cfg=self.cfg,
                        path=self.cfg.paths.checkpoints,
                        tag="best_loss",  # <--- different tag
                    )

                # ---- metrics CSV ----
                self._append_metrics_csv(os.path.join(metrics_dir, "metrics.csv"),
                                         epoch, train_mean, val, l1, mse)

                # ---- visuals ----
                images_dir = os.path.join(self.cfg.paths.visual_results, "train")
                os.makedirs(images_dir, exist_ok=True)

                # pick a batch for visualization
                try:
                    p_vis, c_vis = next(iter(val_loader))
                except StopIteration:
                    p_vis, c_vis = next(iter(train_loader))

                p_vis = p_vis.to(self.device, non_blocking=True)
                c_vis = c_vis.to(self.device, non_blocking=True)
                with torch.no_grad():
                    logits_vis = self.model(p_vis)
                    if self.loss_type == "l1":
                        pred_vis = torch.sigmoid(logits_vis).clamp(0, 1)  # [B,1,H,W]
                    else:
                        probs_vis = logits_vis.softmax(1)
                        pred_vis = (probs_vis[:, 0:1] * 0.0 +
                                    probs_vis[:, 1:2] * 0.5 +
                                    probs_vis[:, 2:3] * 1.0).clamp(0, 1)

                p_q = quantize_three(p_vis)  # [B,1,H,W]
                g_q = quantize_three(pred_vis)  # predicted grayscale
                b_q = blend_generated_with_condition(p_q, g_q)

                base = f"epoch_{epoch:04d}"
                save_visuals(p_q[0].cpu(), c_vis[0].cpu(), g_q[0].cpu(), b_q[0].cpu(),
                             out_dir=images_dir, base_name=base)
                print(f"[viz] wrote {os.path.join(images_dir, base)}.png")

            # ---- once (or per-epoch) bias init from priors — CE only, if method exists
            if (self.loss_type == "ce") and (not self._head_bias_initialized) and hasattr(self,
                                                                                          "set_head_bias_from_priors"):
                total = gt_hist_epoch.sum().float().clamp_min(1.0)
                priors = (gt_hist_epoch.float() / total).clamp_(1e-6, 1.0)
                self.set_head_bias_from_priors(self.model, priors)
                self._head_bias_initialized = True
                print(f"[bias_init] set final head bias to log priors (once)")

        return best_loss
