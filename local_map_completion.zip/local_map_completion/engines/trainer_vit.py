# engines/trainer_vit.py
from __future__ import annotations
import os, csv, time
from types import SimpleNamespace as SN
from typing import Union, Optional, Dict, Any

import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm.auto import tqdm

from utils.io import save_checkpoint, load_checkpoint
from viz.panels import save_visuals
from utils.tensor_ops import quantize_three, blend_generated_with_condition
from losses.vit import recon_loss as vit_recon_loss, eval_metrics_from_logits


class ViTTrainer:
    def __init__(self, model: nn.Module, cfg: SN, device: torch.device):
        self.model = model.to(device)
        self.cfg = cfg
        self.device = device

        train_ns = getattr(cfg, "train", SN())
        loss_ns  = getattr(cfg, "loss",  SN())

        lr = float(getattr(train_ns, "lr", 2e-4))
        wd = float(getattr(train_ns, "weight_decay", 0.0))

        self.opt = torch.optim.Adam(self.model.parameters(), lr=lr, weight_decay=wd)
        self.loss_type = str(getattr(cfg.loss, "type", "mse"))
        self.huber_beta = float(getattr(cfg.loss, "beta", 0.1))

        # --- scheduler (same pattern as GAN) ---
        sched_name = str(getattr(train_ns, "scheduler", "plateau"))
        patience   = int(getattr(train_ns, "patience", 4))
        min_lr     = float(getattr(train_ns, "min_lr", 1e-6))
        epochs     = int(getattr(train_ns, "epochs", 100))

        if sched_name == "plateau":
            self.sched = torch.optim.lr_scheduler.ReduceLROnPlateau(
                self.opt, mode="min", factor=0.5, patience=patience, min_lr=min_lr
            )
        elif sched_name == "cosine":
            self.sched = torch.optim.lr_scheduler.CosineAnnealingLR(
                self.opt, T_max=epochs, eta_min=min_lr
            )
        else:
            self.sched = None
        # ---------------------------------------

    @staticmethod
    def _append_metrics_csv(csv_path: str, epoch: int, train_loss: float, val_loss: float,
                            l1: float, mse: float) -> None:
        os.makedirs(os.path.dirname(csv_path), exist_ok=True)
        new_file = not os.path.exists(csv_path)
        with open(csv_path, "a", newline="") as f:
            w = csv.writer(f)
            if new_file:
                w.writerow(["epoch", "train_loss", "val_loss", "L1", "MSE"])
            w.writerow([epoch, train_loss, val_loss, l1, mse])

    # --- added: load_checkpoint / restore (mirrors CVAE/GAN) ---
    def restore(
            self,
            filename: Union[str, os.PathLike],
            *,
            strict: bool = True,
            map_location: Optional[Union[str, torch.device]] = None,
    ) -> Dict[str, Any]:
        if map_location is None:
            map_location = self.device

        result = load_checkpoint(
            filename=filename,
            objects={'model': self.model, 'opt': self.opt, 'sched': self.sched},
            map_location=map_location,
            strict=strict,
        )

        # cache meta for resume
        self._ckpt_meta = result.get("meta", {})
        self._ckpt_best_val = float(self._ckpt_meta.get("best_val_loss", float("inf")))
        self._ckpt_last_val = float(self._ckpt_meta.get("val_loss", float("nan")))
        self._ckpt_epoch = int(self._ckpt_meta.get("epoch", 0))

        print(
            f"[restore] loaded '{os.path.basename(str(filename))}' "
            f"(epoch={self._ckpt_epoch}, best_val={self._ckpt_best_val:.4f}, "
            f"val={self._ckpt_last_val:.4f})"
        )
        if result.get("restore_report"):
            print(f"[restore] report: {result['restore_report']}")
        return result
    # -----------------------------------------------------------

    # updated: resume-aware fit (optional `result`)
    def fit(self, train_loader, val_loader, result: Optional[Dict[str, Any]] = None):
        best = float("inf")
        start_epoch = 1

        if result:
            meta = result.get("meta", {})
            start_epoch = int(meta.get("epoch", 0)) + 1
            best = float(meta.get("best_val_loss", float("inf")))
            print(f"[fit] resuming from epoch {start_epoch} (best_val so far = {best:.6f})")
        elif hasattr(self, "_ckpt_epoch"):
            start_epoch = int(getattr(self, "_ckpt_epoch", 0)) + 1
            best = float(getattr(self, "_ckpt_best_val", float("inf")))
            print(f"[fit] resuming from epoch {start_epoch} (best_val so far = {best:.6f})")

        train_ns = getattr(self.cfg, "train", SN())
        epochs = int(getattr(train_ns, "epochs", 100))
        val_interval = int(getattr(train_ns, "val_interval", 100))

        if start_epoch > epochs:
            print(f"[fit] start_epoch {start_epoch} > configured epochs {epochs}; exiting.")
            return best

        for epoch in range(start_epoch, epochs + 1):

            epoch_t0 = time.perf_counter()

            # ---- train ----
            self.model.train()
            loss_sum, n = 0.0, 0
            pbar = tqdm(train_loader, desc=f"Train {epoch}/{epochs}", ncols=0)
            for partial, complete in pbar:
                partial = partial.to(self.device, non_blocking=True)
                complete = complete.to(self.device, non_blocking=True)

                logits = self.model(partial)
                loss = vit_recon_loss(logits, complete, mode=self.loss_type, beta=self.huber_beta)

                self.opt.zero_grad(set_to_none=True)
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.opt.step()

                loss_sum += float(loss); n += 1
                pbar.set_postfix(loss=f"{loss_sum / max(1, n):.4f}")

            train_mean = loss_sum / max(1, n)
            print(f"[Epoch {epoch}] loss {train_mean:.4f}")

            # step non-plateau schedulers per epoch
            if self.sched and not isinstance(self.sched, torch.optim.lr_scheduler.ReduceLROnPlateau):
                self.sched.step()

            elapsed = time.perf_counter() - epoch_t0
            print(f"Elapsed time for 1 training epoch {elapsed:.2f}s")  # Elapsed 50.85s ~ 1000 training epochs

            # ---- interval gate ----
            do_val = (epoch % val_interval == 0) or (epoch == epochs)
            if not do_val:
                continue

            # ---- validation ----
            t0 = time.perf_counter()
            self.model.eval()
            val_sum = l1_sum = mse_sum = 0.0
            with torch.no_grad():
                for p, c in val_loader:
                    p = p.to(self.device, non_blocking=True)
                    c = c.to(self.device, non_blocking=True)
                    logits = self.model(p)
                    val_sum += float(vit_recon_loss(logits, c, mode=self.loss_type))
                    l1, mse = eval_metrics_from_logits(logits, c)
                    l1_sum += float(l1); mse_sum += float(mse)

            val = val_sum / max(1, len(val_loader))
            l1  = l1_sum / max(1, len(val_loader))
            mse = mse_sum / max(1, len(val_loader))
            elapsed = time.perf_counter() - t0
            print(f"[Val @ {epoch}] loss {val:.4f} | L1 {l1:.4f} | MSE {mse:.4f} | Elapsed {elapsed:.2f}s")

            # step plateau on validation loss
            if self.sched and isinstance(self.sched, torch.optim.lr_scheduler.ReduceLROnPlateau):
                self.sched.step(val)

            # ---- checkpoints ----
            os.makedirs(self.cfg.paths.checkpoints, exist_ok=True)
            save_checkpoint(
                objects={'model': self.model, 'opt': self.opt, 'sched': self.sched},
                epoch=epoch, best_val=min(best, val), val_loss=val, cfg=self.cfg,
                path=self.cfg.paths.checkpoints, tag=f"epoch_{epoch:04d}"
            )
            if val < best:
                best = val
                save_checkpoint(
                    objects={'model': self.model, 'opt': self.opt, 'sched': self.sched},
                    epoch=epoch, best_val=best, val_loss=val, cfg=self.cfg,
                    path=self.cfg.paths.checkpoints, tag="best"
                )

            # ---- metrics & visuals ----
            metrics_dir = os.path.join(self.cfg.paths.metric_results, "train")
            self._append_metrics_csv(os.path.join(metrics_dir, "metrics.csv"),
                                     epoch, train_mean, val, l1, mse)

            images_dir = os.path.join(self.cfg.paths.visual_results, "train")
            os.makedirs(images_dir, exist_ok=True)
            try:
                p_vis, c_vis = next(iter(val_loader))
            except StopIteration:
                p_vis, c_vis = next(iter(train_loader))

            p_vis = p_vis.to(self.device); c_vis = c_vis.to(self.device)
            with torch.no_grad():
                logits_vis = self.model(p_vis)
                pred_vis = logits_vis.sigmoid().clamp(0, 1)
                p_q = quantize_three(p_vis); g_q = quantize_three(pred_vis)
                b_q = blend_generated_with_condition(p_q, g_q)

            base = f"epoch_{epoch:04d}"
            save_visuals(p_q[0].cpu(), c_vis[0].cpu(), g_q[0].cpu(), b_q[0].cpu(),
                         out_dir=images_dir, base_name=base)
            print(f"[viz] wrote {os.path.join(images_dir, base)}.png")

        return best
