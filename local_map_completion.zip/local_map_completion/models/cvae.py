# models/cvae.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np



class ConditionPyramid32_3x3(nn.Module):
    """
    32x32 condition için piramit:
      32 -> 16 -> 8 -> 4
      decoder'da 4, 8, 16 seviyelerinde fuse edeceğiz (3 up).
    """
    def __init__(self):
        super().__init__()

    def forward(self, cond_32):   # [B,1,32,32]
        cond_16 = F.avg_pool2d(cond_32, 2, 2)   # 32 -> 16
        cond_8  = F.avg_pool2d(cond_16, 2, 2)   # 16 -> 8
        cond_4  = F.avg_pool2d(cond_8, 2, 2)    # 8  -> 4
        return cond_16, cond_8, cond_4


class ConditionalVAE3x3_32(nn.Module):
    """
    32x32 patch'ler için 3 down / 3 up Conditional VAE.
    - Encoder: 32 -> 16 -> 8 -> 4
    - Decoder: 4 -> 8 -> 16 -> 32
    - Condition: 32x32 partial map, 16/8/4 seviyelerinde fuse edilir.

    forward(y, condition):
      y          : [B,1,32,32]  (GT full patch)
      condition  : [B,1,32,32]  (partial / input patch)
    """
    def __init__(
        self,
        in_ch: int = 1,
        base_ch: int = 32,
        latent_dim: int = 32,
        image_size: int = 32,
        num_layers: int = 3,
    ):
        super().__init__()
        assert image_size == 32, "ConditionalVAE3x3_32 is for 32x32 patches."
        assert num_layers == 3, "This variant uses 3 down / 3 up."

        self.in_ch = in_ch
        self.base_ch = base_ch
        self.latent_dim = latent_dim
        self.image_size = image_size
        self.num_layers = num_layers

        ch1 = base_ch        # 32x32 -> 16x16
        ch2 = base_ch * 2    # 16x16 -> 8x8
        ch3 = base_ch * 4    # 8x8   -> 4x4  (bottleneck)

        # -------- Encoder: 32 -> 16 -> 8 -> 4
        self.enc = nn.Sequential(
            # 32 -> 16
            nn.Conv2d(in_ch, ch1, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(ch1),
            nn.ReLU(inplace=True),

            # 16 -> 8
            nn.Conv2d(ch1, ch2, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(ch2),
            nn.ReLU(inplace=True),

            # 8 -> 4
            nn.Conv2d(ch2, ch3, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(ch3),
            nn.ReLU(inplace=True),
        )

        enc_spatial = 4
        self.enc_feat_dim = ch3 * enc_spatial * enc_spatial
        self.fc_mu = nn.Linear(self.enc_feat_dim, latent_dim)
        self.fc_logvar = nn.Linear(self.enc_feat_dim, latent_dim)

        # -------- Condition pyramid: 32 -> 16 -> 8 -> 4
        self.cond_pyr = ConditionPyramid32_3x3()

        # -------- Decoder: z + cond -> logits, 4->8->16->32
        self.fc_dec = nn.Linear(latent_dim, self.enc_feat_dim)

        # 4 -> 8, cond_4 ile fuse
        self.up1 = nn.Sequential(
            nn.ConvTranspose2d(ch3 + 1, ch2, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(ch2),
            nn.ReLU(inplace=True),
        )

        # 8 -> 16, cond_8 ile fuse
        self.up2 = nn.Sequential(
            nn.ConvTranspose2d(ch2 + 1, ch1, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(ch1),
            nn.ReLU(inplace=True),
        )

        # 16 -> 32, cond_16 ile fuse
        self.up3 = nn.Sequential(
            nn.ConvTranspose2d(ch1 + 1, ch1, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(ch1),
            nn.ReLU(inplace=True),
        )

        self.head = nn.Conv2d(ch1, 1, kernel_size=1)  # logits

        self.apply(self._init_weights)

    @staticmethod
    def _init_weights(m):
        if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d)):
            nn.init.kaiming_normal_(m.weight, nonlinearity="relu")
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Linear):
            nn.init.xavier_uniform_(m.weight)
            nn.init.zeros_(m.bias)

    # -------- Encoder
    def encode(self, y):
        h = self.enc(y)                    # [B, ch3, 4, 4]
        h_flat = h.flatten(1)             # [B, ch3*4*4]
        mu = self.fc_mu(h_flat)           # [B, latent_dim]
        log_var = self.fc_logvar(h_flat)  # [B, latent_dim]
        return mu, log_var

    @staticmethod
    def reparameterize(mu, log_var):
        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std)
        return mu + eps * std

    # -------- Decoder
    def decode(self, z, cond_32):
        cond_16, cond_8, cond_4 = self.cond_pyr(cond_32)  # hepsi [B,1,H,W]

        B = z.size(0)
        h = self.fc_dec(z).view(B, self.base_ch * 4, 4, 4)  # ch3

        # 4 -> 8
        h = torch.cat([h, cond_4], dim=1)
        h = self.up1(h)   # [B, ch2, 8, 8]

        # 8 -> 16
        h = torch.cat([h, cond_8], dim=1)
        h = self.up2(h)   # [B, ch1, 16, 16]

        # 16 -> 32
        h = torch.cat([h, cond_16], dim=1)
        h = self.up3(h)   # [B, ch1, 32, 32]

        logits = self.head(h)             # [B,1,32,32]
        return logits

    # -------- Forward & sample
    def forward(self, y, condition):
        """
        y         : [B,1,32,32]  full map
        condition : [B,1,32,32]  partial map
        """
        mu, log_var = self.encode(y)
        z = self.reparameterize(mu, log_var)
        logits = self.decode(z, condition)
        return logits, mu, log_var

    @torch.no_grad()
    def sample(self, condition, mode="posterior_mu", jitter=0.15,
               z_scale=0.6, truncation=1.5):
        """
        32x32 için sampling (128'dekiyle aynı arayüz).
        condition: [B,1,32,32]
        """
        B, device = condition.size(0), condition.device

        if mode == "posterior_mu":
            mu, logvar = self.encode(condition)
            if jitter > 0:
                z = mu + torch.randn_like(mu) * jitter
            else:
                z = mu
        elif mode == "posterior_sample":
            mu, logvar = self.encode(condition)
            z = self.reparameterize(mu, logvar)
        elif mode == "prior":
            z = torch.empty(B, self.latent_dim, device=device).normal_() * z_scale
        elif mode == "prior_trunc":
            z = torch.empty(B, self.latent_dim, device=device).normal_()
            z = torch.clamp(z, -truncation, truncation) * (0.7 / truncation)
        else:
            # default
            mu, logvar = self.encode(condition)
            z = mu

        logits = self.decode(z, condition)
        probs = torch.sigmoid(logits).clamp(0, 1)
        return logits, probs


