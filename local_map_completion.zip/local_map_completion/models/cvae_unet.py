# models/cvae_unet.py
import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------- building blocks (based on your UNet33Res) ----------

def _make_norm(norm, ch):
    if norm is None or norm == "none":
        return nn.Identity()
    if norm == "instance":
        return nn.InstanceNorm2d(ch, affine=True, track_running_stats=False)
    if norm == "batch":
        return nn.BatchNorm2d(ch)
    raise ValueError(f"Unknown norm: {norm}")

def _make_act(act):
    if act == "relu":
        return nn.ReLU(inplace=True)
    if act == "lrelu":
        return nn.LeakyReLU(0.2, inplace=True)
    if act == "gelu":
        return nn.GELU()
    raise ValueError(f"Unknown activation: {act}")

class ResidualConvBlock(nn.Module):
    """
    Two 3x3 convs (+norm+act) with residual skip.
    Uses a 1x1 projection when c_in != c_out.
    """
    def __init__(self, c_in, c_out, norm="instance", act="relu", dropout=0.0):
        super().__init__()
        bias = (norm is None) or (norm == "none")
        self.conv1 = nn.Conv2d(c_in,  c_out, 3, padding=1, bias=bias, padding_mode='reflect')
        self.norm1 = _make_norm(norm, c_out)
        self.act1  = _make_act(act)
        self.conv2 = nn.Conv2d(c_out, c_out, 3, padding=1, bias=bias, padding_mode='reflect')
        self.norm2 = _make_norm(norm, c_out)
        self.drop  = nn.Dropout2d(dropout) if dropout and dropout > 0 else nn.Identity()

        self.proj  = nn.Identity() if c_in == c_out else nn.Conv2d(c_in, c_out, 1, bias=False)
        self.act_out = _make_act(act)

    def forward(self, x):
        identity = self.proj(x)
        y = self.conv1(x)
        y = self.norm1(y)
        y = self.act1(y)
        y = self.conv2(y)
        y = self.norm2(y)
        y = self.drop(y)
        y = y + identity
        return self.act_out(y)

class DownStage(nn.Module):
    """
    Residual block, then stride-2 downsample (conv).
    """
    def __init__(self, c_in, c_out, norm="instance", act="relu"):
        super().__init__()
        self.block = ResidualConvBlock(c_in, c_out, norm=norm, act=act)
        self.down  = nn.Conv2d(c_out, c_out, 3, stride=2, padding=1, padding_mode='reflect')

    def forward(self, x):
        x = self.block(x)
        skip = x
        x = self.down(x)
        return x, skip

class UpStage(nn.Module):
    """
    Bilinear upsample, concatenate skip, residual conv to target channels.
    """
    def __init__(self, c_in, c_skip, c_out, norm="instance", act="relu", dropout=0.0):
        super().__init__()
        self.up   = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.conv = ResidualConvBlock(c_in + c_skip, c_out, norm=norm, act=act, dropout=dropout)

    def forward(self, x, skip):
        x = self.up(x)
        # pad if odd shapes (safety)
        if x.shape[-2:] != skip.shape[-2:]:
            dh = skip.shape[-2] - x.shape[-2]
            dw = skip.shape[-1] - x.shape[-1]
            x = F.pad(x, (0, dw, 0, dh))
        x = torch.cat([x, skip], dim=1)
        return self.conv(x)


# ---------- Conditional U-Net VAE (condition only at bottleneck) ----------

class ConditionalUNetVAE(nn.Module):
    """
    CVAE with a U-Net backbone (3 downs / 3 ups), with encoder->decoder skips.
    - Encoder computes posterior q(z|partial) from the encoder features.
    - Decoder takes sampled z and the condition image (partial) fused ONLY at the bottleneck.
      No multi-scale/pyramid conditioning is used.
    - Forward(partial) -> (logits, mu, log_var)

    Expected tensor ranges: partial in [0,1] or {0, .5, 1}. Output is logits (no sigmoid).
    Spatial size must be divisible by 8 (e.g., 128x128).
    """
    def __init__(
        self,
        in_ch: int = 1,
        out_ch: int = 1,
        base: int = 64,
        latent_dim: int = 64,  # Reasonable default for skip version
        norm: str = "instance",   # "instance" | "batch" | "none"
        act: str = "relu",        # "relu" | "lrelu" | "gelu"
        dropout: float = 0.0,
    ):
        super().__init__()
        self.in_ch = in_ch
        self.out_ch = out_ch
        self.base = base
        self.latent_dim = latent_dim

        # -------- Encoder (U-Net style)
        self.stem  = ResidualConvBlock(in_ch, base, norm=norm, act=act, dropout=dropout)
        self.down1 = DownStage(base,    base*2, norm=norm, act=act)   # 1/2
        self.down2 = DownStage(base*2,  base*4, norm=norm, act=act)   # 1/4
        self.down3 = DownStage(base*4,  base*8, norm=norm, act=act)   # 1/8

        # posterior heads from bottleneck feature (global pooled)
        self.enc_pool  = nn.AdaptiveAvgPool2d((1,1))
        self.fc_mu     = nn.Linear(base*8, latent_dim)
        self.fc_logvar = nn.Linear(base*8, latent_dim)

        # -------- Bottleneck fusion (z + condition @ bottleneck only)
        # we turn z into base*8 channels and tile to bottleneck HxW
        self.fc_z = nn.Linear(latent_dim, base*8)
        # mid takes [base*8 (from z) + 1 (condition)] -> base*8
        self.mid = nn.Sequential(
            ResidualConvBlock(base*8 + 1, base*8, norm=norm, act=act, dropout=dropout),
            ResidualConvBlock(base*8,      base*8, norm=norm, act=act, dropout=dropout),
        )

        # -------- Decoder (U-Net style with skips)
        self.up3 = UpStage(base*8, base*8, base*4, norm=norm, act=act, dropout=dropout)
        self.up2 = UpStage(base*4, base*4, base*2, norm=norm, act=act, dropout=dropout)
        self.up1 = UpStage(base*2, base*2, base,   norm=norm, act=act, dropout=dropout)

        # -------- Head (logits)
        self.head = nn.Conv2d(base, out_ch, 1)

        # init
        self.apply(self._init_weights)

    @staticmethod
    def _init_weights(m):
        if isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(m.weight, nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Linear):
            nn.init.xavier_uniform_(m.weight)
            nn.init.zeros_(m.bias)
        elif isinstance(m, (nn.BatchNorm2d, nn.InstanceNorm2d)):
            if hasattr(m, "weight") and m.weight is not None:
                nn.init.ones_(m.weight)
            if hasattr(m, "bias") and m.bias is not None:
                nn.init.zeros_(m.bias)

    # ----- VAE parts -----

    def encode(self, x):
        """
        x: [B,in_ch,H,W]  (partial image)
        returns:
          mu, log_var: [B, latent_dim]
          skips: tuple(s1,s2,s3) for U-Net decoder
          bottleneck_hw: (H/8, W/8)
        """
        x0 = self.stem(x)         # [B, base,  H,   W]
        x1, s1 = self.down1(x0)   # [B, 2b,   H/2, W/2], skip s1=[B,2b,...]
        x2, s2 = self.down2(x1)   # [B, 4b,   H/4, W/4], skip s2=[B,4b,...]
        x3, s3 = self.down3(x2)   # [B, 8b,   H/8, W/8], skip s3=[B,8b,...]

        vec = self.enc_pool(x3).flatten(1)     # [B, 8b]
        mu = self.fc_mu(vec)
        log_var = self.fc_logvar(vec)
        log_var = torch.clamp(log_var, min=-30.0, max=20.0)
        return mu, log_var, (s1, s2, s3), x3.shape[-2:]

    @staticmethod
    def reparameterize(mu, log_var):
        # prevent exp() overflow/underflow
        log_var = torch.clamp(log_var, min=-30.0, max=20.0)
        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z, condition, skips, bottleneck_hw):
        """
        z:          [B, latent_dim]
        condition:  [B,1,H,W] (partial). Fused ONLY at bottleneck.
        skips:      tuple(s1,s2,s3) from encoder
        bottleneck_hw: (h8, w8)
        returns logits: [B,out_ch,H,W]
        """
        s1, s2, s3 = skips
        h8, w8 = bottleneck_hw

        # turn z into spatial feature map
        z_ch = self.fc_z(z).unsqueeze(-1).unsqueeze(-1)  # [B, 8b, 1, 1]
        z_ch = z_ch.expand(-1, -1, h8, w8)               # [B, 8b, h8, w8]

        # downsample condition to bottleneck and fuse (no pyramid)
        cond_b = F.interpolate(condition, size=(h8, w8), mode="bilinear", align_corners=False)  # [B,1,h8,w8]
        mid_in = torch.cat([z_ch, cond_b], dim=1)  # [B, 8b+1, h8, w8]
        mid = self.mid(mid_in)                     # [B, 8b,   h8, w8]

        # decoder with U-Net skips
        u3 = self.up3(mid, s3)   # -> [B,4b, H/4, W/4]
        u2 = self.up2(u3,  s2)   # -> [B,2b, H/2, W/2]
        u1 = self.up1(u2,  s1)   # -> [B,b,  H,   W]

        logits = self.head(u1)   # [B,out_ch,H,W]
        return logits

    def forward(self, y, partial):
        """
        partial: [B, 1, H, W]  -- the same tensor is used for:
            (a) encoder input to produce q(z | partial) and U-Net skips
            (b) bottleneck conditioning (downsampled to H/8 x W/8)
        Returns:
            logits:  [B, out_ch, H, W]  (no sigmoid)
            mu:      [B, latent_dim]
            log_var: [B, latent_dim]
        """
        H, W = partial.shape[-2:]
        assert (H % 8 == 0) and (W % 8 == 0), "Input spatial size must be divisible by 8."

        mu, log_var, skips, bottleneck_hw = self.encode(y)
        z = self.reparameterize(mu, log_var)
        logits = self.decode(z, partial, skips, bottleneck_hw)
        return logits, mu, log_var

    def sample(self, condition, mode="posterior", deterministic=True):
        """
        condition: [B,1,H,W] partial
        mode: "posterior" uses q(z|condition); "prior" uses z~N(0,I)
        deterministic: if True and mode="posterior", use z = mu (no noise)
        Returns: logits, probs
        """
        H, W = condition.shape[-2:]
        assert (H % 8 == 0) and (W % 8 == 0), "Input spatial size must be divisible by 8."

        # posterior stats from the partial (matches your approach)
        mu, log_var, skips, hw = self.encode(condition)

        if mode == "posterior":
            z = mu if deterministic else self.reparameterize(mu, log_var)
        elif mode == "prior":
            B = condition.size(0)
            z = torch.randn(B, self.latent_dim, device=condition.device, dtype=condition.dtype)
        else:
            raise ValueError(f"unknown mode={mode}")

        logits = self.decode(z, condition, skips, hw)
        probs = logits.sigmoid()
        return logits, probs