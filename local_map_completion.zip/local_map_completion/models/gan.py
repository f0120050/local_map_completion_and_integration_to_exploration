# models/gan.py
from __future__ import annotations

import torch
import torch.nn as nn
from torch.nn.utils import spectral_norm as SN

__all__ = ["UNetG_3x3", "PatchD_3x_SN"]


class UNetG_3x3(nn.Module):
    def __init__(self, in_ch=1, out_ch=1, base=64, activation='sigmoid'):
        super().__init__()
        BN = nn.BatchNorm2d
        self.act_name = activation  # 'sigmoid' or 'none'

        self.e1 = nn.Sequential(nn.Conv2d(in_ch, base, 4, 2, 1), BN(base), nn.LeakyReLU(0.2, True))
        self.e2 = nn.Sequential(nn.Conv2d(base, base*2, 4, 2, 1), BN(base*2), nn.LeakyReLU(0.2, True))
        self.e3 = nn.Sequential(nn.Conv2d(base*2, base*4, 4, 2, 1), BN(base*4), nn.LeakyReLU(0.2, True))

        def up(ci, co): return nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(ci, co, 3, 1, 1), BN(co), nn.ReLU(True)
        )
        self.d1 = up(base*4, base*2)
        self.d2 = up(base*4, base)
        self.d3 = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(base*2, out_ch, 3, 1, 1),
        )
        self.out_act = nn.Sigmoid() if activation == 'sigmoid' else nn.Identity()

    def forward(self, x):
        e1 = self.e1(x); e2 = self.e2(e1); e3 = self.e3(e2)
        d1 = self.d1(e3); d1 = torch.cat([d1, e2], 1)
        d2 = self.d2(d1); d2 = torch.cat([d2, e1], 1)
        y  = self.d3(d2)
        return self.out_act(y)

class PatchD_3x_SN(nn.Module):
    def __init__(self, in_ch_partial=1, in_ch_target=1, base=64):
        super().__init__()
        ch = in_ch_partial + in_ch_target
        self.net = nn.Sequential(
            SN(nn.Conv2d(ch, base, 4, 2, 1)), nn.LeakyReLU(0.2, True),
            SN(nn.Conv2d(base, base*2, 4, 2, 1)), nn.LeakyReLU(0.2, True),
            SN(nn.Conv2d(base*2, base*4, 4, 2, 1)), nn.LeakyReLU(0.2, True),
            SN(nn.Conv2d(base*4, 1, 1, 1, 0)),
        )
    def forward(self, partial, target):
        return self.net(torch.cat([partial, target], 1))
