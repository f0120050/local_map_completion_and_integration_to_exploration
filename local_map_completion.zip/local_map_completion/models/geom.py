import os
import cv2
import numpy as np
import torch
import math
from typing import Optional
from typing import List


# utilities section begins
# helper converts input tensor to float in range zero to one without gradients
def _to_float01(x: torch.Tensor) -> torch.Tensor:
    return x.detach().float().clamp(0, 1)

# quantize any float tensor in range zero to one to nearest of zero half one
def _quantize_three01(x: torch.Tensor) -> torch.Tensor:
    x = x.float()
    xx = x.unsqueeze(-1)
    centers = torch.as_tensor([0.0, 0.5, 1.0], device=x.device, dtype=x.dtype)
    palette = centers.view(*([1] * (xx.ndim - 1)), 3).expand(*xx.shape[:-1], 3)
    diff = (xx - palette).abs()
    idx  = diff.argmin(dim=-1)
    out  = torch.gather(palette, -1, idx.unsqueeze(-1)).squeeze(-1)
    return out

# convert one channel gray in zero half one to numpy bytes zero one two five five
def _np_from_gray01(t: torch.Tensor) -> np.ndarray:
    g = (t.squeeze(0).cpu().numpy() * 255.0).round().astype(np.uint8)
    g[g == 127] = 128
    return g

# convert numpy bytes back to torch gray in zero half one then quantize
def _gray01_from_np(img: np.ndarray, device: torch.device) -> torch.Tensor:
    out = torch.from_numpy(img.astype(np.float32) / 255.0).to(device)
    return _quantize_three01(out.view(1, *out.shape))

# normalize inputs that may be byte coded to exact three levels
def _normalize_to_three_levels(x: torch.Tensor, tol: float = 1e-3) -> torch.Tensor:
    x = x.detach()
    if x.max() > 1.5:
        x = x.float() / 255.0
    mid = 205.0 / 255.0
    hi  = 254.0 / 255.0
    x = torch.where((x - mid).abs() < 0.02, torch.full_like(x, 0.5), x)
    x = torch.where((x - hi ).abs() < 0.01, torch.ones_like(x), x)
    x = torch.where(torch.isclose(x, torch.tensor(0.0, device=x.device), atol=tol), torch.tensor(0.0, device=x.device), x)
    x = torch.where(torch.isclose(x, torch.tensor(0.5, device=x.device), atol=0.05), torch.tensor(0.5, device=x.device), x)
    x = torch.where(torch.isclose(x, torch.tensor(1.0, device=x.device), atol=0.02), torch.tensor(1.0, device=x.device), x)
    xx = x.unsqueeze(-1)
    centers = torch.as_tensor([0.0, 0.5, 1.0], device=x.device).view(1,1,1,1,3)
    diff = (xx - centers).abs()
    idx  = diff.argmin(dim=-1)
    palette = centers.expand(idx.shape + (3,))
    out = torch.take_along_dim(palette, idx.unsqueeze(-1), dim=-1).squeeze(-1)
    return out

# find tight bounding box around edges using canny with padding
def _bbox_from_canny(g_uint8: np.ndarray, low=50, high=150, pad=2):
    edges = cv2.Canny(g_uint8, low, high)
    ys, xs = np.where(edges > 0)
    if len(xs) == 0:
        ys, xs = np.where(g_uint8 != 128)
        if len(xs) == 0:
            h, w = g_uint8.shape
            return (0, 0, w - 1, h - 1), edges
    x1, x2 = max(0, xs.min() - pad), xs.max() + pad
    y1, y2 = max(0, ys.min() - pad), ys.max() + pad
    h, w = g_uint8.shape
    return (max(0, x1), max(0, y1), min(w - 1, x2), min(h - 1, y2)), edges

# cluster near duplicate line coordinates using simple binning
def _cluster_coords(coords, eps=5):
    if len(coords) == 0:
        return []
    coords = np.asarray(coords, dtype=np.int32)
    bins = {}
    for c in coords:
        key = int(round(c / eps) * eps)
        bins.setdefault(key, []).append(c)
    reps = [int(np.median(v)) for v in bins.values()]
    reps = sorted(list(set(reps)))
    return reps


# def _extract_guides_mask(
#     g_uint8: np.ndarray,
#     bbox,
#     rho=1,
#     theta=np.pi/180,
#     # Canny and Hough tuned a bit looser
#     canny_low=30,
#     canny_high=100,
#     thresh=20,          # was 30
#     min_len=24,         # was 40
#     max_gap=18,         # was 10
#     # clustering and orientation tolerance
#     cluster_eps=6,      # was 6
#     slope_tol=1,        # how far from perfectly horizontal/vertical we allow
#     # fallback: longest-run fraction inside bbox for rows/cols
#     min_run_frac_v=0.60,
#     min_run_frac_h=0.60,
#     do_bridge=False      # one light dilation to connect tiny gaps
# ):
#     """
#     Return: (mask_guides_segments, vertical_xs, horizontal_ys, hough_lines_array)
#
#     More tolerant detection:
#       - lighter Canny
#       - looser Hough (lower votes, shorter min length, larger max gap)
#       - optional 3x3 dilation before Hough to bridge hairline gaps
#       - orientation filter to keep only near-vertical / near-horizontal
#       - fallback using longest contiguous edge runs per column/row
#     """
#     x1, y1, x2, y2 = bbox
#     roi = g_uint8[y1:y2+1, x1:x2+1]
#
#     # edges
#     edges = cv2.Canny(roi, canny_low, canny_high)
#     if do_bridge:
#         k = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
#         edges = cv2.dilate(edges, k, iterations=1)
#
#     # Hough
#     lines = cv2.HoughLinesP(
#         edges, rho, theta, thresh,
#         minLineLength=min_len, maxLineGap=max_gap
#     )
#
#     hmask = np.zeros_like(g_uint8, dtype=np.uint8)
#     vx, hy = [], []
#
#     # helper to decide orientation
#     def _is_horizontal(xa, ya, xb, yb):
#         return abs(yb - ya) <= slope_tol * max(1, abs(xb - xa))
#     def _is_vertical(xa, ya, xb, yb):
#         return abs(xb - xa) <= slope_tol * max(1, abs(yb - ya))
#
#     # consume Hough results
#     if lines is not None:
#         for L in lines[:, 0, :]:
#             xa, ya, xb, yb = map(int, L)
#             X1, Y1 = xa + x1, ya + y1
#             X2, Y2 = xb + x1, yb + y1
#
#             if _is_horizontal(xa, ya, xb, yb):
#                 hy.append(int(round((Y1 + Y2) / 2)))
#                 cv2.line(hmask, (X1, Y1), (X2, Y2), 255, 1)
#             elif _is_vertical(xa, ya, xb, yb):
#                 vx.append(int(round((X1 + X2) / 2)))
#                 cv2.line(hmask, (X1, Y1), (X2, Y2), 255, 1)
#             # ignore diagonals
#
#     # fallback if Hough missed some long axes
#     H, W = g_uint8.shape
#     def _longest_run_1d(bits: np.ndarray) -> int:
#         best = cur = 0
#         for v in bits:
#             if v:
#                 cur += 1
#                 if cur > best: best = cur
#             else:
#                 cur = 0
#         return best
#
#     # treat “edges > 0” inside bbox
#     bits = (edges > 0).astype(np.uint8)
#
#     # vertical candidates by column
#     need_v = (len(vx) == 0)  # or you can use a threshold if you want both
#     if need_v:
#         min_run_v = int((y2 - y1 + 1) * min_run_frac_v)
#         for cx in range(bits.shape[1]):
#             col = bits[:, cx]
#             if _longest_run_1d(col) >= min_run_v:
#                 vx.append(cx + x1)
#
#     # horizontal candidates by row
#     need_h = (len(hy) == 0)
#     if need_h:
#         min_run_h = int((x2 - x1 + 1) * min_run_frac_h)
#         for ry in range(bits.shape[0]):
#             row = bits[ry, :]
#             if _longest_run_1d(row) >= min_run_h:
#                 hy.append(ry + y1)
#
#     # collapse near-duplicates
#     vx = _cluster_coords(vx, eps=cluster_eps)
#     hy = _cluster_coords(hy, eps=cluster_eps)
#
#     return hmask.astype(bool), vx, hy, lines
#

# detect short hough line segments inside bbox and return masks and clustered axes
def _extract_guides_mask(g_uint8: np.ndarray, bbox, rho=1, theta=np.pi/180,
                         thresh=30, min_len=40, max_gap=10, cluster_eps=6):
    """Return mask guides segments vertical xs horizontal ys hough lines array"""
    x1, y1, x2, y2 = bbox
    roi = g_uint8[y1:y2+1, x1:x2+1]
    edges = cv2.Canny(roi, 50, 150)
    lines = cv2.HoughLinesP(edges, rho, theta, thresh,
                            minLineLength=min_len, maxLineGap=max_gap)
    hmask = np.zeros_like(g_uint8, dtype=np.uint8)

    vx, hy = [], []
    if lines is not None:
        for L in lines[:, 0, :]:
            xa, ya, xb, yb = map(int, L)
            X1, Y1 = xa + x1, ya + y1
            X2, Y2 = xb + x1, yb + y1
            if abs(Y2 - Y1) <= abs(X2 - X1):
                hy.append(int(round((Y1 + Y2) / 2)))
            else:
                vx.append(int(round((X1 + X2) / 2)))
            cv2.line(hmask, (X1, Y1), (X2, Y2), 255, 1)  # segments only

    vx = _cluster_coords(vx, eps=cluster_eps)
    hy = _cluster_coords(hy, eps=cluster_eps)
    return hmask.astype(bool), vx, hy, lines

# find nearest coordinate in sorted list to left or right within max search
def _nearest_coord(sorted_coords, pos, direction, max_search=256):
    import bisect
    if not sorted_coords:
        return None
    i = bisect.bisect_left(sorted_coords, pos)
    if direction < 0:
        cand = sorted_coords[i-1] if i > 0 else None
        if cand is not None and (pos - cand) <= max_search:
            return cand
    else:
        cand = sorted_coords[i] if i < len(sorted_coords) else None
        if cand is not None and (cand - pos) <= max_search:
            return cand
    return None

# fill rectangle with white but never overwrite protected mask locations
def _fill_rect_safe(img: np.ndarray, x1, y1, x2, y2, protect_mask: np.ndarray):
    if x1 > x2 or y1 > y2:
        return
    submask = protect_mask[y1:y2+1, x1:x2+1]
    subimg  = img[y1:y2+1, x1:x2+1]
    write = ~submask
    subimg[write] = 255
    img[y1:y2+1, x1:x2+1] = subimg


def _fill_hline_safe(img: np.ndarray, y: int, x1: int, x2: int, protect_mask: np.ndarray):
    H, W = img.shape
    if y < 0 or y >= H:
        return
    x1 = max(0, min(W - 1, x1))
    x2 = max(0, min(W - 1, x2))
    if x1 > x2:
        return
    submask = protect_mask[y, x1:x2+1]
    write = ~submask
    if write.any():
        sub = img[y, x1:x2+1]
        sub[write] = 255
        img[y, x1:x2+1] = sub

def _fill_vline_safe(img: np.ndarray, x: int, y1: int, y2: int, protect_mask: np.ndarray):
    H, W = img.shape
    if x < 0 or x >= W:
        return
    y1 = max(0, min(H - 1, y1))
    y2 = max(0, min(H - 1, y2))
    if y1 > y2:
        return
    submask = protect_mask[y1:y2+1, x]
    write = ~submask
    if write.any():
        sub = img[y1:y2+1, x]
        sub[write] = 255
        img[y1:y2+1, x] = sub


# convert grayscale to rgb for debugging images
def _to_rgb(img_uint8: np.ndarray) -> np.ndarray:
    if img_uint8.ndim == 2:
        return cv2.cvtColor(img_uint8, cv2.COLOR_GRAY2BGR)
    return img_uint8.copy()

# draw bounding box on rgb image for debugging
def _draw_bbox(rgb: np.ndarray, bbox, color=(0, 255, 255)):
    x1, y1, x2, y2 = bbox
    cv2.rectangle(rgb, (x1, y1), (x2, y2), color, 1)

# overlay clustered vertical and horizontal guide lines on rgb image
def _overlay_guides(rgb: np.ndarray, vert_xs, horiz_ys):
    h, w = rgb.shape[:2]
    for x in vert_xs:
        cv2.line(rgb, (x, 0), (x, h - 1), (255, 200, 0), 1)  # cyan teal
    for y in horiz_ys:
        cv2.line(rgb, (0, y), (w - 1, y), (0, 200, 255), 1)  # yellow orange

# build a continuous guide mask from clustered lines with chosen thickness
def _full_guide_mask(shape, vert_xs, horiz_ys, thickness=1, bbox=None):
    H, W = shape
    m = np.zeros((H, W), np.uint8)
    if bbox is None:
        x1, y1, x2, y2 = 0, 0, W - 1, H - 1
    else:
        x1, y1, x2, y2 = bbox
    t = max(1, int(thickness))
    for x in vert_xs:
        cv2.line(m, (x, y1), (x, y2), 255, t)
    for y in horiz_ys:
        cv2.line(m, (x1, y), (x2, y), 255, t)
    return m.astype(bool)

# span helpers for door validation using support length idea
def _any_wall_row(row_wall: np.ndarray, x: int, tol: int) -> bool:
    W = row_wall.shape[0]
    x1 = max(0, x - tol)
    x2 = min(W - 1, x + tol)
    return bool(row_wall[x1:x2+1].any())

def _any_wall_col(col_wall: np.ndarray, y: int, tol: int) -> bool:
    H = col_wall.shape[0]
    y1 = max(0, y - tol)
    y2 = min(H - 1, y + tol)
    return bool(col_wall[y1:y2+1].any())

# measure consecutive rows where both flanking walls persist around a horizontal gap
def _support_span_rows(wall: np.ndarray, y: int, xL: int, xR: int, tol: int, probe_limit: int) -> int:
    H, W = wall.shape
    span = 1
    yy = y - 1
    steps = 0
    while yy >= 0 and steps < probe_limit:
        if _any_wall_row(wall[yy, :], xL, tol) and _any_wall_row(wall[yy, :], xR, tol):
            span += 1
            yy -= 1
            steps += 1
        else:
            break
    yy = y + 1
    steps = 0
    while yy < H and steps < probe_limit:
        if _any_wall_row(wall[yy, :], xL, tol) and _any_wall_row(wall[yy, :], xR, tol):
            span += 1
            yy += 1
            steps += 1
        else:
            break
    return span

# measure consecutive columns where both flanking walls persist around a vertical gap
def _support_span_cols(wall: np.ndarray, x: int, yU: int, yD: int, tol: int, probe_limit: int) -> int:
    H, W = wall.shape
    span = 1
    xx = x - 1
    steps = 0
    while xx >= 0 and steps < probe_limit:
        if _any_wall_col(wall[:, xx], yU, tol) and _any_wall_col(wall[:, xx], yD, tol):
            span += 1
            xx -= 1
            steps += 1
        else:
            break
    xx = x + 1
    steps = 0
    while xx < W and steps < probe_limit:
        if _any_wall_col(wall[:, xx], yU, tol) and _any_wall_col(wall[:, xx], yD, tol):
            span += 1
            xx += 1
            steps += 1
        else:
            break
    return span

# ray cast from a start point to the first stop pixel defined by stop mask
def _scan_to_stop(stop_mask: np.ndarray, x: int, y: int, dx: int, dy: int, max_steps: int):
    """Walk from x y by dx dy until we hit a true in stop mask or exceed max steps
       Return coordinates of the stop pixel or none"""
    H, W = stop_mask.shape
    xs, ys = x, y
    for _ in range(max_steps):
        xs += dx
        ys += dy
        if xs < 0 or xs >= W or ys < 0 or ys >= H:
            return None
        if stop_mask[ys, xs]:
            return xs, ys
    return None

# search left across a vertical strip to find nearest stop and return interior limit
def _nearest_left_stop_in_strip(stop_mask: np.ndarray, x: int, yU: int, yD: int):
    H, W = stop_mask.shape
    best = None
    yU = max(0, yU)
    yD = min(H - 1, yD)
    for yy in range(yU, yD + 1):
        xs = x - 1
        while xs >= 0 and not stop_mask[yy, xs]:
            xs -= 1
        if xs >= 0:
            interior = xs + 1
            best = interior if best is None else max(best, interior)
    return best

# search right across a vertical strip to find nearest stop and return interior limit
def _nearest_right_stop_in_strip(stop_mask: np.ndarray, x: int, yU: int, yD: int):
    H, W = stop_mask.shape
    best = None
    yU = max(0, yU)
    yD = min(H - 1, yD)
    for yy in range(yU, yD + 1):
        xs = x + 1
        while xs < W and not stop_mask[yy, xs]:
            xs += 1
        if xs < W:
            interior = xs - 1
            best = interior if best is None else min(best, interior)
    return best

# search upward across a horizontal strip to find nearest stop and return interior limit
def _nearest_up_stop_in_strip(stop_mask: np.ndarray, y: int, xL: int, xR: int):
    H, W = stop_mask.shape
    best = None
    xL = max(0, xL)
    xR = min(W - 1, xR)
    for xx in range(xL, xR + 1):
        ys = y - 1
        while ys >= 0 and not stop_mask[ys, xx]:
            ys -= 1
        if ys >= 0:
            interior = ys + 1
            best = interior if best is None else max(best, interior)
    return best

# search downward across a horizontal strip to find nearest stop and return interior limit
def _nearest_down_stop_in_strip(stop_mask: np.ndarray, y: int, xL: int, xR: int):
    H, W = stop_mask.shape
    best = None
    xL = max(0, xL)
    xR = min(W - 1, xR)
    for xx in range(xL, xR + 1):
        ys = y + 1
        while ys < H and not stop_mask[ys, xx]:
            ys += 1
        if ys < H:
            interior = ys - 1
            best = interior if best is None else min(best, interior)
    return best

# check if a coordinate is on or near a mask within a small radius
def _near_mask(mask: np.ndarray, x: int, y: int, r: int = 1) -> bool:
    H, W = mask.shape
    x1 = max(0, x - r)
    x2 = min(W - 1, x + r)
    y1 = max(0, y - r)
    y2 = min(H - 1, y + r)
    return bool(mask[y1:y2+1, x1:x2+1].any())

def _merge_close_coords(coords, gap=2):
    coords = sorted(int(c) for c in set(coords))
    if not coords: return []
    groups, cur = [], [coords[0]]
    for c in coords[1:]:
        if c - cur[-1] <= gap: cur.append(c)
        else: groups.append(cur)
        cur = [c]
    groups.append(cur)
    return [int(np.median(g)) for g in groups]

def _collapse_segments_to_rails(seg_mask: np.ndarray, vert_xs, horiz_ys, radius: int = 1) -> np.ndarray:
    """
    From the raw Hough segment mask, keep only a single-pixel rail per clustered
    vertical x and horizontal y. We preserve the original segment extents, but
    collapse any duplicated nearby lines into one.
    """
    H, W = seg_mask.shape
    out = np.zeros((H, W), dtype=bool)

    # vertical rails: keep only column x, mark rows where any segment exists within [x-radius, x+radius]
    for x in vert_xs:
        x1 = max(0, x - radius); x2 = min(W - 1, x + radius)
        col_any = seg_mask[:, x1:x2+1].any(axis=1)
        out[col_any, x] = True

    # horizontal rails: keep only row y, mark columns where any segment exists within [y-radius, y+radius]
    for y in horiz_ys:
        y1 = max(0, y - radius); y2 = min(H - 1, y + radius)
        row_any = seg_mask[y1:y2+1, :].any(axis=0)
        out[y, row_any] = True

    return out

def _build_thin_stop_mask(
    wall_mask: np.ndarray,
    full_guide_mask: np.ndarray,
    vert_xs: List[int],
    horiz_ys: List[int],
    g_orig: np.ndarray,
    merge_radius: int = 1,
    clamp_border: bool = False,
) -> np.ndarray:
    """
    Combine walls with full-length guides into a 1-pixel-wide 'stop' mask.
    - Collapses overlapping/shifted guide bands to a single rail per alignment.
    - Removes guide pixels that run through pure-white on both sides
      (door/hall spans), so they don't block filling.
    """
    H, W = wall_mask.shape

    # start from walls only, so we never thicken real walls
    stop = wall_mask.copy()

    # collapse guides to single rails
    thin_guides = np.zeros((H, W), dtype=bool)

    # vertical rails: mark column x wherever any guide is present within [x-merge_radius, x+merge_radius]
    for x in vert_xs:
        x1 = max(0, x - merge_radius); x2 = min(W - 1, x + merge_radius)
        col_any = full_guide_mask[:, x1:x2 + 1].any(axis=1)
        thin_guides[col_any, x] = True

    # horizontal rails: mark row y wherever any guide is present within [y-merge_radius, y+merge_radius]
    for y in horiz_ys:
        y1 = max(0, y - merge_radius); y2 = min(H - 1, y + merge_radius)
        row_any = full_guide_mask[y1:y2 + 1, :].any(axis=0)
        thin_guides[y, row_any] = True

    # remove rail pixels that lie through pure-white on both sides in the original
    # vertical: remove if left and right are both white
    for x in vert_xs:
        ys = np.where(thin_guides[:, x])[0]
        if ys.size == 0:
            continue
        left_white  = (g_orig[ys, np.maximum(0, x - 1)] == 255)
        right_white = (g_orig[ys, np.minimum(W - 1, x + 1)] == 255)
        keep = ~(left_white & right_white)
        thin_guides[ys[~keep], x] = False

    # horizontal: remove if above and below are both white
    for y in horiz_ys:
        xs = np.where(thin_guides[y, :])[0]
        if xs.size == 0:
            continue
        above_white = (g_orig[np.maximum(0, y - 1), xs] == 255)
        below_white = (g_orig[np.minimum(H - 1, y + 1), xs] == 255)
        keep = ~(above_white & below_white)
        thin_guides[y, xs[~keep]] = False

    # combine
    stop |= thin_guides

    if clamp_border:
        stop[0, :]  = True
        stop[-1, :] = True
        stop[:, 0]  = True
        stop[:, -1] = True

    return stop


def _max_run_length(b: np.ndarray) -> int:
    """Longest consecutive True run in a 1D boolean array."""
    best = cur = 0
    for v in b:
        if v:
            cur += 1
            if cur > best: best = cur
        else:
            cur = 0
    return best

def _merge_close_coords(coords, gap=2):
    """Collapse coordinates that are within <= gap pixels."""
    if not coords:
        return []
    coords = sorted(int(c) for c in coords)
    merged, cur = [], [coords[0]]
    for v in coords[1:]:
        if abs(v - cur[-1]) <= gap:
            cur.append(v)
        else:
            merged.append(int(np.median(cur)))
            cur = [v]
    merged.append(int(np.median(cur)))
    # de-dup just in case
    return sorted(list(dict.fromkeys(merged)))

def _find_boundary_guides(seg_guide_mask: np.ndarray, min_len: int = 30, merge_gap: int = 2):
    """
    From the Hough 'segments' guide mask, pick the outermost long guides.
    Returns (vert_xs, horiz_ys) where vert_xs contains [left, right] if both exist
    and horiz_ys contains [top, bottom] if both exist.
    """
    H, W = seg_guide_mask.shape

    # vertical candidates: columns with a long continuous run
    cand_x = []
    for x in range(W):
        if _max_run_length(seg_guide_mask[:, x]) >= min_len:
            cand_x.append(x)
    cand_x = _merge_close_coords(cand_x, gap=merge_gap)

    # horizontal candidates: rows with a long continuous run
    cand_y = []
    for y in range(H):
        if _max_run_length(seg_guide_mask[y, :]) >= min_len:
            cand_y.append(y)
    cand_y = _merge_close_coords(cand_y, gap=merge_gap)

    verts = []
    if cand_x:
        left_x  = min(cand_x)
        right_x = max(cand_x)
        verts = [left_x] if left_x == right_x else [left_x, right_x]

    horiz = []
    if cand_y:
        top_y    = min(cand_y)
        bottom_y = max(cand_y)
        horiz = [top_y] if top_y == bottom_y else [top_y, bottom_y]

    return verts, horiz

def _debug_draw_boundary_guides(rgb: np.ndarray, vert_xs, horiz_ys):
    """Overlay boundary guides: vertical in cyan, horizontal in orange."""
    H, W = rgb.shape[:2]
    for x in vert_xs:
        cv2.line(rgb, (x, 0), (x, H - 1), (255, 200, 0), 1)   # cyan
    for y in horiz_ys:
        cv2.line(rgb, (0, y), (W - 1, y), (0, 200, 255), 1)   # orange

def _clipped_guide_mask(shape, vert_xs, horiz_ys, x_left, x_right, y_top, y_bottom, thickness=1):
    H, W = shape
    m = np.zeros((H, W), np.uint8)
    t = max(1, int(thickness))

    # vertical rails are drawn only between y_top..y_bottom (inclusive)
    for x in vert_xs:
        y1 = max(0, min(y_top, y_bottom))
        y2 = min(H - 1, max(y_top, y_bottom))
        cv2.line(m, (int(x), int(y1)), (int(x), int(y2)), 255, t)

    # horizontal rails are drawn only between x_left..x_right (inclusive)
    for y in horiz_ys:
        x1 = max(0, min(x_left, x_right))
        x2 = min(W - 1, max(x_left, x_right))
        cv2.line(m, (int(x1), int(y)), (int(x2), int(y)), 255, t)

    return m.astype(bool)

def _dbg_draw_rect(canvas, x1, y1, x2, y2, color, label=None):
    x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
    cv2.rectangle(canvas, (x1, y1), (x2, y2), color, 1)
    if label is not None:
        cv2.putText(canvas, label, (x1, max(0, y1-2)), cv2.FONT_HERSHEY_SIMPLEX, 0.3, color, 1, cv2.LINE_AA)

def _dbg_mark_point(canvas, x, y, color, r=2):
    if x is None or y is None: return
    cv2.circle(canvas, (int(x), int(y)), r, color, -1)


# model section begins
class GeometricBaselineNet(torch.nn.Module):
    """Stateless rule based completion returns batch one channel images in three levels"""
    def __init__(
        self,
        method="guide",
        wall_value=0,
        wall_thickness=0,
        max_fill=30,
        verbose=False,
        clamp_border=True,
        # door controls
        door_min_width=2,
        door_max_width=14,
        door_space_min_frac=0.60,
        # anti hallway using local support span
        door_min_support=2,
        door_max_support=10,
        door_support_tol=1,
        door_support_probe=64,
        door_keep_margin=1, # expand carved door opening by this many pixels on each side
        # guide handling
        paint_guides_as_walls=True,
        guide_thickness=1,          # thickness of continuous guide mask used for protection and painting
        debug=False,
        debug_dir="outputs/geom/debug",
        debug_limit=0,

        **kwargs,
    ):
        super().__init__()
        self.method = str(method)
        self.wall_value = int(wall_value)
        self.wall_thickness = int(wall_thickness)
        self.max_fill = int(max_fill)
        self.verbose = bool(verbose)
        self.clamp_border = bool(clamp_border)

        self.door_space = "free"
        self.door_min_width = int(door_min_width)
        self.door_max_width = int(door_max_width)
        self.door_space_min_frac = float(door_space_min_frac)

        self.door_min_support = int(door_min_support)
        self.door_max_support = int(door_max_support)
        self.door_support_tol = int(door_support_tol)
        self.door_support_probe = int(door_support_probe)
        self.door_keep_margin = int(door_keep_margin)

        self.paint_guides_as_walls = bool(paint_guides_as_walls)
        self.guide_thickness = int(guide_thickness)


        self.debug = bool(debug)
        self.debug_dir = str(debug_dir)
        self.debug_limit = int(debug_limit)
        self._dbg_counter = 0
        if self.debug:
            os.makedirs(self.debug_dir, exist_ok=True)

    # debug helpers begin
    def _dbg_on(self) -> bool:
        if not self.debug:
            return False
        if self.debug_limit > 0 and self._dbg_counter >= self.debug_limit:
            return False
        return True

    def _dbg_next_id(self) -> int:
        i = self._dbg_counter
        self._dbg_counter += 1
        return i

    def _dbg_save(self, idx: int, tag: str, img: np.ndarray):
        path = os.path.join(self.debug_dir, f"b{idx:05d}_{tag}.png")
        cv2.imwrite(path, img)

    # prepare masks and find candidate doors
    def _prepare_masks(self, g: np.ndarray):
        """input bytes zero one two five five to boolean masks for unknown free wall and dilated wall"""
        unknown = (g == 128)
        free    = (g == 255)
        wall    = (g == self.wall_value)

        if self.wall_thickness > 1:
            rad = max(1, self.wall_thickness // 2)
        else:
            rad = 1
        k = cv2.getStructuringElement(cv2.MORPH_RECT, (2 * rad + 1, 2 * rad + 1))
        wall_dil = cv2.dilate(wall.astype(np.uint8), k, iterations=1).astype(bool)
        return unknown.astype(bool), free.astype(bool), wall.astype(bool), wall_dil

    # choose which interior space counts for door gaps unknown free or both
    def _select_space_mask(self, unknown: np.ndarray, free: np.ndarray) -> np.ndarray:
        if self.door_space == "unknown": return unknown
        if self.door_space == "free":    return free
        return (unknown | free)

    # scan a row to find short gaps between two walls and validate by support span
    def _scan_row_doors(self, wall: np.ndarray, space: np.ndarray, y: int):
        """horizontal gaps left and right walls"""
        W = wall.shape[1]
        res = []
        x = 0
        row_wall  = wall[y, :]
        row_space = space[y, :]
        while x < W:
            while x < W and not row_wall[x]: x += 1
            if x >= W: break
            while x < W and row_wall[x]: x += 1
            if x >= W: break
            gap_start = x
            while x < W and not row_wall[x]: x += 1
            gap_end = x - 1
            right_is_wall = (x < W and row_wall[x])
            left_is_wall  = (gap_start - 1 >= 0 and row_wall[gap_start - 1])
            if left_is_wall and right_is_wall:
                gap_len = gap_end - gap_start + 1
                if self.door_min_width <= gap_len <= self.door_max_width:
                    frac = float(row_space[gap_start:x].sum()) / float(gap_len)
                    if frac >= self.door_space_min_frac:
                        xL = max(0, gap_start - 1)
                        xR = min(W - 1, gap_end + 1)
                        span = _support_span_rows(
                            wall, y, xL, xR,
                            tol=self.door_support_tol,
                            probe_limit=self.door_support_probe
                        )
                        if self.door_min_support <= span <= self.door_max_support:
                            xc = (gap_start + gap_end) // 2
                            res.append((int(xc), int(y), "horizontal", int(gap_start), int(gap_end)))
        return res

    # scan a column to find short gaps between two walls and validate by support span
    def _scan_col_doors(self, wall: np.ndarray, space: np.ndarray, x: int):
        """vertical gaps up and down walls"""
        H = wall.shape[0]
        res = []
        y = 0
        col_wall = wall[:, x]
        col_space = space[:, x]
        while y < H:
            while y < H and not col_wall[y]: y += 1
            if y >= H: break
            while y < H and col_wall[y]: y += 1
            if y >= H: break
            gap_start = y
            while y < H and not col_wall[y]: y += 1
            gap_end = y - 1
            bottom_is_wall = (y < H and col_wall[y])
            top_is_wall    = (gap_start - 1 >= 0 and col_wall[gap_start - 1])
            if top_is_wall and bottom_is_wall:
                gap_len = gap_end - gap_start + 1
                if self.door_min_width <= gap_len <= self.door_max_width:
                    frac = float(col_space[gap_start:y].sum()) / float(gap_len)
                    if frac >= self.door_space_min_frac:
                        yU = max(0, gap_start - 1)
                        yD = min(H - 1, gap_end + 1)
                        span = _support_span_cols(
                            wall, x, yU, yD,
                            tol=self.door_support_tol,
                            probe_limit=self.door_support_probe
                        )
                        if self.door_min_support <= span <= self.door_max_support:
                            yc = (gap_start + gap_end) // 2
                            res.append((int(x), int(yc), "vertical", int(gap_start), int(gap_end)))
        return res

    # detect doors and optionally treat guides as walls and optionally reject doors on guides

    def _detect_doors_np(self, g: np.ndarray, guide_mask: Optional[np.ndarray] = None):
        unknown, free, wall, wall_for_detect = self._prepare_masks(g)
        # treat guides as walls for detection tightness
        if guide_mask is not None:
            wall_for_detect = (wall_for_detect | guide_mask)

        space = self._select_space_mask(unknown, free)
        H, W = g.shape

        doors = []
        for y in range(H): doors.extend(self._scan_row_doors(wall_for_detect, space, y))
        for x in range(W): doors.extend(self._scan_col_doors(wall_for_detect, space, x))

        # deduplicate door candidates while keeping the widest span per bucket
        if doors:
            buckets = {}
            for d in doors:
                # accept both 3-tuples and 5-tuples
                if len(d) == 3:
                    x, y, ori = d
                    a1 = None
                    a2 = None
                else:
                    x, y, ori, a1, a2 = d

                key = (int(round(x / 2)) * 2, int(round(y / 2)) * 2, ori[0])  # coarse bucket

                if key in buckets:
                    bx, by, bo, b1, b2 = buckets[key]
                    # if either side lacks span info, prefer the one that has it
                    if a1 is None and b1 is None:
                        # keep existing
                        pass
                    elif a1 is None:
                        # keep existing spans
                        pass
                    elif b1 is None:
                        buckets[key] = (x, y, ori, a1, a2)
                    else:
                        # merge by widening to cover both spans
                        buckets[key] = (x, y, ori, min(b1, a1), max(b2, a2))
                else:
                    buckets[key] = (x, y, ori, a1, a2)

            doors = list(buckets.values())

        # reject doors that land on or near guides based on small radius
        if guide_mask is not None and self.exclude_doors_on_guides:
            doors = [(x, y, o) for (x, y, o) in doors
                     if not _near_mask(guide_mask, x, y, self.door_guide_margin)]
        # end reject

        return doors, wall

    def _infer_span_from_mask(self, stop_mask: np.ndarray, x: int, y: int, ori: str, margin: int = 0):
        """Infer full door span [a1, a2] along the door axis using stop_mask.
           For horizontal doors we scan left/right; for vertical, up/down.
           Returns clamped inclusive indices with optional margin expansion."""
        H, W = stop_mask.shape
        if ori == "horizontal":
            L = _scan_to_stop(stop_mask, x, y, dx=-1, dy=0, max_steps=W)
            R = _scan_to_stop(stop_mask, x, y, dx=+1, dy=0, max_steps=W)
            a1 = (L[0] + 1) if L is not None else x
            a2 = (R[0] - 1) if R is not None else x
            a1 = max(0, a1 - margin)
            a2 = min(W - 1, a2 + margin)
        else:
            U = _scan_to_stop(stop_mask, x, y, dx=0, dy=-1, max_steps=H)
            D = _scan_to_stop(stop_mask, x, y, dx=0, dy=+1, max_steps=H)
            a1 = (U[1] + 1) if U is not None else y
            a2 = (D[1] - 1) if D is not None else y
            a1 = max(0, a1 - margin)
            a2 = min(H - 1, a2 + margin)
        return int(a1), int(a2)

    def _ensure_spans(self, doors, stop_mask: np.ndarray, margin: int = 0):
        """Normalize doors to 5-tuples (x, y, ori, a1, a2), inferring spans if missing."""
        out = []
        for d in doors:
            if len(d) == 5:
                x, y, ori, a1, a2 = d
            else:
                x, y, ori = d
                a1, a2 = _infer_span_from_mask(stop_mask, x, y, ori, margin=margin)
            out.append((int(x), int(y), str(ori), int(a1), int(a2)))
        return out

    def _complete_np(self, g: np.ndarray, dbg_id: int = None) -> np.ndarray:
        g = g.copy()
        g_orig = g.copy()
        H, W = g.shape

        # 1) detect doors and walls
        doors, wall_mask = self._detect_doors_np(g)

        # debug: walls only
        if dbg_id is not None and self._dbg_on():
            pm = np.zeros((H, W), np.uint8);
            pm[wall_mask] = 255
            self._dbg_save(dbg_id, "4a_protect_walls", pm)

        # 2) bbox and raw guide segments
        bbox, canny = _bbox_from_canny(g)
        seg_guide_mask, vert_xs, horiz_ys, lines = _extract_guides_mask(g, bbox)
        if dbg_id is not None and self._dbg_on():
            pm = np.zeros((H, W), np.uint8);
            pm[seg_guide_mask] = 255
            self._dbg_save(dbg_id, "4c_guides_segments_raw", pm)

        # 3) merge close guide coords so we do not double-paint parallel rails
        vert_xs = _merge_close_coords(vert_xs, gap=2)
        horiz_ys = _merge_close_coords(horiz_ys, gap=2)

        # 4) full-length rails used for stopping
        full_guide_mask = _full_guide_mask(
            (H, W), vert_xs, horiz_ys, thickness=self.guide_thickness, bbox=bbox
        )
        if dbg_id is not None and self._dbg_on():
            pm = np.zeros((H, W), np.uint8);
            pm[full_guide_mask] = 255
            self._dbg_save(dbg_id, "4d_guides_full_rails", pm)

        # 4.1) find outermost long guides to use as boundaries
        def _max_run_length(b: np.ndarray) -> int:
            best = cur = 0
            for v in b:
                if v:
                    cur += 1; best = max(best, cur)
                else:
                    cur = 0
            return best


        stop_mask = (wall_mask | full_guide_mask)
        if self.clamp_border:
            stop_mask[0, :] = True
            stop_mask[-1, :] = True
            stop_mask[:, 0] = True
            stop_mask[:, -1] = True

        if dbg_id is not None and self._dbg_on():
            pm = np.zeros((H, W), np.uint8)
            pm[stop_mask] = 255
            self._dbg_save(dbg_id, "4f_stop_mask", pm)

        # 6) ensure door spans → produce 5-tuples (x, y, ori, a1, a2)
        doors = self._ensure_spans(
            doors, stop_mask, margin=self.door_keep_margin if hasattr(self, "door_keep_margin") else 0
        )

        # 7) final protect is exactly the thin stop mask
        protect = stop_mask.copy()
        if dbg_id is not None and self._dbg_on():
            pm = np.zeros((H, W), np.uint8);
            pm[protect] = 255
            self._dbg_save(dbg_id, "4g_protect_final", pm)

        # ------ standard debug you already had (input, bbox, guides, doors)
        if dbg_id is not None and self._dbg_on():
            self._dbg_save(dbg_id, "0_input", _to_rgb(g))
            rgb = _to_rgb(canny);
            _draw_bbox(rgb, bbox);
            self._dbg_save(dbg_id, "1_canny_bbox", rgb)
            rgb2 = _to_rgb(g)
            if lines is not None:
                x1, y1, x2, y2 = bbox
                for L in lines[:, 0, :]:
                    xa, ya, xb, yb = map(int, L)
                    cv2.line(rgb2, (xa + x1, ya + y1), (xb + x1, yb + y1), (0, 255, 0), 1)
            _overlay_guides(rgb2, vert_xs, horiz_ys)
            self._dbg_save(dbg_id, "2_hough_guides", rgb2)
            rgb3 = _to_rgb(g)
            for x, y, *_ in doors:
                cv2.circle(rgb3, (x, y), 2, (0, 0, 255), -1)
            self._dbg_save(dbg_id, "3_doors", rgb3)

        # ------ fill bounded by stops
        # ------ fill bounded by stops
        bx1, by1, bx2, by2 = bbox

        def _clip(v, lo, hi):
            return max(lo, min(hi, v))

        # Use a search mask that EXCLUDES the clamp border,
        # so bbox edges are never considered "stops".
        search_mask = stop_mask.copy()
        if self.clamp_border:
            search_mask[0, :] = False
            search_mask[-1, :] = False
            search_mask[:, 0] = False
            search_mask[:, -1] = False

        for di, (x, y, ori, a1, a2) in enumerate(doors):
            # scan to first stop without borders
            L = _scan_to_stop(search_mask, x, y, dx=-1, dy=0, max_steps=max(32, x - bx1))
            R = _scan_to_stop(search_mask, x, y, dx=+1, dy=0, max_steps=max(32, bx2 - x))
            U = _scan_to_stop(search_mask, x, y, dx=0, dy=-1, max_steps=max(32, y - by1))
            D = _scan_to_stop(search_mask, x, y, dx=0, dy=+1, max_steps=max(32, by2 - y))

            # provisional vertical bounds from up/down
            yU = (U[1] + 1) if U is not None else (y - 1)
            yD = (D[1] - 1) if D is not None else (y + 1)

            # resolve left with strip fallback (still on search_mask)
            if L is not None:
                xL = L[0] + 1
                hasL = True
            else:
                yU_s = max(0, yU if U is not None else y - self.max_fill)
                yD_s = min(H - 1, yD if D is not None else y + self.max_fill)
                xL_try = _nearest_left_stop_in_strip(search_mask, x, yU_s, yD_s)
                hasL = (xL_try is not None)
                xL = xL_try if hasL else x

            # resolve right with strip fallback
            if R is not None:
                xR = R[0] - 1
                hasR = True
            else:
                yU_s = max(0, yU if U is not None else y - self.max_fill)
                yD_s = min(H - 1, yD if D is not None else y + self.max_fill)
                xR_try = _nearest_right_stop_in_strip(search_mask, x, yU_s, yD_s)
                hasR = (xR_try is not None)
                xR = xR_try if hasR else x

            # resolve up with strip fallback
            if U is None:
                xL_s = max(0, min(xL, x))
                xR_s = min(W - 1, max(xR, x))
                yU_try = _nearest_up_stop_in_strip(search_mask, y, xL_s, xR_s)
                hasU = (yU_try is not None)
                yU = yU_try if hasU else y
            else:
                hasU = True

            # resolve down with strip fallback
            if D is None:
                xL_s = max(0, min(xL, x))
                xR_s = min(W - 1, max(xR, x))
                yD_try = _nearest_down_stop_in_strip(search_mask, y, xL_s, xR_s)
                hasD = (yD_try is not None)
                yD = yD_try if hasD else y
            else:
                hasD = True

            # clip
            xL = _clip(xL, 0, W - 1);
            xR = _clip(xR, 0, W - 1)
            yU = _clip(yU, 0, H - 1);
            yD = _clip(yD, 0, H - 1)

            # Only fill if BOTH real stops exist in the relevant axis.
            if ori == "horizontal":
                if not (hasL and hasR and hasU and hasD):
                    # optional debug: visualize skip
                    if dbg_id is not None and self._dbg_on():
                        vis = _to_rgb(g.copy())
                        cv2.putText(vis, f"skip H door {di}", (max(0, x - 20), max(10, y - 5)),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0, 0, 255), 1, cv2.LINE_AA)
                        self._dbg_save(dbg_id, f"5x_skip_fill_h_{di}", vis)
                    continue

                _fill_rect_safe(g, _clip(xL, 0, x), _clip(yU, 0, y),
                                _clip(x, 0, W - 1), _clip(y, 0, H - 1), stop_mask)
                _fill_rect_safe(g, _clip(x, 0, W - 1), _clip(yU, 0, y),
                                _clip(xR, 0, W - 1), _clip(y, 0, H - 1), stop_mask)
                _fill_rect_safe(g, _clip(xL, 0, x), _clip(y, 0, H - 1),
                                _clip(x, 0, W - 1), _clip(yD, 0, H - 1), stop_mask)
                _fill_rect_safe(g, _clip(x, 0, W - 1), _clip(y, 0, H - 1),
                                _clip(xR, 0, W - 1), _clip(yD, 0, H - 1), stop_mask)


            else:  # vertical door
                if not (hasU and hasD and hasL and hasR):
                    if dbg_id is not None and self._dbg_on():
                        vis = _to_rgb(g.copy())
                        cv2.putText(vis, f"skip V door {di}", (max(0, x - 20), max(10, y - 5)),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0, 0, 255), 1, cv2.LINE_AA)
                        self._dbg_save(dbg_id, f"5x_skip_fill_v_{di}", vis)
                    continue

                _fill_rect_safe(g, _clip(xL, 0, x), _clip(yU, 0, H - 1),
                                _clip(x, 0, W - 1), _clip(y, 0, H - 1), stop_mask)
                _fill_rect_safe(g, _clip(x, 0, W - 1), _clip(yU, 0, H - 1),
                                _clip(xR, 0, W - 1), _clip(y, 0, H - 1), stop_mask)
                _fill_rect_safe(g, _clip(xL, 0, W - 1), _clip(y, 0, yD),
                                _clip(x, 0, W - 1), _clip(yD, 0, H - 1), stop_mask)
                _fill_rect_safe(g, _clip(x, 0, W - 1), _clip(y, 0, yD),
                                _clip(xR, 0, W - 1), _clip(yD, 0, H - 1), stop_mask)

        # ------ paint guides as thin walls from the stop mask
        # Paint only those stop pixels that are not already walls, and never paint clamp borders.
        # ------ paint guides as thin walls from the stop mask
        if self.paint_guides_as_walls:
            paint_mask = (stop_mask & (~wall_mask))
            if self.clamp_border:
                paint_mask[0, :] = False
                paint_mask[-1, :] = False
                paint_mask[:, 0] = False
                paint_mask[:, -1] = False
            g[paint_mask] = self.wall_value

            # Kılavuz çizgilerini gerçekten SİL: duvar değilse, çıktıyı orijinale geri döndür
            erase_guides = full_guide_mask & (~wall_mask)
            if self.clamp_border:
                erase_guides[0, :] = False
                erase_guides[-1, :] = False
                erase_guides[:, 0] = False
                erase_guides[:, -1] = False

            # duvar olmayan kılavuz piksellerini orijinal girdi değerine döndür
            g[erase_guides] = g_orig[erase_guides]

            if dbg_id is not None and self._dbg_on():
                self._dbg_save(dbg_id, "9_output", _to_rgb(g))



        return g

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        xq = _normalize_to_three_levels(x)
        outs = []
        for b in range(xq.size(0)):
            np_in = _np_from_gray01(xq[b])
            dbg_id = self._dbg_next_id() if self._dbg_on() else None
            np_out = self._complete_np(np_in, dbg_id=dbg_id)
            outs.append(_gray01_from_np(np_out, x.device))
        return torch.stack(outs, dim=0)

