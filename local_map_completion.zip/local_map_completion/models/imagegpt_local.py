import torch
import torch.nn as nn
import torch.nn.functional as F


class GPTConfig:
    def __init__(
        self,
        vocab_size: int = 3,
        n_positions: int = 32 * 32,
        n_layer: int = 6,
        n_head: int = 4,
        n_embd: int = 128,
        dropout: float = 0.1,
    ):
        self.vocab_size = vocab_size
        self.n_positions = n_positions
        self.n_layer = n_layer
        self.n_head = n_head
        self.n_embd = n_embd
        self.dropout = dropout


class CausalSelfAttention(nn.Module):
    def __init__(self, config: GPTConfig):
        super().__init__()
        assert config.n_embd % config.n_head == 0
        self.n_head = config.n_head
        self.head_dim = config.n_embd // config.n_head

        self.c_attn = nn.Linear(config.n_embd, 3 * config.n_embd)
        self.c_proj = nn.Linear(config.n_embd, config.n_embd)

        self.attn_dropout = nn.Dropout(config.dropout)
        self.resid_dropout = nn.Dropout(config.dropout)

        # Causal mask for autoregressive behavior
        mask = torch.tril(torch.ones(config.n_positions, config.n_positions))
        self.register_buffer("mask", mask.view(1, 1, config.n_positions, config.n_positions))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, T, C]
        B, T, C = x.size()
        qkv = self.c_attn(x)  # [B, T, 3*C]
        q, k, v = qkv.split(C, dim=2)

        # [B, T, n_head, head_dim] -> [B, n_head, T, head_dim]
        q = q.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        k = k.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        v = v.view(B, T, self.n_head, self.head_dim).transpose(1, 2)

        # scaled dot-product attention
        att = (q @ k.transpose(-2, -1)) / (self.head_dim ** 0.5)  # [B, n_head, T, T]
        att = att.masked_fill(self.mask[:, :, :T, :T] == 0, float("-inf"))
        att = F.softmax(att, dim=-1)
        att = self.attn_dropout(att)

        y = att @ v  # [B, n_head, T, head_dim]
        y = y.transpose(1, 2).contiguous().view(B, T, C)  # [B, T, C]

        y = self.resid_dropout(self.c_proj(y))
        return y


class Block(nn.Module):
    def __init__(self, config: GPTConfig):
        super().__init__()
        self.ln_1 = nn.LayerNorm(config.n_embd)
        self.attn = CausalSelfAttention(config)
        self.ln_2 = nn.LayerNorm(config.n_embd)
        self.mlp = nn.Sequential(
            nn.Linear(config.n_embd, 4 * config.n_embd),
            nn.GELU(),
            nn.Linear(4 * config.n_embd, config.n_embd),
            nn.Dropout(config.dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.ln_1(x))
        x = x + self.mlp(self.ln_2(x))
        return x


class ImageGPTLocal(nn.Module):
    """
    GPT-style decoder for 32x32 ternary maps.
    - Input: token indices [B, T] in {0,1,2}, T = 1024
    - Output: logits [B, T, vocab_size]
    """

    def __init__(self, config: GPTConfig):
        super().__init__()
        self.config = config

        self.token_emb = nn.Embedding(config.vocab_size, config.n_embd)
        self.pos_emb = nn.Embedding(config.n_positions, config.n_embd)

        self.drop = nn.Dropout(config.dropout)
        self.blocks = nn.ModuleList([Block(config) for _ in range(config.n_layer)])
        self.ln_f = nn.LayerNorm(config.n_embd)

        self.head = nn.Linear(config.n_embd, config.vocab_size)

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, (nn.Linear, nn.Embedding)):
                nn.init.normal_(m.weight, mean=0.0, std=0.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.zeros_(m.bias)

    def forward(self, idx: torch.Tensor) -> torch.Tensor:
        """
        idx: [B, T] long, values in {0,1,2}
        returns logits: [B, T, vocab_size]
        """
        B, T = idx.size()
        assert T <= self.config.n_positions, "Sequence too long for this config"

        pos = torch.arange(0, T, device=idx.device, dtype=torch.long)  # [T]
        pos = pos.unsqueeze(0).expand(B, T)  # [B, T]

        x = self.token_emb(idx) + self.pos_emb(pos)  # [B, T, n_embd]
        x = self.drop(x)

        for block in self.blocks:
            x = block(x)

        x = self.ln_f(x)
        logits = self.head(x)  # [B, T, vocab_size]
        return logits


class ImageGPTLocalWrapper(nn.Module):
    """
    Wrapper to make ImageGPTLocal look like your UNet-style models:

    - Input:  partial map as grayscale tensor [B, 1, 32, 32] with values in {0,1,2} (or floats close).
    - Output: logits [B, 3, 32, 32] for CE loss.

    This lets you re-use a CE-based trainer (similar to UNet/Lama) if you want
    to treat ImageGPT as a per-pixel classifier instead of full autoregressive sampling.
    """

    def __init__(self, config: GPTConfig):
        super().__init__()
        self.gpt = ImageGPTLocal(config)
        # a dummy head interface so your trainer_unet "model.head.out_channels == 3" assertion can pass
        # we don't use this conv; logits come directly from GPT, but out_channels is 3.
        self.head = nn.Conv2d(3, 3, kernel_size=1)
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: [B,1,32,32] with values in {0,1,2} (float or long)
        returns logits: [B,3,32,32]
        """
        B, C, H, W = x.shape
        assert C == 1 and H == 32 and W == 32, "Expected [B,1,32,32]"

        # Convert to integer tokens in {0,1,2}
        if x.dtype.is_floating_point:
            # assume already normalized to 0,1,2 or 0..2
            tokens = torch.round(x.clamp(0, 2)).long()
        else:
            tokens = x.long()

        # Flatten to sequence [B, T]
        tokens = tokens.view(B, -1)  # [B, 1024]

        logits_seq = self.gpt(tokens)  # [B, T, 3]
        logits = logits_seq.view(B, H, W, 3).permute(0, 3, 1, 2).contiguous()  # [B,3,32,32]

        return logits
