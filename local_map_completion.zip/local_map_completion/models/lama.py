# models/lama.py

import torch
import torch.nn as nn
import torch.fft

# Reuse building blocks from your UNet implementation
from models.unet import make_norm, make_act, ResidualConvBlock, DownStage, UpStage


class FourierUnit(nn.Module):
    """
    Simple Fourier unit:
    - FFT2 over H,W
    - 1x1 conv on [real, imag] channels
    - inverse FFT2 back to spatial domain
    """

    def __init__(self, in_ch: int, out_ch: int):
        super().__init__()
        # we concatenate real and imag, so input = 2*in_ch, output = 2*out_ch
        self.conv = nn.Conv2d(in_ch * 2, out_ch * 2, kernel_size=1, bias=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, C, H, W]
        b, c, h, w = x.shape

        # FFT over spatial dims
        x_fft = torch.fft.rfftn(x, s=(h, w), dim=(-2, -1), norm="ortho")  # [B, C, H, W_fft]

        # split real/imag, concat on channels
        real = x_fft.real
        imag = x_fft.imag
        feat = torch.cat([real, imag], dim=1)  # [B, 2C, H, W_fft]

        # 1x1 conv in freq domain
        feat = self.conv(feat)  # [B, 2*out_ch, H, W_fft]

        # back to complex
        real, imag = torch.chunk(feat, 2, dim=1)
        x_fft = torch.complex(real, imag)

        # inverse FFT back to spatial domain, enforcing original size
        out = torch.fft.irfftn(x_fft, s=(h, w), dim=(-2, -1), norm="ortho")
        return out  # [B, out_ch, H, W]


class FFCResidualBlock(nn.Module):
    """
    Residual block with:
    - local 3x3 convs (like your ResidualConvBlock)
    - plus a global Fourier branch
    output = (local + identity) + alpha * fourier(x)
    """

    def __init__(
        self,
        c_in: int,
        c_out: int,
        norm: str = "instance",
        act: str = "relu",
        dropout: float = 0.0,
        fourier_scale: float = 0.5,
    ):
        super().__init__()
        bias = (norm is None) or (norm == "none")

        self.conv1 = nn.Conv2d(c_in,  c_out, 3, padding=1, bias=bias)
        self.norm1 = make_norm(norm, c_out)
        self.act1  = make_act(act)

        self.conv2 = nn.Conv2d(c_out, c_out, 3, padding=1, bias=bias)
        self.norm2 = make_norm(norm, c_out)

        self.drop = nn.Dropout2d(dropout) if dropout and dropout > 0 else nn.Identity()

        self.proj = nn.Identity() if c_in == c_out else nn.Conv2d(c_in, c_out, 1, bias=False)
        self.act_out = make_act(act)

        # global Fourier branch
        self.fourier = FourierUnit(c_in, c_out)
        self.fourier_scale = fourier_scale

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = self.proj(x)

        # local residual branch
        y = self.conv1(x)
        y = self.norm1(y)
        y = self.act1(y)

        y = self.conv2(y)
        y = self.norm2(y)
        y = self.drop(y)

        y = y + identity  # local residual

        # global branch
        g = self.fourier(x)  # [B, c_out, H, W]
        y = y + self.fourier_scale * g

        return self.act_out(y)


class LamaUNet33Res(nn.Module):
    """
    LaMa-like UNet:
    - same encoder/decoder as UNet33Res
    - mid uses FFCResidualBlock (global context via Fourier)
    """

    def __init__(
        self,
        in_ch: int = 1,
        out_ch: int = 3,
        base:   int = 64,
        norm:   str = "instance",  # "instance" | "batch" | "none"
        act:    str = "relu",      # "relu" | "lrelu" | "gelu"
        dropout: float = 0.0,
        final_activation: str = "none",  # "none" (logits for CE) | "sigmoid" | "tanh"
    ):
        super().__init__()
        self.final_activation = final_activation

        # encoder (same as UNet33Res)
        self.stem  = ResidualConvBlock(in_ch, base, norm=norm, act=act, dropout=dropout)
        self.down1 = DownStage(base,    base * 2, norm=norm, act=act)
        self.down2 = DownStage(base * 2, base * 4, norm=norm, act=act)
        self.down3 = DownStage(base * 4, base * 8, norm=norm, act=act)

        # mid: 2x FFCResidualBlock instead of 2x ResidualConvBlock
        self.mid = nn.Sequential(
            FFCResidualBlock(base * 8, base * 8, norm=norm, act=act, dropout=dropout),
            FFCResidualBlock(base * 8, base * 8, norm=norm, act=act, dropout=dropout),
        )

        # decoder (same as UNet33Res)
        self.up3 = UpStage(base * 8, base * 8, base * 4, norm=norm, act=act)
        self.up2 = UpStage(base * 4, base * 4, base * 2, norm=norm, act=act)
        self.up1 = UpStage(base * 2, base * 2, base,     norm=norm, act=act)

        # head
        self.head = nn.Conv2d(base, out_ch, 1)

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, nonlinearity="relu")
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # encoder
        x0 = self.stem(x)         # [B, base, H, W]
        x1, s1 = self.down1(x0)   # [B, 2b, H/2, W/2]
        x2, s2 = self.down2(x1)   # [B, 4b, H/4, W/4]
        x3, s3 = self.down3(x2)   # [B, 8b, H/8, W/8]

        # mid
        mid = self.mid(x3)        # [B, 8b, H/8, W/8]

        # decoder
        u3 = self.up3(mid, s3)    # [B, 4b, H/4, W/4]
        u2 = self.up2(u3, s2)     # [B, 2b, H/2, W/2]
        u1 = self.up1(u2, s1)     # [B, b,  H,  W]

        y = self.head(u1)         # [B, out_ch, H, W]

        if self.final_activation == "sigmoid":
            y = torch.sigmoid(y)
        elif self.final_activation == "tanh":
            y = torch.tanh(y)

        # "none" → logits (for CE)
        return y
