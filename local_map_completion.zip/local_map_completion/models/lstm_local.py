# models/lstm_local.py
import torch
import torch.nn as nn
import torch.nn.functional as F


class LSTMRowModel(nn.Module):
    """
    Local LSTM baseline for 32×32 SDS map completion.
    - Input: [B,1,32,32] values {0,1,2}
    - Output: [B,3,32,32] logits
    """
    def __init__(self, hidden_size=64, num_layers=2, dropout=0.1):
        super().__init__()

        self.hidden_size = hidden_size
        self.num_layers = num_layers

        # embedding for tokens 0,1,2
        self.embedding = nn.Embedding(3, hidden_size)

        # Bidirectional LSTM per row
        self.lstm = nn.LSTM(
            input_size=hidden_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout,
            bidirectional=True,
        )

        # Map each position to 3 output classes
        self.classifier = nn.Linear(hidden_size * 2, 3)

        # dummy "head" to satisfy UNetTrainer.eval interface
        self.head = nn.Conv2d(3, 3, kernel_size=1)
        nn.init.zeros_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def forward(self, x):
        """
        x: [B, 1, 32, 32]
        returns logits: [B,3,32,32]
        """
        B, C, H, W = x.size()
        assert H == 32 and W == 32

        # Convert float values to long tokens
        if x.dtype.is_floating_point:
            x = torch.round(x.clamp(0, 2)).long()
        else:
            x = x.long()

        # Remove channel dim -> [B, 32, 32]
        x = x.squeeze(1)

        # Embed tokens: [B, 32, 32, emb]
        x = self.embedding(x)

        # Process rows independently:
        # reshape to [B*32, 32, emb]
        x = x.view(B * H, W, -1)

        # LSTM: output [B*32, 32, 2*hidden]
        out, _ = self.lstm(x)

        # Per-token classification: [B*32, 32, 3]
        logits = self.classifier(out)

        # reshape back to [B, 3, 32, 32]
        logits = logits.view(B, H, W, 3).permute(0, 3, 1, 2)

        return logits
