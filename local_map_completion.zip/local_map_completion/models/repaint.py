import torch
import torch.nn as nn
from torch.utils import checkpoint
from metrics.ssim import SSIMLoss
from typing import Optional, Union
from types import SimpleNamespace
from losses.diffusion import Diffusion


class TimeEmbedding(nn.Module):
    def __init__(self, dim: int):
        super().__init__()
        self.linear1 = nn.Linear(1, dim)
        self.act = nn.SiLU()
        self.linear2 = nn.Linear(dim, dim)

    def forward(self, t: torch.Tensor) -> torch.Tensor:
        # t: [B] or [B,] int/long → [B,1] float
        t = t.float().unsqueeze(-1)
        return self.linear2(self.act(self.linear1(t)))


class UNetModel(nn.Module):
    """
    Simple UNet-like noise predictor with timestep conditioning at multiple scales.
    Expects concatenated input [x_t, cond] along channel dim when in_channels=2.
    """
    def __init__(self, in_channels: int = 2, base_channels: int = 96, time_emb_dim: int = 128):
        super().__init__()
        self.time_mlp = TimeEmbedding(time_emb_dim)
        self.use_checkpoint = False

        self.time_scale = nn.Parameter(torch.ones(1))

        self.time_proj_128 = nn.Linear(time_emb_dim, base_channels)
        self.time_proj_64  = nn.Linear(time_emb_dim, base_channels * 2)
        self.time_proj_32  = nn.Linear(time_emb_dim, base_channels * 4)
        self.time_proj_16  = nn.Linear(time_emb_dim, base_channels * 8)

        # -------- Down blocks (tek konv) --------
        self.down1 = nn.Sequential(
            nn.Conv2d(in_channels, base_channels, 3, padding=1),
            nn.InstanceNorm2d(base_channels),
            nn.LeakyReLU(0.2, inplace=True),
        )
        self.downsample1 = nn.Conv2d(base_channels, base_channels * 2, kernel_size=3, stride=2, padding=1)

        self.down2 = nn.Sequential(
            nn.Conv2d(base_channels * 2, base_channels * 2, 3, padding=1),
            nn.InstanceNorm2d(base_channels * 2),
            nn.LeakyReLU(0.2, inplace=True),
        )
        self.downsample2 = nn.Conv2d(base_channels * 2, base_channels * 4, kernel_size=3, stride=2, padding=1)

        self.down3 = nn.Sequential(
            nn.Conv2d(base_channels * 4, base_channels * 4, 3, padding=1),
            nn.InstanceNorm2d(base_channels * 4),
            nn.LeakyReLU(0.2, inplace=True),
        )
        self.downsample3 = nn.Conv2d(base_channels * 4, base_channels * 8, kernel_size=3, stride=2, padding=1)

        # -------- Middle (tek konv) --------
        self.middle = nn.Sequential(
            nn.Conv2d(base_channels * 8, base_channels * 8, 3, padding=1),
            nn.InstanceNorm2d(base_channels * 8),
            nn.LeakyReLU(0.2, inplace=True),
        )

        # -------- Up path --------
        self.up3 = nn.ConvTranspose2d(base_channels * 8, base_channels * 4, 2, stride=2)
        self.up_conv3 = nn.Sequential(
            nn.Conv2d(base_channels * 4 + base_channels * 4, base_channels * 4, 3, padding=1),
            nn.InstanceNorm2d(base_channels * 4),
            nn.LeakyReLU(0.2, inplace=True),
        )

        self.up2 = nn.ConvTranspose2d(base_channels * 4, base_channels * 2, 2, stride=2)
        self.up_conv2 = nn.Sequential(
            nn.Conv2d(base_channels * 2 + base_channels * 2, base_channels * 2, 3, padding=1),
            nn.InstanceNorm2d(base_channels * 2),
            nn.LeakyReLU(0.2, inplace=True),
        )

        self.up1 = nn.ConvTranspose2d(base_channels * 2, base_channels, 2, stride=2)
        self.up_conv1 = nn.Sequential(
            nn.Conv2d(base_channels + base_channels, base_channels, 3, padding=1),
            nn.InstanceNorm2d(base_channels),
            nn.LeakyReLU(0.2, inplace=True),
        )

        self.out = nn.Conv2d(base_channels, 1, 1)

    def forward(self, x: torch.Tensor, t: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        # x, cond: [B,1,H,W]; we concatenate inside, but embedding needs t & cond too
        if self.use_checkpoint and self.training:
            t_with_grad = t.to(dtype=torch.float32).detach().clone().requires_grad_(True)
            cond_with_grad = cond.to(dtype=torch.float32).detach().clone().requires_grad_(True)
            return checkpoint.checkpoint(self._forward_impl, x, t_with_grad, cond_with_grad, use_reentrant=False)
        else:
            return self._forward_impl(x, t, cond)

    def _forward_impl(self, x: torch.Tensor, t: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        # time embeddings
        temb = self.time_mlp(t) * self.time_scale

        temb_128 = self.time_proj_128(temb).unsqueeze(-1).unsqueeze(-1)
        temb_64  = self.time_proj_64(temb).unsqueeze(-1).unsqueeze(-1)
        temb_32  = self.time_proj_32(temb).unsqueeze(-1).unsqueeze(-1)
        temb_16  = self.time_proj_16(temb).unsqueeze(-1).unsqueeze(-1)

        # encoder
        if x.shape[2:] != cond.shape[2:]:
            raise ValueError(f"Spatial size mismatch: x {x.shape} vs cond {cond.shape}")
        enc_in = torch.cat([x, cond], dim=1)

        down1_out = self.down1(enc_in)
        down1_out = down1_out + temb_128.expand(-1, -1, down1_out.shape[2], down1_out.shape[3])
        pool1_out = self.downsample1(down1_out)

        down2_out = self.down2(pool1_out)
        down2_out = down2_out + temb_64.expand(-1, -1, down2_out.shape[2], down2_out.shape[3])
        pool2_out = self.downsample2(down2_out)

        down3_out = self.down3(pool2_out)
        down3_out = down3_out + temb_32.expand(-1, -1, down3_out.shape[2], down3_out.shape[3])
        pool3_out = self.downsample3(down3_out)

        middle_out = self.middle(pool3_out)
        middle_out = middle_out + temb_16.expand(-1, -1, middle_out.shape[2], middle_out.shape[3])

        # decoder
        up3_out = self.up3(middle_out)
        up3_out = up3_out + temb_32.expand(-1, -1, up3_out.shape[2], up3_out.shape[3])
        up3_in  = torch.cat([up3_out, down3_out], dim=1)
        up3_conv= self.up_conv3(up3_in)

        up2_out = self.up2(up3_conv)
        up2_out = up2_out + temb_64.expand(-1, -1, up2_out.shape[2], up2_out.shape[3])
        up2_in  = torch.cat([up2_out, down2_out], dim=1)
        up2_conv= self.up_conv2(up2_in)

        up1_out = self.up1(up2_conv)
        up1_out = up1_out + temb_128.expand(-1, -1, up1_out.shape[2], up1_out.shape[3])
        up1_in  = torch.cat([up1_out, down1_out], dim=1)
        up1_conv= self.up_conv1(up1_in)

        return self.out(up1_conv)

class RePaintDiffusion(nn.Module):
    """
    Lightweight diffusion wrapper for RePaint-style inpainting with masked L1 + SSIM + noise prediction losses.
    """
    def __init__(
        self,
        unet_model: UNetModel,
        timesteps: int = 1000,
        beta_start: float = 1e-4,
        beta_end: float = 0.05,
        perceptual_loss_model: Optional[nn.Module] = None,
    ):
        super().__init__()
        self.unet = unet_model
        self.timesteps = timesteps
        self.perceptual_loss_model = perceptual_loss_model

        # Fixed hyperparameters
        self.noise_weight = 1.0
        self.masked_l1_weight = 3.0
        self.fft_weight = 1e-3
        self.ssim_weight = 2.0



        # SSIM loss module
        self.ssim_loss = SSIMLoss()

        # diffusion schedule
        betas = torch.linspace(beta_start, beta_end, timesteps)
        self.register_buffer("betas", betas)
        alphas = 1.0 - self.betas
        self.register_buffer("alphas", alphas)
        alpha_bars = torch.cumprod(self.alphas, dim=0)
        self.register_buffer("alpha_bars", alpha_bars)

    @torch.no_grad()
    def q_sample(self, x_start: torch.Tensor, t: Union[torch.Tensor, int], noise: torch.Tensor) -> torch.Tensor:
        """
        Forward diffusion: x_t ~ q(x_t | x_0)
        """
        if not torch.is_tensor(t):
            t = torch.tensor([t], device=x_start.device, dtype=torch.long)
        t = t.long()
        a_bar = self.alpha_bars.to(t.device)[t].view(-1, 1, 1, 1)
        return a_bar.sqrt() * x_start + (1.0 - a_bar).sqrt() * noise

    def p_losses(self, x_start: torch.Tensor, cond: torch.Tensor, t: torch.Tensor) -> torch.Tensor:
        # noise = torch.randn_like(x_start)
        # x_noisy = self.q_sample(x_start, t, noise)
        # pred_n = self.unet(x_noisy, t, cond)
        #
        # alpha_bar = self.alpha_bars[t].view(-1, 1, 1, 1)
        # x0_pred = (x_noisy - torch.sqrt(1.0 - alpha_bar) * pred_n) / torch.sqrt(alpha_bar)
        # x0_pred = x0_pred.clamp(0.0, 1.0)
        #
        # weights = SimpleNamespace(noise=self.noise_weight,
        #                           masked_l1=self.masked_l1_weight,
        #                           ssim=self.ssim_weight)
        return Diffusion.repaint_loss(self, x_start, cond, t)

    def forward(self, x: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        """
        Sample random timesteps and compute the training loss.
        """
        b = x.shape[0]
        t = torch.randint(0, self.timesteps, (b,), device=x.device, dtype=torch.long)
        return self.p_losses(x, cond, t)


    def _gather_t(self, buf: torch.Tensor, t: torch.Tensor) -> torch.Tensor:
        # buf: [T], t: [B] -> [B,1,1,1]
        return buf.to(t.device)[t].view(-1, 1, 1, 1)

    @torch.no_grad()
    def predict_x0(self, x_t: torch.Tensor, t: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        """x0_theta from epsilon-theta (noise prediction)"""
        eps = self.unet(x_t, t, cond)
        a_bar = self._gather_t(self.alpha_bars, t)
        x0 = (x_t - (1.0 - a_bar).sqrt() * eps) / a_bar.sqrt()
        return x0.clamp(0.0, 1.0)

    @torch.no_grad()
    def p_mean_variance(self, x_t: torch.Tensor, t: torch.Tensor, cond: torch.Tensor):
        """
        DDPM posterior q(x_{t-1} | x_t, x0_theta). Returns mean, var, x0_pred.
        """
        x0_pred = self.predict_x0(x_t, t, cond)

        alphas_t = self._gather_t(self.alphas, t)
        betas_t = self._gather_t(self.betas, t)
        a_bar_t = self._gather_t(self.alpha_bars, t)
        t_prev = torch.clamp(t - 1, min=0)
        a_bar_prev_t = self._gather_t(self.alpha_bars, t_prev)

        # posterior variance/mean (Ho et al. 2020)
        posterior_var = betas_t * (1.0 - a_bar_prev_t) / (1.0 - a_bar_t + 1e-8)
        posterior_mean = (
            (posterior_var.sqrt() * 0.0)  # just to fix dtype/device in fused expr
        )
        posterior_mean = (
                (a_bar_prev_t.sqrt() * betas_t / (1.0 - a_bar_t + 1e-8)) * x0_pred
                + (alphas_t.sqrt() * (1.0 - a_bar_prev_t) / (1.0 - a_bar_t + 1e-8)) * x_t
        )

        return posterior_mean, posterior_var, x0_pred

    @torch.no_grad()
    def p_sample_step(self, x_t: torch.Tensor, t: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        """
        One ancestral DDPM step: x_{t-1} ~ N(mean, var)
        """
        mean, var, _ = self.p_mean_variance(x_t, t, cond)
        # if t == 0 -> no noise
        nonzero_mask = (t > 0).float().view(-1, 1, 1, 1)
        z = torch.randn_like(x_t)
        x_prev = mean + nonzero_mask * (var.clamp(min=1e-20).sqrt() * z)
        return x_prev

    # --- Add these methods inside class RePaintDiffusion(nn.Module): ---

    @torch.no_grad()
    def get_known_mask(self, cond: torch.Tensor) -> torch.Tensor:
        """
        Build a binary mask from your convention where unknown = 0.5.
        Returns float mask with 1 for known pixels and 0 for unknown.
        """
        cond_q = torch.clamp((cond * 2.0).round(), 0, 2) / 2.0  # -> {0, 0.5, 1}
        return (cond_q.sub(0.5).abs() > 1e-6).float()

    @torch.no_grad()
    def blend_known(self, x_like: torch.Tensor, cond: torch.Tensor, known_mask: torch.Tensor) -> torch.Tensor:
        """
        Enforce known pixels from cond into x_like.
        """
        return known_mask * cond + (1.0 - known_mask) * x_like

    @torch.no_grad()
    def sample(
            self,
            cond: torch.Tensor,
            method: str = "repaint",  # "repaint" | "ddim"
            steps: int = 200,  # repaint steps
            jump_length: int = 10,
            n_resample: int = 5,
            guidance_scale: float = 1.0,  # reserved for CFG extensions
            ddim_steps: int = 50,
            ddim_eta: float = 0.0,
    ) -> torch.Tensor:
        """
        Top-level sampling dispatcher. Returns x_0 in [0,1] with known regions preserved.
        """
        if method.lower() == "ddim":
            return self.sample_ddim(cond, steps=ddim_steps, eta=ddim_eta)
        elif method.lower() == "repaint":
            return self.sample_repaint(
                cond,
                steps=steps,
                jump_length=jump_length,
                n_resample=n_resample,
                guidance_scale=guidance_scale,
            )
        else:
            raise ValueError(f"Unknown method: {method!r}")

    @torch.no_grad()
    def sample_repaint(
            self,
            cond: torch.Tensor,
            steps: int = 200,
            jump_length: int = 10,
            n_resample: int = 5,
            guidance_scale: float = 1.0,  # placeholder for CFG if you add null-conditioning
    ) -> torch.Tensor:
        """
        RePaint (jump-diffusion) inpainting. Preserves cond where cond != 0.5.
        """
        device = cond.device
        B, C, H, W = cond.shape
        assert C == 1, "cond must be [B,1,H,W]"

        known_mask = self.get_known_mask(cond)

        # Initialize from noise but inject known region diffused to T-1
        x_t = torch.randn_like(cond)
        t_init = torch.full((B,), steps - 1, device=device, dtype=torch.long)
        cond_noisy = self.q_sample(cond, t_init, torch.randn_like(cond))
        x_t = self.blend_known(x_t, cond_noisy, known_mask)

        # Main loop (T-1 ... 0)
        for i in range(steps - 1, -1, -1):
            t = torch.full((B,), i, device=device, dtype=torch.long)

            # multiple resamples per timestep
            repeats = (n_resample if i > 0 else 1)
            for resample_idx in range(repeats):
                # Optional forward jump (add noise) except last resample
                if resample_idx < repeats - 1 and i > 0:
                    t_jump = torch.clamp(t + jump_length, max=steps - 1)
                    a_bar_curr = self.alpha_bars.to(device)[t].view(-1, 1, 1, 1)
                    a_bar_jump = self.alpha_bars.to(device)[t_jump].view(-1, 1, 1, 1)
                    noise = torch.randn_like(x_t)

                    # forward diffuse x_t from t -> t_jump
                    signal_scale = (a_bar_jump / a_bar_curr).sqrt()
                    noise_scale = ((1.0 - a_bar_jump) / (1.0 - a_bar_curr)).sqrt()
                    x_t = signal_scale * x_t + noise_scale * noise

                    # keep known region consistent at t_jump
                    known_jump = self.q_sample(cond, t_jump, torch.randn_like(cond))
                    x_t = self.blend_known(x_t, known_jump, known_mask)

                # One DDPM denoise step at time t
                x_t = self.p_sample_step(x_t, t, cond)

            # After resamples at this t, softly re-impose known at current t (optional but stable)
            if i > 0:
                known_noisy_now = self.q_sample(cond, t, torch.randn_like(cond))
                x_t = self.blend_known(x_t, known_noisy_now, known_mask)

        # Final x_0 prediction is already at t=0; hard enforce known pixels
        x_0 = self.blend_known(x_t, cond, known_mask).clamp(0.0, 1.0)
        return x_0

    @torch.no_grad()
    def _make_schedule(self, steps: int, device) -> torch.Tensor:
        """Map `steps` evaluations to indices in [0..T-1] descending (T=self.timesteps)."""
        T = self.timesteps
        # e.g. steps=200 -> indices like [999, 994, 989, ..., 0]
        idx = torch.linspace(T - 1, 0, steps, device=device)
        return idx.round().long()


    @torch.no_grad()
    def sample_ddim(
            self,
            cond: torch.Tensor,
            steps: int = 50,
            eta: float = 0.0,
    ) -> torch.Tensor:
        """
        Fast DDIM sampler. Preserves cond where cond != 0.5.
        """
        device = cond.device
        B, C, H, W = cond.shape
        assert C == 1, "cond must be [B,1,H,W]"

        known_mask = self.get_known_mask(cond)

        # timestep schedule (T-1 ... 0) with 'steps' evaluations
        T = self.timesteps
        t_schedule = torch.linspace(T - 1, 0, steps, device=device, dtype=torch.long)

        # init noise and inject known region at start timestep
        x_t = torch.randn_like(cond)
        t_start = t_schedule[0].expand(B)
        cond_noisy = self.q_sample(cond, t_start, torch.randn_like(cond))
        x_t = self.blend_known(x_t, cond_noisy, known_mask)

        for i, t_curr in enumerate(t_schedule):
            t_curr = t_curr.expand(B)
            # predict x0 and eps
            eps_pred = self.unet(x_t, t_curr, cond)
            a_bar_curr = self.alpha_bars.to(device)[t_curr].view(-1, 1, 1, 1)
            x0_pred = ((x_t - (1.0 - a_bar_curr).sqrt() * eps_pred) / a_bar_curr.sqrt()).clamp(0.0, 1.0)

            if i == steps - 1:
                x_t = x0_pred
                break

            t_next = t_schedule[i + 1].expand(B)
            a_bar_next = self.alpha_bars.to(device)[t_next].view(-1, 1, 1, 1)

            # DDIM update (Karras-style)
            sigma = eta * ((1 - a_bar_next) / (1 - a_bar_curr) * (1 - a_bar_curr / a_bar_next)).sqrt()
            x_t = a_bar_next.sqrt() * x0_pred + (1 - a_bar_next - sigma ** 2).sqrt() * eps_pred
            if eta > 0:
                x_t = x_t + sigma * torch.randn_like(x_t)

            # keep known region consistent at t_next
            if (t_next > 0).any():
                known_noisy = self.q_sample(cond, t_next, torch.randn_like(cond))
                x_t = self.blend_known(x_t, known_noisy, known_mask)

        # Hard enforce known at the end
        x_0 = self.blend_known(x_t, cond, known_mask).clamp(0.0, 1.0)
        return x_0

