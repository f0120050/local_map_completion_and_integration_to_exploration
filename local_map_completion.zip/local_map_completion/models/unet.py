# models/unet33_res.py
import torch
import torch.nn as nn

# ------------ blocks ------------

def make_norm(norm, ch):
    if norm is None or norm == "none":
        return nn.Identity()
    if norm == "instance":
        return nn.InstanceNorm2d(ch, affine=True, track_running_stats=False)
    if norm == "batch":
        return nn.BatchNorm2d(ch)
    raise ValueError(f"Unknown norm: {norm}")

def make_act(act):
    if act == "relu":
        return nn.ReLU(inplace=True)
    if act == "lrelu":
        return nn.LeakyReLU(0.2, inplace=True)
    if act == "gelu":
        return nn.GELU()
    raise ValueError(f"Unknown activation: {act}")

class ResidualConvBlock(nn.Module):
    """
    Two 3x3 convs (+norm+act) with residual skip.
    Uses a 1x1 projection when c_in != c_out.
    """
    def __init__(self, c_in, c_out, norm="instance", act="relu", dropout=0.0):
        super().__init__()
        bias = (norm is None) or (norm == "none")
        self.conv1 = nn.Conv2d(c_in,  c_out, 3, padding=1, bias=bias)
        self.norm1 = make_norm(norm, c_out)
        self.act1  = make_act(act)
        self.conv2 = nn.Conv2d(c_out, c_out, 3, padding=1, bias=bias)
        self.norm2 = make_norm(norm, c_out)
        self.drop  = nn.Dropout2d(dropout) if dropout and dropout > 0 else nn.Identity()

        self.proj  = nn.Identity() if c_in == c_out else nn.Conv2d(c_in, c_out, 1, bias=False)
        self.act_out = make_act(act)

    def forward(self, x):
        identity = self.proj(x)
        y = self.conv1(x)
        y = self.norm1(y)
        y = self.act1(y)
        y = self.conv2(y)
        y = self.norm2(y)
        y = self.drop(y)
        y = y + identity
        return self.act_out(y)

class DownStage(nn.Module):
    """
    Residual block, then stride-2 downsample (conv).
    """
    def __init__(self, c_in, c_out, norm="instance", act="relu"):
        super().__init__()
        self.block = ResidualConvBlock(c_in, c_out, norm=norm, act=act)
        self.down  = nn.Conv2d(c_out, c_out, 3, stride=2, padding=1)

    def forward(self, x):
        x = self.block(x)
        skip = x
        x = self.down(x)
        return x, skip

class UpStage(nn.Module):
    """
    Bilinear upsample, concatenate skip, residual conv to target channels.
    """
    def __init__(self, c_in, c_skip, c_out, norm="instance", act="relu"):
        super().__init__()
        self.up   = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.conv = ResidualConvBlock(c_in + c_skip, c_out, norm=norm, act=act)

    def forward(self, x, skip):
        x = self.up(x)
        # pad if odd shapes (rare but safe)
        if x.shape[-2:] != skip.shape[-2:]:
            dh = skip.shape[-2] - x.shape[-2]
            dw = skip.shape[-1] - x.shape[-1]
            x = nn.functional.pad(x, (0, dw, 0, dh))
        x = torch.cat([x, skip], dim=1)
        return self.conv(x)


class AttentionGate(nn.Module):
    """
    Classic Attention U-Net gate:
    - g: decoder features  (coarse, lower resolution)
    - x: encoder skip features (to be gated)
    Produces spatial attention map to suppress irrelevant encoder activations.
    """
    def __init__(self, f_g: int, f_l: int, f_int: int):
        super().__init__()
        self.W_g = nn.Conv2d(f_g,  f_int, kernel_size=1, stride=1, padding=0, bias=True)
        self.W_x = nn.Conv2d(f_l,  f_int, kernel_size=1, stride=1, padding=0, bias=True)
        self.psi = nn.Conv2d(f_int, 1,     kernel_size=1, stride=1, padding=0, bias=True)

        self.relu = nn.ReLU(inplace=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, g: torch.Tensor, x: torch.Tensor) -> torch.Tensor:
        """
        g: [B, f_g, H, W]   (decoder feature after upsample)
        x: [B, f_l, H, W]   (skip feature)
        """
        # project both to intermediate channels
        g1 = self.W_g(g)
        x1 = self.W_x(x)

        # additive attention + non-linearity
        psi = self.relu(g1 + x1)

        # 1x1 conv -> attention map
        psi = self.psi(psi)
        psi = self.sigmoid(psi)   # [B, 1, H, W]

        # gate the skip features
        return x * psi


class AttUpStage(nn.Module):
    """
    Up-sampling stage with an attention gate on the skip connection.
    - upsample decoder features
    - align with skip
    - attention gate the skip
    - concatenate and apply residual conv
    """
    def __init__(self, c_in, c_skip, c_out, norm="instance", act="relu"):
        super().__init__()
        self.up  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        # attention gate uses c_in (decoder channels) as g, c_skip as x
        self.att = AttentionGate(f_g=c_in, f_l=c_skip, f_int=c_out)
        self.conv = ResidualConvBlock(c_in + c_skip, c_out, norm=norm, act=act)

    def forward(self, x, skip):
        # upsample decoder features
        x = self.up(x)

        # pad if shapes mismatch
        if x.shape[-2:] != skip.shape[-2:]:
            dh = skip.shape[-2] - x.shape[-2]
            dw = skip.shape[-1] - x.shape[-1]
            x = nn.functional.pad(x, (0, dw, 0, dh))

        # gate the skip features
        skip_att = self.att(x, skip)

        # concat gated skip
        x = torch.cat([x, skip_att], dim=1)
        return self.conv(x)


# ------------ U-Net 3+3 ------------

class UNet33Res(nn.Module):
    """
    U-Net with 3 down stages + bottleneck + 3 up stages.
    - Skips: encoder feature maps concatenated into decoder.
    - Residual blocks everywhere.
    - No attention, no adversarial terms.
    """
    def __init__(
        self,
        in_ch: int = 1,
        out_ch: int = 1,
        base:   int = 64,
        norm:   str = "instance",  # "instance" | "batch" | "none"
        act:    str = "relu",      # "relu" | "lrelu" | "gelu"
        dropout: float = 0.0,      # per-block dropout (off by default)
        final_activation: str = "sigmoid",  # "sigmoid" | "none" | "tanh"
    ):
        super().__init__()
        self.final_activation = final_activation

        # Encoder (3 downs)
        self.stem = ResidualConvBlock(in_ch, base, norm=norm, act=act, dropout=dropout)
        self.down1 = DownStage(base,    base*2, norm=norm, act=act)   # 1/2
        self.down2 = DownStage(base*2,  base*4, norm=norm, act=act)   # 1/4
        self.down3 = DownStage(base*4,  base*8, norm=norm, act=act)   # 1/8

        # Bottleneck
        self.mid = nn.Sequential(
            ResidualConvBlock(base*8, base*8, norm=norm, act=act, dropout=dropout),
            ResidualConvBlock(base*8, base*8, norm=norm, act=act, dropout=dropout),
        )

        # Decoder (3 ups)
        self.up3 = UpStage(base*8, base*8, base*4, norm=norm, act=act)
        self.up2 = UpStage(base*4, base*4, base*2, norm=norm, act=act)
        self.up1 = UpStage(base*2, base*2, base,   norm=norm, act=act)

        # Head
        self.head = nn.Conv2d(base, out_ch, 1)

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, nonlinearity='relu')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x):
        x0 = self.stem(x)         # [B,base,H,W]
        x1, s1 = self.down1(x0)   # [B,2b,H/2,W/2], skip s1=[B,2b,...]
        x2, s2 = self.down2(x1)   # [B,4b,H/4,W/4], skip s2=[B,4b,...]
        x3, s3 = self.down3(x2)   # [B,8b,H/8,W/8], skip s3=[B,8b,...]

        mid = self.mid(x3)        # [B,8b,H/8,W/8]

        u3  = self.up3(mid, s3)   # -> [B,4b,H/4,W/4]
        u2  = self.up2(u3,  s2)   # -> [B,2b,H/2,W/2]
        u1  = self.up1(u2,  s1)   # -> [B,b, H,  W]

        y = self.head(u1)         # [B,out_ch,H,W]
        if self.final_activation == "sigmoid":
            y = torch.sigmoid(y)
        elif self.final_activation == "tanh":
            y = torch.tanh(y)
        return y

class UNet33ResAtt(nn.Module):
    """
    U-Net with:
    - 3 encoder stages with residual blocks
    - bottleneck with residual blocks
    - 3 decoder stages with AttentionGate on skip connections (AttUpStage)
    API-compatible with UNet33Res.
    """
    def __init__(
        self,
        in_ch: int = 1,
        out_ch: int = 1,
        base:   int = 64,
        norm:   str = "instance",  # "instance" | "batch" | "none"
        act:    str = "relu",      # "relu" | "lrelu" | "gelu"
        dropout: float = 0.0,      # per-block dropout (off by default)
        final_activation: str = "sigmoid",  # "sigmoid" | "none" | "tanh"
    ):
        super().__init__()
        self.final_activation = final_activation

        # Encoder (3 downs) – same as UNet33Res
        self.stem  = ResidualConvBlock(in_ch, base,    norm=norm, act=act, dropout=dropout)
        self.down1 = DownStage(base,      base*2, norm=norm, act=act)   # 1/2
        self.down2 = DownStage(base*2,    base*4, norm=norm, act=act)   # 1/4
        self.down3 = DownStage(base*4,    base*8, norm=norm, act=act)   # 1/8

        # Bottleneck – same as UNet33Res
        self.mid = nn.Sequential(
            ResidualConvBlock(base*8, base*8, norm=norm, act=act, dropout=dropout),
            ResidualConvBlock(base*8, base*8, norm=norm, act=act, dropout=dropout),
        )

        # Decoder (3 ups) – use AttUpStage instead of plain UpStage
        self.up3 = AttUpStage(base*8, base*8, base*4, norm=norm, act=act)
        self.up2 = AttUpStage(base*4, base*4, base*2, norm=norm, act=act)
        self.up1 = AttUpStage(base*2, base*2, base,   norm=norm, act=act)

        # Head
        self.head = nn.Conv2d(base, out_ch, 1)

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, nonlinearity="relu")
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Encoder
        x0 = self.stem(x)         # [B,b,H,W]
        x1, s1 = self.down1(x0)   # [B,2b,H/2,W/2]
        x2, s2 = self.down2(x1)   # [B,4b,H/4,W/4]
        x3, s3 = self.down3(x2)   # [B,8b,H/8,W/8]

        # Bottleneck
        mid = self.mid(x3)        # [B,8b,H/8,W/8]

        # Decoder with attention gates on skips
        u3 = self.up3(mid, s3)    # [B,4b,H/4,W/4]
        u2 = self.up2(u3,  s2)    # [B,2b,H/2,W/2]
        u1 = self.up1(u2,  s1)    # [B,b, H, W]

        y = self.head(u1)         # [B,out_ch,H,W]

        if self.final_activation == "sigmoid":
            y = torch.sigmoid(y)
        elif self.final_activation == "tanh":
            y = torch.tanh(y)
        # "none" → logits (for CE)
        return y
