from __future__ import annotations

from typing import Optional
import torch
from torch import nn, Tensor

__all__ = ["ViTBlock", "ViTEncoder", "ViTDecoder", "ViTEncoderDecoder"]


class ViTBlock(nn.Module):
    def __init__(self, embed_dim, num_heads, mlp_dim, dropout=0.1):
        super().__init__()
        self.norm1 = nn.LayerNorm(embed_dim)
        self.attn = nn.MultiheadAttention(embed_dim, num_heads, dropout=0.0, batch_first=True)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, mlp_dim), nn.GELU(),
            nn.Identity(),
            nn.Linear(mlp_dim, embed_dim), nn.Identity()
        )

    def forward(self, x: Tensor) -> Tensor:
        attn_out, _ = self.attn(x, x, x)
        x = self.norm1(x + attn_out)
        x = self.norm2(x + self.mlp(x))
        return x


class ViTEncoder(nn.Module):
    def __init__(self, image_size, patch_size, embed_dim, num_heads, depth, mlp_dim, dropout=0.1):
        super().__init__()
        assert image_size % patch_size == 0, "image_size must be divisible by patch_size."
        self.image_size = image_size
        self.patch_size = patch_size
        self.num_patches = (image_size // patch_size) ** 2
        self.embed_dim = embed_dim

        self.patch_embed = nn.Conv2d(1, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.cls_token = nn.Parameter(torch.randn(1, 1, embed_dim))
        self.pos_embed = nn.Parameter(torch.randn(1, self.num_patches + 1, embed_dim))
        self.dropout = nn.Identity()
        self.blocks = nn.ModuleList([ViTBlock(embed_dim, num_heads, mlp_dim, dropout) for _ in range(depth)])

    def forward(self, x: Tensor) -> Tensor:  # x: [B,1,H,W]
        B = x.size(0)
        x = self.patch_embed(x)               # [B, D, H', W']
        x = x.flatten(2).transpose(1, 2)      # [B, N, D]
        cls = self.cls_token.expand(B, -1, -1)
        x = torch.cat([cls, x], dim=1)        # [B, N+1, D]
        x = x + self.pos_embed
        x = self.dropout(x)
        for blk in self.blocks:
            x = blk(x)
        return x


class ViTDecoder(nn.Module):
    def __init__(self, image_size, patch_size, embed_dim, num_heads, depth, mlp_dim, dropout=0.1):
        super().__init__()
        assert image_size % patch_size == 0, "image_size must be divisible by patch_size."
        self.image_size = image_size
        self.patch_size = patch_size
        self.num_patches = (image_size // patch_size) ** 2
        self.embed_dim = embed_dim

        self.pos_embed = nn.Parameter(torch.randn(1, self.num_patches + 1, embed_dim))
        self.dropout = nn.Identity()
        self.blocks = nn.ModuleList([ViTBlock(embed_dim, num_heads, mlp_dim, dropout) for _ in range(depth)])
        self.depatch = nn.ConvTranspose2d(embed_dim, 1, kernel_size=patch_size, stride=patch_size)

    def forward(self, x: Tensor) -> Tensor:  # x: [B, N+1, D]
        x = self.dropout(x + self.pos_embed)
        for blk in self.blocks:
            x = blk(x)
        x = x[:, 1:, :]                        # drop CLS
        h = w = self.image_size // self.patch_size
        x = x.transpose(1, 2).reshape(-1, self.embed_dim, h, w)
        x = self.depatch(x)                    # logits [B,1,H,W]
        return x


class ViTEncoderDecoder(nn.Module):
    def __init__(self, image_size=128, patch_size=16, embed_dim=256, num_heads=8, depth=3, mlp_dim=512, dropout=0.1):
        super().__init__()
        self.encoder = ViTEncoder(image_size, patch_size, embed_dim, num_heads, depth, mlp_dim, dropout)
        self.decoder = ViTDecoder(image_size, patch_size, embed_dim, num_heads, depth, mlp_dim, dropout)

    def forward(self, condition: Tensor) -> Tensor:  # partial -> logits
        tokens = self.encoder(condition)
        logits = self.decoder(tokens)
        return logits

    @torch.no_grad()
    def sample(self, condition):
        was_training = self.training
        self.eval()
        out = self.forward(condition)
        if was_training:
            self.train()
        return out
