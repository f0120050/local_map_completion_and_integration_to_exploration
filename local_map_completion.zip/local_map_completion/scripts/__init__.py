# scripts/__init__.py
"""
Script entry points (train/eval/export).

- Run as modules:
    python -m scripts.train
    python -m scripts.eval
    python -m scripts.export_decoder

- Or import and call:
    from scripts import train_main, eval_main, export_decoder_main
    train_main()
"""

__all__ = ["train_main", "eval_main", "export_decoder_main"]


def _lazy_import(module_name):
    import importlib
    return importlib.import_module(f"{__name__}.{module_name}")


def train_main(*args, **kwargs):
    """Entry point for training."""
    return _lazy_import("train").main(*args, **kwargs)


def eval_main(*args, **kwargs):
    """Entry point for evaluation."""
    return _lazy_import("eval").main(*args, **kwargs)


def export_decoder_main(*args, **kwargs):
    """Entry point for exporting decoder-only CVAE."""
    return _lazy_import("export_decoder").main(*args, **kwargs)
