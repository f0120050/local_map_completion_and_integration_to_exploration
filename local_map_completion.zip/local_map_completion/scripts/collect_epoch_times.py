#!/usr/bin/env python3
from pathlib import Path
import json
import csv

BASE = Path("/home/selma/PycharmProjects/map_completion_project")
OUTS = BASE / "outputs"
SAVE_DIR = BASE / "paper_tables"
SAVE_DIR.mkdir(parents=True, exist_ok=True)
CSV_PATH = SAVE_DIR / "epoch_times.csv"

rows = []
for model_dir in sorted(OUTS.iterdir()):
    if not model_dir.is_dir():
        continue
    # expected: outputs/<model_name>/metric_results/test/full/summary.json
    summary_path = model_dir / "metric_results" / "test" / "full" / "summary.json"
    if not summary_path.exists():
        # try a couple of common alternative casings/paths just in case
        alt_paths = [
            model_dir / "metric_results" / "test" / "full" / "SUMMARY.json",
            model_dir / "metric_results" / "eval" / "full" / "summary.json",
        ]
        for ap in alt_paths:
            if ap.exists():
                summary_path = ap
                break
        else:
            # no summary found for this model
            continue

    try:
        data = json.loads(summary_path.read_text())
    except Exception as e:
        print(f"WARNING: could not parse JSON for {model_dir.name}: {e}")
        continue

    model_name = model_dir.name
    epoch_time_sec = data.get("epoch_time_sec", None)
    imgs_per_sec = data.get("imgs_per_sec", None)
    count = data.get("count", None)

    # Derive per-image time when possible
    ms_per_image = None
    if isinstance(imgs_per_sec, (int, float)) and imgs_per_sec > 0:
        ms_per_image = 1000.0 / imgs_per_sec
    elif isinstance(epoch_time_sec, (int, float)) and isinstance(count, (int, float)) and count > 0:
        ms_per_image = (epoch_time_sec / count) * 1000.0

    rows.append({
        "model": model_name,
        "epoch_time_sec": epoch_time_sec,
        "imgs_per_sec": imgs_per_sec,
        "count": count,
        "ms_per_image": ms_per_image
    })

# Write CSV
fieldnames = ["model", "epoch_time_sec", "imgs_per_sec", "count", "ms_per_image"]
with open(CSV_PATH, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    for r in rows:
        writer.writerow(r)

print(f"Wrote {len(rows)} rows to {CSV_PATH}")

# python -m scripts.collect_epoch_times
