# scripts/eval.py
import os
import json
import argparse
from types import SimpleNamespace as SN

import yaml
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm
import time

from datasets.fixed_bbox import FixedBoundingBoxDataset

# ---- model defs (same as train) ----
from models.gan import UNetG_3x3
from models.vit import ViTEncoderDecoder
from models.repaint import UNetModel, RePaintDiffusion
from models.cvae import ConditionalVAE3x3
from models.geom import GeometricBaselineNet
from models.unet import UNet33Res  # keep as in your project

from typing import Optional, Dict, Tuple

from viz.panels import save_visuals
from utils.tensor_ops import (
    quantize_three,
    build_eval_mask,
    blend_generated_with_condition,
    make_known_mask_for_repaint,
    make_known_mask
)

# NEW: single-image saving + tiny helpers
from PIL import Image, ImageDraw, ImageFont
import numpy as np

import torch
import torch.nn.functional as F

@torch.no_grad()
def compose_free_with_cond(cond, x_free, wall_guard_px=1, eps=1e-6):
    """
    cond:  [B,1,H,W] in [0,1], with {1=white, 0.5=unknown, 0=wall}
    x_free:[B,1,H,W] in [0,1] (free sample)
    returns: x_out with
      - known region copied from cond
      - hole region filled from x_free but
          * restricted to the panel (not outer background)
          * walls preserved (both from cond and any new walls predicted)
          * values snapped to {0,.5,1} only in the hole
    """
    import torch.nn.functional as F

    # quantize helpers
    def q3(x):  # to {0,0.5,1}
        return torch.clamp(torch.round(x * 2.0) / 2.0, 0.0, 1.0)

    B, _, H, W = cond.shape
    c_q = q3(cond)

    # masks
    known = (c_q - 0.5).abs().gt(1e-6).float()     # 1 where cond != 0.5
    hole  = 1.0 - known                             # 1 where cond == 0.5
    walls_known = (c_q < 0.25).float() * known     # existing walls only in known area

    # --- estimate the *panel interior* so we don't paint the outer background ---
    # assume the panel is the largest connected component of white=1 that touches the known white.
    # morphological fill is a good enough approximation:
    white_known = (c_q > 0.75).float() * known     # known white
    # dilate known white a few times to grow into the (true) panel interior but
    # NOT into the outer background (unknown remains hole); then cap to the hole.
    panel_est = white_known.clone()
    for _ in range(6):  # grow a bit; tune if needed
        panel_est = F.max_pool2d(panel_est, kernel_size=3, stride=1, padding=1)
    panel_est = (panel_est > 0.0).float()
    # "panel hole" are unknown pixels adjacent to the interior; restrict painting to these
    hole_in_panel = hole * panel_est

    # --- quantize only what we’re going to use from the free sample ---
    xq = q3(x_free)

    # keep any *new* walls the sample proposed inside the panel-hole,
    # but protect a 1px band around existing walls so we don’t overwrite them.
    if wall_guard_px > 0:
        guard = walls_known
        for _ in range(int(wall_guard_px)):
            guard = F.max_pool2d(guard, kernel_size=3, stride=1, padding=1)
        # force guard back to walls (0)
        xq = torch.where(guard > 0.5, torch.zeros_like(xq), xq)

    # restrict painting strictly to panel hole; outer background stays 0.5
    hole_fill = hole_in_panel * xq + (hole * (1.0 - panel_est)) * 0.5

    # compose:
    # - known region: exactly cond
    # - hole region: our restricted/quantized fill
    out = known * cond + (1.0 - known) * hole_fill

    # finally make sure walls are exactly 0
    out = torch.where((walls_known > 0.5), torch.zeros_like(out), out)
    return out.clamp(0, 1)


def _bin(x): return (x > 0.5).float()

def _dilate(x, iters=1):
    y = (x > 0.5).float()
    for _ in range(max(1, iters)):
        y = F.max_pool2d(y, 3, 1, 1)
    return _bin(y)

def _erode(x, iters=1):
    y = (x > 0.5).float()
    for _ in range(max(1, iters)):
        y = 1.0 - F.max_pool2d(1.0 - y, 3, 1, 1)
    return _bin(y)

import torch
import torch.nn.functional as F

def _dilate01(x01: torch.Tensor, iters: int) -> torch.Tensor:
    x = (x01 > 0.5).float()
    for _ in range(max(0, iters)):
        x = F.max_pool2d(x, kernel_size=3, stride=1, padding=1)
    return (x > 0.5).float()

@torch.no_grad()
def prune_free_sample_with_panel(cond: torch.Tensor,
                                 x_free: torch.Tensor,
                                 eps: float = 1e-6,
                                 white_thr: float = 0.75,
                                 ring_px: int = 2) -> torch.Tensor:
    """
    Build a discrete map from a free DDPM sample:
      - background/panel -> 0.5
      - walls from cond  -> 0.0
      - known white from cond -> 1.0
      - new white: only the part of x_free>white_thr inside the panel
        that TOUCHES a ring grown from known white -> 1.0
    """
    # Discretize the condition once
    c_q = torch.clamp(torch.round(cond * 2.0) / 2.0, 0.0, 1.0)

    is_panel  = (c_q.sub(0.5).abs() <= eps).float()   # 1 where 0.5
    is_known  = 1.0 - is_panel
    is_wall   = ((c_q < 0.25).float() * is_known)     # 0 inside known
    is_kwhite = ((c_q > 0.75).float() * is_known)     # 1 inside known

    # White candidates in the HOLE only, from the free sample
    cand_white = ((x_free > white_thr).float() * is_panel)

    # Only keep candidates that touch a ring grown from known white
    ring = _dilate01(is_kwhite, ring_px)
    keep_white = (cand_white * ring)

    # Compose: start with panel gray everywhere
    x = torch.full_like(x_free, 0.5)
    # walls (0) and known white (1) from condition
    x = torch.where(is_wall > 0.5, torch.zeros_like(x), x)
    x = torch.where(is_kwhite > 0.5, torch.ones_like(x), x)
    # add newly grown white in the hole
    x = torch.where(keep_white > 0.5, torch.ones_like(x), x)

    # Final snap for cleanliness
    x = torch.clamp(torch.round(x * 2.0) / 2.0, 0.0, 1.0)
    return x


def relax_known_mask(m_known: torch.Tensor, pixels: int = 1) -> torch.Tensor:
    # allow model to modify a 1–2 px ring around the hole
    # dilate the unknown region, then invert to get a "softer" known
    m_unknown = 1.0 - m_known
    k = 2 * pixels + 1
    m_unknown_dil = F.max_pool2d(m_unknown, kernel_size=k, stride=1, padding=pixels)
    m_known_relaxed = 1.0 - m_unknown_dil
    return m_known_relaxed.clamp(0, 1)

def _save_tensor_png(x: torch.Tensor, out_path: str):
    """
    Save a single-channel tensor in [0,1] as an 8-bit PNG.
    Accepts [1,H,W] or [H,W].
    """
    x = x.detach().cpu()
    if x.dim() == 3:
        x = x.squeeze(0)
    x = x.clamp(0, 1)
    arr = (x.numpy() * 255.0).round().astype("uint8")
    Image.fromarray(arr, mode="L").save(out_path)

# --- display helpers (match panel look) ---
VIS_GRAY = 0.82  # same light gray you see behind panels

def _for_display(x: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    """
    Map unknown=0.5 to the panel gray for display saving.
    Accepts [1,H,W] or [H,W] in [0,1]; returns same shape in [0,1].
    """
    x = x.detach().cpu()
    gray = torch.full_like(x, VIS_GRAY)
    return torch.where((x - 0.5).abs() <= eps, gray, x)

def _apply_mask_with_bg(x: torch.Tensor, mask: torch.Tensor, bg: float = VIS_GRAY) -> torch.Tensor:
    """
    Keep x where mask==1, fill elsewhere with the panel gray.
    Shapes: x [1,H,W] or [H,W], mask [1,H,W] or [H,W].
    """
    x = x.detach().cpu()
    m = (mask.detach().cpu() > 0.5).to(x.dtype)
    bg_img = torch.full_like(x, bg)
    return m * x + (1.0 - m) * bg_img

def _run_dir_from_ckpt(ckpt_or_dir: str) -> str:
    """
    Given a checkpoint path or a model run dir, return the run dir:
    <run_dir>/checkpoints/<file>.pth  -> <run_dir>
    """
    if os.path.isfile(ckpt_or_dir):
        return os.path.dirname(os.path.dirname(os.path.abspath(ckpt_or_dir)))
    return os.path.abspath(ckpt_or_dir)

# --- target'sız inpainting için maskeler ---
import torch.nn.functional as F

# --- masks for target-free inpainting ---
@torch.no_grad()
def unknown_hole_mask_from_condition(cond: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    """
    Extract the *interior hole* from the condition only:
    start from pixels equal to 0.5 (unknown), then remove the large outside
    gray area that touches the image border (using flood fill).
    Input : [B,1,H,W]
    Output: [B,1,H,W] in {0,1}
    """
    cq = quantize_three(cond)                # -> {0, .5, 1}
    unknown = (cq - 0.5).abs() <= eps        # bool

    B, _, H, W = unknown.shape
    outside = torch.zeros_like(unknown, dtype=torch.bool)

    # border mask
    border = torch.zeros_like(unknown, dtype=torch.bool)
    border[:, :, 0, :]  = True
    border[:, :, -1, :] = True
    border[:, :, :, 0]  = True
    border[:, :, :, -1] = True

    # start flood fill from border-unknown pixels
    outside = border & unknown
    prev = torch.zeros_like(outside)

    kernel = torch.ones((1, 1, 3, 3), device=unknown.device, dtype=torch.float32)
    # grow with 8-neighborhood
    for _ in range(H + W):
        grown = F.conv2d(outside.float(), kernel, padding=1) > 0
        outside = grown & unknown
        if (outside == prev).all():
            break
        prev = outside

    hole = unknown & (~outside)
    return hole.float()

# --- DEBUG: save masks & overlays ------------------------------------------
import torch.nn.functional as F
from PIL import Image, ImageDraw

@torch.no_grad()
def _binary_dilate(m01: torch.Tensor, px: int = 1) -> torch.Tensor:
    if px <= 0: return m01
    x = (m01 > 0.5).float()
    k = torch.ones((1,1,3,3), device=x.device, dtype=x.dtype)
    for _ in range(px):
        x = (F.conv2d(x, k, padding=1) > 0).float()
    return x

@torch.no_grad()
def _binary_erode(m01: torch.Tensor, px: int = 1) -> torch.Tensor:
    if px <= 0: return (m01 > 0.5).float()
    x = 1.0 - (m01 > 0.5).float()
    x = _binary_dilate(x, px)
    return (1.0 - x)

@torch.no_grad()
def _mask_outline(m01: torch.Tensor, px: int = 1) -> torch.Tensor:
    """Thin outline of a binary mask."""
    m = (m01 > 0.5).float()
    return (_binary_dilate(m, px) - _binary_erode(m, px)).clamp(0, 1)

def _save_mask_png(mask01: torch.Tensor, out_path: str):
    """Save binary mask (1=white, 0=black). Accepts [1,H,W] or [H,W]."""
    m = mask01.detach().cpu()
    if m.dim() == 3: m = m.squeeze(0)
    arr = (m.clamp(0,1).numpy() * 255).astype("uint8")
    Image.fromarray(arr, mode="L").save(out_path)

def _save_mask_overlay(cond: torch.Tensor, mask01: torch.Tensor, out_path: str):
    """
    Save an RGB overlay: condition in gray, mask outline in red.
    cond: [1,H,W] in [0,1]; mask01: [1,H,W] in {0,1}
    """
    c = _for_display(cond).detach().cpu()
    if c.dim() == 3: c = c.squeeze(0)
    base = (c.clamp(0,1).numpy() * 255).astype("uint8")
    rgb = np.stack([base, base, base], axis=-1)

    outline = _mask_outline(mask01).detach().cpu()
    if outline.dim() == 3: outline = outline.squeeze(0)
    edge = outline.numpy() > 0.5
    rgb[edge] = [255, 0, 0]  # red outline

    Image.fromarray(rgb, mode="RGB").save(out_path)

def _mask_bbox(mask01: torch.Tensor):
    """
    Return (y0, y1, x0, x1) or None if empty.
    mask01: [1,H,W] or [B,1,H,W] (take first if batched).
    """
    m = mask01
    if m.dim() == 4: m = m[0]
    if m.dim() == 3: m = m.squeeze(0)
    idx = (m > 0.5).nonzero(as_tuple=False)
    if idx.numel() == 0:
        return None
    ys = idx[:, 0]; xs = idx[:, 1]
    y0, y1 = int(ys.min().item()), int(ys.max().item()) + 1
    x0, x1 = int(xs.min().item()), int(xs.max().item()) + 1
    return (y0, y1, x0, x1)

def _save_bbox_overlay(cond: torch.Tensor, bbox, out_path: str, width: int = 2):
    """Draw a green rectangle for the bbox on top of the condition."""
    c = _for_display(cond).detach().cpu()
    if c.dim() == 3: c = c.squeeze(0)
    base = (c.clamp(0,1).numpy() * 255).astype("uint8")
    rgb = np.stack([base, base, base], axis=-1)
    im  = Image.fromarray(rgb, mode="RGB")
    if bbox is not None:
        y0, y1, x0, x1 = bbox
        draw = ImageDraw.Draw(im)
        draw.rectangle([x0, y0, x1-1, y1-1], outline=(0,255,0), width=width)
    im.save(out_path)

@torch.no_grad()
def bin_dilate(mask01: torch.Tensor, pixels: int = 1) -> torch.Tensor:
    """Binary dilation by `pixels` using 3x3 kernel. mask01: [B,1,H,W] in {0,1}."""
    if pixels <= 0:
        return mask01
    x = mask01
    k = torch.ones((1,1,3,3), dtype=x.dtype, device=x.device)
    for _ in range(pixels):
        x = (F.conv2d(x, k, padding=1) > 0).to(x.dtype)
    return x

@torch.no_grad()
def make_ring(inner01: torch.Tensor, ring_px: int) -> torch.Tensor:
    """
    Return a thin 'ring' region (0/1) around `inner01`.
    inner01: [B,1,H,W] in {0,1} defining the current map area.
    """
    outer = bin_dilate(inner01, pixels=ring_px)
    ring  = (outer - inner01).clamp(min=0.0, max=1.0)
    return ring

@torch.no_grad()
def map_mask_from_tensor(x: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    """
    Convert a ternary-like tensor to a 'map present' mask.
    Here we treat values != 0.5 as 'inside the map' (occupied or free).
    """
    xq = quantize_three(x)  # -> {0, .5, 1}
    return (xq - 0.5).abs().gt(eps).float()  # 1 inside-map, 0 = unknown/gray

@torch.no_grad()
def progressive_repaint_outpaint(
    net,
    cond: torch.Tensor,
    *,
    hole_mask01: torch.Tensor,     # 1 in the initial hole (interior unknown)
    steps_per_stage: int = 140,
    jump_length: int = 12,
    n_resample: int = 4,
    stages: int = 2,
    ring_px: int = 4,
    relax_known_px: int = 1,
) -> torch.Tensor:
    """
    Stage 0: fill the interior hole (classic RePaint inpainting).
    Then for s = 1..stages: create a 'ring' around current map and fill that ring.
    At each stage we hard-lock everything outside the stage-unknown.
    No ground truth is used.
    """
    device = cond.device
    # ----- Stage 0: interior hole -----
    m_unknown = hole_mask01.clamp(0,1)                  # 1 = unknown to fill
    m_known   = (1.0 - m_unknown).clamp(0,1)            # 1 = lock
    m_known_relax = bin_dilate(m_known, relax_known_px)

    # observed values: lock to condition (raw is fine)
    recon = net.sample_repaint(
        cond=cond,
        observed=cond,
        mask=m_known_relax,
        steps=steps_per_stage,
        jump_length=jump_length,
        n_resample=n_resample,
    ).clamp(0,1)

    # snap ONLY unknown; keep known exact
    rq = quantize_three(recon)
    recon = m_known * cond + (1.0 - m_known) * rq

    # ----- Outpainting stages (rings) -----
    for _ in range(stages):
        # define current 'map area' from what we already have
        map_now = map_mask_from_tensor(recon)           # 1 = inside-map (known or already generated)
        ring    = make_ring(map_now, ring_px=ring_px)   # this ring becomes the new unknown
        if ring.sum() < 1:
            break  # nothing to extend

        m_unknown = ring
        m_known   = (1.0 - m_unknown)
        # lock everything except the ring; relax the lock slightly for continuity
        m_known_relax = bin_dilate(m_known, relax_known_px)

        # observed: lock to the best estimate so far (recon) on known,
        # and leave ring to be painted (it will be overwritten by mask)
        observed_stage = recon

        # sample only the ring area
        recon = net.sample_repaint(
            cond=cond,
            observed=observed_stage,
            mask=m_known_relax,
            steps=steps_per_stage,
            jump_length=jump_length,
            n_resample=n_resample,
        ).clamp(0,1)

        # final snap only on the ring
        rq = quantize_three(recon)
        recon = m_known * observed_stage + (1.0 - m_known) * rq

    return recon


@torch.no_grad()
def relax_known_mask(m_known: torch.Tensor, pixels: int = 1) -> torch.Tensor:
    """
    Dilate the known region by `pixels` (helps wall continuity).
    The final blending will still use the strict (non-dilated) known mask,
    so known pixels remain exactly preserved in the output.
    """
    if pixels <= 0:
        return m_known
    x = m_known
    kernel = torch.ones((1, 1, 3, 3), device=x.device, dtype=torch.float32)
    for _ in range(pixels):
        x = (F.conv2d(x, kernel, padding=1) > 0).float()
    return x

def combine_by_filenames(
    base_names,
    model_ckpts_or_dirs,
    scope="full",              # "full" or "masked"
    kind="blend",              # "cond" | "tgt" | "gen" | "blend"
    out_path="comparison_grid.png",
    include_input=True,
    include_target=True,
    geom_run_dir="outputs/geom",
    header=True,
):
    """
    Build a grid: rows = base_names,
                  cols = [Input] + models + [GEOM] + [Target].
    Loads from: <run_dir>/visual_results/test/<scope>/single/<subkind>/<base>.png
    """

    def _run_dir(p: str) -> str:
        return _run_dir_from_ckpt(p)

    def _pretty_label(name: str) -> str:
        n = name.lower().replace("_", " ")
        if "pix2pix" in n or "cgan" in n or ("gan" in n and "hinge" in n):
            return "CGAN"
        if "repaint" in n or "ddpm" in n:
            return "REPAINT"
        if n.startswith("vit"):
            return "VIT"
        if "unet" in n:
            return "UNET"
        if "cvae" in n:
            return "CVAE"
        if "geom" in n:
            return "GEOM"
        return name.upper()

    run_dirs = [_run_dir(p) for p in model_ckpts_or_dirs]
    model_cols = [
        {
            "label": _pretty_label(os.path.basename(os.path.abspath(rd))),
            "sources": [os.path.join(rd, "visual_results", "test", scope, "single", kind)],
            "subkind": kind,
        }
        for rd in run_dirs
    ]

    # GEOM column (before Target)
    geom_col = None
    if geom_run_dir:
        grd = _run_dir(geom_run_dir)
        gsrc = os.path.join(grd, "visual_results", "test", scope, "single", kind)
        geom_col = {"label": "GEOM", "sources": [gsrc], "subkind": kind}

    # For Input/Target search across all runs (first hit wins)
    all_roots = run_dirs + ([ _run_dir(geom_run_dir) ] if geom_col else [])
    def _roots_for(subkind: str):
        return [os.path.join(rd, "visual_results", "test", scope, "single", subkind) for rd in all_roots]

    columns = []
    if include_input:
        columns.append({"label": "INPUT", "sources": _roots_for("cond"), "subkind": "cond"})
    columns.extend(model_cols)
    if geom_col:
        columns.append(geom_col)  # label already "GEOM"
    if include_target:
        columns.append({"label": "TARGET", "sources": _roots_for("tgt"), "subkind": "tgt"})

    # helper: try multiple source folders for a given base; return first hit
    def _load_first(sources, base_png, ref_wh=None):
        for s in sources:
            fp = os.path.join(s, base_png)
            if os.path.exists(fp):
                im = Image.open(fp).convert("L")
                if ref_wh and im.size != ref_wh:
                    im = im.resize(ref_wh, Image.NEAREST)
                return im
        if ref_wh is None:
            return None
        w, h = ref_wh
        return Image.fromarray(np.zeros((h, w), dtype=np.uint8), mode="L")

    # reference size scan
    ref_w = ref_h = None
    for bn in base_names:
        base_png = f"{bn}.png"
        for col in columns:
            im = _load_first(col["sources"], base_png, ref_wh=None)
            if im is not None:
                ref_w, ref_h = im.size
                break
        if ref_w is not None:
            break
    if ref_w is None:
        raise FileNotFoundError("[combine_by_filenames] Could not find any singles to size from.")

    ref_wh = (ref_w, ref_h)

    # header + spacer heights
    header_h = int(ref_h * 0.28) if header else 0
    spacer_h = int(ref_h * 0.10) if header else 0   # “1 space line” under header

    # build rows
    rows = []
    for bn in base_names:
        base_png = f"{bn}.png"
        cells = [ _load_first(col["sources"], base_png, ref_wh=ref_wh) for col in columns ]
        row_strip = Image.new("L", (ref_w * len(columns), ref_h))
        x = 0
        for im in cells:
            row_strip.paste(im, (x, 0)); x += ref_w
        rows.append(row_strip)

    # canvas
    W = ref_w * len(columns)
    H_rows = ref_h * len(rows)
    H_total = header_h + spacer_h + H_rows
    grid = Image.new("L", (W, H_total), color=int(VIS_GRAY * 255))
    draw = ImageDraw.Draw(grid)

    # header text
    if header:
        try:
            font = ImageFont.truetype("DejaVuSans.ttf", size=int(ref_h * 0.20))
        except Exception:
            font = ImageFont.load_default()

        for ci, col in enumerate(columns):
            label = col["label"].upper()
            cx0 = ci * ref_w
            # measure
            try:
                x0, y0, x1, y1 = draw.textbbox((0, 0), label, font=font)
                tw, th = (x1 - x0), (y1 - y0)
            except Exception:
                try:
                    x0, y0, x1, y1 = font.getbbox(label)
                    tw, th = (x1 - x0), (y1 - y0)
                except Exception:
                    tw, th = draw.textsize(label, font=font)
            tx = cx0 + (ref_w - tw) // 2
            ty = (header_h - th) // 2
            draw.text((tx, ty), label, fill=0, font=font)

        # separator line under header (after the blank spacer)
        y_sep = header_h + spacer_h - 1
        draw.line([(0, y_sep), (W - 1, y_sep)], fill=0, width=1)

    # paste rows
    y0 = header_h + spacer_h
    for strip in rows:
        grid.paste(strip, (0, y0))
        y0 += ref_h

    # grid lines (column + row separators)
    top_y = header_h + spacer_h
    # vertical lines
    for c in range(len(columns) + 1):
        x = c * ref_w
        draw.line([(x, top_y), (x, H_total - 1)], fill=0, width=1)
    # horizontal lines (between rows)
    for r in range(len(rows) + 1):
        y = (header_h + spacer_h) + r * ref_h
        draw.line([(0, y), (W - 1, y)], fill=0, width=1)

    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)
    grid.save(out_path)
    return out_path

# For seg_gan → reconstruct from logits
try:
    from losses.gan import logits_to_recon
except Exception:
    logits_to_recon = None

# optional SSIM impl (already in repo)
try:
    from metrics.ssim import pytorch_ssim
except Exception:
    pytorch_ssim = None


# ---------- YAML helpers ----------
def _dict_to_ns(d):
    if isinstance(d, dict):
        return SN(**{k: _dict_to_ns(v) for k, v in d.items()})
    if isinstance(d, list):
        return [_dict_to_ns(x) for x in d]
    return d

def _visual_dir_from_ckpt(ckpt_path: str, split: str = "test", scope: str = "full") -> str:
    # <...>/<model>/checkpoints/best.pth -> <...>/<model>/visual_results/<split>/<scope>
    model_dir = os.path.dirname(os.path.dirname(os.path.abspath(ckpt_path)))
    out_dir = os.path.join(model_dir, "visual_results", split, scope)
    os.makedirs(out_dir, exist_ok=True)
    return out_dir

def _metric_dir_from_ckpt(ckpt_path: str, split: str = "test", scope: str = "full") -> str:
    # <...>/<model>/checkpoints/best.pth -> <...>/<model>/metric_results/<split>/<scope>
    model_dir = os.path.dirname(os.path.dirname(os.path.abspath(ckpt_path)))
    out_dir = os.path.join(model_dir, "metric_results", split, scope)
    os.makedirs(out_dir, exist_ok=True)
    return out_dir


def load_yaml_ns(path: str) -> SN:
    if not path or not os.path.exists(path):
        return SN()
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return _dict_to_ns(data)

def default_paths(save_root: str, model_name: str) -> SN:
    root = os.path.join(save_root, model_name)
    return SN(
        root=root,
        checkpoints=os.path.join(root, "checkpoints"),
        results=os.path.join(root, "results", "test"),
    )


# ---------- metrics (simple + robust) ----------
@torch.no_grad()
def l1(pred, tgt):
    return float(F.l1_loss(pred, tgt))

@torch.no_grad()
def mse(pred, tgt):
    return float(F.mse_loss(pred, tgt))

@torch.no_grad()
def rmse(pred, tgt):
    return float(torch.sqrt(F.mse_loss(pred, tgt)))

@torch.no_grad()
def ssim(pred, tgt):
    if pytorch_ssim is None:
        return float('nan')
    return float(pytorch_ssim(pred, tgt))

@torch.no_grad()
def uqi(pred, tgt, eps=1e-8):
    """
    Universal Quality Index (global version).
    pred/tgt: [B,1,H,W] in [0,1]
    """
    x = pred.view(pred.size(0), -1)
    y = tgt.view(tgt.size(0), -1)
    mx = x.mean(dim=1, keepdim=True)
    my = y.mean(dim=1, keepdim=True)
    vx = ((x - mx) ** 2).mean(dim=1, keepdim=True)
    vy = ((y - my) ** 2).mean(dim=1, keepdim=True)
    cxy = ((x - mx) * (y - my)).mean(dim=1, keepdim=True)
    num = 4 * cxy * mx * my
    den = (vx + vy + eps) * (mx ** 2 + my ** 2 + eps)
    val = num / (den + eps)
    return float(val.mean())

@torch.no_grad()
def scc(pred, tgt, eps=1e-8):
    """
    Spatial Correlation Coefficient (Pearson correlation of flattened signals).
    """
    x = pred.view(pred.size(0), -1)
    y = tgt.view(tgt.size(0), -1)
    x = x - x.mean(dim=1, keepdim=True)
    y = y - y.mean(dim=1, keepdim=True)
    num = (x * y).sum(dim=1)
    den = torch.sqrt((x ** 2).sum(dim=1) * (y ** 2).sum(dim=1) + eps)
    return float((num / (den + eps)).mean())

@torch.no_grad()
def ergas(pred, tgt, scale=1.0, eps=1e-8):
    """
    ERGAS for single-band: 100/scale * RMSE/mean(target)
    """
    rmse_val = torch.sqrt(F.mse_loss(pred, tgt))
    mu = tgt.mean()
    return float(100.0 / max(scale, 1e-8) * (rmse_val / (mu + eps)))

def to_classes(q):
    """Map {0, .5, 1} → {0,1,2}"""
    z = torch.zeros_like(q, dtype=torch.long)
    z = torch.where(torch.isclose(q, torch.tensor(0.5, device=q.device)), torch.ones_like(z), z)
    z = torch.where(torch.isclose(q, torch.tensor(1.0, device=q.device)), torch.full_like(z, 2), z)
    return z  # [B,1,H,W] long

@torch.no_grad()
def pixel_accuracy(pred_cls, tgt_cls, mask: Optional[torch.Tensor] = None):
    if mask is None:
        return float((pred_cls == tgt_cls).float().mean())
    m = (mask > 0.5).float()
    denom = m.numel() if m.dim() == 0 else m.sum().clamp_min(1.0)
    return float((((pred_cls == tgt_cls).float() * m).sum() / denom))

@torch.no_grad()
def f1_iou_macro(pred_cls, tgt_cls, num_classes=3, eps=1e-6, mask: Optional[torch.Tensor] = None):
    # flatten (apply mask if given)
    p = pred_cls.view(-1).cpu()
    t = tgt_cls.view(-1).cpu()
    if mask is not None:
        m = (mask.view(-1) > 0.5).cpu()
        p = p[m]
        t = t[m]
    f1s, ious = [], []
    for c in range(num_classes):
        tp = ((p == c) & (t == c)).sum().item()
        fp = ((p == c) & (t != c)).sum().item()
        fn = ((p != c) & (t == c)).sum().item()
        denom_iou = tp + fp + fn
        iou_c = tp / denom_iou if denom_iou > 0 else 0.0
        prec = tp / (tp + fp + eps) if (tp + fp) > 0 else 0.0
        rec  = tp / (tp + fn + eps) if (tp + fn) > 0 else 0.0
        f1_c = 2 * prec * rec / (prec + rec + eps) if (prec + rec) > 0 else 0.0
        f1s.append(f1_c); ious.append(iou_c)
    return float(sum(f1s)/len(f1s)), float(sum(ious)/len(ious))

@torch.no_grad()
def binarize_occupancy(x: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    """
    Occupancy-area binarization used for R12-style evaluation.
    Treat anything != 0.5 (i.e., inside the map: walls or free) as 1,
    and 0.5 (unknown/background) as 0.
    Input:  [B,1,H,W] in [0,1] (will be quantized via quantize_three)
    Output: [B,1,H,W] float in {0,1}
    """
    xq = quantize_three(x)                       # -> {0, 0.5, 1.0}
    return (xq.sub(0.5).abs().gt(eps)).float()   # 1 = occupancy area, 0 = not

@torch.no_grad()
def binary_scores(pred_bin: torch.Tensor,
                  tgt_bin: torch.Tensor,
                  mask: Optional[torch.Tensor] = None,
                  eps: float = 1e-8) -> Tuple[float, float, float, float, float]:
    """
    Return (acc, prec, rec, f1, iou) on a binary map.
    pred_bin/tgt_bin: [B,1,H,W] in {0,1} (floats are OK)
    mask (optional):  [B,1,H,W] in {0,1}; if provided, scores are over mask==1.
    """
    p = (pred_bin > 0.5)
    t = (tgt_bin  > 0.5)
    if mask is not None:
        m = (mask > 0.5)
        # If mask is empty, follow your masked-* metrics pattern and return NaNs
        if m.sum().item() == 0:
            return float('nan'), float('nan'), float('nan'), float('nan'), float('nan')
        p = p & m
        t = t & m

    # flatten
    p = p.view(-1)
    t = t.view(-1)

    tp = (p & t).sum().item()
    tn = ((~p) & (~t)).sum().item()
    fp = (p & (~t)).sum().item()
    fn = ((~p) & t).sum().item()

    total = tp + tn + fp + fn
    acc  = (tp + tn) / total if total > 0 else 0.0
    prec = tp / (tp + fp + eps) if (tp + fp) > 0 else 0.0
    rec  = tp / (tp + fn + eps) if (tp + fn) > 0 else 0.0
    f1   = (2.0 * prec * rec) / (prec + rec + eps) if (prec + rec) > 0 else 0.0
    iou  = tp / (tp + fp + fn + eps) if (tp + fp + fn) > 0 else 0.0
    return float(acc), float(prec), float(rec), float(f1), float(iou)


# ---------- masked helpers ----------
def _safe_mask_like(x: torch.Tensor, val: float = 1.0):
    return torch.full_like(x, val)

def _apply_mask(a: torch.Tensor, m: Optional[torch.Tensor]) -> Tuple[torch.Tensor, torch.Tensor]:
    if m is None:
        return a, _safe_mask_like(a)
    return a * m, m

def _masked_mean(diff: torch.Tensor, m: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    denom = m.sum().clamp_min(eps)
    return (diff * m).sum() / denom

@torch.no_grad()
def l1_masked(pred, tgt, mask):
    diff = (pred - tgt).abs()
    _, m = _apply_mask(diff, mask)
    return float(_masked_mean(diff, m))

@torch.no_grad()
def mse_masked(pred, tgt, mask):
    diff2 = (pred - tgt) ** 2
    _, m = _apply_mask(diff2, mask)
    return float(_masked_mean(diff2, m))

@torch.no_grad()
def rmse_masked(pred, tgt, mask):
    return float(torch.sqrt(torch.tensor(mse_masked(pred, tgt, mask))))

@torch.no_grad()
def uqi_masked(pred, tgt, mask, eps=1e-8):
    # Compute UQI on masked pixels (global version over selected elements).
    x = pred[mask > 0.5].view(1, -1)
    y = tgt[mask > 0.5].view(1, -1)
    if x.numel() == 0 or y.numel() == 0:
        return float('nan')
    mx = x.mean(dim=1, keepdim=True)
    my = y.mean(dim=1, keepdim=True)
    vx = ((x - mx) ** 2).mean(dim=1, keepdim=True)
    vy = ((y - my) ** 2).mean(dim=1, keepdim=True)
    cxy = ((x - mx) * (y - my)).mean(dim=1, keepdim=True)
    num = 4 * cxy * mx * my
    den = (vx + vy + eps) * (mx ** 2 + my ** 2 + eps)
    return float((num / (den + eps)).mean())

@torch.no_grad()
def scc_masked(pred, tgt, mask, eps=1e-8):
    x = pred[mask > 0.5].view(1, -1)
    y = tgt[mask > 0.5].view(1, -1)
    if x.numel() == 0 or y.numel() == 0:
        return float('nan')
    x = x - x.mean(dim=1, keepdim=True)
    y = y - y.mean(dim=1, keepdim=True)
    num = (x * y).sum(dim=1)
    den = torch.sqrt((x ** 2).sum(dim=1) * (y ** 2).sum(dim=1) + eps)
    return float((num / (den + eps)).mean())

@torch.no_grad()
def ergas_masked(pred, tgt, mask, scale=1.0, eps=1e-8):
    # ERGAS on masked pixels
    x = pred[mask > 0.5]
    y = tgt[mask > 0.5]
    if x.numel() == 0 or y.numel() == 0:
        return float('nan')
    rmse_val = torch.sqrt(F.mse_loss(x, y))
    mu = y.mean()
    return float(100.0 / max(scale, 1e-8) * (rmse_val / (mu + eps)))

@torch.no_grad()
def ssim_masked(pred, tgt, mask):
    # Approximate masked SSIM by applying mask before SSIM.
    # (Note: SSIM isn't strictly mask-aware; this is a practical proxy.)
    if pytorch_ssim is None:
        return float('nan')
    return float(pytorch_ssim(pred * mask, tgt * mask))


# ---------- build test loader ----------
def build_test_loader(cfg_data: SN):
    ds = getattr(cfg_data, "dataset", SN())
    ld = getattr(cfg_data, "loader", SN())

    test_in  = getattr(ds, "test_input",  "data/test/input")
    test_out = getattr(ds, "test_output", "data/test/output")
    size     = int(getattr(ds, "size", 128))
    bs       = int(getattr(ld, "batch_size", 32))
    nw       = int(getattr(ld, "num_workers", 4))

    test_ds = FixedBoundingBoxDataset(
        input_folder=test_in,
        output_folder=test_out,
        target_size=(size, size),
        margin=10,
        augment=False,
        wall_thickness=3,
    )
    test_loader = DataLoader(test_ds, batch_size=bs, shuffle=False, num_workers=nw, pin_memory=True)
    return test_loader, size


# ---------- model factory + ckpt load ----------
def infer_model_name(model_cfg: SN) -> str:
    name = (
        getattr(model_cfg, "name", None)
        or getattr(getattr(model_cfg, "model", SN()), "name", None)
        or getattr(model_cfg, "type", None)
    )
    if not name:
        for cand in ("cgan", "gan", "pix2pix", "seg_gan", "vit", "repaint", "ddpm", "cvae", "unet", "geom"):
            if hasattr(model_cfg, cand):
                name = cand
                break
    return str(name).lower()

def build_model_for_eval(model_cfg: SN, img_size: int, device: torch.device):
    model_name = infer_model_name(model_cfg)
    if model_name in ("cgan", "gan", "pix2pix", "seg_gan"):
        task = getattr(model_cfg, "task", "pix2pix")
        out_ch = 3 if task == "seg_gan" else 1
        G = UNetG_3x3(in_ch=1, out_ch=out_ch, activation="none" if out_ch == 3 else "sigmoid").to(device)
        return ("gan", task, G)

    elif model_name == "vit":
        vit = getattr(model_cfg, "vit", SN())
        net = ViTEncoderDecoder(
            image_size=img_size,
            patch_size=int(getattr(vit, "patch", 16)),
            embed_dim=int(getattr(vit, "embed", 256)),
            num_heads=int(getattr(vit, "heads", 4)),
            depth=int(getattr(vit, "depth", 3)),
            mlp_dim=int(getattr(vit, "mlp", 512)),
            dropout=0.0,
        ).to(device)
        return ("vit", None, net)

    elif model_name in ("repaint", "ddpm"):
        unet = UNetModel(
            in_channels=2,
            base_channels=model_cfg.model.base_channels,
            time_emb_dim=model_cfg.model.time_emb_dim,
        ).to(device)

        unet.use_checkpoint = bool(getattr(getattr(model_cfg, "model", SN()), "checkpoint", True))

        model = RePaintDiffusion(
            unet_model=unet,
            timesteps=model_cfg.diff.timesteps,
            beta_start=model_cfg.diff.beta_start,
            beta_end=model_cfg.diff.beta_end,
        ).to(device)

        model.noise_weight = float(model_cfg.loss.noise_weight)
        model.masked_l1_weight = float(model_cfg.loss.masked_l1_weight)
        model.ssim_weight = float(model_cfg.loss.ssim_weight)

        return ("repaint", None, model)

    elif model_name == "cvae":
        net = ConditionalVAE3x3(
            in_ch=model_cfg.model.in_ch,
            base_ch=model_cfg.model.base_ch,
            latent_dim=model_cfg.model.latent_dim,
            image_size=model_cfg.model.image_size,
            num_layers=model_cfg.model.num_layers,
        ).to(device)

        return ("cvae", None, net)

    elif model_name == "unet":
        loss = getattr(model_cfg, "loss", SN())
        loss_type = str(getattr(loss, "type", "ce")).lower()
        final_act = "none" if loss_type == "ce" else "sigmoid"

        if loss_type == "ce":
            assert model_cfg.model.out_ch == 3, "CE needs out_ch=3"
        else:
            assert model_cfg.model.out_ch == 1, "L1/MSE needs out_ch=1"

        net = UNet33Res(
            in_ch=model_cfg.model.in_ch,
            out_ch=model_cfg.model.out_ch,
            base=model_cfg.model.base_ch,
            final_activation=final_act,
        ).to(device)

        # return loss_type as 'task' so eval can branch properly
        return ("unet", loss_type, net)

    elif model_name == "geom":
        net = GeometricBaselineNet(
            method=getattr(model_cfg.model, "method", "guide"),
            wall_value=getattr(model_cfg.model, "wall_value", 0),
            wall_thickness=getattr(model_cfg.model, "wall_thickness", 0),
            max_fill=getattr(model_cfg.model, "max_fill", 30),
            verbose=getattr(model_cfg.model, "verbose", False),
            clamp_border=getattr(model_cfg.model, "clamp_border", True),

            door_space=getattr(model_cfg.model, "door_space", "both"),
            door_min_width=getattr(model_cfg.model, "door_min_width", 2),
            door_max_width=getattr(model_cfg.model, "door_max_width", 5),
            door_space_min_frac=getattr(model_cfg.model, "door_space_min_frac", 0.60),
            paint_guides_as_walls=getattr(model_cfg.model, "paint_guides_as_walls", True),

            debug=getattr(model_cfg.model, "debug", False),
            debug_dir=getattr(
                model_cfg.model, "debug_dir",
                os.path.join(getattr(getattr(model_cfg, "paths", SN()), "save_dir", "outputs"),
                             "geom", "debug")
            ),
            debug_limit=getattr(model_cfg.model, "debug_limit", 0),
        ).to(device)

        return ("geom", None, net)

    else:
        raise ValueError(f"Unknown model name in model config: {model_name!r}")

def find_ckpt(model_cfg: SN, default_root="outputs") -> str:
    # Try to infer path like outputs/<task>_<gan_type>/checkpoints/best.pth for GAN
    paths = getattr(model_cfg, "paths", SN())
    save_dir = getattr(paths, "save_dir", default_root)
    model_name = infer_model_name(model_cfg)

    if model_name in ("cgan", "gan", "pix2pix", "seg_gan"):
        task = getattr(model_cfg, "task", "pix2pix")
        gan_type = getattr(getattr(model_cfg, "gan", SN()), "type", "hinge")
        run_name = f"{task}_{gan_type}"
    else:
        run_name = {"vit": "vit", "repaint": "repaint", "ddpm": "repaint", "cvae": "cvae", "unet": "unet", "geom": "geom"}.get(model_name, model_name)

    ckpt_dir = os.path.join(save_dir, run_name, "checkpoints")
    candidates = [os.path.join(ckpt_dir, "best.pth"), os.path.join(ckpt_dir, "epoch_last.pth")]
    for c in candidates:
        if os.path.exists(c):
            return c
    # fallback: any .pth
    if os.path.isdir(ckpt_dir):
        for f in sorted(os.listdir(ckpt_dir)):
            if f.endswith(".pth"):
                return os.path.join(ckpt_dir, f)
    raise FileNotFoundError(f"No checkpoint found under {ckpt_dir}")

def load_generator_from_ckpt(model_kind: str, net: torch.nn.Module, ckpt_path: str, device: torch.device):
    ckpt = torch.load(ckpt_path, map_location=device)
    obj = ckpt.get("objects", {})
    state = None
    if model_kind == "gan":
        state = obj.get("G", None)
    else:
        # for single-net models (vit/cvae/repaint/unet/geom), the saved key may vary;
        # try 'model' then 'G' as fallback
        state = obj.get("model", None) or obj.get("G", None)
    if state is None:
        # or maybe the whole checkpoint is just a state_dict
        if isinstance(ckpt, dict) and all(isinstance(k, str) and "." in k for k in ckpt.keys()):
            state = ckpt
        else:
            raise KeyError(f"Could not find model weights in {ckpt_path}")
    net.load_state_dict(state, strict=False)
    net.eval()
    return net


# ---------- evaluation core ----------
def _init_accumulators():
    return dict(
        count=0,
        pixel_acc=0.0, f1_macro=0.0, iou_macro=0.0,
        l1=0.0, mse=0.0, rmse=0.0, uqi=0.0, ergas=0.0, scc=0.0,
        ssim=0.0,  # may remain 0 if pytorch_ssim is None
        # NEW: R12-style binary metrics (full-image)
        bin_acc=0.0, bin_prec=0.0, bin_rec=0.0, bin_f1=0.0, bin_iou=0.0
    )

def _accumulate(acc: Dict, add: Dict):
    for k in acc.keys():
        if k == "count":
            acc[k] += add.get(k, 0)
        else:
            acc[k] += add.get(k, 0.0)

def _finalize(acc: Dict) -> Dict:
    n = max(1, acc["count"])
    out = {k: (v / n if k != "count" else v) for k, v in acc.items()}
    if pytorch_ssim is None:
        out["ssim"] = None
    return out

def _metrics_full(recon, tgt, pc, tc) -> Dict:
    # existing
    d = dict(
        count=1,
        pixel_acc=pixel_accuracy(pc, tc),
        f1_macro=f1_iou_macro(pc, tc)[0],
        iou_macro=f1_iou_macro(pc, tc)[1],
        l1=l1(recon, tgt),
        mse=mse(recon, tgt),
        rmse=rmse(recon, tgt),
        uqi=uqi(recon, tgt),
        ergas=ergas(recon, tgt, scale=1.0),
        scc=scc(recon, tgt),
    )
    d["ssim"] = ssim(recon, tgt) if pytorch_ssim is not None else 0.0

    # NEW: R12-style binary metrics over the FULL image
    pb = binarize_occupancy(recon)  # 1 = occupancy area
    tb = binarize_occupancy(tgt)
    acc, prec, rec, f1, iou = binary_scores(pb, tb, mask=None)
    d.update(dict(bin_acc=acc, bin_prec=prec, bin_rec=rec, bin_f1=f1, bin_iou=iou))

    return d


def _metrics_masked(recon, tgt, pc, tc, mask) -> Dict:
    d = dict(
        count=1,
        pixel_acc=pixel_accuracy(pc, tc, mask=mask),
        f1_macro=f1_iou_macro(pc, tc, mask=mask)[0],
        iou_macro=f1_iou_macro(pc, tc, mask=mask)[1],
        l1=l1_masked(recon, tgt, mask),
        mse=mse_masked(recon, tgt, mask),
        rmse=rmse_masked(recon, tgt, mask),
        uqi=uqi_masked(recon, tgt, mask),
        ergas=ergas_masked(recon, tgt, mask, scale=1.0),
        scc=scc_masked(recon, tgt, mask),
    )
    d["ssim"] = ssim_masked(recon, tgt, mask) if pytorch_ssim is not None else 0.0

    # NEW: masked R12-style binary metrics (you can ignore these if you only want FULL)
    pb = binarize_occupancy(recon)
    tb = binarize_occupancy(tgt)
    acc, prec, rec, f1, iou = binary_scores(pb, tb, mask=mask)
    d.update(dict(bin_acc=acc, bin_prec=prec, bin_rec=rec, bin_f1=f1, bin_iou=iou))

    return d

@torch.no_grad()
def run_eval(
    model_cfg: SN,
    data_cfg: SN,
    ckpt_path: Optional[str] = None,
    save_root: str = "outputs",
    save_images_every: int = 20,
    max_batches: Optional[int] = None,
):
    device = torch.device(
        (getattr(getattr(model_cfg, "runtime", SN()), "device", "cuda"))
        if torch.cuda.is_available() else "cpu"
    )

    test_loader, size = build_test_loader(data_cfg)
    kind, task, net = build_model_for_eval(model_cfg, size, device)

    # Checkpoint handling: skip for geom (rule-based; no weights)
    save_root = getattr(getattr(model_cfg, "paths", SN()), "save_dir", "outputs")

    if kind == "geom":
        ckpt_path = "(none)"
        # derive output dirs without a checkpoint path
        run_dir = os.path.join(save_root, "geom")
        visual_dir_full   = os.path.join(run_dir, "visual_results", "test", "full")
        visual_dir_masked = os.path.join(run_dir, "visual_results", "test", "masked")
        metric_dir_full   = os.path.join(run_dir, "metric_results", "test", "full")
        metric_dir_masked = os.path.join(run_dir, "metric_results", "test", "masked")
        for d in (visual_dir_full, visual_dir_masked, metric_dir_full, metric_dir_masked):
            os.makedirs(d, exist_ok=True)
    else:
        if ckpt_path is None:
            ckpt_path = find_ckpt(model_cfg, default_root=save_root)
        print(f"[eval] loading checkpoint: {ckpt_path}")
        net = load_generator_from_ckpt(kind, net, ckpt_path, device)
        # where to save results (separate FULL vs MASKED)
        visual_dir_full   = _visual_dir_from_ckpt(ckpt_path, split="test", scope="full")
        visual_dir_masked = _visual_dir_from_ckpt(ckpt_path, split="test", scope="masked")
        metric_dir_full   = _metric_dir_from_ckpt(ckpt_path, split="test", scope="full")
        metric_dir_masked = _metric_dir_from_ckpt(ckpt_path, split="test", scope="masked")

    # accumulators
    acc_full   = _init_accumulators()
    acc_masked = _init_accumulators()

    # NEW: start wall-clock timer for one eval epoch + image counter
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    t_start = time.perf_counter()
    images_seen = 0

    pbar = tqdm(test_loader, desc="Evaluating", ncols=0)
    for b_idx, (cond, tgt) in enumerate(pbar, 1):

        cond = cond.to(device)
        tgt  = tgt.to(device)

        # NEW: count images
        images_seen += int(cond.size(0))

        # forward per model
        recon = None  # safety
        pred_idx = None  # for CE-based unet (class indices)

        if kind == "gan":
            out = net(cond)  # [B,1,H,W] or [B,3,H,W]
            if task == "seg_gan" and out.size(1) == 3 and logits_to_recon is not None:
                recon, _ = logits_to_recon(out)  # [B,1,H,W] in [0,1]
            else:
                recon = out.clamp(0, 1)

        elif kind == "vit":
            recon = torch.sigmoid(net(cond)).clamp(0, 1)

        elif kind == "cvae":
            # You can switch modes if you like; these were in your original file.
            logits, recon = net.sample(cond, mode="prior_trunc", jitter=0, z_scale=0.6, truncation=1)
            recon = recon.clamp(0, 1)
        elif kind == "repaint":

            # DDIM (fast)
            recon = net.sample(cond, method="ddim", ddim_steps=50, ddim_eta=0.0).clamp(0, 1)

            # RePaint (higher fidelity on masks)
            #recon = net.sample(cond, method="repaint", steps=200, jump_length=10, n_resample=5).clamp(0, 1)

        elif kind == "geom":
            recon = net(cond).clamp(0, 1)

        elif kind == "unet":
            # Branch by loss type passed as 'task'
            if str(task).lower() == "ce":
                logits = net(cond)  # [B,3,H,W], final_activation="none"
                pred_idx = logits.argmax(dim=1, keepdim=True)  # [B,1,H,W], long in {0,1,2}
                # map classes → grayscale {0, .5, 1} for image metrics
                recon = pred_idx.float() / 2.0
            else:
                # Regression (l1/mse) → one-channel in [0,1]
                recon = net(cond).clamp(0, 1)
        else:
            raise RuntimeError(f"Unknown model kind: {kind}")

        assert recon is not None, "internal: recon not set"

        # quantized for discrete metrics
        cq = quantize_three(cond)
        rq = quantize_three(recon)
        tq = quantize_three(tgt)

        if kind == "unet" and str(task).lower() == "ce" and pred_idx is not None:
            pc = pred_idx
        else:
            pc = to_classes(rq)
        tc = to_classes(tq)

        # mask for masked evaluation: unknown-in-condition AND known-in-target
        m_unknown = build_eval_mask(cq, tq, eps=1e-6).float()

        if m_unknown.sum().item() == 0:
            # This should rarely happen; warn for visibility
            print(f"[warn] empty masked-eval region at batch {b_idx} (scope=masked).")

        # ---- accumulate FULL metrics
        add_full = _metrics_full(recon, tgt, pc, tc)
        _accumulate(acc_full, add_full)

        # ---- accumulate MASKED metrics (unknown region only)
        add_masked = _metrics_masked(recon, tgt, pc, tc, mask=m_unknown)
        _accumulate(acc_masked, add_masked)

        # ---- save visual examples periodically (both scopes)
        if (b_idx % save_images_every) == 0:
            cq = quantize_three(cond)
            bq = blend_generated_with_condition(cq, rq)

            num_to_save = min(cond.size(0), 4)
            for i in range(num_to_save):
                base = f"b{b_idx:05d}_i{i}"
                # FULL
                save_visuals(
                    cq[i].cpu(),  # condition
                    tq[i].cpu(),  # target
                    rq[i].cpu(),  # generated
                    bq[i].cpu(),  # blended
                    out_dir=visual_dir_full,
                    base_name=base
                )
                # MASKED overlay: zero-out outside unknown for target/gen/blend
                mask_i = m_unknown[i].cpu()
                rq_m = (rq[i].cpu() * mask_i)
                tq_m = (tq[i].cpu() * mask_i)
                bq_m = (bq[i].cpu() * mask_i)  # simple masked visualization
                save_visuals(
                    cq[i].cpu(),
                    tq_m,
                    rq_m,
                    bq_m,
                    out_dir=visual_dir_masked,
                    base_name=base
                )

                # --- NEW: also save all images individually (FULL + MASKED) ---
                single_full = os.path.join(visual_dir_full, "single")
                single_mask = os.path.join(visual_dir_masked, "single")
                for sub in ["cond", "tgt", "gen", "blend"]:
                    os.makedirs(os.path.join(single_full, sub), exist_ok=True)
                    os.makedirs(os.path.join(single_mask, sub), exist_ok=True)

                # FULL singles (render unknown=0.5 as panel gray)
                _save_tensor_png(_for_display(cq[i]), os.path.join(single_full, "cond", f"{base}.png"))
                _save_tensor_png(_for_display(tq[i]), os.path.join(single_full, "tgt", f"{base}.png"))
                _save_tensor_png(_for_display(rq[i]), os.path.join(single_full, "gen", f"{base}.png"))
                _save_tensor_png(_for_display(bq[i]), os.path.join(single_full, "blend", f"{base}.png"))

                # MASKED singles (hole content, panel gray elsewhere)
                _save_tensor_png(_for_display(cq[i]), os.path.join(single_mask, "cond", f"{base}.png"))
                _save_tensor_png(tq_m, os.path.join(single_mask, "tgt", f"{base}.png"))
                _save_tensor_png(rq_m, os.path.join(single_mask, "gen", f"{base}.png"))
                _save_tensor_png(bq_m, os.path.join(single_mask, "blend", f"{base}.png"))

        if max_batches is not None and b_idx >= max_batches:
            break

    # averages
    # NEW: stop timer and compute epoch time / throughput
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    t_end = time.perf_counter()
    epoch_time_sec = float(t_end - t_start)
    imgs_per_sec = (images_seen / epoch_time_sec) if epoch_time_sec > 0 else 0.0

    # averages
    summary_full = _finalize(acc_full)
    summary_masked = _finalize(acc_masked)
    summary_full["ckpt"] = summary_masked["ckpt"] = ckpt_path

    # attach timing to both summaries (same epoch for full & masked)
    summary_full["epoch_time_sec"] = epoch_time_sec
    summary_masked["epoch_time_sec"] = epoch_time_sec
    summary_full["imgs_per_sec"] = imgs_per_sec
    summary_masked["imgs_per_sec"] = imgs_per_sec

    # write CSV + JSON under metric_results/test/{full,masked}
    def _write_results(metric_dir: str, scope_name: str, summary: Dict):
        metrics_csv = os.path.join(metric_dir, "metrics.csv")
        summary_json = os.path.join(metric_dir, "summary.json")
        header = (
            "count,pixel_acc,f1_macro,iou_macro,"
            "bin_acc,bin_prec,bin_rec,bin_f1,bin_iou,"  # NEW
            "l1,mse,rmse,uqi,ergas,scc,ssim,"
            "epoch_time_sec,imgs_per_sec,ckpt\n"
        )

        line = (
            f'{summary["count"]},'
            f'{summary["pixel_acc"]:.6f},'
            f'{summary["f1_macro"]:.6f},'
            f'{summary["iou_macro"]:.6f},'
            f'{summary["bin_acc"]:.6f},'  # NEW
            f'{summary["bin_prec"]:.6f},'  # NEW
            f'{summary["bin_rec"]:.6f},'  # NEW
            f'{summary["bin_f1"]:.6f},'  # NEW
            f'{summary["bin_iou"]:.6f},'  # NEW
            f'{summary["l1"]:.6f},'
            f'{summary["mse"]:.6f},'
            f'{summary["rmse"]:.6f},'
            f'{summary["uqi"]:.6f},'
            f'{summary["ergas"]:.6f},'
            f'{summary["scc"]:.6f},'
            f'{summary["ssim"] if summary["ssim"] is not None else ""},'
            f'{summary.get("epoch_time_sec", 0.0):.6f},'
            f'{summary.get("imgs_per_sec", 0.0):.3f},'
            f'{summary.get("ckpt", "")}\n'
        )

        write_header = not os.path.exists(metrics_csv)
        with open(metrics_csv, "a", encoding="utf-8") as f:
            if write_header:
                f.write(header)
            f.write(line)
        with open(summary_json, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
        print(f"[eval:{scope_name}] wrote metrics to: {metric_dir}")

    _write_results(metric_dir_full, "full", summary_full)
    _write_results(metric_dir_masked, "masked", summary_masked)

    print("\n[eval:full] summary:", json.dumps(summary_full, indent=2))
    print("[eval:full] wrote images  to:", visual_dir_full)
    print("\n[eval:masked] summary:", json.dumps(summary_masked, indent=2))
    print("[eval:masked] wrote images  to:", visual_dir_masked)

def main():
    ap = argparse.ArgumentParser("Evaluate on test set using configs/data.yaml")
    ap.add_argument("--config_model", required=True, type=str, help="e.g. configs/cgan.yaml")
    ap.add_argument("--config_data",  default="configs/data.yaml", type=str)
    ap.add_argument("--ckpt", default=None, type=str, help="optional explicit checkpoint path")
    ap.add_argument("--save_images_every", type=int, default=20)
    ap.add_argument("--max_batches", type=int, default=None)
    args = ap.parse_args()

    model_cfg = load_yaml_ns(args.config_model)
    data_cfg  = load_yaml_ns(args.config_data)

    run_eval(
        model_cfg=model_cfg,
        data_cfg=data_cfg,
        ckpt_path=args.ckpt,
        save_root=getattr(getattr(model_cfg, "paths", SN()), "save_dir", "outputs"),
        save_images_every=args.save_images_every,
        max_batches=args.max_batches,
    )


if __name__ == "__main__":
    main()



# Example runs
# python -m scripts.eval --config_model configs/cgan.yaml   --config_data configs/data.yaml --ckpt outputs/pix2pix_hinge/checkpoints/epoch_1000.pth --save_images_every 1
# python -m scripts.eval --config_model configs/cvae.yaml   --config_data configs/data.yaml --ckpt outputs/cvae/checkpoints/epoch_3500.pth --save_images_every 1
# python -m scripts.eval --config_model configs/repaint.yaml --config_data configs/data.yaml --ckpt outputs/repaint/checkpoints/epoch_1000.pth --save_images_every 1
# python -m scripts.eval --config_model configs/vit.yaml    --config_data configs/data.yaml --ckpt outputs/vit/checkpoints/epoch_10250.pth --save_images_every 1
# python -m scripts.eval --config_model configs/unet.yaml   --config_data configs/data.yaml --ckpt outputs/unet/checkpoints/epoch_1000.pth --save_images_every 1
# python -m scripts.eval --config_model configs/geom.yaml   --config_data configs/data.yaml --save_images_every 1
