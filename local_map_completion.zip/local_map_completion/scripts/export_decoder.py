# scripts/export_decoder.py
import os
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F

from models.cvae import DecoderOnlyCVAE


def _smart_load_full_cvae(model: nn.Module, ckpt_path: str) -> None:
    """
    Load a *full* CVAE checkpoint into `model`. Supports several common layouts:
      - {'model_state_dict': ...}
      - {'state_dict': ...}
      - raw state_dict (dict of tensors)
    If a decoder-only package is given by mistake, we still try to load what we can.
    """
    ckpt = torch.load(ckpt_path, map_location="cpu")

    # If it's a decoder-only package, try to map what we can (non-fatal).
    if isinstance(ckpt, dict) and all(k in ckpt for k in ("decoder_layers", "condition_processors", "decoder_input", "condition_fusion")):
        print("[warn] The checkpoint looks like a decoder-only package. "
              "Loading decoder submodules for verification, then re-exporting.")
        try:
            model.condition_processors.load_state_dict(ckpt["condition_processors"], strict=False)
            model.condition_fusion.load_state_dict(ckpt["condition_fusion"], strict=False)
            model.decoder_input.load_state_dict(ckpt["decoder_input"], strict=False)
            model.decoder_layers.load_state_dict(ckpt["decoder_layers"], strict=False)
        except Exception as e:
            print(f"[warn] Partial load from decoder-only package failed: {e}")
        return

    # Normal full-model cases
    if isinstance(ckpt, dict):
        for key in ("model_state_dict", "state_dict"):
            if key in ckpt and isinstance(ckpt[key], dict):
                missing, unexpected = model.load_state_dict(ckpt[key], strict=False)
                if missing or unexpected:
                    print(f"[warn] Non-strict load. Missing: {missing[:6]}... Unexpected: {unexpected[:6]}...")
                return
        # Try raw state_dict
        try:
            missing, unexpected = model.load_state_dict(ckpt, strict=False)
            if missing or unexpected:
                print(f"[warn] Non-strict load. Missing: {missing[:6]}... Unexpected: {unexpected[:6]}...")
            return
        except Exception:
            pass

    raise RuntimeError(f"Unsupported checkpoint format at: {ckpt_path}")


class CVAEDecoderJIT(nn.Module):
    """
    Minimal wrapper for TorchScript export.
    Accepts (z, condition) and returns the decoded image.
    """
    def __init__(self, cvae: DecoderOnlyCVAE):
        super().__init__()
        # copy submodules needed at inference
        self.condition_processors = cvae.condition_processors
        self.condition_fusion = cvae.condition_fusion
        self.decoder_input = cvae.decoder_input
        self.decoder_layers = cvae.decoder_layers

        # constants / sizes
        self.encoded_channels = cvae.encoded_channels
        self.encoded_size = cvae.encoded_size
        self.patch_size = cvae.patch_size

    def _process_condition(self, condition: torch.Tensor) -> torch.Tensor:
        feats = []
        # torchscript-friendly loop over ModuleList
        for i in range(len(self.condition_processors)):
            feats.append(self.condition_processors[i](condition))
        combined = torch.cat(feats, dim=1)
        return self.condition_fusion(combined)

    def forward(self, z: torch.Tensor, condition: torch.Tensor) -> torch.Tensor:
        cond_emb = self._process_condition(condition)               # [B, latent_dim]
        z_cond = torch.cat([z, cond_emb], dim=1)                    # [B, 2*latent_dim]
        x = self.decoder_input(z_cond)                              # [B, fc_dim]
        x = x.view(-1, self.encoded_channels, self.encoded_size, self.encoded_size)

        for i in range(len(self.decoder_layers)):
            x = self.decoder_layers[i](x)

        if x.shape[-1] != self.patch_size:
            x = F.interpolate(x, size=(self.patch_size, self.patch_size),
                              mode='bilinear', align_corners=False)
        return x


def main():
    ap = argparse.ArgumentParser("Export CVAE decoder-only package (and optional TorchScript).")
    ap.add_argument("--ckpt", required=True, type=str, help="Path to FULL CVAE checkpoint (or decoder-only package).")
    ap.add_argument("--out", required=True, type=str, help="Output path for decoder-only .pth (package).")
    ap.add_argument("--scripted", type=str, default=None,
                    help="Optional path to save TorchScript decoder module (.pt).")
    ap.add_argument("--image_size", type=int, default=128, help="H=W input size.")
    ap.add_argument("--hidden_dim", type=int, default=64)
    ap.add_argument("--latent_dim", type=int, default=16)
    ap.add_argument("--num_layers", type=int, default=4)
    ap.add_argument("--device", type=str, default="cpu", choices=["cpu", "cuda"])
    ap.add_argument("--verify", action="store_true", help="Run a quick decode with random z/condition before saving.")
    args = ap.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() or args.device == "cpu" else "cpu")

    # Build model shell
    model = DecoderOnlyCVAE(
        input_dim=(1, args.image_size, args.image_size),
        hidden_dim=args.hidden_dim,
        latent_dim=args.latent_dim,
        num_layers=args.num_layers
    ).to(device)

    # Load full (or decoder-only) weights
    _smart_load_full_cvae(model, args.ckpt)
    model.eval()

    # Optional quick verification
    if args.verify:
        with torch.no_grad():
            B = 2
            z = torch.randn(B, args.latent_dim, device=device)
            cond = torch.rand(B, 1, args.image_size, args.image_size, device=device)
            out = model.decode(z, cond)
            print(f"[verify] decode(z, cond) -> {tuple(out.shape)} | min={out.min().item():.3f} max={out.max().item():.3f}")

    # Save compact decoder-only package
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    model.save_decoder_only(args.out)
    print(f"✅ Saved decoder-only package to: {args.out}")

    # Optional TorchScript export
    if args.scripted:
        jit_module = CVAEDecoderJIT(model).to(device).eval()
        with torch.no_grad():
            ex_z = torch.randn(1, args.latent_dim, device=device)
            ex_c = torch.rand(1, 1, args.image_size, args.image_size, device=device)
            # Prefer script for control-flow robustness
            scripted = torch.jit.script(jit_module)
            # run once to catch obvious issues
            _ = scripted(ex_z, ex_c)
        os.makedirs(os.path.dirname(os.path.abspath(args.scripted)), exist_ok=True)
        scripted.save(args.scripted)
        print(f"✅ Saved TorchScript decoder to: {args.scripted}")


if __name__ == "__main__":
    main()
