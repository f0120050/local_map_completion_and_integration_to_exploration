from scripts.eval import combine_by_filenames

if __name__=="__main__":
    # pick sample names (bases) and models (either ckpt paths or run dirs)
    bases = ["b00001_i0", "b00002_i0", "b00003_i2",  "b00004_i0", "b00005_i3", "b00010_i3"]
    models = [
        "outputs/cvae/checkpoints/epoch_3500.pth",
        "outputs/pix2pix_hinge/checkpoints/epoch_1000.pth",
        "outputs/repaint/checkpoints/epoch_1000.pth",
        "outputs/vit/checkpoints/epoch_10250.pth",
        "outputs/unet/checkpoints/epoch_1000.pth",
    ]

    # choose scope = "full" or "masked", and kind = "cond" | "tgt" | "gen" | "blend"
    combine_by_filenames(
        base_names=bases,
        model_ckpts_or_dirs=models,
        scope="full",
        kind="blend",
        out_path="paper_figures/comparison_full_blend.png",
    )

    # python -m scripts.make_combined_visual_result