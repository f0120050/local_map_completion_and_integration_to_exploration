# scripts/make_tables.py
import os
import json
import argparse
from typing import Dict, List, Tuple, Optional

# Optional: pandas only used for CSV export convenience (not required for LaTeX)
try:
    import pandas as pd
except Exception:
    pd = None


PIX_COLS = ["l1", "mse", "rmse", "ssim", "uqi", "ergas"]
CLS_COLS = ["iou_macro", "f1_macro", "pixel_acc"]

# For bolding winners
MIN_BETTER = {"l1", "mse", "rmse", "ergas"}
MAX_BETTER = {"ssim", "uqi", "scc", "iou_macro", "f1_macro", "pixel_acc"}

# Pretty names for table headers (match your paper)
PRETTY = {
    "l1": "L1 $\\downarrow$",
    "mse": "MSE $\\downarrow$",
    "rmse": "RMSE $\\downarrow$",
    "ssim": "SSIM $\\uparrow$",
    "uqi": "UQI $\\uparrow$",
    "ergas": "ERGAS $\\downarrow$",
    "iou_macro": "IoU $\\uparrow$",
    "f1_macro": "F1 $\\uparrow$",
    "pixel_acc": "Accuracy $\\uparrow$",
}

# Heuristic mapping from run dir names to display names used in paper
def infer_display_name(run_dir: str) -> str:
    base = os.path.basename(os.path.abspath(run_dir))
    b = base.lower()
    if "cvae" in b:
        return "CVAE"
    if "pix2pix" in b or "cgan" in b or "gan" in b:
        return "CGAN"
    if "repaint" in b or "ddpm" in b:
        return "RePaint"
    if b == "vit" or "vit" in b:
        return "ViT(16)"
    if "unet" in b:
        # If you trained both CE and regression, you can rename folder to unet_ce / unet_mse
        # or post-edit labels below.
        return "UNet(3+3)"
    if "geom" in b:
        return "GEOM(CPU)"
    # Fallback to folder name
    return base

def _run_dir_from_any(path: str) -> str:
    # If a checkpoint file is given, return its parent run dir
    if os.path.isfile(path):
        return os.path.dirname(os.path.dirname(os.path.abspath(path)))
    return os.path.abspath(path)

def _summary_path(run_dir: str, scope: str, split: str="test") -> str:
    return os.path.join(run_dir, "metric_results", split, scope, "summary.json")

def _load_summary(run_dir: str, scope: str) -> Optional[Dict]:
    p = _summary_path(run_dir, scope)
    if not os.path.exists(p):
        return None
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

def _fmt(v: Optional[float], decimals: int = 3) -> str:
    if v is None:
        return "-"
    try:
        return f"{float(v):.{decimals}f}"
    except Exception:
        return "-"

def _best_indices(rows: List[Dict], cols: List[str]) -> Dict[str, int]:
    idx = {}
    for c in cols:
        vals = []
        for r in rows:
            v = r.get(c, None)
            try:
                vals.append(float("nan") if v is None else float(v))
            except Exception:
                vals.append(float("nan"))
        # choose best ignoring NaN
        best_i = None
        if c in MIN_BETTER:
            best_val = float("inf")
            for i, v in enumerate(vals):
                if v == v and v < best_val:  # v==v filters NaN
                    best_val = v; best_i = i
        else:  # max better
            best_val = -float("inf")
            for i, v in enumerate(vals):
                if v == v and v > best_val:
                    best_val = v; best_i = i
        if best_i is not None:
            idx[c] = best_i
    return idx

def _latex_table(rows: List[Dict], cols: List[str], model_names: List[str],
                 caption: str, label: str) -> str:
    winners = _best_indices(rows, cols)

    headers = " & ".join(
        ["\\textbf{Model}"] + [f"\\textbf{{{PRETTY.get(c, c)}}}" for c in cols]
    ) + " \\\\"

    lines = [
        "\\begin{table}[t]",
        "\\centering",
        f"\\caption{{{caption}}}",
        f"\\label{{{label}}}",
        "\\begingroup",                             # keep spacing local
        "\\setlength{\\tabcolsep}{3pt}",
        "\\footnotesize",
        "\\begin{tabular}{l" + "c"*len(cols) + "}",
        "\\toprule",
        headers,
        "\\midrule",
    ]

    for i, name in enumerate(model_names):
        vals = []
        for c in cols:
            v = rows[i].get(c, None)
            s = _fmt(v, 6)
            if winners.get(c, -1) == i:
                s = f"\\textbf{{{s}}}"
            vals.append(s)
        lines.append(name + " & " + " & ".join(vals) + " \\\\")
        # If you want a little air between logical groups, use:
        # lines.append("\\addlinespace")

    lines += [
        "\\bottomrule",
        "\\end{tabular}",
        "\\endgroup",
        "\\end{table}",
    ]
    return "\n".join(lines)

def _collect_rows(run_dirs: List[str], scope: str) -> Tuple[List[Dict], List[str]]:
    rows, names = [], []
    for p in run_dirs:
        rd = _run_dir_from_any(p)
        s = _load_summary(rd, scope)
        if s is None:
            # skip missing
            continue
        rows.append(s)
        names.append(infer_display_name(rd))
    return rows, names

def _export_csv(rows: List[Dict], names: List[str], out_csv: str, cols: List[str]):
    if pd is None:
        return
    os.makedirs(os.path.dirname(os.path.abspath(out_csv)) or ".", exist_ok=True)
    df = pd.DataFrame([{**{ "Model": names[i] }, **{k: rows[i].get(k, None) for k in cols}} for i in range(len(names))])
    df.to_csv(out_csv, index=False)

def make_tables(
    run_paths: List[str],
    out_dir: str = "paper_tables",
    split: str = "test",
    generate_csv: bool = True,
):
    os.makedirs(out_dir, exist_ok=True)

    for scope in ("full", "masked"):
        rows, names = _collect_rows(run_paths, scope=scope)
        if not rows:
            print(f"[warn] No summaries found for scope='{scope}'. Skipping.")
            continue

        # PIX table
        cap_pix = "Pixelwise and perceptual metrics (test set, " + ("full image" if scope=="full" else "masked unknown region") + ")."
        lab_pix = f"tab:pix_metrics_{scope}"
        tex_pix = _latex_table(rows, PIX_COLS, names, cap_pix, lab_pix)
        with open(os.path.join(out_dir, f"pix_metrics_{scope}.tex"), "w", encoding="utf-8") as f:
            f.write(tex_pix)

        # CLS table
        cap_cls = "Discrete metrics computed on $\\{0,0.5,1\\}$ labels (test set, " + ("full image" if scope=="full" else "masked unknown region") + ")."
        lab_cls = f"tab:cls_metrics_{scope}"
        tex_cls = _latex_table(rows, CLS_COLS, names, cap_cls, lab_cls)
        with open(os.path.join(out_dir, f"cls_metrics_{scope}.tex"), "w", encoding="utf-8") as f:
            f.write(tex_cls)

        # Optional CSV exports (handy for spreadsheet checks)
        if generate_csv:
            _export_csv(rows, names, os.path.join(out_dir, f"pix_metrics_{scope}.csv"), PIX_COLS)
            _export_csv(rows, names, os.path.join(out_dir, f"cls_metrics_{scope}.csv"), CLS_COLS)

        print(f"[ok] Wrote LaTeX + CSV for scope='{scope}' to {out_dir}")

def parse_args():
    ap = argparse.ArgumentParser("Aggregate per-model metrics into LaTeX tables.")
    ap.add_argument("--runs", nargs="+", required=True,
                    help="List of run dirs or checkpoint paths (one per model).")
    ap.add_argument("--out_dir", default="paper_tables", type=str,
                    help="Where to write the LaTeX/CSV files.")
    ap.add_argument("--no_csv", action="store_true", help="Do not emit CSV copies.")
    return ap.parse_args()

if __name__ == "__main__":
    args = parse_args()
    make_tables(run_paths=args.runs, out_dir=args.out_dir, generate_csv=not args.no_csv)


#
# python -m scripts.make_tables \
#   --runs \
#   outputs/cvae \
#   outputs/pix2pix_hinge \
#   outputs/repaint \
#   outputs/vit \
#   outputs/unet \
#   outputs/geom \
#   --out_dir paper_tables
