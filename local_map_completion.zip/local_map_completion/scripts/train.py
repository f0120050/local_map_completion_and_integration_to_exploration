# scripts/train.py
import os
import argparse
import json
from types import SimpleNamespace as SN

import torch
from torch.utils.data import DataLoader
import yaml

# ---- local imports (your package layout) ----
from datasets.fixed_bbox import FixedBoundingBoxDataset

from models.gan import UNetG_3x3, PatchD_3x_SN
from models.vit import ViTEncoderDecoder
from models.repaint import UNetModel, RePaintDiffusion
from models.cvae import ConditionalVAE3x3_32


from models.unet import UNet33Res
from models.unet import UNet33ResAtt
from models.lama import LamaUNet33Res   # <--- NEW

from engines.trainer_unet import UNetTrainer
from engines.trainer_lama import LamaTrainer

from models.cvae_unet import ConditionalUNetVAE

from engines.trainer_gan import TrainerGAN
from engines.trainer_vit import ViTTrainer
from engines.trainer_repaint import RePaintTrainer
from engines.trainer_cvae import CVAETrainer
from engines.trainer_cvae_unet import CVAEUNetTrainer
from models.geom import GeometricBaselineNet
from engines.trainer_geom import GeomRunner
from engines.trainer_imagegpt import ImageGPTTrainer
from models.imagegpt_local import GPTConfig, ImageGPTLocalWrapper
from models.lstm_local import LSTMRowModel
from engines.trainer_lstm import LSTMTrainer




# optional evaluator
try:
    from engines.evaluator import evaluate
except Exception:
    evaluate = None


# -----------------------
# Helpers for YAML config
# -----------------------
def _dict_to_ns(d):
    if isinstance(d, dict):
        return SN(**{k: _dict_to_ns(v) for k, v in d.items()})
    elif isinstance(d, list):
        return [_dict_to_ns(v) for v in d]
    return d


def load_yaml_ns(path):
    if not path or not os.path.exists(path):
        return SN()
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return _dict_to_ns(data)

def attach_default_paths(cfg: SN, model_name: str, base_out: str = "outputs") -> SN:
    if not hasattr(cfg, "paths"):
        cfg.paths = SN()
    root = getattr(cfg.paths, "save_dir", base_out)
    run_dir = os.path.join(root, model_name)

    cfg.paths.root = run_dir
    cfg.paths.checkpoints = os.path.join(run_dir, "checkpoints")

    # NEW: split images vs metrics
    cfg.paths.visual_results = os.path.join(run_dir, "visual_results")  # /train, /val, /test
    cfg.paths.metric_results = os.path.join(run_dir, "metric_results")  # /train, /val, /test

    # make dirs we’ll use during training time
    os.makedirs(cfg.paths.checkpoints, exist_ok=True)
    os.makedirs(os.path.join(cfg.paths.visual_results, "train"), exist_ok=True)
    os.makedirs(os.path.join(cfg.paths.metric_results, "train"), exist_ok=True)
    os.makedirs(os.path.join(cfg.paths.metric_results, "test"), exist_ok=True)
    return cfg


# -----------------------
# Data building
# -----------------------
def build_dataloaders(cfg_data):
    ds = getattr(cfg_data, "dataset", SN())
    ld = getattr(cfg_data, "loader", SN())

    train_in = getattr(ds, "train_input", "data/train/input")
    train_out = getattr(ds, "train_output", "data/train/output")
    val_in = getattr(ds, "val_input", None)  # ← Changed default to None
    val_out = getattr(ds, "val_output", None)  # ← Changed default to None
    size = int(getattr(ds, "size", 128))
    bs = int(getattr(ld, "batch_size", 32))
    nw = int(getattr(ld, "num_workers", 4))

    # ---- Training dataset (always required) ----
    train_ds = FixedBoundingBoxDataset(
        input_folder=train_in,
        output_folder=train_out,
        target_size=(size, size),
        margin=10,
        augment= True, #lambda x, y: augment_tensor_pair(x, y, p=0.7),#True,
        wall_thickness=1,
    )

    train_loader = DataLoader(
        train_ds, batch_size=bs, shuffle=True,
        num_workers=nw, pin_memory=True, drop_last=True
    )

    print(f"[Data] Created training loader with {len(train_ds)} samples")

    # ---- Validation dataset (optional) ----
    val_loader = None
    if val_in and val_out:
        # Check if directories exist and are not empty
        if os.path.exists(val_in) and os.path.exists(val_out):
            try:
                val_ds = FixedBoundingBoxDataset(
                    input_folder=val_in,
                    output_folder=val_out,
                    target_size=(size, size),
                    margin=10,
                    augment=False,
                    wall_thickness=1,
                )
                val_loader = DataLoader(
                    val_ds, batch_size=bs, shuffle=False,
                    num_workers=nw, pin_memory=True
                )
                print(f"[Data] Created validation loader with {len(val_ds)} samples")
            except (AssertionError, ValueError) as e:
                print(f"[Data] Warning: Could not create validation loader: {e}")
                print("[Data] Training without validation")
                val_loader = None
        else:
            print(f"[Data] Validation paths not found: {val_in}, {val_out}")
            print("[Data] Training without validation")
    else:
        print("[Data] No validation paths specified - training without validation")

    # Pack back the few values that trainers expect
    data_args = SN(
        train_input=train_in, train_output=train_out,
        val_input=val_in, val_output=val_out,
        size=size, batch_size=bs, num_workers=nw
    )

    return train_loader, val_loader, data_args

def cfg_paths(save_dir, model_name):
    ckpt_dir = os.path.join(save_dir, model_name)
    os.makedirs(ckpt_dir, exist_ok=True)
    return SN(checkpoints=ckpt_dir, results=os.path.join(ckpt_dir, "results"))


# -----------------------
# Model-specific trainers
# -----------------------
def train_gan(model_cfg, data_args, device):
    loss  = getattr(model_cfg, "loss",  SN())
    train = getattr(model_cfg, "train", SN())
    gan   = getattr(model_cfg, "gan",   SN())

    # defaults
    task = getattr(model_cfg, "task", "pix2pix")  # or "seg_gan"
    gan_type = getattr(gan, "type", "hinge")

    # Build cfg object that the existing TrainerGAN expects
    cfg = SN(
        task=task,
        gan=SN(type=gan_type),
        loss=SN(
            # pix2pix
            use_masked_l1=bool(getattr(loss, "use_masked_l1", False)),
            lambda_mask=float(getattr(loss, "lambda_mask", 50.0)),
            lambda_full=float(getattr(loss, "lambda_full", 5.0)),
            lambda_l1=float(getattr(loss, "lambda_l1", 100.0)),
            # seg_gan
            ce_weights=getattr(loss, "ce_weights", None),
            lambda_ce_mask=float(getattr(loss, "lambda_ce_mask", 2.0)),
            lambda_ce_full=float(getattr(loss, "lambda_ce_full", 0.2)),
            lambda_adv=float(getattr(loss, "lambda_adv", 0.05)),
        ),
        train=SN(
            lr_g=float(getattr(train, "lr_g", 2e-4)),
            lr_d=float(getattr(train, "lr_d", 2e-4)),
            epochs=int(getattr(train, "epochs", 100)),
            g_updates=int(getattr(train, "g_updates", 5)),
            scheduler=str(getattr(train, "scheduler", "plateau")),
            # val_interval is optional; TrainerGAN has a default of 100
            val_interval=int(getattr(train, "val_interval", 100)),
        ),
        paths=cfg_paths(getattr(model_cfg.paths, "save_dir", "outputs"), f"{task}_{gan_type}")
    )

    train_loader, val_loader, _ = build_dataloaders(SN(dataset=SN(
        train_input=data_args.train_input,
        train_output=data_args.train_output,
        val_input=data_args.val_input,
        val_output=data_args.val_output,
        size=data_args.size
    ), loader=SN(batch_size=data_args.batch_size, num_workers=data_args.num_workers)))

    # Generator/Discriminator
    if cfg.task == "seg_gan":
        G = UNetG_3x3(in_ch=1, out_ch=3, activation="none")
    else:
        G = UNetG_3x3(in_ch=1, out_ch=1, activation="sigmoid")
    D = PatchD_3x_SN()

    cfg = attach_default_paths(cfg, f"{cfg.task}_{cfg.gan.type}")
    trainer = TrainerGAN(G.to(device), D.to(device), cfg, device)

    # --- NEW: resume from checkpoint (same pattern as CVAE) ---
    ckpt_path = getattr(getattr(model_cfg, "paths", SN()), "checkpoint", None)
    result = None
    if not ckpt_path:
        print("[restore] no checkpoint path provided in config (paths.checkpoint).")
    else:
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")
        result = trainer.restore(ckpt_path, strict=True)
        ok = all((not miss and not unexp) for (miss, unexp) in result["restore_report"].values())
        if not ok:
            print("[restore] warning:", result["restore_report"])
    # ----------------------------------------------------------

    trainer.fit(train_loader=train_loader, val_loader=None, result = result)
    return cfg

def train_vit(model_cfg, data_args, device):
    vit   = getattr(model_cfg, "vit",   SN())
    loss  = getattr(model_cfg, "loss",  SN())
    train = getattr(model_cfg, "train", SN())

    cfg = SN(
        loss=SN(
            type=str(getattr(loss, "type", "smooth_l1")),
            beta=0.1,
        ),
        train=SN(
            lr=float(getattr(train, "lr", 2e-4)),
            weight_decay=float(getattr(train, "weight_decay", 1e-4)),
            epochs=int(getattr(train, "epochs", 100)),
            val_interval=int(getattr(train, "val_interval", 100)),
            # scheduler knobs (same pattern as GAN)
            scheduler=str(getattr(train, "scheduler", "plateau")),  # "plateau" | "cosine" | "none"
            patience=int(getattr(train, "patience", 4)),             # for plateau
            min_lr=float(getattr(train, "min_lr", 1e-6)),            # for plateau/cosine
        ),
        paths=cfg_paths(getattr(model_cfg.paths, "save_dir", "outputs"), "vit")
    )

    train_loader, val_loader, _ = build_dataloaders(SN(dataset=SN(
        train_input=data_args.train_input,
        train_output=data_args.train_output,
        val_input=data_args.val_input,
        val_output=data_args.val_output,
        size=data_args.size
    ), loader=SN(batch_size=data_args.batch_size, num_workers=data_args.num_workers)))

    model = ViTEncoderDecoder(
        image_size=data_args.size,
        patch_size=int(getattr(vit, "patch", 16)),
        embed_dim=int(getattr(vit, "embed", 256)),
        num_heads=int(getattr(vit, "heads", 4)),
        depth=int(getattr(vit, "depth", 3)),
        mlp_dim=int(getattr(vit, "mlp", 512)),
        dropout=0.1,
    ).to(device)

    cfg = attach_default_paths(cfg, "vit")

    from engines.trainer_vit import ViTTrainer
    trainer = ViTTrainer(model, cfg, device)

    # resume from checkpoint if provided (same as CVAE/GAN)
    ckpt_path = getattr(getattr(model_cfg, "paths", SN()), "checkpoint", None)
    result = None
    if not ckpt_path:
        print("[restore] no checkpoint path provided in config (paths.checkpoint).")
    else:
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")
        result = trainer.restore(ckpt_path, strict=True)
        ok = all((not miss and not unexp) for (miss, unexp) in result["restore_report"].values())
        if not ok:
            print("[restore] warning:", result["restore_report"])

    trainer.fit(train_loader, val_loader, result)
    return cfg

def train_repaint(model_cfg, data_args, device):
    from types import SimpleNamespace as SN

    diff  = getattr(model_cfg, "diff",  SN())
    loss  = getattr(model_cfg, "loss",  SN())
    train = getattr(model_cfg, "train", SN())
    mdl   = getattr(model_cfg, "model", SN())

    cfg = SN(
        loss=SN(
            noise_weight=float(getattr(loss, "noise_weight", getattr(loss, "noise_l1", 1.0))),
            masked_l1_weight=float(getattr(loss, "masked_l1_weight", getattr(loss, "masked_x0_l1", 3.0))),
            ssim_weight=float(getattr(loss, "ssim_weight", getattr(loss, "ssim", 2.0))),
        ),
        diff=SN(
            timesteps=int(getattr(diff, "timesteps", 1000)),
            beta_start=float(getattr(diff, "beta_start", 1e-4)),
            beta_end=float(getattr(diff, "beta_end", 0.05)),
        ),
        train=SN(
            lr=float(getattr(train, "lr", 2e-4)),
            epochs=int(getattr(train, "epochs", 1000)),
            val_interval=int(getattr(train, "val_interval", getattr(train, "val_interval", 100))),
            scheduler=str(getattr(train, "scheduler", "plateau")),  # parity with CVAE
            patience=int(getattr(train, "patience", 6)),
            min_lr=float(getattr(train, "min_lr", 1e-6)),
        ),
        model=SN(
            base_channels=int(getattr(mdl, "base_channels", getattr(mdl, "base_ch", 96))),
            time_emb_dim=int(getattr(mdl, "time_emb_dim", getattr(mdl, "time_dim", 128))),
        ),
        paths=cfg_paths(getattr(model_cfg.paths, "save_dir", "outputs"), "repaint"),
        runtime=SN(
            device=str(getattr(getattr(model_cfg, "runtime", SN()), "device", "cuda")),
            seed=int(getattr(getattr(model_cfg, "runtime", SN()), "seed", 42)),
        ),
    )

    # dataloaders (same as CVAE)
    train_loader, val_loader, _ = build_dataloaders(SN(dataset=SN(
        train_input=data_args.train_input,
        train_output=data_args.train_output,
        val_input=data_args.val_input,
        val_output=data_args.val_output,
        size=data_args.size
    ), loader=SN(batch_size=data_args.batch_size, num_workers=data_args.num_workers)))

    # model
    unet = UNetModel(
        in_channels=2,
        base_channels=cfg.model.base_channels,
        time_emb_dim=cfg.model.time_emb_dim,
    ).to(device)

    unet.use_checkpoint = bool(getattr(getattr(cfg, "model", SN()), "checkpoint", True))

    model = RePaintDiffusion(
        unet_model=unet,
        timesteps=cfg.diff.timesteps,
        beta_start=cfg.diff.beta_start,
        beta_end=cfg.diff.beta_end,
    ).to(device)

    model.noise_weight = float(cfg.loss.noise_weight)
    model.masked_l1_weight = float(cfg.loss.masked_l1_weight)
    model.ssim_weight = float(cfg.loss.ssim_weight)

    cfg = attach_default_paths(cfg, "repaint")

    trainer = RePaintTrainer(model, cfg, device)

    # optional resume (same as CVAE)
    ckpt_path = getattr(getattr(model_cfg, "paths", SN()), "checkpoint", None)
    result = None
    if ckpt_path:
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")
        result = trainer.restore(ckpt_path, strict=True)
        ok = all((not miss and not unexp) for (miss, unexp) in result["restore_report"].values())
        if not ok:
            print("[restore] warning:", result["restore_report"])

    trainer.fit(train_loader, val_loader, result=result)
    return cfg


def train_cvae(model_cfg, data_args, device):
    loss  = getattr(model_cfg, "loss",  SN())
    train = getattr(model_cfg, "train", SN())
    mdl   = getattr(model_cfg, "model", SN())

    cfg = SN(
        loss=SN(
            type=str(getattr(loss, "type", "mse")),   # "mse" | "bce_logits"
            beta=float(getattr(loss, "beta", 0.5)),
        ),
        train=SN(
            lr=float(getattr(train, "lr", 1e-4)),
            epochs=int(getattr(train, "epochs", 100)),
            val_interval=int(getattr(train, "val_interval", 100)),
            # --- NEW: scheduler options ---
            scheduler=str(getattr(train, "scheduler", "plateau")),  # "plateau" | "cosine" | "none"
            patience=int(getattr(train, "patience", 4)),            # only for plateau
            min_lr=float(getattr(train, "min_lr", 1e-6)),           # plateau/cosine
            input=str(getattr(train, "input", "complete")),
        ),
        model=SN(
            in_ch=int(getattr(mdl, "in_ch", 1)),
            base_ch=int(getattr(mdl, "base_ch", 32)),
            latent_dim=int(getattr(mdl, "latent_dim", 32)),
            image_size=int(getattr(mdl, "image_size", 128)),
            num_layers=int(getattr(mdl, "num_layers", 3)),
        ),
        paths=cfg_paths(getattr(model_cfg.paths, "save_dir", "outputs"), "cvae"),
        runtime=SN(
            device=str(getattr(getattr(model_cfg, "runtime", SN()), "device", "cuda")),
            seed=int(getattr(getattr(model_cfg, "runtime", SN()), "seed", 42)),
        ),
    )

    train_loader, val_loader, _ = build_dataloaders(SN(dataset=SN(
        train_input=data_args.train_input,
        train_output=data_args.train_output,
        val_input=data_args.val_input,
        val_output=data_args.val_output,
        size=data_args.size
    ), loader=SN(batch_size=data_args.batch_size, num_workers=data_args.num_workers)))

    model = ConditionalVAE3x3_32(
        in_ch=cfg.model.in_ch,
        base_ch=cfg.model.base_ch,
        latent_dim=cfg.model.latent_dim,
        image_size=cfg.model.image_size,
        num_layers=cfg.model.num_layers,
    ).to(device)

    cfg = attach_default_paths(cfg, "cvae")

    # scripts/train.py (inside train_cvae)

    trainer = CVAETrainer(model, cfg, device)
    ckpt_path = getattr(getattr(model_cfg, "paths", SN()), "checkpoint", None)
    result = None
    if not ckpt_path:
        print("[restore] no checkpoint path provided in config (paths.checkpoint).")
    else:
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")
        result = trainer.restore(ckpt_path, strict=True)
        ok = all((not miss and not unexp) for (miss, unexp) in result["restore_report"].values())
        if not ok:
            print("[restore] warning:", result["restore_report"])

    trainer.fit(train_loader, val_loader, result)
    return cfg


def train_unet(model_cfg, data_args, device):
    loss  = getattr(model_cfg, "loss",  SN())
    train = getattr(model_cfg, "train", SN())
    mdl   = getattr(model_cfg, "model", SN())

    # ---- pack config (mirrors CVAE style) ----
    cfg = SN(
        loss=SN(
            # CE-only or CE+Dice (matches losses/unet.py)
            type=str(getattr(loss, "type", "ce")),            # "ce" | "ce_dice"
            label_smoothing=float(getattr(loss, "label_smoothing", 0.0)),
            class_weights=getattr(loss, "class_weights", None),
            dice_weight=float(getattr(loss, "dice_weight", 0.5)),
            ignore_index=int(getattr(loss, "ignore_index", 255)),
            ignore_unknown=bool(getattr(loss, "ignore_unknown", False)),
        ),
        train=SN(
            lr=float(getattr(train, "lr", 2e-4)),
            epochs=int(getattr(train, "epochs", 1000)),
            val_interval=int(getattr(train, "val_interval", 100)),
            scheduler=str(getattr(train, "scheduler", "plateau")),  # "plateau" | "cosine" | "none"
            patience=int(getattr(train, "patience", 6)),
            min_lr=float(getattr(train, "min_lr", 1e-6)),
        ),
        model=SN(
            in_ch=int(getattr(mdl, "in_ch", 1)),
            out_ch=int(getattr(mdl, "out_ch", 3)),            # 3 logits for 3 classes
            base_ch=int(getattr(mdl, "base_ch", 96)),
            num_layers=int(getattr(mdl, "num_layers", 3)),    # encoder/decoder depth
            residual=bool(getattr(mdl, "residual", True)),    # enable residual blocks
            image_size=int(getattr(mdl, "image_size", 128)),  # kept for parity, not used by U-Net
            dropout=float(getattr(mdl, "dropout", 0.0)),
        ),
        paths=cfg_paths(getattr(model_cfg.paths, "save_dir", "outputs"), "unet"),
        runtime=SN(
            device=str(getattr(getattr(model_cfg, "runtime", SN()), "device", "cuda")),
            seed=int(getattr(getattr(model_cfg, "runtime", SN()), "seed", 42)),
        ),
    )

    # ---- dataloaders (same as CVAE) ----
    train_loader, val_loader, _ = build_dataloaders(SN(dataset=SN(
        train_input=data_args.train_input,
        train_output=data_args.train_output,
        val_input=data_args.val_input,
        val_output=data_args.val_output,
        size=data_args.size
    ), loader=SN(batch_size=data_args.batch_size, num_workers=data_args.num_workers)))

    # ---- model ----
    # scripts/train.py  (in train_unet)
    # ...
    loss_type = str(getattr(loss, "type", "ce")).lower()
    final_act = "none" if loss_type == "ce" else "sigmoid"

    if loss_type == "ce":
        assert cfg.model.out_ch == 3, "CE needs out_ch=3"
    else:
        assert cfg.model.out_ch == 1, "L1 needs out_ch=1"

    model = UNet33Res(
        in_ch=cfg.model.in_ch,
        out_ch=cfg.model.out_ch,  # keep 3 for CE per your YAML
        base=cfg.model.base_ch,
        dropout=cfg.model.dropout,
        final_activation=final_act,  # <-- important
    ).to(device)

    # ensure standard output directory scaffold exists
    cfg = attach_default_paths(cfg, "unet")

    # ---- trainer ----
    trainer = UNetTrainer(model, cfg, device)

    # ---- optional restore ----
    ckpt_path = getattr(getattr(model_cfg, "paths", SN()), "checkpoint", None)
    result = None
    if ckpt_path:
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")
        result = trainer.restore(ckpt_path, strict=True)

        # optional sanity report (missing/unexpected keys)
        ok = all((not miss and not unexp) for (miss, unexp) in result["restore_report"].values())
        if not ok:
            print("[restore] warning:", result["restore_report"])

    # ---- train (single call; resume-aware) ----
    trainer.fit(train_loader, val_loader, result=result)
    return cfg

def train_unet_attention(model_cfg, data_args, device):
    loss  = getattr(model_cfg, "loss",  SN())
    train = getattr(model_cfg, "train", SN())
    mdl   = getattr(model_cfg, "model", SN())

    # ---- pack config (mirrors CVAE style) ----
    cfg = SN(
        loss=SN(
            # CE-only or CE+Dice (matches losses/unet.py)
            type=str(getattr(loss, "type", "ce")),            # "ce" | "ce_dice"
            label_smoothing=float(getattr(loss, "label_smoothing", 0.0)),
            class_weights=getattr(loss, "class_weights", None),
            dice_weight=float(getattr(loss, "dice_weight", 0.5)),
            ignore_index=int(getattr(loss, "ignore_index", 255)),
            ignore_unknown=bool(getattr(loss, "ignore_unknown", False)),
        ),
        train=SN(
            lr=float(getattr(train, "lr", 2e-4)),
            epochs=int(getattr(train, "epochs", 1000)),
            val_interval=int(getattr(train, "val_interval", 100)),
            scheduler=str(getattr(train, "scheduler", "plateau")),  # "plateau" | "cosine" | "none"
            patience=int(getattr(train, "patience", 6)),
            min_lr=float(getattr(train, "min_lr", 1e-6)),
        ),
        model=SN(
            in_ch=int(getattr(mdl, "in_ch", 1)),
            out_ch=int(getattr(mdl, "out_ch", 3)),            # 3 logits for 3 classes
            base_ch=int(getattr(mdl, "base_ch", 96)),
            num_layers=int(getattr(mdl, "num_layers", 3)),    # encoder/decoder depth
            residual=bool(getattr(mdl, "residual", True)),    # enable residual blocks
            image_size=int(getattr(mdl, "image_size", 128)),  # kept for parity, not used by U-Net
            dropout=float(getattr(mdl, "dropout", 0.0)),
        ),
        paths=cfg_paths(getattr(model_cfg.paths, "save_dir", "outputs"), "unet_attention"),
        runtime=SN(
            device=str(getattr(getattr(model_cfg, "runtime", SN()), "device", "cuda")),
            seed=int(getattr(getattr(model_cfg, "runtime", SN()), "seed", 42)),
        ),
    )

    # ---- dataloaders (same as CVAE) ----
    train_loader, val_loader, _ = build_dataloaders(SN(dataset=SN(
        train_input=data_args.train_input,
        train_output=data_args.train_output,
        val_input=data_args.val_input,
        val_output=data_args.val_output,
        size=data_args.size
    ), loader=SN(batch_size=data_args.batch_size, num_workers=data_args.num_workers)))

    # ---- model ----
    # scripts/train.py  (in train_unet_attention)
    # ...
    loss_type = str(getattr(loss, "type", "ce")).lower()
    final_act = "none" if loss_type == "ce" else "sigmoid"

    if loss_type == "ce":
        assert cfg.model.out_ch == 3, "CE needs out_ch=3"
    else:
        assert cfg.model.out_ch == 1, "L1 needs out_ch=1"

    model = UNet33ResAtt(
        in_ch=cfg.model.in_ch,
        out_ch=cfg.model.out_ch,
        base=cfg.model.base_ch,
        dropout=cfg.model.dropout,
        final_activation=final_act,
    ).to(device)

    # ensure standard output directory scaffold exists
    cfg = attach_default_paths(cfg, "unet_attention")

    # ---- trainer ----
    trainer = UNetTrainer(model, cfg, device)

    # ---- optional restore ----
    ckpt_path = getattr(getattr(model_cfg, "paths", SN()), "checkpoint", None)
    result = None
    if ckpt_path:
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")
        result = trainer.restore(ckpt_path, strict=True)

        # optional sanity report (missing/unexpected keys)
        ok = all((not miss and not unexp) for (miss, unexp) in result["restore_report"].values())
        if not ok:
            print("[restore] warning:", result["restore_report"])

    # ---- train (single call; resume-aware) ----
    trainer.fit(train_loader, val_loader, result=result)
    return cfg

def train_imagegpt_local(model_cfg, data_args, device):
    loss  = getattr(model_cfg, "loss",  SN())
    train = getattr(model_cfg, "train", SN())
    mdl   = getattr(model_cfg, "model", SN())

    # ---- pack config (same style as UNet / LaMa) ----
    cfg = SN(
        loss=SN(
            # CE-only (recommended) or CE+Dice (if you want)
            type=str(getattr(loss, "type", "ce")),            # "ce" | "ce_dice"
            label_smoothing=float(getattr(loss, "label_smoothing", 0.0)),
            class_weights=getattr(loss, "class_weights", None),
            dice_weight=float(getattr(loss, "dice_weight", 0.5)),
            ignore_index=int(getattr(loss, "ignore_index", 255)),
            ignore_unknown=bool(getattr(loss, "ignore_unknown", False)),
        ),
        train=SN(
            lr=float(getattr(train, "lr", 2e-4)),
            epochs=int(getattr(train, "epochs", 1000)),
            val_interval=int(getattr(train, "val_interval", 100)),
            scheduler=str(getattr(train, "scheduler", "plateau")),  # "plateau" | "cosine" | "none"
            patience=int(getattr(train, "patience", 6)),
            min_lr=float(getattr(train, "min_lr", 1e-6)),
        ),
        model=SN(
            # for compatibility with other code paths
            in_ch=int(getattr(mdl, "in_ch", 1)),
            out_ch=int(getattr(mdl, "out_ch", 3)),            # 3 logits for 3 classes
            # GPT-specific options are read directly from mdl below
        ),
        paths=cfg_paths(getattr(model_cfg.paths, "save_dir", "outputs"), "imagegpt_local"),
        runtime=SN(
            device=str(getattr(getattr(model_cfg, "runtime", SN()), "device", "cuda")),
            seed=int(getattr(getattr(model_cfg, "runtime", SN()), "seed", 42)),
        ),
    )

    # ---- dataloaders (same as UNet / LaMa) ----
    train_loader, val_loader, _ = build_dataloaders(
        SN(
            dataset=SN(
                train_input=data_args.train_input,
                train_output=data_args.train_output,
                val_input=data_args.val_input,
                val_output=data_args.val_output,
                size=data_args.size,
            ),
            loader=SN(
                batch_size=data_args.batch_size,
                num_workers=data_args.num_workers,
            ),
        )
    )

    # ---- model ----
    loss_type = str(getattr(loss, "type", "ce")).lower()
    if loss_type != "ce":
        raise ValueError("ImageGPTLocal currently assumes CE-style training (loss.type='ce')")

    # build GPT config from YAML fields (with safe defaults)
    gpt_cfg = GPTConfig(
        vocab_size=int(getattr(mdl, "vocab_size", 3)),
        n_positions=int(getattr(mdl, "n_positions", 32 * 32)),
        n_layer=int(getattr(mdl, "n_layer", 6)),
        n_head=int(getattr(mdl, "n_head", 4)),
        n_embd=int(getattr(mdl, "n_embd", 128)),
        dropout=float(getattr(mdl, "dropout", 0.1)),
    )

    model = ImageGPTLocalWrapper(gpt_cfg).to(device)

    # ensure standard output directory scaffold exists
    cfg = attach_default_paths(cfg, "imagegpt_local")

    # ---- trainer (reuse UNetTrainer, ImageGPTLocalWrapper matches its interface) ----
    trainer = UNetTrainer(model, cfg, device)

    # ---- optional restore from checkpoint ----
    ckpt_path = getattr(getattr(model_cfg, "paths", SN()), "checkpoint", None)
    result = None
    if ckpt_path:
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")
        result = trainer.restore(ckpt_path, strict=True)

        # optional sanity report (missing/unexpected keys)
        ok = all(
            (not miss and not unexp)
            for (miss, unexp) in result["restore_report"].values()
        )
        if not ok:
            print("[restore] warning:", result["restore_report"])

    # ---- train (single call; resume-aware) ----
    trainer.fit(train_loader, val_loader, result=result)
    return cfg

def train_lstm_local(model_cfg, data_args, device):
    from types import SimpleNamespace as SN

    loss  = getattr(model_cfg, "loss",  SN())
    train = getattr(model_cfg, "train", SN())
    mdl   = getattr(model_cfg, "model", SN())
    pcfg  = getattr(model_cfg, "paths", SN())

    # ---- build cfg for LSTMTrainer ----
    cfg = SN(
        loss=SN(
            type=str(getattr(loss, "type", "ce")),
            label_smoothing=float(getattr(loss, "label_smoothing", 0.0)),
            dice_weight=float(getattr(loss, "dice_weight", 0.5)),
            ignore_unknown=bool(getattr(loss, "ignore_unknown", False)),
            ignore_index=int(getattr(loss, "ignore_index", 255)),
            use_dynamic_class_weights=bool(getattr(loss, "use_dynamic_class_weights", True)),
            class_weights=getattr(loss, "class_weights", None),
        ),
        train=SN(
            lr=float(getattr(train, "lr", 1.0e-3)),
            epochs=int(getattr(train, "epochs", 1000)),
            val_interval=int(getattr(train, "val_interval", 100)),
            scheduler=str(getattr(train, "scheduler", "plateau")),  # "plateau" | "cosine" | "none"
            patience=int(getattr(train, "patience", 4)),
            min_lr=float(getattr(train, "min_lr", 1e-6)),
        ),
        model=SN(
            in_ch=int(getattr(mdl, "in_ch", 1)),
            out_ch=int(getattr(mdl, "out_ch", 3)),
            hidden_size=int(getattr(mdl, "hidden_size", 64)),
            num_layers=int(getattr(mdl, "num_layers", 2)),
            dropout=float(getattr(mdl, "dropout", 0.1)),
        ),
        paths=cfg_paths(getattr(pcfg, "save_dir", "outputs"), "lstm_local"),
    )

    # ---- dataloaders (same pattern as ViT/Repaint) ----
    train_loader, val_loader, _ = build_dataloaders(
        SN(
            dataset=SN(
                train_input=data_args.train_input,
                train_output=data_args.train_output,
                val_input=data_args.val_input,
                val_output=data_args.val_output,
                size=data_args.size,
            ),
            loader=SN(
                batch_size=data_args.batch_size,
                num_workers=data_args.num_workers,
            ),
        )
    )

    # ---- model ----
    model = LSTMRowModel(
        hidden_size=cfg.model.hidden_size,
        num_layers=cfg.model.num_layers,
        dropout=cfg.model.dropout,
    ).to(device)

    # add metric/visual/checkpoint dirs
    cfg = attach_default_paths(cfg, "lstm_local")

    # ---- trainer ----
    trainer = LSTMTrainer(model, cfg, device)

    # ---- optional resume from checkpoint ----
    ckpt_path = getattr(getattr(model_cfg, "paths", SN()), "checkpoint", None)
    result = None
    if not ckpt_path:
        print("[restore] no checkpoint path provided in config (paths.checkpoint).")
    else:
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")
        result = trainer.restore(ckpt_path, strict=True)
        ok = all((not miss and not unexp) for (miss, unexp) in result["restore_report"].values())
        if not ok:
            print("[restore] warning:", result["restore_report"])

    # ---- train ----
    trainer.fit(train_loader, val_loader, result=result)
    return cfg

def train_lama(model_cfg, data_args, device):
    loss  = getattr(model_cfg, "loss",  SN())
    train = getattr(model_cfg, "train", SN())
    mdl   = getattr(model_cfg, "model", SN())

    cfg = SN(
        loss=SN(
            type=str(getattr(loss, "type", "ce")),
            label_smoothing=float(getattr(loss, "label_smoothing", 0.0)),
            class_weights=getattr(loss, "class_weights", None),
            dice_weight=float(getattr(loss, "dice_weight", 0.5)),
            ignore_index=int(getattr(loss, "ignore_index", 255)),
            ignore_unknown=bool(getattr(loss, "ignore_unknown", False)),
            use_dynamic_class_weights=bool(getattr(loss, "use_dynamic_class_weights", True)),
        ),
        train=SN(
            lr=float(getattr(train, "lr", 2e-4)),
            epochs=int(getattr(train, "epochs", 1000)),
            val_interval=int(getattr(train, "val_interval", 100)),
            scheduler=str(getattr(train, "scheduler", "plateau")),
            patience=int(getattr(train, "patience", 6)),
            min_lr=float(getattr(train, "min_lr", 1e-6)),
        ),
        model=SN(
            in_ch=int(getattr(mdl, "in_ch", 1)),
            out_ch=int(getattr(mdl, "out_ch", 3)),
            base_ch=int(getattr(mdl, "base_ch", 96)),
            num_layers=int(getattr(mdl, "num_layers", 3)),
            residual=bool(getattr(mdl, "residual", True)),
            image_size=int(getattr(mdl, "image_size", 128)),
            dropout=float(getattr(mdl, "dropout", 0.0)),
        ),
        paths=cfg_paths(getattr(model_cfg.paths, "save_dir", "outputs"), "lama"),
        runtime=SN(
            device=str(getattr(getattr(model_cfg, "runtime", SN()), "device", "cuda")),
            seed=int(getattr(getattr(model_cfg, "runtime", SN()), "seed", 42)),
        ),
    )

    # dataloaders
    train_loader, val_loader, _ = build_dataloaders(SN(dataset=SN(
        train_input=data_args.train_input,
        train_output=data_args.train_output,
        val_input=data_args.val_input,
        val_output=data_args.val_output,
        size=data_args.size,
    ), loader=SN(batch_size=data_args.batch_size, num_workers=data_args.num_workers)))

    # model
    loss_type = str(getattr(loss, "type", "ce")).lower()
    final_act = "none" if loss_type == "ce" else "sigmoid"

    if loss_type == "ce":
        assert cfg.model.out_ch == 3, "CE needs out_ch=3"
    else:
        assert cfg.model.out_ch == 1, "L1 needs out_ch=1"

    model = LamaUNet33Res(
        in_ch=cfg.model.in_ch,
        out_ch=cfg.model.out_ch,
        base=cfg.model.base_ch,
        dropout=cfg.model.dropout,
        final_activation=final_act,
    ).to(device)

    cfg = attach_default_paths(cfg, "lama")

    trainer = LamaTrainer(model, cfg, device)

    ckpt_path = getattr(getattr(model_cfg, "paths", SN()), "checkpoint", None)
    result = None
    if ckpt_path:
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")
        result = trainer.restore(ckpt_path, strict=True)
        ok = all((not miss and not unexp) for (miss, unexp) in result["restore_report"].values())
        if not ok:
            print("[restore] warning:", result["restore_report"])

    trainer.fit(train_loader, val_loader, result=result)
    return cfg

def train_cvae_unet(model_cfg, data_args, device):
    loss  = getattr(model_cfg, "loss",  SN())
    train = getattr(model_cfg, "train", SN())
    mdl   = getattr(model_cfg, "model", SN())

    # ---- pack config (CVAE-UNet style) ----
    cfg = SN(
        loss=SN(
            type=str(getattr(loss, "type", "mse")).lower(),  # "mse" | "bce_logits"
            beta=float(getattr(loss, "beta", 1.0)),
        ),
        train=SN(
            lr=float(getattr(train, "lr", 2e-4)),
            epochs=int(getattr(train, "epochs", 1000)),
            val_interval=int(getattr(train, "val_interval", 100)),
            scheduler=str(getattr(train, "scheduler", "plateau")),  # "plateau" | "cosine" | "none"
            patience=int(getattr(train, "patience", 6)),
            min_lr=float(getattr(train, "min_lr", 1e-6)),
        ),
        model=SN(
            in_ch=int(getattr(mdl, "in_ch", 1)),
            out_ch=int(getattr(mdl, "out_ch", 1)),          # logits channel(s); usually 1 for BCE/MSE
            base=int(getattr(mdl, "base_ch", 64)),          # base channel width for UNet body
            latent_dim=int(getattr(mdl, "latent_dim", 32)), # VAE latent size
        ),
        paths=cfg_paths(getattr(model_cfg.paths, "save_dir", "outputs"), "cvae_unet"),
        runtime=SN(
            device=str(getattr(getattr(model_cfg, "runtime", SN()), "device", "cuda")),
            seed=int(getattr(getattr(model_cfg, "runtime", SN()), "seed", 42)),
        ),
    )

    # ---- dataloaders (same API as your UNet/CVAE) ----
    train_loader, val_loader, _ = build_dataloaders(SN(dataset=SN(
        train_input=data_args.train_input,
        train_output=data_args.train_output,
        val_input=data_args.val_input,
        val_output=data_args.val_output,
        size=data_args.size
    ), loader=SN(batch_size=data_args.batch_size, num_workers=data_args.num_workers)))

    # ---- model ----
    # ConditionalUNetVAE outputs *logits*; loss handles sigmoid internally when needed.
    if cfg.loss.type not in ("mse", "bce_logits", "ce_logits"):
        raise ValueError("cfg.loss.type must be 'mse' or 'bce_logits'")
    if cfg.loss.type == "bce_logits":
        assert cfg.model.out_ch == 1
    elif cfg.loss.type == "ce_logits":
        assert cfg.model.out_ch == 3

    model = ConditionalUNetVAE(
        in_ch=cfg.model.in_ch,
        out_ch=cfg.model.out_ch,
        base=cfg.model.base,
        latent_dim=cfg.model.latent_dim,
    ).to(device)

    # ensure standard output directory scaffold exists
    cfg = attach_default_paths(cfg, "cvae_unet")

    # ---- trainer ----
    trainer = CVAEUNetTrainer(model, cfg, device)

    # ---- optional restore ----
    ckpt_path = getattr(getattr(model_cfg, "paths", SN()), "checkpoint", None)
    result = None
    if ckpt_path:
        if not os.path.exists(ckpt_path):
            raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")
        result = trainer.restore(ckpt_path, strict=True)

        ok = all((not miss and not unexp) for (miss, unexp) in result["restore_report"].values())
        if not ok:
            print("[restore] warning:", result["restore_report"])

    # ---- train (single call; resume-aware) ----
    trainer.fit(train_loader, val_loader, result=result)
    return cfg


def train_geom(model_cfg, data_args, device):
    # Shorthands
    mcfg   = getattr(model_cfg, "model",   SN())
    pcfg   = getattr(model_cfg, "paths",   SN())
    pcfg   = getattr(model_cfg, "paths",   SN())
    rcfg   = getattr(model_cfg, "runtime", SN())

    # Back-compat: if legacy door_kernel is present and door_min_width not set,
    # treat it as the door_min_width.
    legacy_door_min = int(getattr(mcfg, "door_kernel", 0)) or None

    cfg = SN(
        model=SN(
            # existing
            method=str(getattr(mcfg, "method", "guide")),
            max_fill=int(getattr(mcfg, "max_fill", 30)),
            verbose=bool(getattr(mcfg, "verbose", False)),

            # newly surfaced fields
            wall_value=int(getattr(mcfg, "wall_value", 0)),
            wall_thickness=int(getattr(mcfg, "wall_thickness", 1)),
            clamp_border=bool(getattr(mcfg, "clamp_border", True)),

            # door & guide tuning
            door_space=str(getattr(mcfg, "door_space", "both")),
            door_min_width=int(getattr(mcfg, "door_min_width", legacy_door_min if legacy_door_min is not None else 2)),
            door_max_width=int(getattr(mcfg, "door_max_width", 14)),
            door_space_min_frac=float(getattr(mcfg, "door_space_min_frac", 0.60)),
            paint_guides_as_walls=bool(getattr(mcfg, "paint_guides_as_walls", True)),

            # debug
            debug=bool(getattr(mcfg, "debug", True)),
            debug_dir=str(getattr(mcfg, "debug_dir", "outputs/geom/debug")),
            debug_limit=int(getattr(mcfg, "debug_limit", 60)),
        ),
        paths=cfg_paths(getattr(pcfg, "save_dir", "outputs"), "geom"),
        runtime=SN(
            device=str(getattr(rcfg, "device", "cpu")),
            seed=int(getattr(rcfg, "seed", 42)),
        ),
    )

    # dataloaders (use your common builder)
    train_loader, val_loader, _ = build_dataloaders(SN(dataset=SN(
        train_input=data_args.train_input,
        train_output=data_args.train_output,
        val_input=data_args.val_input,
        val_output=data_args.val_output,
        size=data_args.size
    ), loader=SN(batch_size=data_args.batch_size, num_workers=data_args.num_workers)))

    cfg = attach_default_paths(cfg, "geom")  # adds visual_results, metric_results, checkpoints, etc.

    runner = GeomRunner(cfg, device=torch.device(cfg.runtime.device))
    runner.fit(train_loader, val_loader)
    return cfg
# -----------------------
# Main
# -----------------------
def main():
    p = argparse.ArgumentParser("YAML-driven trainer")
    p.add_argument("--config_model", type=str, required=True, help="e.g. configs/cgan.yaml")
    p.add_argument("--config_data",  type=str, default="configs/data.yaml")
    p.add_argument("--eval_after", action="store_true")
    # optional overrides
    p.add_argument("--device", type=str, default=None)
    p.add_argument("--seed", type=int, default=None)
    args = p.parse_args()

    model_cfg = load_yaml_ns(args.config_model)
    data_cfg  = load_yaml_ns(args.config_data)

    # runtime defaults + overrides
    if not hasattr(model_cfg, "runtime"):
        model_cfg.runtime = SN()
    if not hasattr(model_cfg, "paths"):
        model_cfg.paths = SN()

    device_str = getattr(model_cfg.runtime, "device", None) or ("cuda" if torch.cuda.is_available() else "cpu")
    if args.device is not None:
        device_str = args.device
    model_cfg.runtime.device = device_str

    seed_val = int(getattr(model_cfg.runtime, "seed", 42))
    if args.seed is not None:
        seed_val = int(args.seed)
    model_cfg.runtime.seed = seed_val

    save_dir = getattr(model_cfg.paths, "save_dir", "outputs")
    model_cfg.paths.save_dir = save_dir

    # pick model name
    model_name = (
        getattr(model_cfg, "name", None)
        or getattr(getattr(model_cfg, "model", SN()), "name", None)
        or getattr(model_cfg, "type", None)
    )
    if not model_name:
        # fallback: guess by present blocks
        for cand in ("cgan", "gan", "pix2pix", "seg_gan", "vit", "repaint", "ddpm", "cvae", "unet", "cvae_unet"):
            if hasattr(model_cfg, cand):
                model_name = cand
                break
    model_name = str(model_name).lower()

    # seed & device
    torch.manual_seed(seed_val)
    if torch.cuda.is_available() and device_str.startswith("cuda"):
        torch.cuda.manual_seed_all(seed_val)
        torch.backends.cudnn.benchmark = True
    device = torch.device(
        device_str if (torch.cuda.is_available() and device_str.startswith("cuda")) or device_str == "cpu"
        else "cpu"
    )

    # build common data args from data YAML
    train_loader, val_loader, data_args = build_dataloaders(data_cfg)  # also validates paths
    # (we will rebuild loaders inside each train_* to conform to their current API;
    #  data_args keeps values consistent.)

    print("device:", device)
    print("model_name:", model_name)

    # dispatch by model
    if model_name in ("cgan", "gan", "pix2pix", "seg_gan"):
        # ensure GAN task consistency
        if model_name == "seg_gan":
            model_cfg.task = "seg_gan"
        cfg = train_gan(model_cfg, data_args, device)
        print_name = f"{cfg.task}_{cfg.gan.type}"
    elif model_name == "vit":
        cfg = train_vit(model_cfg, data_args, device)
        print_name = "vit"
    elif model_name in ("repaint", "ddpm"):
        cfg = train_repaint(model_cfg, data_args, device)
        print_name = "repaint"
    elif model_name == "cvae":
        cfg = train_cvae(model_cfg, data_args, device)
        print_name = "cvae"
    elif model_name == "unet":
        cfg = train_unet(model_cfg, data_args, device)
        print_name = "unet"
    elif model_name == "unet_attention":
        cfg = train_unet_attention(model_cfg, data_args, device)
        print_name = "unet_attention"
    elif model_name == "lama":
        cfg = train_lama(model_cfg, data_args, device)
        print_name = "lama"
    elif model_name == "imagegpt_local":
        cfg = train_imagegpt_local(model_cfg, data_args, device)
        print_name = "imagegpt_local"
    elif model_name == "cvae_unet":
        cfg = train_cvae_unet(model_cfg, data_args, device)
        print_name = "cvae_unet"
    elif model_name == "lstm_local":
        cfg = train_lstm_local(model_cfg, data_args, device)
        print_name = "lstm_local"
    elif model_name == "geom":
        cfg = train_geom(model_cfg, data_args, device)
        print_name = "geom"

    else:
        raise ValueError(f"Unknown model type from YAML: {model_name!r}")

    # optional quick eval
    if args.eval_after and evaluate is not None:
        print("\n[Eval] Running quick evaluation on validation split...")
        # Reuse the already-built val_loader from above if your evaluator accepts it,
        # or rebuild one here. For now, we just print a stub:
        print("[Eval] Skipped (hook up to an evaluator instance if needed).")

    print(f"\n✅ Training finished. Checkpoints in: {cfg.paths.checkpoints}")


if __name__ == "__main__":
    main()

# source .venv/bin/activate

# python -m scripts.train --config_model configs/cgan.yaml --config_data configs/data.yaml --eval_after

# python -m scripts.train --config_model configs/cvae.yaml --config_data configs/data.yaml --eval_after

# python -m scripts.train --config_model configs/vit.yaml --config_data configs/data.yaml --eval_after

# python -m scripts.train --config_model configs/repaint.yaml --config_data configs/data.yaml --eval_after

# python -m scripts.train --config_model configs/unet.yaml --config_data configs/data.yaml --eval_after

# python -m scripts.train --config_model configs/cvae_unet.yaml --config_data configs/data.yaml --eval_after

# python -m scripts.train --config_model configs/geom.yaml --config_data configs/data.yaml --eval_after

# python -m scripts.train --config_model configs/lama.yaml --config_data configs/data.yaml --eval_after

# python -m scripts.train --config_model configs/unet_attention.yaml --config_data configs/data.yaml --eval_after
# python -m scripts.train --config_model configs/imagegpt_local.yaml --config_data configs/data.yaml --eval_after



# Elapsed time for 1 training epoch for
# cgan: 31.90s
# cvae:  9.81s
# vit: 2.53s
# repaint: 51.82s
# unet: 64.11s

