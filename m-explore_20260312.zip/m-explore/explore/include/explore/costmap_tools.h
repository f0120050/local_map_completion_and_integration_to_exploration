#ifndef COSTMAP_TOOLS_H_
#define COSTMAP_TOOLS_H_

#include <costmap_2d/costmap_2d.h>
#include <geometry_msgs/PointStamped.h>
#include <geometry_msgs/PolygonStamped.h>
#include <ros/ros.h>
#include <queue>
#include <vector>
#include <algorithm>
#include <cmath>   // or <cstdlib>

// NOTE: Callers should hold *costmap.getMutex()* while using nhood*/nearestCell
// if the costmap can be updated from other threads.

namespace frontier_exploration
{

inline std::vector<unsigned int> nhood4(unsigned int idx,
                                        const costmap_2d::Costmap2D& costmap)
{
  std::vector<unsigned int> out;
  unsigned int size_x = costmap.getSizeInCellsX();
  unsigned int size_y = costmap.getSizeInCellsY();

  if (idx >= size_x * size_y) {
    ROS_WARN("Evaluating nhood for offmap point");
    return out;
  }

  if (idx % size_x > 0) out.push_back(idx - 1);
  if (idx % size_x < size_x - 1) out.push_back(idx + 1);
  if (idx >= size_x) out.push_back(idx - size_x);
  if (idx < size_x * (size_y - 1)) out.push_back(idx + size_x);

  return out;
}

inline std::vector<unsigned int> nhood8(unsigned int idx,
                                        const costmap_2d::Costmap2D& costmap)
{
  std::vector<unsigned int> out = nhood4(idx, costmap);
  unsigned int size_x = costmap.getSizeInCellsX();
  unsigned int size_y = costmap.getSizeInCellsY();

  if (idx >= size_x * size_y) {
    return out;
  }

  if (idx % size_x > 0 && idx >= size_x) out.push_back(idx - 1 - size_x);
  if (idx % size_x > 0 && idx < size_x * (size_y - 1)) out.push_back(idx - 1 + size_x);
  if (idx % size_x < size_x - 1 && idx >= size_x) out.push_back(idx + 1 - size_x);
  if (idx % size_x < size_x - 1 && idx < size_x * (size_y - 1)) out.push_back(idx + 1 + size_x);

  return out;
}

/**
 * @brief Find nearest cell of a specified value using BFS
 * @param result Index of located cell
 * @param start Index initial cell to search from
 * @param val Specified value to search for
 * @param costmap Reference to map data
 * @param max_radius (optional) maximum search radius in cells (Chebyshev distance). 
 *        If <= 0, search the whole map.
 * @return True if a cell with the requested value was found
 */
inline bool nearestCell(unsigned int& result, unsigned int start, unsigned char val,
                        const costmap_2d::Costmap2D& costmap, int max_radius = -1)
{
  const unsigned char* map = costmap.getCharMap();
  const unsigned int size_x = costmap.getSizeInCellsX();
  const unsigned int size_y = costmap.getSizeInCellsY();
  const unsigned int total_size = size_x * size_y;

  if (start >= total_size) {
    return false;
  }

  // Early return if start already matches
  if (map[start] == val) {
    result = start;
    return true;
  }

  // Get (x,y) of the starting cell
  unsigned int start_x = start % size_x;
  unsigned int start_y = start / size_x;

  std::queue<unsigned int> bfs;
  bfs.push(start);

  std::vector<uint8_t> visited(total_size, 0);
  visited[start] = 1;

  while (!bfs.empty()) {
    unsigned int idx = bfs.front();
    bfs.pop();

    unsigned int x = idx % size_x;
    unsigned int y = idx / size_x;

    // Check radius limit
    if (max_radius > 0) {
      int dx = std::abs((int)x - (int)start_x);
      int dy = std::abs((int)y - (int)start_y);
      if (std::max(dx, dy) > max_radius) {
        continue;  // don't expand further
      }
    }

    for (unsigned int nbr : nhood8(idx, costmap)) {
      if (!visited[nbr]) {
        if (map[nbr] == val) {
          result = nbr;
          return true;
        }
        visited[nbr] = 1;
        bfs.push(nbr);
      }
    }
  }
  return false;
}

}  // namespace frontier_exploration

#endif
