#ifndef DISTANCE_CALCULATOR_H_
#define DISTANCE_CALCULATOR_H_

#include <ros/ros.h>
#include <nav_msgs/GetPlan.h>
#include <costmap_2d/costmap_2d.h>

#include <string>
#include <utility>
#include <vector>
#include <limits>

#include <opencv2/core.hpp>

namespace frontier_exploration
{

/**
 * @brief Distance calculator for Euclidean/graph distances and multi-goal search
 *        over a costmap (Dijkstra, A*, and A* with completion heuristic).
 *
 * Thread-safety: call graph-search routines while holding the costmap mutex
 * (the .cpp acquires it internally for the multi-goal methods and distance-field).
 */
class DistanceCalculator {
public:
  explicit DistanceCalculator(ros::NodeHandle nh = ros::NodeHandle("~"))
  : nh_(nh) {}

  // --- Wiring / config ---
  void setCostmap(costmap_2d::Costmap2D* cm) { cm_ = cm; }
  void setGlobalFrame(const std::string& frame) { global_frame_ = frame; }
  void initMakePlanClient();  // lazily (re)initializes /make_plan client

  // --- Simple distance metrics (meters) ---
  double euclideanDistance(double x1, double y1, double x2, double y2);
  double manhattanDistance(double x1, double y1, double x2, double y2);
  double chebyshevDistance(double x1, double y1, double x2, double y2);
  double squaredEuclideanDistance(double x1, double y1, double x2, double y2);

  // --- Global planner service distance (meters) ---
  double computeDistanceUsingMakePlan(double sx, double sy, double gx, double gy);
  double computeDistanceUsingMakePlanSafe(double sx, double sy, double gx, double gy);

  // --- Multi-goal graph search on the costmap (distances returned in cells unless noted) ---
  void multiGoalDijkstra(int sx, int sy,
                         const std::vector<std::pair<int,int>>& goals_xy,
                         std::vector<double>& out_dist,
                         bool allow_unknown=false);

  // Weighted A* (octile heuristic). w=1 → optimal A*, w>1 → Weighted A*
  void multiGoalAstar(int sx, int sy,
                      const std::vector<std::pair<int,int>>& goals_xy,
                      std::vector<double>& out_dist,
                      bool allow_unknown=false,
                      double w=1.0);

  // A* with completion heuristic (distances returned in *meters*)
  void multiGoalAstarCompletionHeuristic(
      int sx, int sy,
      const std::vector<std::pair<int,int>>& goals_xy,
      std::vector<double>& out_dist,
      bool allow_unknown,
      double w,
      const cv::Mat& gt_map_aligned,  // CV_8UC1, 0/205/254, aligned to costmap grid
      int patch,                       // square patch side length (cells)
      double meters_per_cell,
      double bias_k,
      double free_weight,
      double obst_weight
    );

  // --- Pre-flight in-process reachability check (cells) ---
  bool preflightAstarReachable(int sx, int sy, int gx, int gy,
                               bool allow_unknown,
                               int max_expansions = 30000,
                               int max_runtime_ms = 60,
                               int goal_tol = 1);

  // --- Cached distance-field (cells from a fixed start) ---
  void ensureDistanceField(int sx, int sy, bool allow_unknown=false);
  void ensureDistanceFieldOptimized(int sx, int sy, bool allow_unknown, double max_distance);

  // Lookup (cells) after ensureDistanceField*()
  inline double distToCell(int x, int y) const {
    if (!field_valid_ || !inb(x, y)) {
      return std::numeric_limits<double>::infinity();
    }
    const size_t idx = static_cast<size_t>(y * field_cols_ + x);
    if (idx >= dist_field_.size()) return std::numeric_limits<double>::infinity();
    return dist_field_[idx];
  }

  inline void invalidateDistanceField() { field_valid_ = false; }

  // Bounds check helper
  inline bool inb(int x, int y) const {
    if (!cm_) return false;
    return x >= 0 && x < static_cast<int>(cm_->getSizeInCellsX()) &&
           y >= 0 && y < static_cast<int>(cm_->getSizeInCellsY());
  }

private:
  // Cell blocked helper (uses costmap semantics; unknown may be allowed)
  inline bool blocked(int x, int y, bool allow_unknown) const;

  bool planningBlocked(int x, int y,bool allow_unknown) const;

  // --- ROS / wiring ---
  ros::NodeHandle nh_;
  std::string makeplan_service_{"/planner_service_node/navfn/make_plan"};
  double makeplan_tolerance_{0.1};
  ros::ServiceClient make_plan_client_;
  costmap_2d::Costmap2D* cm_{nullptr};
  std::string global_frame_{"map"};

  // --- Cached distance-field state ---
  std::vector<double> dist_field_; // size = rows*cols, cells from (sx,sy)
  int  field_start_idx_{-1};
  int  field_cols_{-1}, field_rows_{-1};
  bool field_allow_unknown_{false};
  bool field_valid_{false};
};

} // namespace frontier_exploration

#endif // DISTANCE_CALCULATOR_H_
