#ifndef EXPERIMENT_LOGGER_H_
#define EXPERIMENT_LOGGER_H_

#include <fstream>
#include <string>
#include <geometry_msgs/Point.h>
#include <mutex>  // ADD

namespace explore {
class ExperimentLogger {
public:
  explicit ExperimentLogger(const std::string& filename);
  ~ExperimentLogger();

  void logTarget(const geometry_msgs::Point& target, const std::string& method);
  void logTrajectoryPoint(const geometry_msgs::Point& position, double timestamp);
  void flush();
  // experiment_logger.h içine eklenecek metodlar
  //void logMetrics(double distance_m, double completion_percent, double elapsed_sec);
  // In explore.h or where ExperimentLogger is defined
 void logMetrics(double distance, double completion_percent, double elapsed_time,
                int gt_width, int gt_height, int costmap_width, int costmap_height);
  void logOperation(const std::string& operation_name, double duration_ms, const std::string& info = "");
  void logTargetReached(const geometry_msgs::Point& target, 
                     double travel_time_sec, 
                     double travel_distance_m);

   // Milestone logging - captures completion percentage thresholds
  void logMilestone(int threshold_percent, 
                    double elapsed_sec,
                    double total_distance_m,
                    double measured_completion_percent);
  
  // Experiment lifecycle events
  void logExperimentStart(const std::string& distance_method,
                          const std::string& map_name = "");
  
  void logExperimentEnd(double total_time_sec,
                        double total_distance_m,
                        double final_completion_percent,
                        int frontiers_visited,
                        int navigation_failures = 0);

private:
  std::ofstream file_;
  mutable std::mutex mtx_;   // ADD: guard file_ access
};

} // namespace explore
#endif
