    /*********************************************************************
    *
    * Software License Agreement (BSD License)
    *
    *  Copyright (c) 2008, Robert Bosch LLC.
    *  Copyright (c) 2015-2016, Jiri Horner.
    *  All rights reserved.
    *
    *  Redistribution and use in source and binary forms, with or without
    *  modification, are permitted provided that the following conditions
    *  are met:
    *
    *   * Redistributions of source code must retain the above copyright
    *     notice, this list of conditions and the following disclaimer.
    *   * Redistributions in binary form must reproduce the above
    *     copyright notice, this list of conditions and the following
    *     disclaimer in the documentation and/or other materials provided
    *     with the distribution.
    *   * Neither the name of the Jiri Horner nor the names of its
    *     contributors may be used to endorse or promote products derived
    *     from this software without specific prior written permission.
    *
    *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
    *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
    *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
    *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
    *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
    *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
    *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
    *  POSSIBILITY OF SUCH DAMAGE.
    *
    *********************************************************************/

    #include <explore/explore.h>



    #include <thread>
    #include <iostream> 
    #include <opencv2/opencv.hpp> 
    #include <ctime>
    #include <iostream>
    #include <fstream>
    #include <std_msgs/Int32.h>
    #include <chrono>
    #include <geometry_msgs/PoseArray.h>
    #include <cmath>

    #include <atomic>
    #include <iomanip>
    #include <sstream>
    #include <cstdlib>
    #include <regex>
    #include <boost/filesystem.hpp>
    namespace fs = boost::filesystem;

    #include <yaml-cpp/yaml.h>
    #include <costmap_2d/cost_values.h>  // FREE_SPACE, LETHAL_OBSTACLE, NO_INFORMATION

    #include <limits> //(NaN kontrolü için)




    using namespace cv; 
    using namespace std; 

    #include <ctime>

    clock_t beginClock, endClock;



    inline static bool operator==(const geometry_msgs::Point& one,
                                const geometry_msgs::Point& two)
    {
    double dx = one.x - two.x;
    double dy = one.y - two.y;
    double dist = sqrt(dx * dx + dy * dy);
    return dist < 0.01;
    }

    namespace explore
    {

            Explore::Explore()
                : private_nh_("~")
                , tf_listener_(ros::Duration(10.0))
                , costmap_client_(private_nh_, relative_nh_, &tf_listener_)  
                , move_base_client_("move_base")  // Initialize here with hardcoded name
                , prev_distance_(std::numeric_limits<double>::max()) // 0 idi
                , last_markers_count_(0)
                ,  last_roi_markers_count_(0)
                , last_text_markers_count_(0)
                , fallback_attempt_count_(0) 
                , fallback_attempted_(false)
                , fallback_current_index_(0)
                , fallback_session_count_(0)              
                , fallback_current_session_attempts_(0)  
            {
                
                private_nh_.param("planner_frequency", planner_frequency_, 1.0);
                private_nh_.param("progress_timeout", timeout, 60.0); // default = 30.0
                progress_timeout_ = ros::Duration(timeout);
                private_nh_.param("visualize", visualize_, true);
                private_nh_.param("potential_scale", potential_scale_, 1e-3);
                private_nh_.param("orientation_scale", orientation_scale_, 0.0);
                private_nh_.param("gain_scale", gain_scale_, 1.0);
                private_nh_.param("min_frontier_size", min_frontier_size, 0.5);
                private_nh_.param("with_map_completion", with_map_completion, 0);
                private_nh_.param<std::string>("distance_method", distance_method, std::string("euclidean"));
                private_nh_.param("validate_with_makeplan", validate_with_makeplan_, false);
                private_nh_.param("publish_maps", publish_maps_, true);
                private_nh_.param("gt_image_path", gt_image_path_, std::string(""));
                private_nh_.param("gt_dir", gt_dir_, std::string(""));

                private_nh_.param("use_completed_map", use_completed_map_, 1);
                private_nh_.param("use_closed_live_map", use_closed_live_map_, 1);
                private_nh_.param("use_closing", use_closing_, 1);
                private_nh_.param("use_clustering", use_clustering_, 1);
                private_nh_.param("use_filtering", use_filtering_, 1);
                

                // ---- GT görüntü & referans koordinatları ----  
                
                private_nh_.param("gt_origin_x", gt_origin_x_, -26.0);     
                private_nh_.param("gt_origin_y", gt_origin_y_, -26.0);     
                private_nh_.param("gt_resolution", gt_resolution_, 0.1);  
                private_nh_.param("rect_size", rect_size_, 32);
                

                private_nh_.param("completion_known_scale", completion_known_scale_, 1.0);  
                private_nh_.param("completion_obstacle_scale", completion_obstacle_scale_, 0.5);


                private_nh_.param("prefer_preflight_astar", prefer_preflight_astar_, true);
                private_nh_.param("preflight_max_stretch",  preflight_max_stretch_,  2.2);
                private_nh_.param("preflight_min_cap_m",    preflight_min_cap_m_,    3.0);
                private_nh_.param("preflight_max_radius_m", preflight_max_radius_m_, 12.0);
                private_nh_.param("door_threshold_m",       door_threshold_m_,       0.70);

                private_nh_.param("room_behind_wall_scale", room_behind_wall_scale_, 5.0);
                private_nh_.param("barrier_penalty_scale", barrier_penalty_scale_, 2.0);
                private_nh_.param("frontier_on_obstacle_penalty_scale", frontier_on_obstacle_penalty_scale_, 0.3);

                private_nh_.param("obstacle_distance_threshold", obstacle_distance_threshold_, 0.3);
                private_nh_.param("publish_closed_live_map", publish_closed_live_map_, true);

                private_nh_.param("gt_fine_dx", fine_dx, 0.0);
                private_nh_.param("gt_fine_dy", fine_dy, 0.0);

                private_nh_.param("alignment_search_radius", alignment_search_radius, 5.0);
                private_nh_.param("alignment_min_score", alignment_min_score, 0.3);
                private_nh_.param("alignment_min_pixels", alignment_min_pixels, 20);
                private_nh_.param("realignment_period", realignment_period, 30.0);
                

                // Logging parametreleri
                private_nh_.param("log_metrics_enabled", log_metrics_enabled_, true);
                private_nh_.param("log_operations_enabled", log_operations_enabled_, true);
                private_nh_.param("metrics_log_interval", metrics_log_interval_, 5.0); // 5 saniyede bir

                private_nh_.param("noise_in_room_threshold", noise_in_room_threshold_, 0.6);
                private_nh_.param("check_distance", check_distance_, 0.4);
                private_nh_.param("interior_noise_min_length", interior_noise_min_length_, 0.15);
                private_nh_.param("interior_noise_max_length", interior_noise_max_length_, 0.40);
                private_nh_.param("interior_noise_agreement_ratio", interior_noise_agreement_ratio_, 0.80);
                private_nh_.param("interior_noise_max_obstacle_ratio", interior_noise_max_obstacle_ratio_, 0.08);

                private_nh_.param("exterior_noise_min_length", exterior_noise_min_length_, 0.15);
                private_nh_.param("exterior_noise_max_thickness_cells", exterior_noise_max_thickness_cells_, 2);
                private_nh_.param("exterior_noise_unknown_lookahead_m", exterior_noise_unknown_lookahead_m_, 0.6);
                private_nh_.param("exterior_noise_wall_search_m", exterior_noise_wall_search_m_, 0.6);
                private_nh_.param("exterior_noise_agree_ratio", exterior_noise_agree_ratio_, 0.4);
                private_nh_.param("exterior_noise_island_radius_m", exterior_noise_island_radius_m_, 0.5);
                private_nh_.param("exterior_noise_island_cells_max", exterior_noise_island_cells_max_, 25);

                private_nh_.param("trapped_max_traversable_gap_m", trapped_max_traversable_gap_m_, 0.35);
                private_nh_.param("trapped_wall_detect_range_m", trapped_wall_detect_range_m_, 0.6);
                private_nh_.param("trapped_min_obstacle_ratio", trapped_min_obstacle_ratio_, 0.6);
                private_nh_.param("trapped_min_samples_agree", trapped_min_samples_agree_, 0.7);
                private_nh_.param("trapped_min_frontier_length", trapped_min_frontier_length_, 0.15);
                private_nh_.param("trapped_max_frontier_length", trapped_max_frontier_length_, 1.5);

                private_nh_.param("bridge_min_length", bridge_min_length_, 0.12);
                private_nh_.param("bridge_max_thickness_per_side_m", bridge_max_thickness_per_side_m_, 0.10);
                private_nh_.param("bridge_wall_search_m", bridge_wall_search_m_, 0.6);
                private_nh_.param("bridge_min_unknown_ratio_per_side", bridge_min_unknown_ratio_per_side_, 0.65);
                private_nh_.param("bridge_min_thin_ratio", bridge_min_thin_ratio_, 0.70);
                private_nh_.param("bridge_min_unknown_ratio", bridge_min_unknown_ratio_, 0.70);
                private_nh_.param("bridge_unknown_lookahead_m", bridge_unknown_lookahead_m_, 0.4);
                private_nh_.param("bridge_max_island_cells", bridge_max_island_cells_, 30);

                private_nh_.param("corner_max_frontier_length", corner_max_frontier_length_, 0.35);
                private_nh_.param("corner_max_unknown_depth", corner_max_unknown_depth_, 0.30);
                private_nh_.param("corner_max_unknown_volume", corner_max_unknown_volume_, 0.08);
                private_nh_.param("corner_min_wall_coverage", corner_min_wall_coverage_, 0.60);
                private_nh_.param("corner_angle_threshold", corner_angle_threshold_, 120.0);
                private_nh_.param("corner_min_confidence", corner_min_confidence_, 0.65);
                private_nh_.param("corner_wall_search_distance", corner_wall_search_distance_, 0.25);
                private_nh_.param("corner_min_pocket_depth", corner_min_pocket_depth_, 0.05);


                private_nh_.param("direction_consistency_weight", direction_consistency_weight_, 0.6);
                private_nh_.param("cluster_distance_threshold", cluster_distance_threshold_, 2.0);

               
                // Başlangıç değerleri
                total_distance_traveled_ = 0.0;
                last_robot_position_.x = 0.0;
                last_robot_position_.y = 0.0;
                last_robot_position_.z = 0.0;

                // ═══════════════════════════════════════════════════════════════
                // EXTRACT ENVIRONMENT NAME FROM GT_DIR (for log filename)
                // ═══════════════════════════════════════════════════════════════
                std::string env_name = "unknown";
                if (!gt_dir_.empty() && boost::filesystem::exists(gt_dir_)) {
                    // Find PGM file in directory
                    for (boost::filesystem::directory_iterator it(gt_dir_), end; it != end; ++it) {
                        std::string ext = it->path().extension().string();
                        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
                        
                        if (ext == ".pgm") {
                            env_name = it->path().stem().string();  // "4bb7447766005e95922e3d51c4a5b6fa"
                            ROS_INFO("Environment name for logging: %s", env_name.c_str());
                            break;  // First PGM found
                        }
                    }
                }

                // Logger oluştur
                if (log_metrics_enabled_ || log_operations_enabled_) {
                    const char* base_dir = std::getenv("EXPLORATION_LOG_DIR");
                    if (!base_dir) base_dir = std::getenv("HOME");
                    if (!base_dir) base_dir = "/tmp";
                    
                    std::string log_dir = std::string(base_dir) + "/exploration_logs";
                    boost::filesystem::create_directories(log_dir);
                    
                    // CREATE LOG FILENAME WITH ENVIRONMENT NAME
                    auto now = std::chrono::system_clock::now();
                    auto now_c = std::chrono::system_clock::to_time_t(now);
                    std::stringstream log_filename;
                    log_filename << log_dir << "/" << env_name << "_";  // ← env_name BAŞTA!

                    log_filename << distance_method 
                                    << "_use" << use_completed_map_ 
                                    << "_with" << with_map_completion 
                                    << "_live" << use_closed_live_map_ 
                                    << "_closing" << use_closing_ 
                                    << "_clustering" << use_clustering_
                                    << "_filtering" << use_filtering_
                                    << "_"
                                    << std::put_time(std::localtime(&now_c), "%Y%m%d_%H%M%S") << ".csv";

                    experiment_logger_ = std::make_unique<ExperimentLogger>(log_filename.str());
                    ROS_INFO("✓ Unified logger initialized: %s", log_filename.str().c_str());
                    
                    experiment_logger_->logExperimentStart(distance_method);
                    
                    // Milestones
                    completion_milestones_.clear();
                    reached_milestones_.clear();
                    for (int p = 5; p <= 50; p += 5) completion_milestones_.push_back(p);
                    for (int p = 55; p <= 90; p += 5) completion_milestones_.push_back(p);
                    for (int p = 92; p <= 100; p += 2) completion_milestones_.push_back(p);
                }

                

                //ROS_INFO("rect_size param = %d", rect_size_);


                is_in_fallback_active_ = false;
                
                search_ = std::make_unique<frontier_exploration::FrontierSearch>(costmap_client_.getCostmap(),
                                                            potential_scale_, 
                                                            gain_scale_,
                                                            min_frontier_size,
                                                            distance_method,
                                                            rect_size_,
                                                            completion_known_scale_,
                                                            completion_obstacle_scale_,
                                                            obstacle_distance_threshold_,
                                                            door_threshold_m_,
                                                            use_completed_map_,
                                                            use_closed_live_map_,
                                                            use_closing_,
                                                            use_filtering_,
                                                            use_clustering_,
                                                            room_behind_wall_scale_,
                                                            barrier_penalty_scale_,
                                                            frontier_on_obstacle_penalty_scale_,
                                                            check_distance_,
                                                            experiment_logger_,
                                                            with_map_completion,
                                                            noise_in_room_threshold_,
                                                            direction_consistency_weight_,
                                                            cluster_distance_threshold_,
                                                            interior_noise_min_length_,           
                                                            interior_noise_max_length_,           
                                                            interior_noise_agreement_ratio_,      
                                                            interior_noise_max_obstacle_ratio_,
                                                            exterior_noise_min_length_,
                                                            exterior_noise_max_thickness_cells_,
                                                            exterior_noise_unknown_lookahead_m_,
                                                            exterior_noise_wall_search_m_,
                                                            exterior_noise_agree_ratio_,
                                                            exterior_noise_island_radius_m_,
                                                            exterior_noise_island_cells_max_,
                                                            trapped_max_traversable_gap_m_,
                                                            trapped_wall_detect_range_m_,
                                                            trapped_min_obstacle_ratio_,
                                                            trapped_min_samples_agree_,
                                                            trapped_min_frontier_length_,
                                                            trapped_max_frontier_length_,
                                                            bridge_min_length_,
                                                            bridge_max_thickness_per_side_m_,
                                                            bridge_wall_search_m_,
                                                            bridge_min_unknown_ratio_per_side_,
                                                            bridge_min_thin_ratio_,
                                                            bridge_min_unknown_ratio_,
                                                            bridge_unknown_lookahead_m_,
                                                            bridge_max_island_cells_,
                                                            corner_max_frontier_length_,
                                                            corner_max_unknown_depth_,
                                                            corner_max_unknown_volume_,
                                                            corner_min_wall_coverage_,
                                                            corner_angle_threshold_,
                                                            corner_min_confidence_,
                                                            corner_wall_search_distance_,
                                                            corner_min_pocket_depth_ );

                
                                                            search_->setRectSize(rect_size_);  // <- zinciri senkronla

                has_active_target_ = false;
                target_start_distance_ = 0.0;

                // Metrics timer başlat
                if (log_metrics_enabled_) {
                    exploration_start_time_ = ros::Time::now();


                    

                    metrics_timer_ = private_nh_.createTimer(
                        ros::Duration(metrics_log_interval_),
                        &Explore::metricsTimerCallback, this);
                    //ROS_INFO("Metrics logging enabled with interval: %.1f seconds", metrics_log_interval_);
                }

                //ROS_INFO("Explore: rect_size param = %d (propagated to FrontierSearch)", search_->getRectSize());

                last_roi_markers_count_=0;

                // if (!gt_image_path_.empty()) {
                //     auto gt_start = std::chrono::high_resolution_clock::now();
                    
                //     if (loadGTOnce()) {
                //         // Log initial load time
                //         if (log_operations_enabled_ && experiment_logger_) {
                //             auto gt_end = std::chrono::high_resolution_clock::now();
                //             double gt_duration_ms = std::chrono::duration<double, std::milli>(gt_end - gt_start).count();
                //             experiment_logger_->logOperation("GT_loading", gt_duration_ms);
                //             ROS_INFO("GT loading took %.2f ms", gt_duration_ms);
                //         }
                //     } else {
                //         ROS_ERROR("Failed to load GT - continuing without GT reference");
                //     }
                // }


                // ═══════════════════════════════════════════════════════════════
                // LOAD FULL GT ONCE IN CONSTRUCTOR
                // ═══════════════════════════════════════════════════════════════
                full_gt_loaded_ = false;

                if (!gt_dir_.empty() && boost::filesystem::exists(gt_dir_)) {
                    // Find PGM and YAML files
                    std::string pgm_file, yaml_file;
                    
                    for (boost::filesystem::directory_iterator it(gt_dir_), end; it != end; ++it) {
                        std::string ext = it->path().extension().string();
                        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
                        
                        if (ext == ".pgm") pgm_file = it->path().string();
                        else if (ext == ".yaml") yaml_file = it->path().string();
                    }
                    
                    if (!pgm_file.empty()) {
                        // Load FULL GT image
                        full_gt_image_ = cv::imread(pgm_file, cv::IMREAD_GRAYSCALE);
                        
                        if (!full_gt_image_.empty()) {
                            // Read YAML metadata
                            full_gt_origin_x_ = gt_origin_x_;  // Default from launch file
                            full_gt_origin_y_ = gt_origin_y_;
                            full_gt_resolution_ = gt_resolution_;
                            
                            if (!yaml_file.empty() && boost::filesystem::exists(yaml_file)) {
                                try {
                                    YAML::Node yaml_doc = YAML::LoadFile(yaml_file);
                                    
                                    if (yaml_doc["resolution"]) {
                                        full_gt_resolution_ = yaml_doc["resolution"].as<double>();
                                    }
                                    
                                    if (yaml_doc["origin"] && yaml_doc["origin"].IsSequence() && 
                                        yaml_doc["origin"].size() >= 2) {
                                        full_gt_origin_x_ = yaml_doc["origin"][0].as<double>();
                                        full_gt_origin_y_ = yaml_doc["origin"][1].as<double>();
                                    }
                                } catch (...) {
                                    ROS_WARN("Failed to parse GT YAML, using launch file params");
                                }
                            }
                            
                            full_gt_loaded_ = true;
                            ROS_INFO("✓ Full GT loaded ONCE: %dx%d, origin=(%.3f, %.3f), res=%.4f",
                                    full_gt_image_.cols, full_gt_image_.rows,
                                    full_gt_origin_x_, full_gt_origin_y_, full_gt_resolution_);
                        }
                    }
                }



                dc_.setCostmap(costmap_client_.getCostmap());                 
                dc_.setGlobalFrame(costmap_client_.getGlobalFrameID());   
                
                // odom_sub_ = private_nh_.subscribe<nav_msgs::Odometry>(
                // "odom",   // topic name (check if your robot publishes under "odom" or something like "/odom")
                // 10, 
                // &Explore::odomCallback, 
                // this
                // );


                if (visualize_) {
                    marker_array_publisher_ =
                        private_nh_.advertise<visualization_msgs::MarkerArray>("/frontiers", 10);
                }
                

                //selected_frontier_pub_ = private_nh_.advertise<explore_lite::FrontierMsg>("selected_frontier", 10);
                exploration_finished_pub_ = private_nh_.advertise<std_msgs::Int32>("exploration_finished", 10);
                //frontiers_pub_ = private_nh_.advertise<explore_lite::FrontierArray>("all_frontiers", 10);
                
                //if(with_map_completion == 1){
                //ROS_INFO("with_map_completion: %d ", with_map_completion);
                //target_frontier_sub_ = private_nh_.subscribe("/target_frontier", 10, &Explore::targetFrontierCallback, this);
                //}
                

                completed_pub_ = private_nh_.advertise<nav_msgs::OccupancyGrid>("/completed_map", 1, /*latch=*/true);
                closed_live_pub_ = private_nh_.advertise<nav_msgs::OccupancyGrid>("/closed_live_map", 1, /*latch=*/true);
                gt_map_pub_ = private_nh_.advertise<nav_msgs::OccupancyGrid>("/gt_map", 1, /*latch=*/true);
                processed_map_pub_ = private_nh_.advertise<nav_msgs::OccupancyGrid>("/processed_map", 1, true); // latched

                //ROS_WARN("Publishers created: completed_pub subscribers=%d, gt_map_pub subscribers=%d", 
                //completed_pub_.getNumSubscribers(), gt_map_pub_.getNumSubscribers());

                // FIX: RViz ilk latched mesajı hemen alabilsin diye bir defalık seed + publish
                if (publish_maps_) {
                    // costmap boyutlarında matrisleri hazırla (boşsa)
                    if(use_completed_map_)
                    {
                        search_->seedCompletedMapFromCostmap();
                    }

                    if(use_closed_live_map_)
                    {
                        search_->seedClosedLiveMapFromCostmap();
                    }
                    
                    //search_.seedGT();         
                    publishMaps();
                    //ROS_INFO("Initial /completed_map and /gt_map published (latched).");
                }

                
                //ROS_INFO("Waiting to connect to move_base server");
                move_base_client_.waitForServer();
                //ROS_INFO("Connected to move_base server");

                // In the Explore constructor and makePlan(), add:
                const unsigned int W = costmap_client_.getCostmap()->getSizeInCellsX();
                const unsigned int H = costmap_client_.getCostmap()->getSizeInCellsY();
            
                // Explore constructor içinde
                make_plan_client_ = private_nh_.serviceClient<nav_msgs::GetPlan>("/move_base/make_plan");

                exploring_timer_ =
                    relative_nh_.createTimer(ros::Duration(1. / planner_frequency_),
                                            [this](const ros::TimerEvent&) { 
                                            makePlan(); 
                                            });



            }


            Explore::~Explore()
            {
                // Log experiment end before cleanup
                if (experiment_logger_) {
                    double elapsed_sec = (ros::Time::now() - exploration_start_time_).toSec();
                    double completion = calculateExplorationProgress();
                    experiment_logger_->logExperimentEnd(
                        elapsed_sec,
                        total_distance_traveled_,
                        completion,
                        frontier_switch_count_,
                        progress_timeout_count_
                    );
                }


                try {
                    stop();
                    
                    // Clean up timers
                    oneshot_.stop();
                    exploring_timer_.stop();
                    
                    // Clear blacklist to free memory
                    frontier_blacklist_.clear();
                    frontier_blacklist_.shrink_to_fit();
                    

                    move_base_client_.cancelAllGoals();
                    if (visualize_) {
                        deleteAllFrontierMarkers();
                    }

                    ROS_WARN("Waiting 10s - check RViz now!");
                    ros::Duration(10.0).sleep();
                    
                } catch (const std::exception& e) {
                    //ROS_ERROR("Exception in Explore destructor: %s", e.what());
                } catch (...) {
                    //ROS_ERROR("Unknown exception in Explore destructor");
                }
            }


            bool isSamePoint(const geometry_msgs::Point& p1, const geometry_msgs::Point& p2, double tolerance = 1e-3) 
            {
                return (std::abs(p1.x - p2.x) < tolerance &&
                        std::abs(p1.y - p2.y) < tolerance &&
                        std::abs(p1.z - p2.z) < tolerance);
            }

            

            // void Explore::visualizeFrontiers(const std::vector<frontier_exploration::Frontier>& frontiers,
            //                      geometry_msgs::Point target_position)
            // {
            //     const double MATCH_EPS = 0.5;
                
            //     visualization_msgs::MarkerArray markers;
                
            //     // Delete old markers
            //     if (last_markers_count_ > 0) {
            //         visualization_msgs::Marker delete_marker;
            //         delete_marker.header.frame_id = costmap_client_.getGlobalFrameID();
            //         delete_marker.header.stamp = ros::Time::now();
            //         delete_marker.ns = "frontiers";
            //         delete_marker.action = visualization_msgs::Marker::DELETEALL;
            //         markers.markers.push_back(delete_marker);
            //     }
                
            //     int marker_id = 0;
                
            //     // Helper: Check if point is in filtered clusters
            //     auto isInFilteredCluster = [&](const geometry_msgs::Point& p) -> bool {
            //         for (const auto& cluster : filtered_clusters_) {
            //             for (const auto& member : cluster.members) {
            //                 if (std::hypot(p.x - member.x, p.y - member.y) < MATCH_EPS) {
            //                     return true;
            //                 }
            //             }
            //         }
            //         return false;
            //     };
                
            //     // Visualize each frontier (only safest point)
            //     for (const auto& frontier : frontiers) {
            //         bool is_blacklisted = goalOnBlacklist(frontier.safest_point);
            //         bool is_filtered = isInFilteredCluster(frontier.safest_point);
            //         bool is_target = (std::hypot(frontier.safest_point.x - target_position.x,
            //                                     frontier.safest_point.y - target_position.y) < MATCH_EPS);
                    
            //         // Safest point marker (SPHERE)
            //         visualization_msgs::Marker safest_marker;
            //         safest_marker.header.frame_id = costmap_client_.getGlobalFrameID();
            //         safest_marker.header.stamp = ros::Time::now();
            //         safest_marker.ns = "safest_points";
            //         safest_marker.id = marker_id++;
            //         safest_marker.type = visualization_msgs::Marker::SPHERE;
            //         safest_marker.action = visualization_msgs::Marker::ADD;
            //         safest_marker.pose.position = frontier.safest_point;
            //         safest_marker.pose.orientation.w = 1.0;

            //         // Color and size based on status
            //         if (is_target) {
            //             // Target: CYAN, biggest
            //             safest_marker.scale.x = 0.5;
            //             safest_marker.scale.y = 0.5;
            //             safest_marker.scale.z = 0.5;
            //             safest_marker.color.r = 0.0;
            //             safest_marker.color.g = 1.0;
            //             safest_marker.color.b = 1.0;
            //             safest_marker.color.a = 1.0;
            //         } else if (is_blacklisted) {
            //             // Blacklisted: RED, small
            //             safest_marker.scale.x = 0.2;
            //             safest_marker.scale.y = 0.2;
            //             safest_marker.scale.z = 0.2;
            //             safest_marker.color.r = 1.0;
            //             safest_marker.color.g = 0.0;
            //             safest_marker.color.b = 0.0;
            //             safest_marker.color.a = 0.5;
            //         } else if (is_filtered) {
            //             // Filtered (in cluster): ORANGE, medium
            //             safest_marker.scale.x = 0.3;
            //             safest_marker.scale.y = 0.3;
            //             safest_marker.scale.z = 0.3;
            //             safest_marker.color.r = 1.0;
            //             safest_marker.color.g = 0.6;
            //             safest_marker.color.b = 0.0;
            //             safest_marker.color.a = 0.8;
            //         } else {
            //             // Normal frontier: GREEN, medium
            //             safest_marker.scale.x = 0.3;
            //             safest_marker.scale.y = 0.3;
            //             safest_marker.scale.z = 0.3;
            //             safest_marker.color.r = 0.0;
            //             safest_marker.color.g = 1.0;
            //             safest_marker.color.b = 0.0;
            //             safest_marker.color.a = 1.0;
            //         }

            //         markers.markers.push_back(safest_marker);
            //     }
                
            //     // ✅ Visualize cluster centers (CUBE)
            //     for (size_t i = 0; i < filtered_clusters_.size(); ++i) {
            //         const auto& cluster = filtered_clusters_[i];
                    
            //         visualization_msgs::Marker cluster_marker;
            //         cluster_marker.header.frame_id = costmap_client_.getGlobalFrameID();
            //         cluster_marker.header.stamp = ros::Time::now();
            //         cluster_marker.ns = "cluster_centers";
            //         cluster_marker.id = marker_id++;
            //         cluster_marker.type = visualization_msgs::Marker::CUBE;
            //         cluster_marker.action = visualization_msgs::Marker::ADD;
            //         cluster_marker.pose.position = cluster.center;
            //         cluster_marker.pose.orientation.w = 1.0;
            //         cluster_marker.scale.x = 0.4;
            //         cluster_marker.scale.y = 0.4;
            //         cluster_marker.scale.z = 0.4;
                    
            //         // Yellow for cluster center
            //         cluster_marker.color.r = 1.0;
            //         cluster_marker.color.g = 1.0;
            //         cluster_marker.color.b = 0.0;
            //         cluster_marker.color.a = 0.7;
                    
            //         markers.markers.push_back(cluster_marker);
                    
            //         // Cluster member count text
            //         visualization_msgs::Marker text_marker;
            //         text_marker.header.frame_id = costmap_client_.getGlobalFrameID();
            //         text_marker.header.stamp = ros::Time::now();
            //         text_marker.ns = "cluster_text";
            //         text_marker.id = marker_id++;
            //         text_marker.type = visualization_msgs::Marker::TEXT_VIEW_FACING;
            //         text_marker.action = visualization_msgs::Marker::ADD;
            //         text_marker.pose.position = cluster.center;
            //         text_marker.pose.position.z = 0.5;  // Above cluster
            //         text_marker.pose.orientation.w = 1.0;
            //         text_marker.scale.z = 0.3;  // Text size
                    
            //         text_marker.color.r = 1.0;
            //         text_marker.color.g = 1.0;
            //         text_marker.color.b = 1.0;
            //         text_marker.color.a = 1.0;
                    
            //         text_marker.text = "C" + std::to_string(i) + " (" + std::to_string(cluster.members.size()) + ")";
                    
            //         markers.markers.push_back(text_marker);
            //     }
                
            //     // ✅ Fallback attempt counter text
            //     if (fallback_attempt_count_ > 0) {
            //         visualization_msgs::Marker fallback_text;
            //         fallback_text.header.frame_id = costmap_client_.getGlobalFrameID();
            //         fallback_text.header.stamp = ros::Time::now();
            //         fallback_text.ns = "fallback_status";
            //         fallback_text.id = marker_id++;
            //         fallback_text.type = visualization_msgs::Marker::TEXT_VIEW_FACING;
            //         fallback_text.action = visualization_msgs::Marker::ADD;
                    
            //         auto pose = costmap_client_.getRobotPose();
            //         fallback_text.pose.position = pose.position;
            //         fallback_text.pose.position.z = 1.0;  // Above robot
            //         fallback_text.pose.orientation.w = 1.0;
            //         fallback_text.scale.z = 0.5;
                    
            //         fallback_text.color.r = 1.0;
            //         fallback_text.color.g = 0.0;
            //         fallback_text.color.b = 0.0;
            //         fallback_text.color.a = 1.0;
                    
            //         fallback_text.text = "FALLBACK " + std::to_string(fallback_attempt_count_) + "/" + 
            //                             std::to_string(MAX_FALLBACK_ATTEMPTS);
                    
            //         markers.markers.push_back(fallback_text);
            //     }
                
            //     last_markers_count_ = markers.markers.size();
                
            //     if (marker_array_publisher_) {
            //         marker_array_publisher_.publish(markers);
            //     }
            // }


            void Explore::visualizeFrontiers(const std::vector<frontier_exploration::Frontier>& frontiers,
                                 geometry_msgs::Point target_position)
            {
                const double MATCH_EPS = 0.5;
                
                visualization_msgs::MarkerArray markers;
                
                // Delete old markers
                if (last_markers_count_ > 0) {
                    visualization_msgs::Marker delete_marker;
                    delete_marker.header.frame_id = costmap_client_.getGlobalFrameID();
                    delete_marker.header.stamp = ros::Time::now();
                    delete_marker.ns = "frontiers";
                    delete_marker.action = visualization_msgs::Marker::DELETEALL;
                    markers.markers.push_back(delete_marker);
                }
                
                int marker_id = 0;
                
                // Visualize each frontier (only safest point)
                for (const auto& frontier : frontiers) {
                    bool is_blacklisted = goalOnBlacklist(frontier.safest_point);
                    bool is_target = (std::hypot(frontier.safest_point.x - target_position.x,
                                                frontier.safest_point.y - target_position.y) < MATCH_EPS);
                    
                    // Safest point marker (SPHERE)
                    visualization_msgs::Marker safest_marker;
                    safest_marker.header.frame_id = costmap_client_.getGlobalFrameID();
                    safest_marker.header.stamp = ros::Time::now();
                    safest_marker.ns = "safest_points";
                    safest_marker.id = marker_id++;
                    safest_marker.type = visualization_msgs::Marker::SPHERE;
                    safest_marker.action = visualization_msgs::Marker::ADD;
                    safest_marker.pose.position = frontier.safest_point;
                    safest_marker.pose.orientation.w = 1.0;

                    // Color and size based on status
                    if (is_target) {
                        // Target: CYAN, biggest
                        safest_marker.scale.x = 0.5;
                        safest_marker.scale.y = 0.5;
                        safest_marker.scale.z = 0.5;
                        safest_marker.color.r = 0.0;
                        safest_marker.color.g = 1.0;
                        safest_marker.color.b = 1.0;
                        safest_marker.color.a = 1.0;
                    } else if (is_blacklisted) {
                        // Blacklisted: RED, small
                        safest_marker.scale.x = 0.2;
                        safest_marker.scale.y = 0.2;
                        safest_marker.scale.z = 0.2;
                        safest_marker.color.r = 1.0;
                        safest_marker.color.g = 0.0;
                        safest_marker.color.b = 0.0;
                        safest_marker.color.a = 0.5;
                    } else {
                        // Normal frontier: GREEN, medium
                        safest_marker.scale.x = 0.3;
                        safest_marker.scale.y = 0.3;
                        safest_marker.scale.z = 0.3;
                        safest_marker.color.r = 0.0;
                        safest_marker.color.g = 1.0;
                        safest_marker.color.b = 0.0;
                        safest_marker.color.a = 1.0;
                    }

                    markers.markers.push_back(safest_marker);
                }
                
                last_markers_count_ = markers.markers.size();
                
                if (marker_array_publisher_) {
                    marker_array_publisher_.publish(markers);
                }
            }

            // ═══════════════════════════════════════════════════════════════════════
            // OPTIONAL: Add legend marker to RViz
            // ═══════════════════════════════════════════════════════════════════════
            /*
            void Explore::publishColorLegend() {
                visualization_msgs::Marker legend;
                legend.header.frame_id = costmap_client_.getGlobalFrameID();
                legend.header.stamp = ros::Time(0);
                legend.ns = "filter_legend";
                legend.id = 0;
                legend.type = visualization_msgs::Marker::TEXT_VIEW_FACING;
                legend.action = visualization_msgs::Marker::ADD;
                legend.lifetime = ros::Duration(0);
                
                legend.pose.position.x = -5.0;  // Adjust to visible location
                legend.pose.position.y = -5.0;
                legend.pose.position.z = 2.0;
                legend.pose.orientation.w = 1.0;
                
                legend.scale.z = 0.3;
                legend.color.r = 1.0;
                legend.color.g = 1.0;
                legend.color.b = 1.0;
                legend.color.a = 1.0;
                
                legend.text = "FILTER COLORS:\n"
                            "BLUE=Safe | YELLOW=Obstacle | CYAN=Interior\n"
                            "MAGENTA=Exterior | PURPLE=Trapped | PINK=Bridge\n"
                            "RED RECT=Blacklisted";
                
                visualization_msgs::MarkerArray legend_msg;
                legend_msg.markers.push_back(legend);
                marker_array_publisher_.publish(legend_msg);
            }
            */


            // void Explore::targetFrontierCallback(const explore_lite::FrontierMsg::ConstPtr& msg) 
            // {
            //     if (!msg) {
            //         //ROS_WARN("Received null frontier message");
            //         return;
            //     }

            //     // Validate input before any locking
            //     if (!std::isfinite(msg->centroid.x) || !std::isfinite(msg->centroid.y)) {
            //         //ROS_WARN_THROTTLE(1.0, "Invalid frontier coordinates (inf/nan). Ignoring.");
            //         return;
            //     }

            //     // Single atomic update of shared state
            //     {
            //         std::lock_guard<std::mutex> lock(target_mutex_);
            //         received_target_frontier = *msg;  // Copy while holding lock
            //         use_external_target = true;
            //     }

            //     // Cancel any pending replan outside the lock
            //     oneshot_.stop();

            //     // Schedule replan with proper error handling
            //     oneshot_ = relative_nh_.createTimer(
            //         ros::Duration(0), 
            //         [this](const ros::TimerEvent&) {
            //             try {
            //                 makePlan();
            //             } catch (const std::exception& e) {
            //                 //ROS_ERROR("Exception in makePlan: %s", e.what());
            //             }
            //         },
            //         true  // oneshot
            //     );
            // }

            void Explore::deleteAllFrontierMarkers()
            {
                visualization_msgs::MarkerArray markers;
                
                // Delete all namespaces
                std::vector<std::string> namespaces = {
                    "frontiers",
                    "safest_points",
                    "cluster_centers",
                    "cluster_text",
                    "fallback_status"
                };
                
                for (const auto& ns : namespaces) {
                    visualization_msgs::Marker delete_marker;
                    delete_marker.header.frame_id = costmap_client_.getGlobalFrameID();
                    delete_marker.header.stamp = ros::Time::now();
                    delete_marker.ns = ns;
                    delete_marker.action = visualization_msgs::Marker::DELETEALL;
                    markers.markers.push_back(delete_marker);
                }
                
                if (marker_array_publisher_) {
                    marker_array_publisher_.publish(markers);
                }
                
                last_markers_count_ = 0;
            }

            // bool Explore::loadGTOnce() 
            // {
            //     if (gt_image_path_.empty()) {
            //         ROS_WARN("GT image path is empty - GT functionality disabled");
            //         return false;
            //     }
                
            //     // Wait for costmap to be ready
            //     ROS_INFO("Waiting for costmap to be ready before loading GT...");
            //     ros::Rate rate(10);
            //     int attempts = 0;
            //     while (ros::ok() && attempts < 50) {
            //         auto* cm = costmap_client_.getCostmap();
            //         if (cm && cm->getSizeInCellsX() > 0 && cm->getSizeInCellsY() > 0) {
            //             ROS_INFO("✓ Costmap ready (%dx%d)", cm->getSizeInCellsX(), cm->getSizeInCellsY());
            //             break;
            //         }
            //         rate.sleep();
            //         attempts++;
            //     }
                
            //     auto* cm = costmap_client_.getCostmap();
            //     if (!cm || cm->getSizeInCellsX() == 0) {
            //         ROS_ERROR("Costmap not ready after waiting - GT loading failed!");
            //         return false;
            //     }
                
            //     // Get costmap parameters
            //     const int cur_W = cm->getSizeInCellsX();
            //     const int cur_H = cm->getSizeInCellsY();
            //     const double cur_res = cm->getResolution();
            //     const double cur_origin_x = cm->getOriginX();
            //     const double cur_origin_y = cm->getOriginY();
                
            //     ROS_INFO("Costmap params: %dx%d, origin=(%.3f, %.3f), res=%.4f", 
            //             cur_W, cur_H, cur_origin_x, cur_origin_y, cur_res);
                
            //     // ═══════════════════════════════════════════════════════════════
            //     // READ YAML FILE (if exists)
            //     // ═══════════════════════════════════════════════════════════════
            //     std::string yaml_path = gt_image_path_;
            //     size_t dot_pos = yaml_path.find_last_of('.');
            //     if (dot_pos != std::string::npos) {
            //         yaml_path = yaml_path.substr(0, dot_pos) + ".yaml";
            //     } else {
            //         yaml_path += ".yaml";
            //     }
                
            //     // Initialize with launch file parameters as fallback
            //     double ox = gt_origin_x_;
            //     double oy = gt_origin_y_;
            //     double res = gt_resolution_;
            //     double theta = 0.0;
            //     bool has_yaml = false;
                
            //     if (boost::filesystem::exists(yaml_path)) {
            //         try {
            //             YAML::Node yaml_doc = YAML::LoadFile(yaml_path);
                        
            //             if (yaml_doc["resolution"]) {
            //                 res = yaml_doc["resolution"].as<double>();
            //             }
                        
            //             if (yaml_doc["origin"]) {
            //                 auto origin = yaml_doc["origin"];
            //                 if (origin.IsSequence() && origin.size() >= 2) {
            //                     ox = origin[0].as<double>();
            //                     oy = origin[1].as<double>();
            //                     if (origin.size() >= 3) {
            //                         theta = origin[2].as<double>();
            //                     }
            //                 }
            //             }
                        
            //             has_yaml = true;
            //             ROS_INFO("✓ Loaded YAML metadata from: %s", yaml_path.c_str());
            //             ROS_INFO("  origin: (%.3f, %.3f), theta: %.3f°, resolution: %.4f", 
            //                     ox, oy, theta * 180.0 / M_PI, res);
            //         } 
            //         catch (const YAML::Exception& e) {
            //             ROS_WARN("Failed to parse YAML %s: %s", yaml_path.c_str(), e.what());
            //             ROS_WARN("Using launch file parameters instead");
            //         }
            //     } else {
            //         ROS_WARN("YAML file not found: %s", yaml_path.c_str());
            //         ROS_WARN("Using launch file parameters: origin=(%.3f, %.3f), res=%.4f",
            //                 ox, oy, res);
            //     }
                
            //     // ═══════════════════════════════════════════════════════════════
            //     // LOAD GT IMAGE
            //     // ═══════════════════════════════════════════════════════════════
            //     cv::Mat img = cv::imread(gt_image_path_, cv::IMREAD_GRAYSCALE);
            //     if (img.empty()) {
            //         ROS_ERROR("Failed to load GT image: %s", gt_image_path_.c_str());
            //         return false;
            //     }
                
            //     const int W_orig = img.cols;
            //     const int H_orig = img.rows;
                
            //     ROS_INFO("✓ Loaded GT image from: %s (size: %dx%d)", 
            //             gt_image_path_.c_str(), W_orig, H_orig);
            //     ROS_INFO("Original GT params: origin=(%.3f,%.3f), res=%.6f, theta=%.3f°", 
            //             ox, oy, res, theta * 180.0 / M_PI);
                
            //     // ═══════════════════════════════════════════════════════════════
            //     // AFFINE TRANSFORM - EXACT SAME AS loadBestGTFromDir()
            //     // ═══════════════════════════════════════════════════════════════
                
            //     // 1) Resolution scale factor
            //     const double scale = cur_res / res;
                
            //     // 2) Flip GT on Y-axis (ROS->OpenCV conversion)
            //     cv::Mat flipped;
            //     cv::flip(img, flipped, 0);
                
            //     // 3) Create affine transform matrix
            //     cv::Mat M = cv::Mat::zeros(2, 3, CV_64F);
                
            //     // Scale component
            //     M.at<double>(0, 0) = scale;
            //     M.at<double>(1, 1) = scale;
                
            //     // Translation component
            //     double world_dx = -cur_origin_x + ox;
            //     double world_dy = cur_origin_y - oy;
                
            //     double pixel_tx = world_dx / cur_res;
            //     double pixel_ty = world_dy / cur_res;

            //     // Apply fine-tuning parameters
            //     pixel_tx += fine_dx;
            //     pixel_ty -= fine_dy;
                
            //     M.at<double>(0, 2) = pixel_tx;
            //     M.at<double>(1, 2) = -pixel_ty;
                
            //     ROS_INFO("Transform: scale=%.6f, translation=(%.3fpx, %.3fpx) + fine_tune(%.3f, %.3f)",
            //             scale, pixel_tx - fine_dx, pixel_ty + fine_dy, fine_dx, fine_dy);
                
            //     // 4) Apply transform
            //     cv::Mat aligned;
            //     cv::warpAffine(flipped, aligned, M, cv::Size(cur_W, cur_H), 
            //                 cv::INTER_NEAREST,
            //                 cv::BORDER_CONSTANT,
            //                 cv::Scalar(205));
                
            //     // 5) Flip back (OpenCV->ROS)
            //     cv::flip(aligned, gt_image_raw_, 0);
                
            //     ROS_INFO("✓ GT aligned with affine transform:");
            //     ROS_INFO("  Source: %s (%dx%d) -> Target: (%dx%d)", 
            //             gt_image_path_.c_str(), W_orig, H_orig, cur_W, cur_H);
                
            //     // ═══════════════════════════════════════════════════════════════
            //     // UPDATE METADATA - USE COSTMAP PARAMETERS (same as old code)
            //     // ═══════════════════════════════════════════════════════════════
            //     gt_origin_x_ = cur_origin_x;
            //     gt_origin_y_ = cur_origin_y;
            //     gt_resolution_ = cur_res;
                
            //     ROS_INFO("Final GT origin: (%.3f, %.3f), res: %.6f", 
            //             gt_origin_x_, gt_origin_y_, gt_resolution_);
                
            //     // ═══════════════════════════════════════════════════════════════
            //     // SET GT IN FRONTIERSEARCH - USE COSTMAP PARAMETERS
            //     // ═══════════════════════════════════════════════════════════════
            //     search_->setGtImage(gt_image_raw_);
            //     search_->setYamlOriginRes(gt_origin_x_, gt_origin_y_, gt_resolution_);
            //     search_->seedGT();
                
            //     ROS_INFO("✓ GT loaded and resized (%dx%d)", gt_image_raw_.cols, gt_image_raw_.rows);
            //     ROS_INFO("✓✓✓ GT LOADED PERMANENTLY in constructor (will NEVER reload)");
                
            //     return true;
            // }


            // bool Explore::loadBestGTFromDir(int cur_W, int cur_H, double cur_res)
            // {
            //     // --- Costmap kökeni ve parametreleri ---
            //     auto* cm = costmap_client_.getCostmap();
            //     const double cur_origin_x = cm->getOriginX();
            //     const double cur_origin_y = cm->getOriginY();
            //     const bool have_cur_origin = std::isfinite(cur_origin_x) && std::isfinite(cur_origin_y);

            //     if (gt_dir_.empty() || !fs::exists(gt_dir_)) {
            //         ROS_WARN("gt_dir is empty or does not exist: %s", gt_dir_.c_str());
            //         return false;
            //     }

            //     auto norm_ext = [](const fs::path& p){
            //         std::string e = p.extension().string();
            //         std::transform(e.begin(), e.end(), e.begin(), ::tolower);
            //         return e;
            //     };

            //     struct Cand {
            //         std::string yaml_path;
            //         std::string img_path;
            //         int w{0}, h{0};                 // piksel
            //         bool has_yaml{false};
            //         double res{std::numeric_limits<double>::quiet_NaN()};
            //         double ox{0.0}, oy{0.0};        // origin (m)
            //         double theta{0.0};
            //     };
            //     std::vector<Cand> cands;

            //     auto load_yaml_meta = [&](const fs::path& yaml_path, Cand& c) -> bool {
            //         try {
            //             YAML::Node n = YAML::LoadFile(yaml_path.string());
            //             if (!n || !n["image"]) return false;

            //             fs::path image_path(n["image"].as<std::string>());
            //             if (!image_path.is_absolute())
            //                 image_path = yaml_path.parent_path() / image_path;

            //             cv::Mat img = cv::imread(image_path.string(), cv::IMREAD_GRAYSCALE);
            //             if (img.empty()) return false;

            //             c.yaml_path = yaml_path.string();
            //             c.img_path  = image_path.string();
            //             c.w = img.cols; c.h = img.rows;
            //             c.has_yaml = true;

            //             if (n["resolution"]) c.res = n["resolution"].as<double>();
            //             if (n["origin"] && n["origin"].IsSequence() && n["origin"].size() >= 2) {
            //                 c.ox = n["origin"][0].as<double>();
            //                 c.oy = n["origin"][1].as<double>();
            //                 if (n["origin"].size() >= 3 && n["origin"][2].IsScalar()) {
            //                     try { c.theta = n["origin"][2].as<double>(); } catch (...) { c.theta = 0.0; }
            //                 }
            //             }
            //             return true;
            //         } catch (...) {
            //             return false;
            //         }
            //     };

            //     // ---- 1) YAML'lar ----
            //     for (fs::directory_iterator it(gt_dir_), end; it != end; ++it) {
            //         const fs::path p = it->path();
            //         if (!fs::is_regular_file(p) || norm_ext(p) != ".yaml") continue;

            //         Cand c;
            //         if (!load_yaml_meta(p, c)) continue;
            //         cands.emplace_back(std::move(c));
            //     }

            //     // ---- 2) Sidecar'lı PGM'ler ve yalın PGM'ler ----
            //     auto already = [&](const std::string& path){
            //         return std::any_of(cands.begin(), cands.end(),
            //                         [&](const Cand& c){ return c.img_path == path; });
            //     };

            //     for (fs::directory_iterator it(gt_dir_), end; it != end; ++it) {
            //         const fs::path p = it->path();
            //         if (!fs::is_regular_file(p) || norm_ext(p) != ".pgm") continue;
            //         if (already(p.string())) continue;

            //         cv::Mat img = cv::imread(p.string(), cv::IMREAD_GRAYSCALE);
            //         if (img.empty()) continue;

            //         Cand c;
            //         c.img_path = p.string();
            //         c.w = img.cols; c.h = img.rows;

            //         fs::path sidecar = p; sidecar.replace_extension(".yaml");
            //         if (fs::exists(sidecar) && fs::is_regular_file(sidecar)) {
            //             Cand m = c;
            //             if (load_yaml_meta(sidecar, m)) c = std::move(m);
            //         }

            //         cands.emplace_back(std::move(c));
            //     }

            //     if (cands.empty()) {
            //         ROS_WARN("No GT candidates in %s", gt_dir_.c_str());
            //         return false;
            //     }

            //     // ---- 3) Dünya kapsama kontrolü ----
            //     auto covers_world = [&](const Cand& c)->bool {
            //         if (!have_cur_origin || std::isnan(c.res)) return (c.w >= cur_W && c.h >= cur_H);
            //         const double gt_min_x = c.ox, gt_max_x = c.ox + c.w * c.res;
            //         const double gt_min_y = c.oy, gt_max_y = c.oy + c.h * c.res;
            //         const double cur_min_x = cur_origin_x, cur_max_x = cur_origin_x + cur_W * cur_res;
            //         const double cur_min_y = cur_origin_y, cur_max_y = cur_origin_y + cur_H * cur_res;
            //         return (gt_min_x <= cur_min_x && gt_max_x >= cur_max_x &&
            //                 gt_min_y <= cur_min_y && gt_max_y >= cur_max_y);
            //     };

            //     // ---- 4) EN İYİ ADAYI SEÇ: Önce boyuta, sonra orijine en yakın ----
            //     auto best_it = std::min_element(cands.begin(), cands.end(),
            //         [&](const Cand& a, const Cand& b){
            //             // Seviye 0: Dünyayı kapsamak kritik (varsa)
            //             const bool ac = covers_world(a), bc = covers_world(b);
            //             if (ac != bc) return ac; // Kapsayan kazanır
                        
            //             // Seviye 1: BOYUT FARKI (mutlak fark - en önemli kriter)
            //             long long a_size_diff = std::llabs((long long)a.w - cur_W) + 
            //                                 std::llabs((long long)a.h - cur_H);
            //             long long b_size_diff = std::llabs((long long)b.w - cur_W) + 
            //                                 std::llabs((long long)b.h - cur_H);
                        
            //             if (a_size_diff != b_size_diff) return a_size_diff < b_size_diff;
                        
            //             // Seviye 2: ORİJİN FARKI (Öklid mesafesi - ikinci önemli kriter)
            //             if (have_cur_origin && !std::isnan(a.res) && !std::isnan(b.res)) {
            //                 double a_origin_diff = std::hypot(a.ox - cur_origin_x, a.oy - cur_origin_y);
            //                 double b_origin_diff = std::hypot(b.ox - cur_origin_x, b.oy - cur_origin_y);
                            
            //                 if (std::abs(a_origin_diff - b_origin_diff) > 1e-6) {
            //                     return a_origin_diff < b_origin_diff;
            //                 }
            //             }
                        
            //             // Seviye 3: Resolution farkı
            //             if (cur_res > 0.0 && !std::isnan(a.res) && !std::isnan(b.res)) {
            //                 double a_res_diff = std::fabs(a.res - cur_res);
            //                 double b_res_diff = std::fabs(b.res - cur_res);
            //                 if (std::abs(a_res_diff - b_res_diff) > 1e-9) {
            //                     return a_res_diff < b_res_diff;
            //                 }
            //             }
                        
            //             // Seviye 4: Rotasyon yok olanı tercih et
            //             bool a_has_rot = std::fabs(a.theta) > 1e-9;
            //             bool b_has_rot = std::fabs(b.theta) > 1e-9;
            //             if (a_has_rot != b_has_rot) return !a_has_rot;
                        
            //             // Seviye 5: YAML'lı olanı tercih et (metadata var)
            //             if (a.has_yaml != b.has_yaml) return a.has_yaml;
                        
            //             // Seviye 6: Daha az fazlalık (aşırı büyük haritadan kaçın)
            //             long long a_over = std::max(0, a.w - cur_W) + std::max(0, a.h - cur_H);
            //             long long b_over = std::max(0, b.w - cur_W) + std::max(0, b.h - cur_H);
            //             return a_over < b_over;
            //         });

            //     const Cand chosen = *best_it;

            //     // ---- 5) Seçim bilgisini logla ----
            //     long long size_diff = std::llabs((long long)chosen.w - cur_W) + 
            //                         std::llabs((long long)chosen.h - cur_H);
            //     double origin_diff = have_cur_origin ? 
            //                         std::hypot(chosen.ox - cur_origin_x, chosen.oy - cur_origin_y) : 0.0;
                
            //     // ROS_INFO("Selected GT from %zu candidates:", cands.size());
            //     // ROS_INFO("  File: %s", chosen.img_path.c_str());
            //     // ROS_INFO("  Criteria: size_diff=%lld pixels, origin_diff=%.3fm", size_diff, origin_diff);
            //     // ROS_INFO("  GT size: %dx%d, target: %dx%d", chosen.w, chosen.h, cur_W, cur_H);
            //     // if (have_cur_origin) {
            //     //     ROS_INFO("  GT origin: (%.3f, %.3f), target: (%.3f, %.3f)", 
            //     //              chosen.ox, chosen.oy, cur_origin_x, cur_origin_y);
            //     // }

            //     // ---- 6) Görüntüyü yükle ----
            //     cv::Mat img = cv::imread(chosen.img_path, cv::IMREAD_GRAYSCALE);
            //     if (img.empty()) {
            //         ROS_ERROR("Failed to load chosen GT image: %s", chosen.img_path.c_str());
            //         return false;
            //     }

            //     // ---- 7) Metaları ata ve AFFINE TRANSFORM uygula ----
            //     double ox = 0.0, oy = 0.0, res = cur_res;
            //     if (chosen.has_yaml) {
            //         ox  = chosen.ox;
            //         oy  = chosen.oy;
            //         res = (!std::isnan(chosen.res)) ? chosen.res : cur_res;
                    
            //         // ROS_INFO("Original GT params: origin=(%.3f,%.3f), res=%.6f, theta=%.3f°", 
            //         //          ox, oy, res, chosen.theta * 180.0 / M_PI);
            //     }

            //     // ---- 8) AFFINE TRANSFORM İLE HASSAS HİZALAMA ----
            //     const int W_orig = img.cols, H_orig = img.rows;
                
            //     // 8.1) Resolution scale faktörü
            //     const double scale = cur_res / res;
                
            //     // 8.2) GT'yi önce Y ekseninde flip et (ROS->OpenCV dönüşümü için)
            //     cv::Mat flipped;
            //     cv::flip(img, flipped, 0);
                
            //     // 8.3) Affine transform matrisi oluştur
            //     cv::Mat M = cv::Mat::zeros(2, 3, CV_64F);
                
            //     // Scale komponenti
            //     M.at<double>(0, 0) = scale;
            //     M.at<double>(1, 1) = scale;
                
            //     // Translation komponenti
            //     double world_dx = -cur_origin_x + ox;
            //     double world_dy = cur_origin_y - oy;
                
            //     double pixel_tx = world_dx / cur_res;
            //     double pixel_ty = world_dy / cur_res;

            //     // Fine-tuning parametrelerini uygula
            //     pixel_tx += fine_dx;
            //     pixel_ty -= fine_dy;
                
            //     M.at<double>(0, 2) = pixel_tx;
            //     M.at<double>(1, 2) = -pixel_ty;
                
            //     // // Eğer rotasyon varsa ekle
            //     // if (std::fabs(chosen.theta) > 1e-9) {
            //     //     cv::Point2f center(pixel_tx, -pixel_ty);
            //     //     cv::Mat rot_mat = cv::getRotationMatrix2D(center, -chosen.theta * 180.0 / M_PI, scale);
            //     //     M = rot_mat.clone();
            //     //     M.at<double>(0, 2) += pixel_tx;
            //     //     M.at<double>(1, 2) += -pixel_ty;
            //     // }
                
            //     // 8.4) Transform uygula
            //     cv::Mat aligned;
            //     cv::warpAffine(flipped, aligned, M, cv::Size(cur_W, cur_H), 
            //                 cv::INTER_NEAREST,
            //                 cv::BORDER_CONSTANT,
            //                 cv::Scalar(205));
                
            //     // 8.5) Tekrar flip et (OpenCV->ROS)
            //     cv::flip(aligned, gt_image_raw_, 0);
                
            //     //8.6) Metadata'yı güncelle - COSTMAP parametrelerini kullan
            //     gt_origin_x_ = cur_origin_x;
            //     gt_origin_y_ = cur_origin_y;
            //     gt_resolution_ = cur_res;
                
            //     // ROS_INFO("✓ GT aligned with affine transform:");
            //     // ROS_INFO("  Source: %s (%dx%d) -> Target: (%dx%d)", chosen.img_path.c_str(), W_orig, H_orig, cur_W, cur_H);
            //     // ROS_INFO("  Transform: scale=%.6f, translation=(%.3fpx, %.3fpx) + fine_tune(%.3f, %.3f)",
            //     //          scale, pixel_tx, pixel_ty, fine_dx, fine_dy);
            //     // ROS_INFO("  Final GT origin: (%.3f, %.3f), res: %.6f", gt_origin_x_, gt_origin_y_, gt_resolution_);

            //     return true;
            // }

            bool Explore::loadBestGTFromDir(int cur_W, int cur_H, double cur_res)
            {
                // --- Costmap origin and parameters ---
                auto* cm = costmap_client_.getCostmap();
                const double cur_origin_x = cm->getOriginX();
                const double cur_origin_y = cm->getOriginY();

                if (gt_dir_.empty() || !fs::exists(gt_dir_)) {
                    ROS_WARN("gt_dir is empty or does not exist: %s", gt_dir_.c_str());
                    return false;
                }

                // ═══════════════════════════════════════════════════════════════
                // SIMPLIFIED: Find the single PGM file in directory
                // ═══════════════════════════════════════════════════════════════
                std::string pgm_file;
                std::string yaml_file;
                
                for (fs::directory_iterator it(gt_dir_), end; it != end; ++it) {
                    std::string ext = it->path().extension().string();
                    std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
                    
                    if (ext == ".pgm") {
                        pgm_file = it->path().string();
                    } else if (ext == ".yaml") {
                        yaml_file = it->path().string();
                    }
                }
                
                if (pgm_file.empty()) {
                    ROS_ERROR("No PGM file found in: %s", gt_dir_.c_str());
                    return false;
                }

                // ═══════════════════════════════════════════════════════════════
                // Load image
                // ═══════════════════════════════════════════════════════════════
                cv::Mat img = cv::imread(pgm_file, cv::IMREAD_GRAYSCALE);
                if (img.empty()) {
                    ROS_ERROR("Failed to load GT image: %s", pgm_file.c_str());
                    return false;
                }

                // ═══════════════════════════════════════════════════════════════
                // Read YAML metadata if exists
                // ═══════════════════════════════════════════════════════════════
                double ox = 0.0, oy = 0.0, res = cur_res;
                double theta = 0.0;
                bool has_yaml = false;
                
                if (!yaml_file.empty() && fs::exists(yaml_file)) {
                    try {
                        YAML::Node n = YAML::LoadFile(yaml_file);
                        
                        if (n["resolution"]) {
                            res = n["resolution"].as<double>();
                        }
                        
                        if (n["origin"] && n["origin"].IsSequence() && n["origin"].size() >= 2) {
                            ox = n["origin"][0].as<double>();
                            oy = n["origin"][1].as<double>();
                            if (n["origin"].size() >= 3 && n["origin"][2].IsScalar()) {
                                try { theta = n["origin"][2].as<double>(); } catch (...) { theta = 0.0; }
                            }
                        }
                        
                        has_yaml = true;
                    } catch (...) {
                        ROS_WARN("Failed to parse YAML: %s, using defaults", yaml_file.c_str());
                    }
                }

                // ═══════════════════════════════════════════════════════════════
                // AFFINE TRANSFORM - EXACT SAME AS BEFORE
                // ═══════════════════════════════════════════════════════════════
                const int W_orig = img.cols, H_orig = img.rows;
                
                // Resolution scale factor
                const double scale = cur_res / res;
                
                // Flip GT on Y-axis (ROS->OpenCV conversion)
                cv::Mat flipped;
                cv::flip(img, flipped, 0);
                
                // Create affine transform matrix
                cv::Mat M = cv::Mat::zeros(2, 3, CV_64F);
                
                // Scale component
                M.at<double>(0, 0) = scale;
                M.at<double>(1, 1) = scale;
                
                // Translation component
                double world_dx = -cur_origin_x + ox;
                double world_dy = cur_origin_y - oy;
                
                double pixel_tx = world_dx / cur_res;
                double pixel_ty = world_dy / cur_res;

                // Apply fine-tuning parameters
                pixel_tx += fine_dx;
                pixel_ty -= fine_dy;
                
                M.at<double>(0, 2) = pixel_tx;
                M.at<double>(1, 2) = -pixel_ty;
                
                // Apply transform
                cv::Mat aligned;
                cv::warpAffine(flipped, aligned, M, cv::Size(cur_W, cur_H), 
                            cv::INTER_NEAREST,
                            cv::BORDER_CONSTANT,
                            cv::Scalar(205));
                
                // Flip back (OpenCV->ROS)
                cv::flip(aligned, gt_image_raw_, 0);
                
                // Update metadata - use COSTMAP parameters
                gt_origin_x_ = cur_origin_x;
                gt_origin_y_ = cur_origin_y;
                gt_resolution_ = cur_res;
                
                return true;
            }

           
                

            // void Explore::makePlan()
            // {
            //     // In the Explore constructor and makePlan(), add:
            //     const unsigned int W = costmap_client_.getCostmap()->getSizeInCellsX();
            //     const unsigned int H = costmap_client_.getCostmap()->getSizeInCellsY();
            //     //ROS_INFO_THROTTLE(5.0, "Current costmap size: %ux%u", W, H);

            //     try 
            //     {
            //         if (with_map_completion == 1) {
            //             ros::spinOnce();
            //         }

            //         // Validate costmap early
            //         auto* cm = costmap_client_.getCostmap();
            //         if (!cm) {
            //             ROS_ERROR("Costmap pointer is null");
            //             return;
            //         }
                    


            //         const unsigned int W = cm->getSizeInCellsX();
            //         const unsigned int H = cm->getSizeInCellsY();
            //         const double res = cm->getResolution();

            //         if (W == 0 || H == 0 || res <= 0.0) {
            //             ROS_ERROR("Invalid costmap dimensions: %ux%u, res=%.6f", W, H, res);
            //             return;
            //         }

            //         // Set map parameters
            //         search_->setMapSaverOriginRes(cm->getOriginX(), cm->getOriginY(), res, 
            //                                     static_cast<int>(W), static_cast<int>(H));
                   
                    

            //         // Handle map epoch changes
            //         const uint64_t epoch = costmap_client_.getMapEpoch();

            //         if (epoch != last_map_epoch_) {
            //             search_->invalidateDistanceField();
                        
            //             if (publish_maps_ && full_gt_loaded_) {
            //                 auto gt_start = std::chrono::high_resolution_clock::now();
                            
            //                 // ═══════════════════════════════════════════════════════════════
            //                 // EXTRACT RELEVANT CROP FROM FULL GT
            //                 // ═══════════════════════════════════════════════════════════════
                            
            //                 const int cur_W = W;
            //                 const int cur_H = H;
            //                 const double cur_res = res;
            //                 const double cur_origin_x = cm->getOriginX();
            //                 const double cur_origin_y = cm->getOriginY();
                            
            //                 // Calculate scale
            //                 const double scale = cur_res / full_gt_resolution_;
                            
            //                 // Flip full GT (ROS->OpenCV)
            //                 cv::Mat full_flipped;
            //                 cv::flip(full_gt_image_, full_flipped, 0);
                            
            //                 // Create affine transform matrix
            //                 cv::Mat M = cv::Mat::zeros(2, 3, CV_64F);
            //                 M.at<double>(0, 0) = scale;
            //                 M.at<double>(1, 1) = scale;
                            
            //                 // Translation
            //                 double world_dx = -cur_origin_x + full_gt_origin_x_;
            //                 double world_dy = cur_origin_y - full_gt_origin_y_;
            //                 double pixel_tx = world_dx / cur_res;
            //                 double pixel_ty = world_dy / cur_res;
                            
            //                 // Apply fine-tuning
            //                 pixel_tx += fine_dx;
            //                 pixel_ty -= fine_dy;
                            
            //                 M.at<double>(0, 2) = pixel_tx;
            //                 M.at<double>(1, 2) = -pixel_ty;
                            
            //                 // Extract and transform the relevant crop
            //                 cv::Mat aligned;
            //                 int width = full_flipped.cols;   
            //                 int height = full_flipped.rows;  
            //                 cv::warpAffine(full_flipped, aligned, M, cv::Size(cur_W, cur_H),
            //                             cv::INTER_NEAREST,
            //                             cv::BORDER_CONSTANT,
            //                             cv::Scalar(205));
                            
            //                 // Flip back (OpenCV->ROS)
            //                 cv::flip(aligned, gt_image_raw_, 0);
                            
                            
            //                 // Update metadata to match current costmap
            //                 gt_origin_x_ = cur_origin_x;
            //                 gt_origin_y_ = cur_origin_y;
            //                 gt_resolution_ = cur_res;
                            
            //                 // Set in FrontierSearch
            //                 search_->setGtImage(gt_image_raw_);
            //                 search_->setYamlOriginRes(gt_origin_x_, gt_origin_y_, gt_resolution_);
            //                 //search_->seedGT();
                            
            //                 // Log the operation
            //                 if (log_operations_enabled_ && experiment_logger_) {
            //                     auto gt_end = std::chrono::high_resolution_clock::now();
            //                     double gt_duration_ms = std::chrono::duration<double, std::milli>(gt_end - gt_start).count();
            //                     experiment_logger_->logOperation("GT_loading", gt_duration_ms);
            //                 }
                            
            //                 ROS_DEBUG("GT crop extracted: %dx%d from full %dx%d (%.2f ms)",
            //                         cur_W, cur_H, full_gt_image_.cols, full_gt_image_.rows,
            //                         std::chrono::duration<double, std::milli>(
            //                             std::chrono::high_resolution_clock::now() - gt_start).count());
            //             }
                        
            //             last_map_epoch_ = epoch;
            //         }

                    

            //         auto start_time = std::chrono::high_resolution_clock::now();

            //         // Get robot pose with validation
            //         auto pose = costmap_client_.getRobotPose();
                   
            //         unsigned int mx, my;
            //         if (!cm->worldToMap(pose.position.x, pose.position.y, mx, my)) {
            //             //ROS_ERROR("Robot position out of costmap bounds (x:%.2f y:%.2f)",
            //                         //pose.position.x, pose.position.y);
            //             return;
            //         }

            //         geometry_msgs::Point current_pos = pose.position;
            //         updateTravelDistance(current_pos);

                    
            //         // Publish preprocessed map BEFORE frontier search
            //         //publishPreprocessedMap();

            //         // Find frontiers
                    
            //         auto frontiers = search_->searchFrom(pose.position);

            //         if (frontiers.empty()) {
            //             ROS_INFO("No explorable frontiers remaining");
            //             stop();
            //             return;
            //         }

            //         frontier_blacklist_.erase(
            //             std::remove_if(frontier_blacklist_.begin(), frontier_blacklist_.end(),
            //                 [&](const BlacklistEntry& e){
            //                 const auto& p = e.position;
            //                 bool still_exists = false;
            //                 for (const auto& f : frontiers) {
            //                     const double FRONTIER_MATCH_EPS = 0.5; 
            //                     if (std::hypot(f.safest_point.x - p.x, f.safest_point.y - p.y) < FRONTIER_MATCH_EPS) {
            //                     still_exists = true;
            //                     break;
            //                     }
            //                 }
            //                 return !still_exists;
            //                 }),
            //             frontier_blacklist_.end());


            //         // Check if any non-blacklisted frontiers exist
            //         auto valid_frontier = std::find_if(frontiers.begin(), frontiers.end(),
            //                                         [this](const frontier_exploration::Frontier& f) {
            //                                             return !goalOnBlacklist(f.safest_point) ;
            //                                         });

            //         if (valid_frontier == frontiers.end()) {
            //             ROS_INFO("All remaining frontiers are blacklisted. Exploration complete.");
            //             ROS_ERROR("STOPPING: %zu frontiers, %zu blacklisted", 
            //             frontiers.size(), frontier_blacklist_.size());
            //             stop();
            //             return;
            //         }

            //         //ROS_INFO("Found %zu frontiers. Best cost: %.3f", frontiers.size(), frontiers.front().cost);

            //         // Process frontiers for publishing
            //         std::vector<explore_lite::FrontierMsg> frontiers_msg;
            //         geometry_msgs::Point target_position;
            //         frontier_exploration::Frontier target_frontier;
            //         bool found_target = false;
            //         double min_distance;


                    
            //         // Count valid frontiers ONCE (only when spatial filtering is enabled)
            //         // size_t valid_frontier_count = 0;
            //         // if (use_completed_map_ == 1 && use_filtering_ == 1) {
            //         //     for (const auto& f : frontiers) {
            //         //         if (!f.isFlaggedByAnyFilter()) {
            //         //             valid_frontier_count++;
            //         //         }
            //         //     }
            //         //     ROS_INFO("Valid frontiers: %zu / %zu", valid_frontier_count, frontiers.size());
            //         // }


            //         // ✅ MAIN LOOP - Process ALL frontiers
            //         for (auto& frontier : frontiers) {
                        
            //             bool should_blacklist = frontier.isFlaggedByAnyFilter();
    
            //             if (should_blacklist && use_completed_map_ == 1 && use_filtering_ == 1) {
            //                 // Spatial-aware filtering:
            //                 // Blacklist flagged frontier ONLY IF it has >=1 VALID alternative nearby.
            //                 size_t nearby_any = 0;
            //                 const double NEIGHBORHOOD_RADIUS = 15.0;

            //                 for (const auto& other : frontiers) {
            //                     if (&other == &frontier) continue;
            //                     if (goalOnBlacklist(other.safest_point)) continue; // optional; see note below
            //                     if (other.isFlaggedByAnyFilter()) continue; 

            //                     double dx = frontier.centroid.x - other.centroid.x;
            //                     double dy = frontier.centroid.y - other.centroid.y;
            //                     double dist = std::hypot(dx, dy);

            //                     if (dist < NEIGHBORHOOD_RADIUS) {
            //                         nearby_any++;
            //                     }
            //                 }

            //                 if (nearby_any >= 1) {
            //                     // blacklist because there exists ANY other frontier nearby
            //                     if (!goalOnBlacklist(frontier.safest_point)) {
            //                         frontier_blacklist_.push_back(BlacklistEntry(frontier.safest_point,
            //                                                                     BlacklistReason::ARTIFICIAL_AREA,
            //                                                                     1.0));
            //                         ROS_DEBUG("Blacklisting flagged frontier (has %zu other frontiers nearby)", nearby_any);
            //                     }
                                
            //                     continue;
            //                 } else {
            //                     // alone: do NOT blacklist now; rescue logic will handle old blacklist entries too
            //                     ROS_WARN("Keeping flagged frontier (no other frontiers nearby)");
            //                 }



            //             }
                        
            //             explore_lite::FrontierMsg frontier_msg;
            //             frontier_msg.size = frontier.size;
            //             frontier_msg.min_distance = frontier.min_distance;
                        
            //             frontier_msg.cost = frontier.cost;

            //             //ROS_ERROR("frontier.cost: %.3f",frontier.cost);
            //             frontier_msg.initial = frontier.initial;
            //             frontier_msg.centroid = frontier.centroid;
            //             frontier_msg.middle = frontier.middle;
            //             frontier_msg.points = frontier.points;
            //             frontier_msg.map_resolution = frontier.map_resolution;
            //             frontier_msg.is_in_blacklist = goalOnBlacklist(frontier.safest_point);
            //             frontier_msg.is_target = false;

            //             if (!found_target && !frontier_msg.is_in_blacklist) {
            //                 target_position = frontier.safest_point;                            
            //                 target_frontier = frontier;
            //                 frontier_msg.is_target = true;
            //                 found_target = true;
            //                 min_distance = frontier.min_distance;
            //                 //selected_frontier_pub_.publish(frontier_msg);
            //             }

            //             if (!frontier_msg.is_in_blacklist) {
            //                 frontiers_msg.push_back(std::move(frontier_msg));
            //             }                    
            //         }

            //         // After selecting target
            //         if (found_target) {
            //             // Check if target is too far
            //             double dx = target_position.x - pose.position.x;
            //             double dy = target_position.y - pose.position.y;
            //             double target_distance = std::sqrt(dx*dx + dy*dy);
                        
            //             const double NEIGHBORHOOD_THRESHOLD = 15.0;  // Same as NEIGHBORHOOD_RADIUS
                        
            //             if (target_distance > NEIGHBORHOOD_THRESHOLD) {
            //                 // Target is far! Check for nearby blacklisted frontiers
                            
            //                 std::vector<std::pair<geometry_msgs::Point, double>> nearby_blacklisted;

            //                 for (const auto& bl_entry : frontier_blacklist_) {
            //                     geometry_msgs::Point bl_point = bl_entry.position;  // ✅ Use .position

            //                     // ✅ Find matching frontier and check if it's filter-flagged
            //                     bool is_filtered = false;
            //                     for (const auto& f : frontiers) {
            //                         double dx = f.safest_point.x - bl_point.x;
            //                         double dy = f.safest_point.y - bl_point.y;
            //                         if (std::sqrt(dx*dx + dy*dy) < 0.5) {
            //                             is_filtered = f.isFlaggedByAnyFilter();
            //                             break;
            //                         }
            //                     }
                                
            //                     // ✅ Only rescue if blacklisted due to filtering
            //                     if (!is_filtered) {
            //                         continue;  // Skip non-filtered blacklisted frontiers
            //                     }
                                
            //                     double dx_bl = bl_point.x - pose.position.x;
            //                     double dy_bl = bl_point.y - pose.position.y;
            //                     double dist_from_robot = std::sqrt(dx_bl*dx_bl + dy_bl*dy_bl);
                                
            //                     if (dist_from_robot < NEIGHBORHOOD_THRESHOLD) {
            //                         nearby_blacklisted.push_back(std::make_pair(bl_point, dist_from_robot));
            //                     }
            //                 }

            //                 // If there are blacklisted frontiers nearby
            //                 if (!nearby_blacklisted.empty()) {
            //                     // Sort by distance from robot (furthest first)
            //                     std::sort(nearby_blacklisted.begin(), nearby_blacklisted.end(),
            //                             [](const std::pair<geometry_msgs::Point, double>& a, 
            //                                 const std::pair<geometry_msgs::Point, double>& b) { 
            //                                 return a.second > b.second; 
            //                             });
                                
            //                     // Rescue the FURTHEST nearby blacklisted frontier
            //                     geometry_msgs::Point rescued = nearby_blacklisted[0].first;
                                
            //                     auto it = std::find_if(frontier_blacklist_.begin(), frontier_blacklist_.end(),
            //                                         [&rescued](const BlacklistEntry& entry) {  // ✅ Changed parameter type
            //                                             double dx = entry.position.x - rescued.x;
            //                                             double dy = entry.position.y - rescued.y;
            //                                             return std::sqrt(dx*dx + dy*dy) < 0.5;
            //                                         });
                                
            //                     if (it != frontier_blacklist_.end()) {
            //                         frontier_blacklist_.erase(it);
                                    
            //                         // Find min_distance
            //                         double rescued_min_distance = min_distance;
            //                         for (const auto& f : frontiers) {
            //                             double dx = f.safest_point.x - rescued.x;
            //                             double dy = f.safest_point.y - rescued.y;
            //                             if (std::sqrt(dx*dx + dy*dy) < 0.5) {
            //                                 rescued_min_distance = f.min_distance;
            //                                 break;
            //                             }
            //                         }
                                    
            //                         ROS_WARN("Rescued blacklisted frontier at (%.2f, %.2f)", rescued.x, rescued.y);
                                    
            //                         target_position = rescued;
            //                         min_distance = rescued_min_distance;
            //                     }
            //                 }                                                   
            //             }
            //         }


                
            //         if(publish_maps_)
            //         {
            //             publishMaps();
            //         }


            //         if (visualize_) 
            //         {
            //             // // Create clean list for visualization
            //             // std::vector<frontier_exploration::Frontier> vis_frontiers;
            //             // for (const auto& f : frontiers) {
            //             //     if (!goalOnBlacklist(f.safest_point)) {
            //             //         vis_frontiers.push_back(f);
            //             //     }
            //             // }

                            
            //             // 3. Publish new markers
            //             visualizeFrontiers(frontiers, target_position);
                                
            //             // Wait 500ms for the new markers to appear before proceeding
            //             //ros::Duration(0.5).sleep(); 
            //         }
                        
                        
            //         // --- Goal re-issue debounce: aynı hedefi sürekli yeniden göndermeyelim ---
            //         static geometry_msgs::Point last_goal;
            //         static bool have_last_goal = false;

            //         auto goal_dist = [&](const geometry_msgs::Point& a, const geometry_msgs::Point& b)
            //         {
            //             return std::hypot(a.x - b.x, a.y - b.y);
            //         };

            //         const double reissue_thresh = 0.20; // 20 cm değişim yoksa yeniden gönderme
            //         if (have_last_goal && goal_dist(last_goal, target_position) < reissue_thresh) {
            //             //ROS_DEBUG("Goal unchanged (<%.2fm), not re-sending", reissue_thresh);
            //         } else {

            //             // ============ YENİ KOD BURAYA ============
            //             // Eğer aktif bir target varsa ve YENİ bir target seçildiyse
            //             if (has_active_target_) {
            //                 double old_dx = last_goal.x - current_target_.x;
            //                 double old_dy = last_goal.y - current_target_.y;
            //                 double dist_from_old_target = std::sqrt(old_dx*old_dx + old_dy*old_dy);
                                
            //                 // Yeni target eskisinden farklı mı? (>1m fark varsa)
            //                 double new_dx = target_position.x - current_target_.x;
            //                 double new_dy = target_position.y - current_target_.y;
            //                 double target_change_dist = std::sqrt(new_dx*new_dx + new_dy*new_dy);
                                
            //                 if (target_change_dist > 1.0) {
            //                     // Target değişti - önceki target'a ulaşılamadı
            //                     double elapsed_time = (ros::Time::now() - target_start_time_).toSec();
            //                     double travel_dist = total_distance_traveled_ - target_start_distance_;
                                    
            //                     if (experiment_logger_) {
            //                         // Özel bir log tipi: target_changed veya target_abandoned
            //                         std::string reason = "changed_to_new_target";
            //                         experiment_logger_->logTarget(current_target_, reason);
            //                     }
                                    
            //                     // ROS_WARN("Target changed/abandoned after %.1f sec (%.2f m traveled)", 
            //                     //         elapsed_time, travel_dist);
            //                 }
            //                 // Eğer target'a çok yakınsak (0.5m içinde), başarılı sayalım
            //                 else if (dist_from_old_target < 0.5) {
            //                     double elapsed_time = (ros::Time::now() - target_start_time_).toSec();
            //                     double travel_dist = total_distance_traveled_ - target_start_distance_;
                                    
            //                     if (experiment_logger_) {
            //                         experiment_logger_->logTargetReached(current_target_, elapsed_time, travel_dist);
            //                     }
                                    
            //                     // ROS_INFO("✓ Target reached in %.1f sec, traveled %.2f m", 
            //                     //         elapsed_time, travel_dist);
            //                 }
            //             }
                            
            //             // Yeni target'ı kaydet
            //             current_target_ = target_position;
            //             target_start_time_ = ros::Time::now();
            //             target_start_distance_ = total_distance_traveled_;
            //             has_active_target_ = true;
                            
            //             if (experiment_logger_) {
            //                 experiment_logger_->logTarget(target_position, "frontier_selected");
            //             }
            //             // ============ YENİ KOD BİTİŞ ============
                            
            //             if (!sendNavigationGoal(target_position, min_distance)) {
            //                 ROS_ERROR("Failed to send navigation goal");
            //                 return;
            //             }
            //             have_last_goal = true;
            //             last_goal = target_position;
            //             //ROS_INFO("Sent goal (%.2f, %.2f)", target_position.x, target_position.y);
            //         }


            //         // Log timing
            //         auto duration = std::chrono::duration<double, std::milli>(
            //             std::chrono::high_resolution_clock::now() - start_time);
            //         ////ROS_DEBUG("Planning cycle took %.2f ms", duration.count());

            //         if (log_operations_enabled_ && experiment_logger_) {
            //             experiment_logger_->logOperation("makePlan_cycle", duration.count());
            //         }


            //     } catch (const std::exception& e) {
            //         ROS_ERROR("Exception in makePlan: %s", e.what());
            //     } catch (...) {
            //         ROS_ERROR("Unknown exception in makePlan");
            //     }
            // }

            // void Explore::makePlan()
            // {
            //     try
            //     {
            //         if (with_map_completion == 1) {
            //             ros::spinOnce();
            //         }

            //         auto* cm = costmap_client_.getCostmap();
            //         if (!cm) {
            //             ROS_ERROR("Costmap pointer is null");
            //             return;
            //         }

            //         const unsigned int W = cm->getSizeInCellsX();
            //         const unsigned int H = cm->getSizeInCellsY();
            //         const double res = cm->getResolution();

            //         if (W == 0 || H == 0 || res <= 0.0) {
            //             ROS_ERROR("Invalid costmap dimensions: %ux%u, res=%.6f", W, H, res);
            //             return;
            //         }

            //         search_->setMapSaverOriginRes(cm->getOriginX(), cm->getOriginY(), res,
            //                                     static_cast<int>(W), static_cast<int>(H));

            //         const uint64_t epoch = costmap_client_.getMapEpoch();
            //         if (epoch != last_map_epoch_) {
            //             search_->invalidateDistanceField();

            //             if (publish_maps_ && full_gt_loaded_) {
            //                 auto gt_start = std::chrono::high_resolution_clock::now();

            //                 const int cur_W = W;
            //                 const int cur_H = H;
            //                 const double cur_res = res;
            //                 const double cur_origin_x = cm->getOriginX();
            //                 const double cur_origin_y = cm->getOriginY();

            //                 const double scale = cur_res / full_gt_resolution_;

            //                 cv::Mat full_flipped;
            //                 cv::flip(full_gt_image_, full_flipped, 0);

            //                 cv::Mat M = cv::Mat::zeros(2, 3, CV_64F);
            //                 M.at<double>(0, 0) = scale;
            //                 M.at<double>(1, 1) = scale;

            //                 double world_dx = -cur_origin_x + full_gt_origin_x_;
            //                 double world_dy = cur_origin_y - full_gt_origin_y_;
            //                 double pixel_tx = world_dx / cur_res;
            //                 double pixel_ty = world_dy / cur_res;

            //                 pixel_tx += fine_dx;
            //                 pixel_ty -= fine_dy;

            //                 M.at<double>(0, 2) = pixel_tx;
            //                 M.at<double>(1, 2) = -pixel_ty;

            //                 cv::Mat aligned;
            //                 cv::warpAffine(full_flipped, aligned, M, cv::Size(cur_W, cur_H),
            //                             cv::INTER_NEAREST,
            //                             cv::BORDER_CONSTANT,
            //                             cv::Scalar(205));

            //                 cv::flip(aligned, gt_image_raw_, 0);

            //                 gt_origin_x_ = cur_origin_x;
            //                 gt_origin_y_ = cur_origin_y;
            //                 gt_resolution_ = cur_res;

            //                 search_->setGtImage(gt_image_raw_);
            //                 search_->setYamlOriginRes(gt_origin_x_, gt_origin_y_, gt_resolution_);

            //                 if (log_operations_enabled_ && experiment_logger_) {
            //                     auto gt_end = std::chrono::high_resolution_clock::now();
            //                     double gt_duration_ms =
            //                         std::chrono::duration<double, std::milli>(gt_end - gt_start).count();
            //                     experiment_logger_->logOperation("GT_loading", gt_duration_ms);
            //                 }

            //                 ROS_DEBUG("GT crop extracted: %dx%d from full %dx%d (%.2f ms)",
            //                         cur_W, cur_H, full_gt_image_.cols, full_gt_image_.rows,
            //                         std::chrono::duration<double, std::milli>(
            //                             std::chrono::high_resolution_clock::now() - gt_start).count());
            //             }

            //             last_map_epoch_ = epoch;
            //         }

            //         auto start_time = std::chrono::high_resolution_clock::now();

            //         auto pose = costmap_client_.getRobotPose();

            //         unsigned int mx, my;
            //         if (!cm->worldToMap(pose.position.x, pose.position.y, mx, my)) {
            //             return;
            //         }

            //         updateTravelDistance(pose.position);

            //         auto frontiers = search_->searchFrom(pose.position);
            //         if (frontiers.empty()) {
            //             ROS_INFO("No explorable frontiers remaining");
            //             stop();
            //             return;
            //         }

            //         // Remove stale blacklist entries (frontier no longer exists)
            //         frontier_blacklist_.erase(
            //             std::remove_if(frontier_blacklist_.begin(), frontier_blacklist_.end(),
            //                         [&](const BlacklistEntry& e) {
            //                             const auto& p = e.position;
            //                             bool still_exists = false;
            //                             for (const auto& f : frontiers) {
            //                                 const double FRONTIER_MATCH_EPS = 0.5;
            //                                 if (std::hypot(f.safest_point.x - p.x, f.safest_point.y - p.y) < FRONTIER_MATCH_EPS) {
            //                                 //                                                              
            //                                     still_exists = true;
            //                                     break;
            //                                 }
            //                             }
            //                             return !still_exists;
            //                         }),
            //             frontier_blacklist_.end());

            //         // Find any non-blacklisted frontier
            //         auto valid_frontier = std::find_if(
            //             frontiers.begin(), frontiers.end(),
            //             [this](const frontier_exploration::Frontier& f) {
            //                 return !goalOnBlacklist(f.safest_point);
            //             });

            //         std::vector<explore_lite::FrontierMsg> frontiers_msg;
            //         geometry_msgs::Point target_position;
            //         frontier_exploration::Frontier target_frontier;
            //         bool found_target = false;
            //         double min_distance = 0.0;

            //         // fallback debug marker state (RVIZ)
            //         has_last_fallback_goal_ = false;

            //         // fallback goal already sent?
            //         bool goal_sent_in_fallback = false;

            //         // Helpers for fallback selection
            //         auto getCostAt = [&](double wx, double wy, unsigned char& out_cost) -> bool {
            //             unsigned int gx, gy;
            //             if (!cm->worldToMap(wx, wy, gx, gy)) return false;
            //             out_cost = cm->getCost(gx, gy);
            //             return true;
            //         };

            //         auto isTraversable = [&](double wx, double wy) -> bool {
            //             unsigned char c;
            //             if (!getCostAt(wx, wy, c)) return false;

            //             if (c == costmap_2d::LETHAL_OBSTACLE) return false;
            //             if (c == costmap_2d::INSCRIBED_INFLATED_OBSTACLE) return false;

            //             // FREE + UNKNOWN kesin geçilebilir kabul
            //             if (c == costmap_2d::FREE_SPACE) return true;
            //             if (c == costmap_2d::NO_INFORMATION) return true;

            //             // Diğer costlar (inflation band vb.) -> geçilebilir bırak
            //             return true;
            //         };

            //         auto isUnknown = [&](double wx, double wy) -> bool {
            //             unsigned char c;
            //             if (!getCostAt(wx, wy, c)) return false;
            //             return (c == costmap_2d::NO_INFORMATION);
            //         };

            //         auto findCandidatePreferUnknown = [&](const geometry_msgs::Point& desired,
            //                                             geometry_msgs::Point& out) -> bool
            //         {
            //             // önce desired noktasını dene
            //             if (isTraversable(desired.x, desired.y)) { out = desired; return true; }

            //             // sonra çevresinde: UNKNOWN varsa önce onu seç
            //             const double SAMPLE_R = 1.0;
            //             const int SAMPLE_N = 24;

            //             bool have_trav = false;
            //             geometry_msgs::Point best_trav;

            //             for (int i = 0; i < SAMPLE_N; ++i) {
            //                 const double ang = (2.0 * M_PI * i) / SAMPLE_N;
            //                 const double wx = desired.x + SAMPLE_R * std::cos(ang);
            //                 const double wy = desired.y + SAMPLE_R * std::sin(ang);

            //                 if (!isTraversable(wx, wy)) continue;

            //                 // UNKNOWN bulunduysa direkt seç
            //                 if (isUnknown(wx, wy)) {
            //                     out.x = wx; out.y = wy; out.z = 0.0;
            //                     return true;
            //                 }

            //                 // yoksa traversable aday tut
            //                 if (!have_trav) {
            //                     have_trav = true;
            //                     best_trav.x = wx; best_trav.y = wy; best_trav.z = 0.0;
            //                 }
            //             }

            //             if (have_trav) { out = best_trav; return true; }
            //             return false;
            //         };

            //         if (valid_frontier == frontiers.end())
            //         {
            //             // ---- FALLBACK: filtering kaynaklı blacklist entry'lerine yakın UNKNOWN hedef dene ----
            //             const double MATCH_EPS = 0.5;
            //             const double BEYOND_FRONTIER = 1.0;   // frontier'in ötesine (robot->frontier doğrultusunda)

            //             struct BLItem {
            //                 geometry_msgs::Point p;
            //                 double dr;
            //                 double min_dist;
            //             };

            //             std::vector<BLItem> bl_items;
            //             bl_items.reserve(frontier_blacklist_.size());

            //             // Filtering kaynaklı olanları topla
            //             for (const auto& bl_entry : frontier_blacklist_) {
            //                 const geometry_msgs::Point& p = bl_entry.position;

            //                 bool matched = false;
            //                 bool is_filtered = false;
            //                 double matched_min_dist = 0.0;

            //                 for (const auto& f : frontiers) {
            //                     if (std::hypot(f.safest_point.x - p.x, f.safest_point.y - p.y) < MATCH_EPS) {
            //                         matched = true;
            //                         is_filtered = f.isFlaggedByAnyFilter();
            //                         matched_min_dist = f.min_distance;
            //                         break;
            //                     }
            //                 }
            //                 if (!matched) continue;
            //                 if (!is_filtered) continue;

            //                 const double dr = std::hypot(p.x - pose.position.x, p.y - pose.position.y);
            //                 bl_items.push_back({p, dr, matched_min_dist});
            //             }

            //             if (bl_items.empty()) {
            //                 ROS_WARN("All frontiers blacklisted, but no FILTERED blacklist entries match current frontiers. Exploration complete.");
            //                 ROS_ERROR("STOPPING: %zu frontiers, %zu blacklisted", frontiers.size(), frontier_blacklist_.size());
            //                 stop();
            //                 return;
            //             }

            //             std::sort(bl_items.begin(), bl_items.end(),
            //                     [](const BLItem& a, const BLItem& b) { return a.dr < b.dr; });

            //             bool fallback_ok = false;

            //             // Sırayla dene: move_base kabul edene kadar devam
            //             for (const auto& item : bl_items) {
            //                 const geometry_msgs::Point& bl = item.p;

            //                 const double vx = bl.x - pose.position.x;
            //                 const double vy = bl.y - pose.position.y;
            //                 const double L  = std::hypot(vx, vy);
            //                 if (L < 1e-6) continue;

            //                 const double ux = vx / L;
            //                 const double uy = vy / L;

            //                 // frontier'in "ötesi"
            //                 geometry_msgs::Point desired;
            //                 desired.x = bl.x + BEYOND_FRONTIER * ux;
            //                 desired.y = bl.y + BEYOND_FRONTIER * uy;
            //                 desired.z = 0.0;

            //                 geometry_msgs::Point candidate_goal;
            //                 if (!findCandidatePreferUnknown(desired, candidate_goal)) {
            //                     continue;
            //                 }

            //                 // move_base kabul ederse burada çık
            //                 if (sendNavigationGoal(candidate_goal, item.min_dist)) {
            //                     // ✅ Cost logging ekledik
            //                     unsigned char goal_cost = 255; // default
            //                     getCostAt(candidate_goal.x, candidate_goal.y, goal_cost);

            //                     target_position = candidate_goal;
            //                     min_distance = item.min_dist;
            //                     found_target = true;

            //                     last_fallback_goal_ = candidate_goal;
            //                     has_last_fallback_goal_ = true;

            //                     fallback_ok = true;
            //                     goal_sent_in_fallback = true;

            //                     ROS_WARN("Fallback goal sent (prefer UNKNOWN): (%.2f, %.2f) [base frontier %.2f, %.2f], cost=%d",
            //                             candidate_goal.x, candidate_goal.y, bl.x, bl.y, goal_cost);
            //                     break;
            //                 } else {
            //                     ROS_WARN("Fallback candidate rejected: (%.2f, %.2f). Trying next...",
            //                             candidate_goal.x, candidate_goal.y);
            //                 }
            //             }

            //             if (!fallback_ok) {
            //                 ROS_INFO("All remaining frontiers are blacklisted; tried all filtered blacklist entries and could not send any fallback goal.");
            //                 ROS_ERROR("STOPPING: %zu frontiers, %zu blacklisted", frontiers.size(), frontier_blacklist_.size());
            //                 stop();
            //                 return;
            //             }
            //         }
            //         else
            //         {
            //             // MAIN LOOP - Process ALL frontiers
            //             for (auto& frontier : frontiers)
            //             {
            //                 bool should_blacklist = frontier.isFlaggedByAnyFilter();

            //                 if (should_blacklist && use_completed_map_ == 1 && use_filtering_ == 1) {
            //                     // size_t nearby_any = 0;
            //                     // const double NEIGHBORHOOD_RADIUS = 15.0;

            //                     // for (const auto& other : frontiers) {
            //                     //     if (&other == &frontier) continue;
            //                     //     if (goalOnBlacklist(other.safest_point)) continue;
            //                     //     if (other.isFlaggedByAnyFilter()) continue;

            //                     //     const double dist = std::hypot(frontier.centroid.x - other.centroid.x,
            //                     //                                 frontier.centroid.y - other.centroid.y);

            //                     //     if (dist < NEIGHBORHOOD_RADIUS) {
            //                     //         nearby_any++;
            //                     //     }
            //                     // }

            //                     // if (nearby_any >= 1) {
            //                         if (!goalOnBlacklist(frontier.safest_point)) {
            //                             frontier_blacklist_.push_back(BlacklistEntry(frontier.safest_point,
            //                                                                         BlacklistReason::ARTIFICIAL_AREA,
            //                                                                         1.0));
            //                             //ROS_DEBUG("Blacklisting flagged frontier (has %zu other frontiers nearby)", nearby_any);
            //                         }
            //                     //     continue;
            //                     // } else {
            //                     //     ROS_WARN("Keeping flagged frontier (no other frontiers nearby)");
            //                     // }
            //                 }

            //                 explore_lite::FrontierMsg frontier_msg;
            //                 frontier_msg.size = frontier.size;
            //                 frontier_msg.min_distance = frontier.min_distance;
            //                 frontier_msg.cost = frontier.cost;
            //                 frontier_msg.initial = frontier.initial;
            //                 frontier_msg.centroid = frontier.centroid;
            //                 frontier_msg.middle = frontier.middle;
            //                 frontier_msg.points = frontier.points;
            //                 frontier_msg.map_resolution = frontier.map_resolution;
            //                 frontier_msg.is_in_blacklist = goalOnBlacklist(frontier.safest_point);
            //                 frontier_msg.is_target = false;

            //                 if (!found_target && !frontier_msg.is_in_blacklist) {
            //                     target_position = frontier.safest_point;
            //                     target_frontier = frontier;
            //                     frontier_msg.is_target = true;
            //                     found_target = true;
            //                     min_distance = frontier.min_distance;
            //                 }

            //                 if (!frontier_msg.is_in_blacklist) {
            //                     frontiers_msg.push_back(std::move(frontier_msg));
            //                 }
            //             }

            //             // Midpoint rescue logic (mevcut mantığın)
            //             if (found_target) {
            //                 const double target_distance = std::hypot(target_position.x - pose.position.x,
            //                                                         target_position.y - pose.position.y);

            //                 const double NEIGHBORHOOD_THRESHOLD = 15.0;

            //                 if (target_distance > NEIGHBORHOOD_THRESHOLD) {

            //                     const double MATCH_EPS = 0.5;
            //                     const int max_k = static_cast<int>(std::ceil(target_distance / NEIGHBORHOOD_THRESHOLD));

            //                     geometry_msgs::Point mid;
            //                     mid.x = 0.5 * (pose.position.x + target_position.x);
            //                     mid.y = 0.5 * (pose.position.y + target_position.y);
            //                     mid.z = 0.0;

            //                     for (int k = 1; k <= max_k; ++k) {
            //                         const double search_radius = k * NEIGHBORHOOD_THRESHOLD;

            //                         bool found_candidate = false;
            //                         geometry_msgs::Point best_point;
            //                         double best_score = std::numeric_limits<double>::infinity();

            //                         for (const auto& bl_entry : frontier_blacklist_) {
            //                             const geometry_msgs::Point& bl_point = bl_entry.position;

            //                             const double dist_from_robot = std::hypot(bl_point.x - pose.position.x,
            //                                                                     bl_point.y - pose.position.y);

            //                             if (dist_from_robot >= search_radius) continue;

            //                             bool matched_frontier = false;
            //                             bool is_filtered = false;

            //                             for (const auto& f : frontiers) {
            //                                 if (std::hypot(f.safest_point.x - bl_point.x,
            //                                             f.safest_point.y - bl_point.y) < MATCH_EPS) {
            //                                     matched_frontier = true;
            //                                     is_filtered = f.isFlaggedByAnyFilter();
            //                                     break;
            //                                 }
            //                             }

            //                             if (!matched_frontier) continue;
            //                             if (!is_filtered) continue;

            //                             const double score = std::hypot(bl_point.x - mid.x, bl_point.y - mid.y);
            //                             if (score < best_score) {
            //                                 best_score = score;
            //                                 best_point = bl_point;
            //                                 found_candidate = true;
            //                             }
            //                         }

            //                         if (found_candidate) {
            //                             auto it = std::find_if(frontier_blacklist_.begin(), frontier_blacklist_.end(),
            //                                                 [&](const BlacklistEntry& entry) {
            //                                                     return std::hypot(entry.position.x - best_point.x,
            //                                                                         entry.position.y - best_point.y) < MATCH_EPS;
            //                                                 });

            //                             if (it != frontier_blacklist_.end()) {
            //                                 frontier_blacklist_.erase(it);

            //                                 double rescued_min_distance = min_distance;
            //                                 for (const auto& f : frontiers) {
            //                                     if (std::hypot(f.safest_point.x - best_point.x,
            //                                                 f.safest_point.y - best_point.y) < MATCH_EPS) {
            //                                         rescued_min_distance = f.min_distance;
            //                                         break;
            //                                     }
            //                                 }

            //                                 ROS_WARN("Rescued blacklisted frontier at (%.2f, %.2f) within %d*NEIGHBORHOOD (closest to midpoint)",
            //                                         best_point.x, best_point.y, k);

            //                                 target_position = best_point;
            //                                 min_distance = rescued_min_distance;
            //                             }
            //                             break;
            //                         }
            //                     }
            //                 }
            //             }
            //         }

            //         if (!found_target) {
            //             ROS_WARN("No target selected. Stopping to avoid undefined target.");
            //             stop();
            //             return;
            //         }

            //         if (publish_maps_) {
            //             publishMaps();
            //         }

            //         if (visualize_) {
            //             visualizeFrontiers(frontiers, target_position);
            //         }

            //         // --- Goal re-issue debounce ---
            //         static geometry_msgs::Point last_goal;
            //         static bool have_last_goal = false;

            //         auto goal_dist = [&](const geometry_msgs::Point& a, const geometry_msgs::Point& b) {
            //             return std::hypot(a.x - b.x, a.y - b.y);
            //         };

            //         const double reissue_thresh = 0.20;

            //         // fallback içinde goal zaten gönderildiyse tekrar gönderme
            //         if (!goal_sent_in_fallback)
            //         {
            //             if (!(have_last_goal && goal_dist(last_goal, target_position) < reissue_thresh))
            //             {
            //                 if (has_active_target_) {
            //                     const double old_dx = last_goal.x - current_target_.x;
            //                     const double old_dy = last_goal.y - current_target_.y;
            //                     const double dist_from_old_target = std::sqrt(old_dx*old_dx + old_dy*old_dy);

            //                     const double new_dx = target_position.x - current_target_.x;
            //                     const double new_dy = target_position.y - current_target_.y;
            //                     const double target_change_dist = std::sqrt(new_dx*new_dx + new_dy*new_dy);

            //                     if (target_change_dist > 1.0) {
            //                         if (experiment_logger_) {
            //                             experiment_logger_->logTarget(current_target_, "changed_to_new_target");
            //                         }
            //                     }
            //                     else if (dist_from_old_target < 0.5) {
            //                         const double elapsed_time = (ros::Time::now() - target_start_time_).toSec();
            //                         const double travel_dist = total_distance_traveled_ - target_start_distance_;

            //                         if (experiment_logger_) {
            //                             experiment_logger_->logTargetReached(current_target_, elapsed_time, travel_dist);
            //                         }
            //                     }
            //                 }

            //                 current_target_ = target_position;
            //                 target_start_time_ = ros::Time::now();
            //                 target_start_distance_ = total_distance_traveled_;
            //                 has_active_target_ = true;

            //                 if (experiment_logger_) {
            //                     experiment_logger_->logTarget(target_position, "frontier_selected");
            //                 }

            //                 if (!sendNavigationGoal(target_position, min_distance)) {
            //                     ROS_ERROR("Failed to send navigation goal");
            //                     return;
            //                 }

            //                 have_last_goal = true;
            //                 last_goal = target_position;
            //             }
            //         }
            //         else
            //         {
            //             // fallback içinde goal gönderildi: state güncelle
            //             current_target_ = target_position;
            //             target_start_time_ = ros::Time::now();
            //             target_start_distance_ = total_distance_traveled_;
            //             has_active_target_ = true;

            //             have_last_goal = true;
            //             last_goal = target_position;

            //             if (experiment_logger_) {
            //                 experiment_logger_->logTarget(target_position, "fallback_goal_sent");
            //             }
            //         }

            //         auto duration = std::chrono::duration<double, std::milli>(
            //             std::chrono::high_resolution_clock::now() - start_time);

            //         if (log_operations_enabled_ && experiment_logger_) {
            //             experiment_logger_->logOperation("makePlan_cycle", duration.count());
            //         }
            //     }
            //     catch (const std::exception& e) {
            //         ROS_ERROR("Exception in makePlan: %s", e.what());
            //     }
            //     catch (...) {
            //         ROS_ERROR("Unknown exception in makePlan");
            //     }
            // }

            // void Explore::makePlan()
            // {
            //     try
            //     {
            //         if (with_map_completion == 1) {
            //             ros::spinOnce();
            //         }

            //         auto* cm = costmap_client_.getCostmap();
            //         if (!cm) {
            //             ROS_ERROR("Costmap pointer is null");
            //             return;
            //         }

            //         const unsigned int W = cm->getSizeInCellsX();
            //         const unsigned int H = cm->getSizeInCellsY();
            //         const double res = cm->getResolution();

            //         if (W == 0 || H == 0 || res <= 0.0) {
            //             ROS_ERROR("Invalid costmap dimensions: %ux%u, res=%.6f", W, H, res);
            //             return;
            //         }

            //         search_->setMapSaverOriginRes(cm->getOriginX(), cm->getOriginY(), res,
            //                                     static_cast<int>(W), static_cast<int>(H));

            //         const uint64_t epoch = costmap_client_.getMapEpoch();
            //         if (epoch != last_map_epoch_) {
            //             search_->invalidateDistanceField();

            //             if (publish_maps_ && full_gt_loaded_) {
            //                 auto gt_start = std::chrono::high_resolution_clock::now();

            //                 const int cur_W = W;
            //                 const int cur_H = H;
            //                 const double cur_res = res;
            //                 const double cur_origin_x = cm->getOriginX();
            //                 const double cur_origin_y = cm->getOriginY();

            //                 const double scale = cur_res / full_gt_resolution_;

            //                 cv::Mat full_flipped;
            //                 cv::flip(full_gt_image_, full_flipped, 0);

            //                 cv::Mat M = cv::Mat::zeros(2, 3, CV_64F);
            //                 M.at<double>(0, 0) = scale;
            //                 M.at<double>(1, 1) = scale;

            //                 double world_dx = -cur_origin_x + full_gt_origin_x_;
            //                 double world_dy = cur_origin_y - full_gt_origin_y_;
            //                 double pixel_tx = world_dx / cur_res;
            //                 double pixel_ty = world_dy / cur_res;

            //                 pixel_tx += fine_dx;
            //                 pixel_ty -= fine_dy;

            //                 M.at<double>(0, 2) = pixel_tx;
            //                 M.at<double>(1, 2) = -pixel_ty;

            //                 cv::Mat aligned;
            //                 cv::warpAffine(full_flipped, aligned, M, cv::Size(cur_W, cur_H),
            //                             cv::INTER_NEAREST,
            //                             cv::BORDER_CONSTANT,
            //                             cv::Scalar(205));

            //                 cv::flip(aligned, gt_image_raw_, 0);

            //                 gt_origin_x_ = cur_origin_x;
            //                 gt_origin_y_ = cur_origin_y;
            //                 gt_resolution_ = cur_res;

            //                 search_->setGtImage(gt_image_raw_);
            //                 search_->setYamlOriginRes(gt_origin_x_, gt_origin_y_, gt_resolution_);

            //                 if (log_operations_enabled_ && experiment_logger_) {
            //                     auto gt_end = std::chrono::high_resolution_clock::now();
            //                     double gt_duration_ms =
            //                         std::chrono::duration<double, std::milli>(gt_end - gt_start).count();
            //                     experiment_logger_->logOperation("GT_loading", gt_duration_ms);
            //                 }

            //                 ROS_DEBUG("GT crop extracted: %dx%d from full %dx%d (%.2f ms)",
            //                         cur_W, cur_H, full_gt_image_.cols, full_gt_image_.rows,
            //                         std::chrono::duration<double, std::milli>(
            //                             std::chrono::high_resolution_clock::now() - gt_start).count());
            //             }

            //             last_map_epoch_ = epoch;
            //         }

            //         auto start_time = std::chrono::high_resolution_clock::now();

            //         auto pose = costmap_client_.getRobotPose();

            //         unsigned int mx, my;
            //         if (!cm->worldToMap(pose.position.x, pose.position.y, mx, my)) {
            //             return;
            //         }

            //         updateTravelDistance(pose.position);

            //         auto frontiers = search_->searchFrom(pose.position);
            //         if (frontiers.empty()) {
            //             ROS_INFO("No explorable frontiers remaining");
            //             stop();
            //             return;
            //         }

            //         // Remove stale blacklist entries
            //         frontier_blacklist_.erase(
            //             std::remove_if(frontier_blacklist_.begin(), frontier_blacklist_.end(),
            //                         [&](const BlacklistEntry& e) {
            //                             const auto& p = e.position;
            //                             bool still_exists = false;
            //                             for (const auto& f : frontiers) {
            //                                 const double FRONTIER_MATCH_EPS = 0.5;
            //                                 if (std::hypot(f.safest_point.x - p.x, f.safest_point.y - p.y) < FRONTIER_MATCH_EPS) {
            //                                     still_exists = true;
            //                                     break;
            //                                 }
            //                             }
            //                             return !still_exists;
            //                         }),
            //             frontier_blacklist_.end());

            //         // Clean up filtered clusters
            //         cleanupFilteredClusters(frontiers);

            //         std::vector<explore_lite::FrontierMsg> frontiers_msg;
            //         geometry_msgs::Point target_position;
            //         frontier_exploration::Frontier target_frontier;
            //         bool found_target = false;
            //         double min_distance = 0.0;

            //         // Process ALL frontiers
            //         for (auto& frontier : frontiers)
            //         {
            //             bool should_blacklist = frontier.isFlaggedByAnyFilter();

            //             // Filtering-flagged → Check neighborhood FIRST, then add to cluster
            //             if (should_blacklist && use_completed_map_ == 1 && use_filtering_ == 1) {
            //                 // ✅ Neighborhood check (cluster eklemeden önce)
            //                 const double NEIGHBORHOOD_RADIUS = 15.0;
            //                 size_t nearby_valid = 0;

            //                 for (const auto& other : frontiers) {
            //                     if (&other == &frontier) continue;
            //                     if (goalOnBlacklist(other.safest_point)) continue;
            //                     if (other.isFlaggedByAnyFilter()) continue;

            //                     // Direct distance check (not via cluster centers)
            //                     double dist = std::hypot(other.centroid.x - frontier.centroid.x,
            //                                             other.centroid.y - frontier.centroid.y);

            //                     if (dist < NEIGHBORHOOD_RADIUS) {
            //                         nearby_valid++;
            //                     }
            //                 }

            //                 // Blacklist if alternatives exist
            //                 if (nearby_valid >= 1) {
            //                     if (!goalOnBlacklist(frontier.safest_point)) {
            //                         frontier_blacklist_.push_back(BlacklistEntry(frontier.safest_point,
            //                                                                     BlacklistReason::ARTIFICIAL_AREA,
            //                                                                     1.0));
            //                         ROS_DEBUG("Blacklisting filtering-flagged frontier - %zu nearby valid",
            //                                 nearby_valid);
            //                     }
            //                 } else {
            //                     ROS_WARN("Keeping filtering-flagged frontier at (%.2f, %.2f) - isolated",
            //                             frontier.safest_point.x, frontier.safest_point.y);
            //                 }

            //                 // ✅ Add to cluster AFTER decision
            //                 addToFilteredCluster(frontier.safest_point);
            //             }

            //             explore_lite::FrontierMsg frontier_msg;
            //             frontier_msg.size = frontier.size;
            //             frontier_msg.min_distance = frontier.min_distance;
            //             frontier_msg.cost = frontier.cost;
            //             frontier_msg.initial = frontier.initial;
            //             frontier_msg.centroid = frontier.centroid;
            //             frontier_msg.middle = frontier.middle;
            //             frontier_msg.points = frontier.points;
            //             frontier_msg.map_resolution = frontier.map_resolution;
            //             frontier_msg.is_in_blacklist = goalOnBlacklist(frontier.safest_point);
            //             frontier_msg.is_target = false;

            //             if (!found_target && !frontier_msg.is_in_blacklist) {
            //                 target_position = frontier.safest_point;
            //                 target_frontier = frontier;
            //                 frontier_msg.is_target = true;
            //                 found_target = true;
            //                 min_distance = frontier.min_distance;
            //             }

            //             if (!frontier_msg.is_in_blacklist) {
            //                 frontiers_msg.push_back(std::move(frontier_msg));
            //             }
            //         }

            //         if (found_target) {
            //             const double target_distance = std::hypot(target_position.x - pose.position.x,
            //                                                     target_position.y - pose.position.y);
                        
            //             const double RESCUE_DISTANCE_THRESHOLD = 20.0;
                        
            //             if (target_distance > RESCUE_DISTANCE_THRESHOLD && !filtered_clusters_.empty()) {
            //                 double nearest_cluster_dist = std::numeric_limits<double>::infinity();
            //                 geometry_msgs::Point nearest_cluster_center;
            //                 bool found_nearer_cluster = false;
                            
            //                 for (const auto& cluster : filtered_clusters_) {
            //                     double dist = std::hypot(cluster.center.x - pose.position.x,
            //                                             cluster.center.y - pose.position.y);
                                
            //                     if (dist < nearest_cluster_dist && dist < target_distance) {
            //                         nearest_cluster_dist = dist;
            //                         nearest_cluster_center = cluster.center;
            //                         found_nearer_cluster = true;
            //                     }
            //                 }
                            
            //                 if (found_nearer_cluster) {
            //                     ROS_WARN("RESCUE: Target %.2fm away, switching to nearest cluster at %.2fm",
            //                             target_distance, nearest_cluster_dist);
                                
            //                     target_position = nearest_cluster_center;
            //                     min_distance = nearest_cluster_dist;
                                
            //                     if (experiment_logger_) {
            //                         experiment_logger_->logTarget(target_position, "rescue_cluster_center");
            //                     }
            //                 }
            //             }
            //         }

            //         // ---- FALLBACK: Try cluster centers (max 3 attempts) ----
            //         if (!found_target && fallback_attempt_count_ < MAX_FALLBACK_ATTEMPTS) {
            //             if (!filtered_clusters_.empty()) {
            //                 // Sort clusters by distance to robot
            //                 std::vector<std::pair<double, size_t>> cluster_distances;
            //                 for (size_t i = 0; i < filtered_clusters_.size(); ++i) {
            //                     double dist = std::hypot(filtered_clusters_[i].center.x - pose.position.x,
            //                                             filtered_clusters_[i].center.y - pose.position.y);
            //                     cluster_distances.push_back({dist, i});
            //                 }

            //                 std::sort(cluster_distances.begin(), cluster_distances.end());

            //                 // ✅ FIX: fallback_attempt_count_ kadar ilerle
            //                 size_t cluster_idx = std::min(static_cast<size_t>(fallback_attempt_count_),
            //                                             cluster_distances.size() - 1);

            //                 if (cluster_idx < cluster_distances.size()) {
            //                     size_t selected_idx = cluster_distances[cluster_idx].second;
            //                     const auto& selected_cluster = filtered_clusters_[selected_idx];

            //                     target_position = selected_cluster.center;
            //                     min_distance = cluster_distances[cluster_idx].first;
            //                     found_target = true;

            //                     ROS_WARN("FALLBACK (attempt %d/%d): Selected cluster #%zu at (%.2f, %.2f), dist=%.2fm, members=%zu",
            //                             fallback_attempt_count_ + 1, MAX_FALLBACK_ATTEMPTS,
            //                             cluster_idx,
            //                             selected_cluster.center.x, selected_cluster.center.y,
            //                             min_distance,
            //                             selected_cluster.members.size());

            //                     fallback_attempt_count_++;

            //                     if (experiment_logger_) {
            //                         experiment_logger_->logTarget(target_position, "fallback_cluster_center");
            //                     }
            //                 }
            //             }
            //         }

            //         // No valid target found → STOP
            //         if (!found_target) {
            //             if (fallback_attempt_count_ >= MAX_FALLBACK_ATTEMPTS) {
            //                 ROS_ERROR("STOPPING: Reached max fallback attempts (%d)", MAX_FALLBACK_ATTEMPTS);
            //             } else {
            //                 ROS_ERROR("STOPPING: No valid frontiers, no clusters available");
            //             }
            //             ROS_ERROR("Stats: %zu frontiers, %zu blacklisted, %zu clusters",
            //                     frontiers.size(), frontier_blacklist_.size(), filtered_clusters_.size());
            //             stop();
            //             return;
            //         }

            //         // Reset fallback counter on successful normal target selection
            //         if (found_target && fallback_attempt_count_ > 0) {
            //             // Check if this was a cluster center or normal frontier
            //             bool is_cluster_center = false;
            //             for (const auto& cluster : filtered_clusters_) {
            //                 if (std::hypot(target_position.x - cluster.center.x,
            //                             target_position.y - cluster.center.y) < 0.1) {
            //                     is_cluster_center = true;
            //                     break;
            //                 }
            //             }

            //             if (!is_cluster_center) {
            //                 ROS_INFO("Resetting fallback counter (found normal frontier)");
            //                 fallback_attempt_count_ = 0;
            //             }
            //         }

            //         if (publish_maps_) {
            //             publishMaps();
            //         }

            //         if (visualize_) {
            //             visualizeFrontiers(frontiers, target_position);
            //         }

            //         // --- Goal re-issue debounce ---
            //         static geometry_msgs::Point last_goal;
            //         static bool have_last_goal = false;

            //         auto goal_dist = [&](const geometry_msgs::Point& a, const geometry_msgs::Point& b) {
            //             return std::hypot(a.x - b.x, a.y - b.y);
            //         };

            //         const double reissue_thresh = 0.20;

            //         if (!(have_last_goal && goal_dist(last_goal, target_position) < reissue_thresh))
            //         {
            //             if (has_active_target_) {
            //                 const double old_dx = last_goal.x - current_target_.x;
            //                 const double old_dy = last_goal.y - current_target_.y;
            //                 const double dist_from_old_target = std::sqrt(old_dx*old_dx + old_dy*old_dy);

            //                 const double new_dx = target_position.x - current_target_.x;
            //                 const double new_dy = target_position.y - current_target_.y;
            //                 const double target_change_dist = std::sqrt(new_dx*new_dx + new_dy*new_dy);

            //                 if (target_change_dist > 1.0) {
            //                     if (experiment_logger_) {
            //                         experiment_logger_->logTarget(current_target_, "changed_to_new_target");
            //                     }
            //                 }
            //                 else if (dist_from_old_target < 0.5) {
            //                     const double elapsed_time = (ros::Time::now() - target_start_time_).toSec();
            //                     const double travel_dist = total_distance_traveled_ - target_start_distance_;

            //                     if (experiment_logger_) {
            //                         experiment_logger_->logTargetReached(current_target_, elapsed_time, travel_dist);
            //                     }
            //                 }
            //             }

            //             current_target_ = target_position;
            //             target_start_time_ = ros::Time::now();
            //             target_start_distance_ = total_distance_traveled_;
            //             has_active_target_ = true;

            //             if (experiment_logger_) {
            //                 experiment_logger_->logTarget(target_position, "frontier_selected");
            //             }

            //             if (!sendNavigationGoal(target_position, min_distance)) {
            //                 ROS_ERROR("Failed to send navigation goal");
            //                 return;
            //             }

            //             have_last_goal = true;
            //             last_goal = target_position;
            //         }

            //         auto duration = std::chrono::duration<double, std::milli>(
            //             std::chrono::high_resolution_clock::now() - start_time);

            //         if (log_operations_enabled_ && experiment_logger_) {
            //             experiment_logger_->logOperation("makePlan_cycle", duration.count());
            //         }
            //     }
            //     catch (const std::exception& e) {
            //         ROS_ERROR("Exception in makePlan: %s", e.what());
            //     }
            //     catch (...) {
            //         ROS_ERROR("Unknown exception in makePlan");
            //     }
            // }

            // void Explore::makePlan()
            // {
            //     try
            //     {
            //         if (with_map_completion == 1) {
            //             ros::spinOnce();
            //         }

            //         auto* cm = costmap_client_.getCostmap();
            //         if (!cm) {
            //             ROS_ERROR("Costmap pointer is null");
            //             return;
            //         }

            //         const unsigned int W = cm->getSizeInCellsX();
            //         const unsigned int H = cm->getSizeInCellsY();
            //         const double res = cm->getResolution();

            //         if (W == 0 || H == 0 || res <= 0.0) {
            //             ROS_ERROR("Invalid costmap dimensions: %ux%u, res=%.6f", W, H, res);
            //             return;
            //         }

            //         search_->setMapSaverOriginRes(cm->getOriginX(), cm->getOriginY(), res,
            //                                     static_cast<int>(W), static_cast<int>(H));

            //         const uint64_t epoch = costmap_client_.getMapEpoch();
            //         if (epoch != last_map_epoch_) {
            //             search_->invalidateDistanceField();

            //             if (publish_maps_ && full_gt_loaded_) {
            //                 auto gt_start = std::chrono::high_resolution_clock::now();
            //                 const int cur_W = W;
            //                 const int cur_H = H;
            //                 const double cur_res = res;
            //                 const double cur_origin_x = cm->getOriginX();
            //                 const double cur_origin_y = cm->getOriginY();
            //                 const double scale = cur_res / full_gt_resolution_;

            //                 cv::Mat full_flipped;
            //                 cv::flip(full_gt_image_, full_flipped, 0);

            //                 cv::Mat M = cv::Mat::zeros(2, 3, CV_64F);
            //                 M.at<double>(0, 0) = scale;
            //                 M.at<double>(1, 1) = scale;

            //                 double world_dx = -cur_origin_x + full_gt_origin_x_;
            //                 double world_dy = cur_origin_y - full_gt_origin_y_;
            //                 double pixel_tx = world_dx / cur_res;
            //                 double pixel_ty = world_dy / cur_res;

            //                 pixel_tx += fine_dx;
            //                 pixel_ty -= fine_dy;

            //                 M.at<double>(0, 2) = pixel_tx;
            //                 M.at<double>(1, 2) = -pixel_ty;

            //                 cv::Mat aligned;
            //                 cv::warpAffine(full_flipped, aligned, M, cv::Size(cur_W, cur_H),
            //                             cv::INTER_NEAREST,
            //                             cv::BORDER_CONSTANT,
            //                             cv::Scalar(205));

            //                 cv::flip(aligned, gt_image_raw_, 0);
            //                 gt_origin_x_ = cur_origin_x;
            //                 gt_origin_y_ = cur_origin_y;
            //                 gt_resolution_ = cur_res;

            //                 search_->setGtImage(gt_image_raw_);
            //                 search_->setYamlOriginRes(gt_origin_x_, gt_origin_y_, gt_resolution_);

            //                 if (log_operations_enabled_ && experiment_logger_) {
            //                     auto gt_end = std::chrono::high_resolution_clock::now();
            //                     double gt_duration_ms = std::chrono::duration<double, std::milli>(gt_end - gt_start).count();
            //                     experiment_logger_->logOperation("GT_loading", gt_duration_ms);
            //                 }
            //             }
            //             last_map_epoch_ = epoch;
            //         }

            //         auto start_time = std::chrono::high_resolution_clock::now();
            //         auto pose = costmap_client_.getRobotPose();

            //         unsigned int mx, my;
            //         if (!cm->worldToMap(pose.position.x, pose.position.y, mx, my)) return;

            //         updateTravelDistance(pose.position);

            //         auto frontiers = search_->searchFrom(pose.position);
                    
            //         if (frontiers.empty()) {
            //             ROS_INFO("No explorable frontiers remaining");
            //             stop();
            //             return;
            //         }

            //         // ARTIFICIAL_AREA sebepli tüm frontierları sil
            //         frontier_blacklist_.erase(
            //             std::remove_if(frontier_blacklist_.begin(), frontier_blacklist_.end(),
            //                 [](const BlacklistEntry& e) {
            //                     return e.reason == BlacklistReason::ARTIFICIAL_AREA;
            //                 }),
            //             frontier_blacklist_.end());

            //         // ════════════════════════════════════════════════════════════════
            //         // KEEP 30% REPRESENTATIVE FILTERED FRONTIERS (different regions)
            //         // BLACKLIST 70%
            //         // ════════════════════════════════════════════════════════════════
                    
            //         // Önce safest_point'leri senkronize et
            //         for (auto& frontier : frontiers) {
            //             frontier.safest_point = frontier.centroid;
            //         }
                    
            //         // Filtrelenen frontierları topla
            //         std::vector<size_t> filtered_indices;
            //         for (size_t i = 0; i < frontiers.size(); ++i) {
            //             if (frontiers[i].isFlaggedByAnyFilter() && use_filtering_ == 1) {
            //                 filtered_indices.push_back(i);
            //             }
            //         }
                    
            //         // %30'unu seç (farklı bölgelerden - farthest point sampling)
            //         std::vector<size_t> keep_indices;
                    
            //         if (!filtered_indices.empty()) {
            //             int num_to_keep = std::max(1, (int)(filtered_indices.size() * 0.3));
                        
            //             // Greedy farthest point selection
            //             // 1. İlk noktayı seç (en uzak frontier'dan)
            //             double max_dist = -1;
            //             size_t first_idx = filtered_indices[0];
            //             for (size_t idx : filtered_indices) {
            //                 double dist = std::hypot(frontiers[idx].centroid.x - pose.position.x,
            //                                         frontiers[idx].centroid.y - pose.position.y);
            //                 if (dist > max_dist) {
            //                     max_dist = dist;
            //                     first_idx = idx;
            //                 }
            //             }
            //             keep_indices.push_back(first_idx);
                        
            //             // 2. Kalan noktaları seç (seçilenlere en uzak olanları)
            //             while (keep_indices.size() < (size_t)num_to_keep && keep_indices.size() < filtered_indices.size()) {
            //                 double max_min_dist = -1;
            //                 size_t best_idx = filtered_indices[0];
                            
            //                 for (size_t candidate_idx : filtered_indices) {
            //                     // Zaten seçilmiş mi?
            //                     bool already_selected = false;
            //                     for (size_t selected_idx : keep_indices) {
            //                         if (candidate_idx == selected_idx) {
            //                             already_selected = true;
            //                             break;
            //                         }
            //                     }
            //                     if (already_selected) continue;
                                
            //                     // Seçilenlere minimum mesafeyi bul
            //                     double min_dist = std::numeric_limits<double>::max();
            //                     for (size_t selected_idx : keep_indices) {
            //                         double dist = std::hypot(
            //                             frontiers[candidate_idx].centroid.x - frontiers[selected_idx].centroid.x,
            //                             frontiers[candidate_idx].centroid.y - frontiers[selected_idx].centroid.y
            //                         );
            //                         min_dist = std::min(min_dist, dist);
            //                     }
                                
            //                     // En uzak olanı seç
            //                     if (min_dist > max_min_dist) {
            //                         max_min_dist = min_dist;
            //                         best_idx = candidate_idx;
            //                     }
            //                 }
                            
            //                 keep_indices.push_back(best_idx);
            //             }
                        
            //             ROS_INFO("📍 Keeping %zu/%zu filtered frontiers (30%% representative from different regions)",
            //                     keep_indices.size(), filtered_indices.size());
            //         }
                    
            //         // Şimdi blacklist'e at (keep_indices'te olmayanlar)
            //         for (size_t i = 0; i < frontiers.size(); ++i) {
            //             auto& frontier = frontiers[i];
                        
            //             if (frontier.isFlaggedByAnyFilter() && use_filtering_ == 1) {
            //                 // Keep listesinde mi?
            //                 bool should_keep = false;
            //                 for (size_t keep_idx : keep_indices) {
            //                     if (i == keep_idx) {
            //                         should_keep = true;
            //                         break;
            //                     }
            //                 }
                            
            //                 if (should_keep) {
            //                     ROS_DEBUG("Keeping representative filtered frontier at (%.2f, %.2f)",
            //                             frontier.safest_point.x, frontier.safest_point.y);
            //                     continue;  // Atma
            //                 }
                            
            //                 // Blacklist'e at
            //                 if (!goalOnBlacklist(frontier.safest_point)) {
            //                     frontier_blacklist_.push_back(
            //                         BlacklistEntry(frontier.safest_point, 
            //                                     BlacklistReason::ARTIFICIAL_AREA, 1.0));
            //                 }
            //             }
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // TARGET SELECTION
            //         // ════════════════════════════════════════════════════════════════
                    
            //         geometry_msgs::Point target_position;
            //         bool found_target = false;
            //         double min_distance = 0.0;

            //         for (auto& frontier : frontiers) {
            //             if (!found_target && !goalOnBlacklist(frontier.safest_point)) {
            //                 target_position = frontier.safest_point;
            //                 found_target = true;
            //                 min_distance = frontier.min_distance;
            //             }
            //         }

            //         if (publish_maps_) publishMaps();
            //         if (visualize_) visualizeFrontiers(frontiers, target_position);

            //         // ════════════════════════════════════════════════════════════════
            //         // SEND NAVIGATION GOAL
            //         // ════════════════════════════════════════════════════════════════
                    
            //         static geometry_msgs::Point last_goal_sent;
            //         static bool have_last_goal = false;
            //         const double reissue_thresh = 0.20;

            //         if (found_target && (!have_last_goal || std::hypot(last_goal_sent.x - target_position.x, last_goal_sent.y - target_position.y) > reissue_thresh))
            //         {
            //             if (has_active_target_ && std::hypot(last_goal_sent.x - target_position.x, last_goal_sent.y - target_position.y) > 1.0) {
            //                 if (experiment_logger_) experiment_logger_->logTarget(current_target_, "changed_to_new_target");
            //             }

            //             current_target_ = target_position;
            //             target_start_time_ = ros::Time::now();
            //             target_start_distance_ = total_distance_traveled_;
            //             has_active_target_ = true;

            //             if (experiment_logger_) {
            //                 std::string type = fallback_attempted_ && fallback_current_index_ > 0 ? "fallback_frontier" : "frontier_selected";
            //                 experiment_logger_->logTarget(target_position, type);
            //             }

            //             if (sendNavigationGoal(target_position, min_distance)) {
            //                 last_goal_sent = target_position;
            //                 have_last_goal = true;
            //             }
            //         }

            //         auto duration = std::chrono::duration<double, std::milli>(std::chrono::high_resolution_clock::now() - start_time);
            //         if (log_operations_enabled_ && experiment_logger_) experiment_logger_->logOperation("makePlan_cycle", duration.count());
            //     }
            //     catch (const std::exception& e) { ROS_ERROR("Exception in makePlan: %s", e.what()); }
            // }

            

            

            // void Explore::makePlan()
            // {
            //     try
            //     {
            //         if (with_map_completion == 1) {
            //             ros::spinOnce();
            //         }

            //         costmap_2d::Costmap2D* cm = costmap_client_.getCostmap();
            //         if (!cm) {
            //             ROS_ERROR("Costmap pointer is null");
            //             return;
            //         }

            //         const unsigned int W = cm->getSizeInCellsX();
            //         const unsigned int H = cm->getSizeInCellsY();
            //         const double res = cm->getResolution();

            //         if (W == 0 || H == 0 || res <= 0.0) {
            //             ROS_ERROR("Invalid costmap dimensions: %ux%u, res=%.6f", W, H, res);
            //             return;
            //         }

            //         search_->setMapSaverOriginRes(cm->getOriginX(), cm->getOriginY(), res,
            //                                     static_cast<int>(W), static_cast<int>(H));

            //         const uint64_t epoch = costmap_client_.getMapEpoch();
            //         if (epoch != last_map_epoch_) {
            //             search_->invalidateDistanceField();

            //             if (publish_maps_ && full_gt_loaded_) {
            //                 std::chrono::high_resolution_clock::time_point gt_start = std::chrono::high_resolution_clock::now();
            //                 const int cur_W = W;
            //                 const int cur_H = H;
            //                 const double cur_res = res;
            //                 const double cur_origin_x = cm->getOriginX();
            //                 const double cur_origin_y = cm->getOriginY();
            //                 const double scale = cur_res / full_gt_resolution_;

            //                 cv::Mat full_flipped;
            //                 cv::flip(full_gt_image_, full_flipped, 0);

            //                 cv::Mat M = cv::Mat::zeros(2, 3, CV_64F);
            //                 M.at<double>(0, 0) = scale;
            //                 M.at<double>(1, 1) = scale;

            //                 double world_dx = -cur_origin_x + full_gt_origin_x_;
            //                 double world_dy = cur_origin_y - full_gt_origin_y_;
            //                 double pixel_tx = world_dx / cur_res;
            //                 double pixel_ty = world_dy / cur_res;

            //                 pixel_tx += fine_dx;
            //                 pixel_ty -= fine_dy;

            //                 M.at<double>(0, 2) = pixel_tx;
            //                 M.at<double>(1, 2) = -pixel_ty;

            //                 cv::Mat aligned;
            //                 cv::warpAffine(full_flipped, aligned, M, cv::Size(cur_W, cur_H),
            //                             cv::INTER_NEAREST,
            //                             cv::BORDER_CONSTANT,
            //                             cv::Scalar(205));

            //                 cv::flip(aligned, gt_image_raw_, 0);
            //                 gt_origin_x_ = cur_origin_x;
            //                 gt_origin_y_ = cur_origin_y;
            //                 gt_resolution_ = cur_res;

            //                 search_->setGtImage(gt_image_raw_);
            //                 search_->setYamlOriginRes(gt_origin_x_, gt_origin_y_, gt_resolution_);

            //                 if (log_operations_enabled_ && experiment_logger_) {
            //                     std::chrono::high_resolution_clock::time_point gt_end = std::chrono::high_resolution_clock::now();
            //                     double gt_duration_ms = std::chrono::duration<double, std::milli>(gt_end - gt_start).count();
            //                     experiment_logger_->logOperation("GT_loading", gt_duration_ms);
            //                 }
            //             }
            //             last_map_epoch_ = epoch;
            //         }

            //         std::chrono::high_resolution_clock::time_point start_time = std::chrono::high_resolution_clock::now();
            //         geometry_msgs::Pose pose = costmap_client_.getRobotPose();

            //         unsigned int mx, my;
            //         if (!cm->worldToMap(pose.position.x, pose.position.y, mx, my)) return;

            //         updateTravelDistance(pose.position);

            //         std::vector<frontier_exploration::Frontier> frontiers = search_->searchFrom(pose.position);
                    
            //         if (frontiers.empty()) {
            //             ROS_INFO("No explorable frontiers remaining");
            //             stop();
            //             return;
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // FRONTIER PROCESSING
            //         // ════════════════════════════════════════════════════════════════
                    
            //         // Önce safest_point'leri senkronize et
            //         for (size_t i = 0; i < frontiers.size(); ++i) {
            //             frontiers[i].safest_point = frontiers[i].centroid;
            //         }
                    
            //         // SADECE use_completed_map=1 VE use_filtering=1 ise filtreleme yap
            //         if (use_completed_map_ == 1 && use_filtering_ == 1) {
            //             // ARTIFICIAL_AREA sebepli tüm frontierları sil
            //             frontier_blacklist_.erase(
            //                 std::remove_if(frontier_blacklist_.begin(), frontier_blacklist_.end(),
            //                     BlacklistReasonFilter(BlacklistReason::ARTIFICIAL_AREA)),
            //                 frontier_blacklist_.end());
                        
            //             // Deneme geçmişini de temizle (yeni map → yeni şans)
            //             attempted_artificial_positions_.clear();

            //             // Var olmayan frontierları temizle (artık frontier olmayan pozisyonlar)
            //             for (size_t i = 0; i < frontier_blacklist_.size(); ) {
            //                 bool exists = false;
            //                 for (size_t j = 0; j < frontiers.size(); ++j) {
            //                     if (std::hypot(frontier_blacklist_[i].position.x - frontiers[j].centroid.x,
            //                                 frontier_blacklist_[i].position.y - frontiers[j].centroid.y) < 0.1) {
            //                         exists = true;
            //                         break;
            //                     }
            //                 }
            //                 if (!exists) {
            //                     frontier_blacklist_.erase(frontier_blacklist_.begin() + i);
            //                 } else {
            //                     ++i;
            //                 }
            //             }
                        
            //             // Filtrelenenleri blacklist'e at
            //             for (size_t i = 0; i < frontiers.size(); ++i) {
            //                 if (frontiers[i].isFlaggedByAnyFilter()) {
            //                     if (!goalOnBlacklist(frontiers[i].safest_point)) {
            //                         frontier_blacklist_.push_back(
            //                             BlacklistEntry(frontiers[i].safest_point, 
            //                                         BlacklistReason::ARTIFICIAL_AREA, 1.0));
            //                     }
            //                 }
            //             }
                        
            //             // LOG: Filtering durumu
            //             size_t artificial_count = 0;
            //             for (size_t i = 0; i < frontier_blacklist_.size(); ++i) {
            //                 if (frontier_blacklist_[i].reason == BlacklistReason::ARTIFICIAL_AREA) {
            //                     artificial_count++;
            //                 }
            //             }
                        
            //             if (log_operations_enabled_ && experiment_logger_) {
            //                 std::ostringstream oss;
            //                 oss << "filtering:total_frontiers=" << frontiers.size() 
            //                     << ",blacklist_count=" << artificial_count 
            //                     << ",attempted_count=" << attempted_artificial_positions_.size();
            //                 experiment_logger_->logOperation("debug_filtering", 0, oss.str());
            //             }
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // TARGET SELECTION
            //         // ════════════════════════════════════════════════════════════════
                    
            //         geometry_msgs::Point target_position;
            //         bool found_target = false;
            //         double min_distance = 0.0;

            //         for (size_t i = 0; i < frontiers.size(); ++i) {
            //             if (!found_target && !goalOnBlacklist(frontiers[i].safest_point)) {
            //                 target_position = frontiers[i].safest_point;
            //                 found_target = true;
            //                 min_distance = frontiers[i].min_distance;
            //             }
            //         }
                    
            //         // LOG: Target selection
            //         if (log_operations_enabled_ && experiment_logger_) {
            //             if (found_target) {
            //                 geometry_msgs::Point robot_pos = pose.position;
            //                 double target_dist = std::hypot(target_position.x - robot_pos.x,
            //                                             target_position.y - robot_pos.y);
            //                 std::ostringstream oss;
            //                 oss << "target_selection:found=1,pos=(" << target_position.x << "," << target_position.y 
            //                     << "),dist=" << target_dist;
            //                 experiment_logger_->logOperation("debug_target", 0, oss.str());
            //             } else {
            //                 experiment_logger_->logOperation("debug_target", 0, "target_selection:found=0");
            //             }
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // PROGRESSIVE NEIGHBORHOOD FALLBACK
            //         // ════════════════════════════════════════════════════════════════
                    
            //         if (use_completed_map_ == 1 && use_filtering_ == 1) {
            //             geometry_msgs::Point robot_pos = pose.position;
                        
            //             const double NEIGHBORHOOD_1 = 20.0;
            //             const double NEIGHBORHOOD_2 = 40.0;
            //             const double NEIGHBORHOOD_3 = 60.0;
                        
            //             // CASE 1: Valid target var - Progressive cleanup
            //             if (found_target) {
            //                 fallback_attempted_ = false;
                            
            //                 double target_dist = std::hypot(target_position.x - robot_pos.x,
            //                                             target_position.y - robot_pos.y);
                            
            //                 bool override_with_cleanup = false;
            //                 geometry_msgs::Point cleanup_target;
            //                 std::string cleanup_neighborhood;
                            
            //                 // Helper: Get farthest in neighborhood
            //                 if (target_dist >= NEIGHBORHOOD_2) {
            //                     // Check N1
            //                     double farthest_dist = -1.0;
            //                     bool found = false;
            //                     for (size_t i = 0; i < frontier_blacklist_.size(); ++i) {
            //                         if (frontier_blacklist_[i].reason == BlacklistReason::ARTIFICIAL_AREA) {
            //                             // Daha önce denendi mi kontrol et
            //                             std::string key = positionToKey(frontier_blacklist_[i].position);
            //                             if (attempted_artificial_positions_.find(key) != attempted_artificial_positions_.end()) {
            //                                 continue;  // Daha önce denendi, skip
            //                             }
                                        
            //                             double dist = std::hypot(frontier_blacklist_[i].position.x - robot_pos.x,
            //                                                     frontier_blacklist_[i].position.y - robot_pos.y);
            //                             if (dist >= 0 && dist < NEIGHBORHOOD_1 && dist > farthest_dist) {
            //                                 farthest_dist = dist;
            //                                 cleanup_target = frontier_blacklist_[i].position;
            //                                 found = true;
            //                             }
            //                         }
            //                     }
            //                     if (found) {
            //                         override_with_cleanup = true;
            //                         cleanup_neighborhood = "N1";
            //                     }
            //                 }
                            
            //                 if (!override_with_cleanup && target_dist >= NEIGHBORHOOD_3) {
            //                     // Check N2
            //                     double farthest_dist = -1.0;
            //                     bool found = false;
            //                     for (size_t i = 0; i < frontier_blacklist_.size(); ++i) {
            //                         if (frontier_blacklist_[i].reason == BlacklistReason::ARTIFICIAL_AREA) {
            //                             // Daha önce denendi mi kontrol et
            //                             std::string key = positionToKey(frontier_blacklist_[i].position);
            //                             if (attempted_artificial_positions_.find(key) != attempted_artificial_positions_.end()) {
            //                                 continue;  // Daha önce denendi, skip
            //                             }
                                        
            //                             double dist = std::hypot(frontier_blacklist_[i].position.x - robot_pos.x,
            //                                                     frontier_blacklist_[i].position.y - robot_pos.y);
            //                             if (dist >= NEIGHBORHOOD_1 && dist < NEIGHBORHOOD_2 && dist > farthest_dist) {
            //                                 farthest_dist = dist;
            //                                 cleanup_target = frontier_blacklist_[i].position;
            //                                 found = true;
            //                             }
            //                         }
            //                     }
            //                     if (found) {
            //                         override_with_cleanup = true;
            //                         cleanup_neighborhood = "N2";
            //                     }
            //                 }
                            
            //                 if (!override_with_cleanup && target_dist >= NEIGHBORHOOD_3) {
            //                     // Check N3
            //                     double farthest_dist = -1.0;
            //                     bool found = false;
            //                     for (size_t i = 0; i < frontier_blacklist_.size(); ++i) {
            //                         if (frontier_blacklist_[i].reason == BlacklistReason::ARTIFICIAL_AREA) {
            //                             // Daha önce denendi mi kontrol et
            //                             std::string key = positionToKey(frontier_blacklist_[i].position);
            //                             if (attempted_artificial_positions_.find(key) != attempted_artificial_positions_.end()) {
            //                                 continue;  // Daha önce denendi, skip
            //                             }
                                        
            //                             double dist = std::hypot(frontier_blacklist_[i].position.x - robot_pos.x,
            //                                                     frontier_blacklist_[i].position.y - robot_pos.y);
            //                             if (dist >= NEIGHBORHOOD_2 && dist < NEIGHBORHOOD_3 && dist > farthest_dist) {
            //                                 farthest_dist = dist;
            //                                 cleanup_target = frontier_blacklist_[i].position;
            //                                 found = true;
            //                             }
            //                         }
            //                     }
            //                     if (found) {
            //                         override_with_cleanup = true;
            //                         cleanup_neighborhood = "N3";
            //                     }
            //                 }
                            
            //                 if (override_with_cleanup) {
            //                     target_position = cleanup_target;
            //                     min_distance = std::hypot(cleanup_target.x - robot_pos.x,
            //                                             cleanup_target.y - robot_pos.y);
                                
            //                     // Denendi olarak işaretle
            //                     attempted_artificial_positions_.insert(positionToKey(cleanup_target));
                                
            //                     // LOG: Cleanup triggered
            //                     if (log_operations_enabled_ && experiment_logger_) {
            //                         std::ostringstream oss;
            //                         oss << "cleanup:neighborhood=" << cleanup_neighborhood 
            //                             << ",target_dist=" << target_dist 
            //                             << ",cleanup_pos=(" << cleanup_target.x << "," << cleanup_target.y 
            //                             << "),cleanup_dist=" << min_distance;
            //                         experiment_logger_->logOperation("debug_cleanup", 0, oss.str());
            //                     }
                                
            //                     ROS_WARN("🧹 CLEANUP %s: Target at %.1fm, cleaning farthest at (%.2f, %.2f), dist=%.2fm",
            //                             cleanup_neighborhood.c_str(), target_dist,
            //                             cleanup_target.x, cleanup_target.y, min_distance);
                                
            //                     // Blacklist'te BIRAK (çıkarma!) - explore edince zaten kaybolur
            //                 }
                            
            //                 // LOG: No cleanup was triggered
            //                 if (!override_with_cleanup && log_operations_enabled_ && experiment_logger_) {
            //                     std::ostringstream oss;
            //                     oss << "no_cleanup:target_dist=" << target_dist 
            //                         << ",reason=";
            //                     if (target_dist < NEIGHBORHOOD_2) {
            //                         oss << "target_too_close";
            //                     } else {
            //                         oss << "no_blacklist_in_neighborhoods";
            //                     }
            //                     experiment_logger_->logOperation("debug_no_cleanup", 0, oss.str());
            //                 }
            //             }
                        
            //             // CASE 2: Valid yok - 1 fallback
            //             else {
            //                 if (!fallback_attempted_) {
            //                     // Try N1 - EN YAKIN
            //                     double nearest_dist = std::numeric_limits<double>::max();
            //                     geometry_msgs::Point fallback_point;
            //                     bool found = false;
            //                     int skipped_unreachable = 0;
                                
            //                     for (size_t i = 0; i < frontier_blacklist_.size(); ++i) {
            //                         if (frontier_blacklist_[i].reason == BlacklistReason::ARTIFICIAL_AREA) {
            //                             // Daha önce denendi mi kontrol et
            //                             std::string key = positionToKey(frontier_blacklist_[i].position);
            //                             if (attempted_artificial_positions_.find(key) != attempted_artificial_positions_.end()) {
            //                                 continue;  // Daha önce denendi, skip
            //                             }
                                        
            //                             double dist = std::hypot(frontier_blacklist_[i].position.x - robot_pos.x,
            //                                                     frontier_blacklist_[i].position.y - robot_pos.y);
            //                             if (dist >= 0 && dist < NEIGHBORHOOD_1) {
            //                                 // YENİ: Gidilebilir mi kontrol et
            //                                 if (!isReachable(robot_pos, frontier_blacklist_[i].position)) {
            //                                     skipped_unreachable++;
            //                                     continue;  // Gidilemez, skip
            //                                 }
                                            
            //                                 if (dist < nearest_dist) {
            //                                     nearest_dist = dist;
            //                                     fallback_point = frontier_blacklist_[i].position;
            //                                     found = true;
            //                                 }
            //                             }
            //                         }
            //                     }
                                
            //                     if (found) {
            //                         target_position = fallback_point;
            //                         found_target = true;
            //                         min_distance = nearest_dist;
            //                         fallback_attempted_ = true;
                                    
            //                         // Denendi olarak işaretle
            //                         attempted_artificial_positions_.insert(positionToKey(fallback_point));
                                    
            //                         // LOG: Fallback triggered
            //                         if (log_operations_enabled_ && experiment_logger_) {
            //                             std::ostringstream oss;
            //                             oss << "fallback:pos=(" << fallback_point.x << "," << fallback_point.y 
            //                                 << "),dist=" << min_distance 
            //                                 << ",blacklist_count=" << frontier_blacklist_.size()
            //                                 << ",skipped_unreachable=" << skipped_unreachable;
            //                             experiment_logger_->logOperation("debug_fallback", 0, oss.str());
            //                         }
                                    
            //                         ROS_WARN("⚠️  FALLBACK: Trying NEAREST N1 at (%.2f, %.2f), dist=%.2fm (skipped %d unreachable)",
            //                                 fallback_point.x, fallback_point.y, min_distance, skipped_unreachable);
                                    
            //                         // Blacklist'te BIRAK (çıkarma!) - explore edince zaten kaybolur
            //                     } else {
            //                         // No blacklist in N1 either
            //                         if (log_operations_enabled_ && experiment_logger_) {
            //                             experiment_logger_->logOperation("debug_fallback_failed", 0, 
            //                                 "fallback_failed:reason=no_blacklist_in_N1");
            //                         }
            //                         ROS_ERROR("❌ FALLBACK FAILED: No blacklist in N1");
            //                         stop();
            //                         return;
            //                     }
            //                 } else {
            //                     // Fallback already attempted once - STOP
            //                     if (log_operations_enabled_ && experiment_logger_) {
            //                         experiment_logger_->logOperation("debug_fallback_failed", 0, 
            //                             "fallback_failed:reason=already_attempted");
            //                     }
            //                     ROS_ERROR("❌ NO FRONTIERS AFTER FALLBACK");
            //                     stop();
            //                     return;
            //                 }
            //             }
            //         }

            //         if (!found_target) {
            //             if (log_operations_enabled_ && experiment_logger_) {
            //                 experiment_logger_->logOperation("debug_no_target", 0, "no_target:frontiers_exist_but_all_blacklisted");
            //             }
            //             ROS_ERROR("❌ NO FRONTIERS REMAINING");
            //             stop();
            //             return;
            //         }

            //         if (publish_maps_) publishMaps();
            //         if (visualize_) visualizeFrontiers(frontiers, target_position);

            //         // ════════════════════════════════════════════════════════════════
            //         // SEND NAVIGATION GOAL
            //         // ════════════════════════════════════════════════════════════════
                    
            //         static geometry_msgs::Point last_goal_sent;
            //         static bool have_last_goal = false;
            //         const double reissue_thresh = 0.20;

            //         if (found_target && (!have_last_goal || std::hypot(last_goal_sent.x - target_position.x, last_goal_sent.y - target_position.y) > reissue_thresh))
            //         {
            //             if (has_active_target_ && std::hypot(last_goal_sent.x - target_position.x, last_goal_sent.y - target_position.y) > 1.0) {
            //                 if (experiment_logger_) experiment_logger_->logTarget(current_target_, "changed_to_new_target");
            //             }

            //             current_target_ = target_position;
            //             target_start_time_ = ros::Time::now();
            //             target_start_distance_ = total_distance_traveled_;
            //             has_active_target_ = true;

            //             if (experiment_logger_) {
            //                 experiment_logger_->logTarget(target_position, "frontier_selected");
            //             }

            //             if (sendNavigationGoal(target_position, min_distance)) {
            //                 last_goal_sent = target_position;
            //                 have_last_goal = true;
            //             }
            //         }

            //         std::chrono::duration<double, std::milli> duration = std::chrono::duration<double, std::milli>(
            //             std::chrono::high_resolution_clock::now() - start_time);
            //         if (log_operations_enabled_ && experiment_logger_) 
            //             experiment_logger_->logOperation("makePlan_cycle", duration.count());
            //     }
            //     catch (const std::exception& e) { 
            //         ROS_ERROR("Exception in makePlan: %s", e.what()); 
            //     }
            // }

            // Helper: Check if target is reachable (no obstacles in straight line)
            bool Explore::isReachable(const geometry_msgs::Point& from, const geometry_msgs::Point& to) 
            {
                costmap_2d::Costmap2D* cm = costmap_client_.getCostmap();
                if (!cm) return false;
                
                unsigned int x0, y0, x1, y1;
                if (!cm->worldToMap(from.x, from.y, x0, y0)) return false;
                if (!cm->worldToMap(to.x, to.y, x1, y1)) return false;
                
                // Bresenham algoritması başlangıcı
                int dx = abs((int)x1 - (int)x0);
                int dy = abs((int)y1 - (int)y0);
                int sx = x0 < x1 ? 1 : -1;
                int sy = y0 < y1 ? 1 : -1;
                int err = dx - dy;
                
                unsigned int x = x0, y = y0;
                while (true) {
                    unsigned char cost = cm->getCost(x, y);
                    
                    // KRİTİK DÜZELTME: Sadece 254 (duvar) değil, 
                    // 253 (robotun sığamayacağı kadar yakın alan) kontrol edilmeli.
                    if (cost >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                        return false; // Doğrudan bir engel var veya yol çok dar
                    }
                    
                    if (x == x1 && y == y1) break;
                    
                    int e2 = 2 * err;
                    if (e2 > -dy) { err -= dy; x += sx; }
                    if (e2 < dx) { err += dx; y += sy; }
                }
                
                return true; // Yol temiz (Görüş hattı açık)
            }

            // void Explore::makePlan()
            // {
            //     try
            //     {
            //         if (with_map_completion == 1) {
            //             ros::spinOnce();
            //         }

            //         costmap_2d::Costmap2D* cm = costmap_client_.getCostmap();
            //         if (!cm) {
            //             ROS_ERROR("Costmap pointer is null");
            //             return;
            //         }

            //         const unsigned int W = cm->getSizeInCellsX();
            //         const unsigned int H = cm->getSizeInCellsY();
            //         const double res = cm->getResolution();

            //         if (W == 0 || H == 0 || res <= 0.0) {
            //             ROS_ERROR("Invalid costmap dimensions: %ux%u, res=%.6f", W, H, res);
            //             return;
            //         }

            //         search_->setMapSaverOriginRes(cm->getOriginX(), cm->getOriginY(), res,
            //                                     static_cast<int>(W), static_cast<int>(H));

            //         const uint64_t epoch = costmap_client_.getMapEpoch();
            //         if (epoch != last_map_epoch_) {
            //             search_->invalidateDistanceField();

            //             if (publish_maps_ && full_gt_loaded_) {
            //                 std::chrono::high_resolution_clock::time_point gt_start = std::chrono::high_resolution_clock::now();
            //                 const int cur_W = W;
            //                 const int cur_H = H;
            //                 const double cur_res = res;
            //                 const double cur_origin_x = cm->getOriginX();
            //                 const double cur_origin_y = cm->getOriginY();
            //                 const double scale = cur_res / full_gt_resolution_;

            //                 cv::Mat full_flipped;
            //                 cv::flip(full_gt_image_, full_flipped, 0);

            //                 cv::Mat M = cv::Mat::zeros(2, 3, CV_64F);
            //                 M.at<double>(0, 0) = scale;
            //                 M.at<double>(1, 1) = scale;

            //                 double world_dx = -cur_origin_x + full_gt_origin_x_;
            //                 double world_dy = cur_origin_y - full_gt_origin_y_;
            //                 double pixel_tx = world_dx / cur_res;
            //                 double pixel_ty = world_dy / cur_res;

            //                 pixel_tx += fine_dx;
            //                 pixel_ty -= fine_dy;

            //                 M.at<double>(0, 2) = pixel_tx;
            //                 M.at<double>(1, 2) = -pixel_ty;

            //                 cv::Mat aligned;
            //                 cv::warpAffine(full_flipped, aligned, M, cv::Size(cur_W, cur_H),
            //                             cv::INTER_NEAREST,
            //                             cv::BORDER_CONSTANT,
            //                             cv::Scalar(205));

            //                 cv::flip(aligned, gt_image_raw_, 0);
            //                 gt_origin_x_ = cur_origin_x;
            //                 gt_origin_y_ = cur_origin_y;
            //                 gt_resolution_ = cur_res;

            //                 search_->setGtImage(gt_image_raw_);
            //                 search_->setYamlOriginRes(gt_origin_x_, gt_origin_y_, gt_resolution_);

            //                 if (log_operations_enabled_ && experiment_logger_) {
            //                     std::chrono::high_resolution_clock::time_point gt_end = std::chrono::high_resolution_clock::now();
            //                     double gt_duration_ms = std::chrono::duration<double, std::milli>(gt_end - gt_start).count();
            //                     experiment_logger_->logOperation("GT_loading", gt_duration_ms);
            //                 }
            //             }
            //             last_map_epoch_ = epoch;
            //         }

            //         std::chrono::high_resolution_clock::time_point start_time = std::chrono::high_resolution_clock::now();
            //         geometry_msgs::Pose pose = costmap_client_.getRobotPose();

            //         unsigned int mx, my;
            //         if (!cm->worldToMap(pose.position.x, pose.position.y, mx, my)) return;

            //         updateTravelDistance(pose.position);

            //         std::vector<frontier_exploration::Frontier> frontiers = search_->searchFrom(pose.position);
                    
            //         if (frontiers.empty()) {
            //             ROS_INFO("No explorable frontiers remaining");
            //             stop();
            //             return;
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // FRONTIER PROCESSING
            //         // ════════════════════════════════════════════════════════════════
                    
            //         // Önce safest_point'leri senkronize et
            //         for (size_t i = 0; i < frontiers.size(); ++i) {
            //             frontiers[i].safest_point = frontiers[i].centroid;
            //         }
                    
            //         // SADECE use_completed_map=1 VE use_filtering=1 ise filtreleme yap
            //         if (use_completed_map_ == 1 && use_filtering_ == 1) {
            //             // ARTIFICIAL_AREA sebepli tüm frontierları sil
            //             frontier_blacklist_.erase(
            //                 std::remove_if(frontier_blacklist_.begin(), frontier_blacklist_.end(),
            //                     BlacklistReasonFilter(BlacklistReason::ARTIFICIAL_AREA)),
            //                 frontier_blacklist_.end());
                        
            //             // Deneme geçmişini de temizle (yeni map → yeni şans)
            //             attempted_artificial_positions_.clear();

            //             // Var olmayan frontierları temizle (artık frontier olmayan pozisyonlar)
            //             for (size_t i = 0; i < frontier_blacklist_.size(); ) {
            //                 bool exists = false;
            //                 for (size_t j = 0; j < frontiers.size(); ++j) {
            //                     if (std::hypot(frontier_blacklist_[i].position.x - frontiers[j].centroid.x,
            //                                 frontier_blacklist_[i].position.y - frontiers[j].centroid.y) < 0.1) {
            //                         exists = true;
            //                         break;
            //                     }
            //                 }
            //                 if (!exists) {
            //                     frontier_blacklist_.erase(frontier_blacklist_.begin() + i);
            //                 } else {
            //                     ++i;
            //                 }
            //             }
                        
            //             // Filtrelenenleri blacklist'e at
            //             for (size_t i = 0; i < frontiers.size(); ++i) {
            //                 if (frontiers[i].isFlaggedByAnyFilter()) {
            //                     if (!goalOnBlacklist(frontiers[i].safest_point)) {
            //                         frontier_blacklist_.push_back(
            //                             BlacklistEntry(frontiers[i].safest_point, 
            //                                         BlacklistReason::ARTIFICIAL_AREA, 1.0));
            //                     }
            //                 }
            //             }
                        
            //             // LOG: Filtering durumu
            //             size_t artificial_count = 0;
            //             for (size_t i = 0; i < frontier_blacklist_.size(); ++i) {
            //                 if (frontier_blacklist_[i].reason == BlacklistReason::ARTIFICIAL_AREA) {
            //                     artificial_count++;
            //                 }
            //             }
                        
            //             if (log_operations_enabled_ && experiment_logger_) {
            //                 std::ostringstream oss;
            //                 oss << "total_frontiers=" << frontiers.size() 
            //                     << ",blacklist_count=" << artificial_count 
            //                     << ",attempted_count=" << attempted_artificial_positions_.size();
            //                 experiment_logger_->logOperation("debug_filtering", 0, oss.str());
            //             }
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // TARGET SELECTION
            //         // ════════════════════════════════════════════════════════════════
                    
            //         geometry_msgs::Point target_position;
            //         bool found_target = false;
            //         double min_distance = 0.0;

            //         for (size_t i = 0; i < frontiers.size(); ++i) {
            //             if (!found_target && !goalOnBlacklist(frontiers[i].safest_point)) {
            //                 target_position = frontiers[i].safest_point;
            //                 found_target = true;
            //                 min_distance = frontiers[i].min_distance;
                            
            //             }
            //         }
                    
            //         // LOG: Target selection
            //         if (log_operations_enabled_ && experiment_logger_) {
            //             if (found_target) {
            //                 geometry_msgs::Point robot_pos = pose.position;
            //                 double target_dist = std::hypot(target_position.x - robot_pos.x,
            //                                             target_position.y - robot_pos.y);
            //                 std::ostringstream oss;
            //                 oss << "found=1,pos=(" << target_position.x << "," << target_position.y 
            //                     << "),dist=" << target_dist;
            //                 experiment_logger_->logOperation("debug_target", 0, oss.str());
            //             } else {
            //                 experiment_logger_->logOperation("debug_target", 0, "found=0");
            //             }
            //         }

                    
            //         // ══════════════════════════════════════════════════════════════════════════
            //         // BLACKLIST FALLBACK (SAFE & PERSISTENT VERSION)
            //         // ══════════════════════════════════════════════════════════════════════════

            //         if (use_completed_map_ == 1 && use_filtering_ == 1) {
            //             geometry_msgs::Point robot_pos = pose.position;
                        
            //             if (!found_target) {
            //                 ROS_INFO("🔍 FALLBACK: No active target. Checking artificial blacklist candidates...");
                            
            //                 std::vector<std::pair<double, geometry_msgs::Point>> candidates;
            //                 for (size_t i = 0; i < frontier_blacklist_.size(); ++i) {
            //                     if (frontier_blacklist_[i].reason == BlacklistReason::ARTIFICIAL_AREA) {
            //                         std::string key = positionToKey(frontier_blacklist_[i].position);
                                    
            //                         // Daha önce başarısız olduğumuz koordinatları atla
            //                         if (attempted_artificial_positions_.find(key) != attempted_artificial_positions_.end()) {
            //                             continue;
            //                         }
                                    
            //                         double dist = std::hypot(frontier_blacklist_[i].position.x - robot_pos.x,
            //                                                 frontier_blacklist_[i].position.y - robot_pos.y);
            //                         candidates.push_back(std::make_pair(dist, frontier_blacklist_[i].position));
            //                     }
            //                 }
                            
            //                 // En yakından uzağa sırala
            //                 std::sort(candidates.begin(), candidates.end(), 
            //                     [](const std::pair<double, geometry_msgs::Point>& a, const std::pair<double, geometry_msgs::Point>& b) {
            //                         return a.first < b.first;
            //                     });

            //                 bool found_reachable_fallback = false;
            //                 costmap_2d::Costmap2D* costmap = costmap_client_.getCostmap();

            //                 for (size_t i = 0; i < candidates.size(); ++i) {
            //                     geometry_msgs::Point current_candidate = candidates[i].second;
            //                     geometry_msgs::Point projected_goal = current_candidate;
                                
            //                     unsigned int mx, my;
            //                     if (costmap->worldToMap(current_candidate.x, current_candidate.y, mx, my)) {
            //                         unsigned char current_cost = costmap->getCost(mx, my);
                                    
            //                         // 1. ADIM: Eğer nokta geçersizse (Unknown, Lethal, Inscribed), 0 (Free) ara
            //                         if (current_cost >= 253) {
            //                             bool shifted = false;
            //                             // 8x8'lik (yaklaşık 40cm) bir alanda boş hücre ara
            //                             for (int radius = 1; radius <= 8 && !shifted; ++radius) {
            //                                 for (int dx = -radius; dx <= radius && !shifted; ++dx) {
            //                                     for (int dy = -radius; dy <= radius; ++dy) {
            //                                         if (abs(dx) != radius && abs(dy) != radius) continue;
                                                    
            //                                         if (costmap->getCost(mx + dx, my + dy) == 0) {
            //                                             costmap->mapToWorld(mx + dx, my + dy, projected_goal.x, projected_goal.y);
            //                                             shifted = true;
            //                                             break;
            //                                         }
            //                                     }
            //                                 }
            //                             }
            //                             if (!shifted) {
            //                                 ROS_DEBUG("Candidate %zu: No free space within 40cm. Skipping.", i);
            //                                 continue; 
            //                             }
            //                         }
            //                     }

            //                     // 2. ADIM: Planlayıcıdan (MoveBase) yol iste
            //                     nav_msgs::GetPlan srv;
            //                     srv.request.start.header.frame_id = "map";
            //                     srv.request.start.header.stamp = ros::Time::now();
            //                     srv.request.start.pose.position = robot_pos;
            //                     srv.request.start.pose.orientation.w = 1.0;

            //                     srv.request.goal.header.frame_id = "map";
            //                     srv.request.goal.header.stamp = ros::Time::now();
            //                     srv.request.goal.pose.position = projected_goal; // 🔥 PROJECTED GOAL
            //                     srv.request.goal.pose.orientation.w = 1.0;
            //                     srv.request.tolerance = 0.5; // Yarım metre tolerans

            //                     if (make_plan_client_.call(srv) && !srv.response.plan.poses.empty()) {
            //                         // 3. ADIM: BAŞARI - Hedefi güncelle ve döngüden çık
            //                         target_position = projected_goal;
            //                         found_target = true; 
            //                         min_distance = candidates[i].first;
            //                         found_reachable_fallback = true;
                                    
            //                         // Bu noktayı artık denendi olarak işaretle
            //                         attempted_artificial_positions_.insert(positionToKey(current_candidate));
                                    
            //                         ROS_WARN("✅ FALLBACK SUCCESS: Found valid plan for candidate %zu at (%.2f, %.2f)", 
            //                                 i, target_position.x, target_position.y);
            //                         break; 
            //                     } else {
            //                         // Başarısız olursa bu koordinatı işaretle ki bir sonraki sefer denemesin
            //                         attempted_artificial_positions_.insert(positionToKey(current_candidate));
            //                         ROS_DEBUG("Candidate %zu unreachable. Trying next...", i);
            //                     }
            //                 }

            //                 // 4. ADIM: Eğer hiçbir aday işe yaramadıysa keşfi durdur
            //                 if (!found_reachable_fallback && !candidates.empty()) {
            //                     ROS_ERROR("❌ FALLBACK FAILED: All candidates are physically unreachable. Stopping exploration.");
            //                     stop(); 
            //                     return;
            //                 }
            //             }
            //         }

            //         if (!found_target) {
            //             if (log_operations_enabled_ && experiment_logger_) {
            //                 experiment_logger_->logOperation("debug_no_target", 0, "frontiers_exist_but_all_blacklisted");
            //             }
            //             ROS_ERROR("❌ NO FRONTIERS REMAINING");
            //             stop();
            //             return;
            //         }

            //         if (publish_maps_) publishMaps();
            //         if (visualize_) visualizeFrontiers(frontiers, target_position);

            //         // ════════════════════════════════════════════════════════════════
            //         // SEND NAVIGATION GOAL
            //         // ════════════════════════════════════════════════════════════════
                    
            //         static geometry_msgs::Point last_goal_sent;
            //         static bool have_last_goal = false;
            //         const double reissue_thresh = 0.20;

            //         if (found_target && (!have_last_goal || std::hypot(last_goal_sent.x - target_position.x, last_goal_sent.y - target_position.y) > reissue_thresh))
            //         {
            //             if (has_active_target_ && std::hypot(last_goal_sent.x - target_position.x, last_goal_sent.y - target_position.y) > 1.0) {
            //                 if (experiment_logger_) experiment_logger_->logTarget(current_target_, "changed_to_new_target");
            //             }

            //             current_target_ = target_position;
            //             target_start_time_ = ros::Time::now();
            //             target_start_distance_ = total_distance_traveled_;
            //             has_active_target_ = true;

            //             if (experiment_logger_) {
            //                 experiment_logger_->logTarget(target_position, "frontier_selected");
            //             }

            //             if (sendNavigationGoal(target_position, min_distance)) {
            //                 last_goal_sent = target_position;
            //                 have_last_goal = true;
            //             }
            //         }

            //         std::chrono::duration<double, std::milli> duration = std::chrono::duration<double, std::milli>(
            //             std::chrono::high_resolution_clock::now() - start_time);
            //         if (log_operations_enabled_ && experiment_logger_) 
            //             experiment_logger_->logOperation("makePlan_cycle", duration.count());
            //     }
            //     catch (const std::exception& e) { 
            //         ROS_ERROR("Exception in makePlan: %s", e.what()); 
            //     }
            // }

            // void Explore::makePlan()
            // {
            //     try
            //     {
            //         if (with_map_completion == 1) {
            //             ros::spinOnce();
            //         }

            //         costmap_2d::Costmap2D* cm = costmap_client_.getCostmap();
            //         if (!cm) {
            //             ROS_ERROR("Costmap pointer is null");
            //             return;
            //         }

            //         const unsigned int W = cm->getSizeInCellsX();
            //         const unsigned int H = cm->getSizeInCellsY();
            //         const double res = cm->getResolution();

            //         if (W == 0 || H == 0 || res <= 0.0) {
            //             ROS_ERROR("Invalid costmap dimensions: %ux%u, res=%.6f", W, H, res);
            //             return;
            //         }

            //         search_->setMapSaverOriginRes(cm->getOriginX(), cm->getOriginY(), res,
            //                                     static_cast<int>(W), static_cast<int>(H));

            //         const uint64_t epoch = costmap_client_.getMapEpoch();
            //         if (epoch != last_map_epoch_) {
            //             search_->invalidateDistanceField();

            //             if (publish_maps_ && full_gt_loaded_) {
            //                 std::chrono::high_resolution_clock::time_point gt_start = std::chrono::high_resolution_clock::now();
            //                 const int cur_W = W;
            //                 const int cur_H = H;
            //                 const double cur_res = res;
            //                 const double cur_origin_x = cm->getOriginX();
            //                 const double cur_origin_y = cm->getOriginY();
            //                 const double scale = cur_res / full_gt_resolution_;

            //                 cv::Mat full_flipped;
            //                 cv::flip(full_gt_image_, full_flipped, 0);

            //                 cv::Mat M = cv::Mat::zeros(2, 3, CV_64F);
            //                 M.at<double>(0, 0) = scale;
            //                 M.at<double>(1, 1) = scale;

            //                 double world_dx = -cur_origin_x + full_gt_origin_x_;
            //                 double world_dy = cur_origin_y - full_gt_origin_y_;
            //                 double pixel_tx = world_dx / cur_res;
            //                 double pixel_ty = world_dy / cur_res;

            //                 pixel_tx += fine_dx;
            //                 pixel_ty -= fine_dy;

            //                 M.at<double>(0, 2) = pixel_tx;
            //                 M.at<double>(1, 2) = -pixel_ty;

            //                 cv::Mat aligned;
            //                 cv::warpAffine(full_flipped, aligned, M, cv::Size(cur_W, cur_H),
            //                             cv::INTER_NEAREST,
            //                             cv::BORDER_CONSTANT,
            //                             cv::Scalar(205));

            //                 cv::flip(aligned, gt_image_raw_, 0);
            //                 gt_origin_x_ = cur_origin_x;
            //                 gt_origin_y_ = cur_origin_y;
            //                 gt_resolution_ = cur_res;

            //                 search_->setGtImage(gt_image_raw_);
            //                 search_->setYamlOriginRes(gt_origin_x_, gt_origin_y_, gt_resolution_);

            //                 if (log_operations_enabled_ && experiment_logger_) {
            //                     std::chrono::high_resolution_clock::time_point gt_end = std::chrono::high_resolution_clock::now();
            //                     double gt_duration_ms = std::chrono::duration<double, std::milli>(gt_end - gt_start).count();
            //                     experiment_logger_->logOperation("GT_loading", gt_duration_ms);
            //                 }
            //             }
            //             last_map_epoch_ = epoch;
            //         }

            //         std::chrono::high_resolution_clock::time_point start_time = std::chrono::high_resolution_clock::now();
            //         geometry_msgs::Pose pose = costmap_client_.getRobotPose();

            //         unsigned int mx, my;
            //         if (!cm->worldToMap(pose.position.x, pose.position.y, mx, my)) return;

            //         updateTravelDistance(pose.position);

            //         // EĞER HALİ HAZIRDA BİR FALLBACK HEDEFİNE GİDİYORSAK VE HEDEF DEĞİŞMEDİYSE ÇIK
            //         if (is_in_fallback_active_ && has_active_target_) {
            //             ROS_INFO_THROTTLE(2.0, "Already executing fallback goal. Waiting...");
            //             return; 
            //         }

            //         std::vector<frontier_exploration::Frontier> frontiers = search_->searchFrom(pose.position);
                    
            //         if (frontiers.empty()) {
            //             ROS_INFO("No explorable frontiers remaining");
            //             stop();
            //             return;
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // FRONTIER PROCESSING
            //         // ════════════════════════════════════════════════════════════════
                    
            //         // Önce safest_point'leri senkronize et
            //         for (size_t i = 0; i < frontiers.size(); ++i) {
            //             frontiers[i].safest_point = frontiers[i].centroid;
            //         }
                    
            //         // SADECE use_completed_map=1 VE use_filtering=1 ise filtreleme yap
            //         if (use_completed_map_ == 1 && use_filtering_ == 1) {
            //             // ARTIFICIAL_AREA sebepli tüm frontierları sil
            //             frontier_blacklist_.erase(
            //                 std::remove_if(frontier_blacklist_.begin(), frontier_blacklist_.end(),
            //                     BlacklistReasonFilter(BlacklistReason::ARTIFICIAL_AREA)),
            //                 frontier_blacklist_.end());
                        
            //             // Deneme geçmişini de temizle (yeni map → yeni şans)
            //             attempted_artificial_positions_.clear();

            //             // Var olmayan frontierları temizle (artık frontier olmayan pozisyonlar)
            //             for (size_t i = 0; i < frontier_blacklist_.size(); ) {
            //                 bool exists = false;
            //                 for (size_t j = 0; j < frontiers.size(); ++j) {
            //                     if (std::hypot(frontier_blacklist_[i].position.x - frontiers[j].centroid.x,
            //                                 frontier_blacklist_[i].position.y - frontiers[j].centroid.y) < 0.1) {
            //                         exists = true;
            //                         break;
            //                     }
            //                 }
            //                 if (!exists) {
            //                     frontier_blacklist_.erase(frontier_blacklist_.begin() + i);
            //                 } else {
            //                     ++i;
            //                 }
            //             }
                        
            //             // Filtrelenenleri blacklist'e at
            //             for (size_t i = 0; i < frontiers.size(); ++i) {
            //                 if (frontiers[i].isFlaggedByAnyFilter()) {
            //                     if (!goalOnBlacklist(frontiers[i].safest_point)) {
            //                         frontier_blacklist_.push_back(
            //                             BlacklistEntry(frontiers[i].safest_point, 
            //                                         BlacklistReason::ARTIFICIAL_AREA, 1.0));
            //                     }
            //                 }
            //             }
                        
            //             // LOG: Filtering durumu
            //             size_t artificial_count = 0;
            //             for (size_t i = 0; i < frontier_blacklist_.size(); ++i) {
            //                 if (frontier_blacklist_[i].reason == BlacklistReason::ARTIFICIAL_AREA) {
            //                     artificial_count++;
            //                 }
            //             }
                        
            //             if (log_operations_enabled_ && experiment_logger_) {
            //                 std::ostringstream oss;
            //                 oss << "total_frontiers=" << frontiers.size() 
            //                     << ",blacklist_count=" << artificial_count 
            //                     << ",attempted_count=" << attempted_artificial_positions_.size();
            //                 experiment_logger_->logOperation("debug_filtering", 0, oss.str());
            //             }
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // TARGET SELECTION WITH SIMPLE 3-ATTEMPT FALLBACK
            //         // ════════════════════════════════════════════════════════════════
                    
            //         geometry_msgs::Point target_position;
            //         bool found_target = false;
            //         double min_distance = 0.0;
            //         geometry_msgs::Point robot_pos = pose.position;

            //         // ─────────────────────────────────────────────────────────────────
            //         // STEP 1: Try normal frontiers (not blacklisted)
            //         // ─────────────────────────────────────────────────────────────────
            //         for (size_t i = 0; i < frontiers.size(); ++i) {
            //             if (!found_target && !goalOnBlacklist(frontiers[i].safest_point)) {
            //                 target_position = frontiers[i].safest_point;
            //                 found_target = true;
            //                 min_distance = frontiers[i].min_distance;
                            
            //                 // SUCCESS: Reset fallback counter
            //                 fallback_session_count_ = 0;
                            
            //                 ROS_INFO("✅ Normal frontier selected: (%.2f, %.2f)", 
            //                          target_position.x, target_position.y);
            //                 break;
            //             }
            //         }
                    
            //         // LOG: Target selection
            //         if (log_operations_enabled_ && experiment_logger_) {
            //             if (found_target) {
            //                 double target_dist = std::hypot(target_position.x - robot_pos.x,
            //                                                 target_position.y - robot_pos.y);
            //                 std::ostringstream oss;
            //                 oss << "found=1,pos=(" << target_position.x << "," << target_position.y 
            //                     << "),dist=" << target_dist;
            //                 experiment_logger_->logOperation("debug_target", 0, oss.str());
            //             } else {
            //                 experiment_logger_->logOperation("debug_target", 0, "found=0");
            //             }
            //         }

            //         // ─────────────────────────────────────────────────────────────────
            //         // // STEP 2: FALLBACK - Blacklist'ten en yakını seç ve GİT
            //         // // ─────────────────────────────────────────────────────────────────
            //         // if (!found_target && !frontier_blacklist_.empty()) {
                        
            //         //     ROS_WARN("⚠️ No normal frontiers. FALLBACK #%d: Selecting from %zu blacklisted frontiers...", 
            //         //             fallback_session_count_ + 1, frontier_blacklist_.size());
                        
            //         //     // Build candidates from blacklist (sort by distance)
            //         //     std::vector<std::pair<double, geometry_msgs::Point>> candidates;
            //         //     for (size_t i = 0; i < frontier_blacklist_.size(); ++i) {
            //         //         double dist = std::hypot(frontier_blacklist_[i].position.x - robot_pos.x,
            //         //                                 frontier_blacklist_[i].position.y - robot_pos.y);
            //         //         candidates.push_back(std::make_pair(dist, frontier_blacklist_[i].position));
            //         //     }
                        
            //         //     // Sort by distance (closest first)
            //         //     std::sort(candidates.begin(), candidates.end(), 
            //         //         [](const std::pair<double, geometry_msgs::Point>& a, 
            //         //         const std::pair<double, geometry_msgs::Point>& b) {
            //         //             return a.first < b.first;
            //         //         });
                        
            //         //     // Select the closest one
            //         //     geometry_msgs::Point candidate = candidates[0].second;
            //         //     geometry_msgs::Point projected_goal = candidate;
                        
            //         //     // Try to shift if on obstacle
            //         //     costmap_2d::Costmap2D* costmap = costmap_client_.getCostmap();
            //         //     unsigned int mx, my;
            //         //     if (costmap->worldToMap(candidate.x, candidate.y, mx, my)) {
            //         //         unsigned char cost = costmap->getCost(mx, my);
                            
            //         //         if (cost >= 253) {
            //         //             bool shifted = false;
            //         //             for (int radius = 1; radius <= 8 && !shifted; ++radius) {
            //         //                 for (int dx = -radius; dx <= radius && !shifted; ++dx) {
            //         //                     for (int dy = -radius; dy <= radius; ++dy) {
            //         //                         if (abs(dx) != radius && abs(dy) != radius) continue;
                                            
            //         //                         int nx = mx + dx;
            //         //                         int ny = my + dy;
            //         //                         if (nx >= 0 && nx < (int)costmap->getSizeInCellsX() &&
            //         //                             ny >= 0 && ny < (int)costmap->getSizeInCellsY()) {
            //         //                             if (costmap->getCost(nx, ny) == 0) {
            //         //                                 costmap->mapToWorld(nx, ny, projected_goal.x, projected_goal.y);
            //         //                                 shifted = true;
            //         //                                 break;
            //         //                             }
            //         //                         }
            //         //                     }
            //         //                 }
            //         //             }
            //         //         }
            //         //     }
                        
            //         //     // Set target
            //         //     target_position = projected_goal;
            //         //     found_target = true;
            //         //     min_distance = candidates[0].first;
                        
            //         //     ROS_WARN("✅ FALLBACK #%d: Selected blacklisted frontier at (%.2f, %.2f), distance: %.2f m", 
            //         //             fallback_session_count_ + 1, target_position.x, target_position.y, min_distance);
                        
            //         //     // Increment counter
            //         //     fallback_session_count_++;
                        
            //         //     // ✅ COUNTER KONTROLÜ: 3. denemeden sonra DUR
            //         //     if (fallback_session_count_ >= MAX_FALLBACK_ATTEMPTS) {
            //         //         ROS_ERROR("❌ FALLBACK EXHAUSTED: Used all %d attempts. Stopping exploration NEXT makePlan.", 
            //         //                 MAX_FALLBACK_ATTEMPTS);
            //         //         // NOT: Şu anda hedef seçtik, hedefe gidecek. Bir sonraki makePlan'de duracak.
            //         //     }
            //         // }

            //         // ─────────────────────────────────────────────────────────────────
            //         // STEP 2: FALLBACK - TÜM blacklist frontierlarını make_plan ile test et
            //         // ─────────────────────────────────────────────────────────────────
            //         if (!found_target && !frontier_blacklist_.empty()) {

            //             // 1. Cancel current goal
            //             move_base_client_.cancelAllGoals();
            //             ros::Duration(0.5).sleep();  // move_base'in durması için bekle
    
                        
            //             ROS_WARN("⚠️ No normal frontiers. FALLBACK #%d: Testing %zu blacklisted frontiers with make_plan...", 
            //                     fallback_session_count_ + 1, frontier_blacklist_.size());
                        
            //             // Build candidates from blacklist (sort by distance)
            //             std::vector<std::pair<double, geometry_msgs::Point>> candidates;
            //             for (size_t i = 0; i < frontier_blacklist_.size(); ++i) {
            //                 double dist = std::hypot(frontier_blacklist_[i].position.x - robot_pos.x,
            //                                         frontier_blacklist_[i].position.y - robot_pos.y);
            //                 candidates.push_back(std::make_pair(dist, frontier_blacklist_[i].position));
            //             }
                        
            //             // Sort by distance (closest first)
            //             std::sort(candidates.begin(), candidates.end(), 
            //                 [](const std::pair<double, geometry_msgs::Point>& a, 
            //                 const std::pair<double, geometry_msgs::Point>& b) {
            //                     return a.first < b.first;
            //                 });
                        
            //             // make_plan servisi için hazırlık
            //             costmap_2d::Costmap2D* costmap = costmap_client_.getCostmap();
            //             nav_msgs::GetPlan srv;
            //             srv.request.start.header.frame_id = "map";
            //             srv.request.start.pose.position = robot_pos;
            //             srv.request.start.pose.orientation.w = 1.0;
            //             srv.request.goal.header.frame_id = "map";
            //             srv.request.goal.pose.orientation.w = 1.0;
            //             srv.request.tolerance = 0.5;
                        
            //             bool found_reachable = false;
                        
            //             // TÜM blacklist frontierlarını test et
            //             for (size_t i = 0; i < candidates.size(); ++i) {
            //                 geometry_msgs::Point candidate = candidates[i].second;
            //                 geometry_msgs::Point projected_goal = candidate;
                            
            //                 // Try to shift if on obstacle
            //                 unsigned int mx, my;
            //                 if (costmap->worldToMap(candidate.x, candidate.y, mx, my)) {
            //                     unsigned char cost = costmap->getCost(mx, my);
                                
            //                     if (cost >= 253) {  // Unknown/Lethal/Inscribed
            //                         bool shifted = false;
            //                         for (int radius = 1; radius <= 8 && !shifted; ++radius) {
            //                             for (int dx = -radius; dx <= radius && !shifted; ++dx) {
            //                                 for (int dy = -radius; dy <= radius; ++dy) {
            //                                     if (abs(dx) != radius && abs(dy) != radius) continue;
                                                
            //                                     int nx = mx + dx;
            //                                     int ny = my + dy;
            //                                     if (nx >= 0 && nx < (int)costmap->getSizeInCellsX() &&
            //                                         ny >= 0 && ny < (int)costmap->getSizeInCellsY()) {
            //                                         if (costmap->getCost(nx, ny) == 0) {
            //                                             costmap->mapToWorld(nx, ny, projected_goal.x, projected_goal.y);
            //                                             shifted = true;
            //                                             break;
            //                                         }
            //                                     }
            //                                 }
            //                             }
            //                         }
            //                         if (!shifted) {
            //                             ROS_DEBUG("  Candidate %zu: On obstacle, no free space. Skip.", i);
            //                             continue;
            //                         }
            //                     }
            //                 }
                            
            //                 // Test with make_plan
            //                 srv.request.goal.header.stamp = ros::Time::now();
            //                 srv.request.goal.pose.position = projected_goal;
                            
            //                 if (make_plan_client_.call(srv) && !srv.response.plan.poses.empty()) {
            //                     target_position = projected_goal;
            //                     found_target = true;
            //                     found_reachable = true;
            //                     is_in_fallback_active_ = true; // Fallback modunu aktif et
                                
            //                     ROS_WARN("✅ FALLBACK SUCCESS: Targeting %f, %f", target_position.x, target_position.y);
            //                     break;
            //                 } else {
            //                     ROS_DEBUG("  Candidate %zu unreachable, trying next...", i);
                                
            //                 }

                            
            //             }
                        
            //             // Hiçbiri başarılı değil
            //             if (!found_reachable) {
            //                 fallback_session_count_++;
                            
            //                 ROS_ERROR("❌ FALLBACK #%d FAILED: All %zu candidates unreachable. Counter: %d/%d", 
            //                         fallback_session_count_, candidates.size(), 
            //                         fallback_session_count_, MAX_FALLBACK_ATTEMPTS);
                            
            //                 if (fallback_session_count_ >= MAX_FALLBACK_ATTEMPTS) {
            //                     ROS_ERROR("❌ ALL FALLBACKS EXHAUSTED. Stopping exploration.");
            //                     stop();
            //                     return;
            //                 }
                            
            //                 ROS_WARN("⚠️ Attempts remaining: %d. Scheduling replan...", 
            //                         MAX_FALLBACK_ATTEMPTS - fallback_session_count_);
            //                 scheduleReplan();
            //                 return;
            //             }
            //         }
            //         else
            //         {
            //             is_in_fallback_active_ = false;
            //         }

            //         if (found_target) {
            //             if (sendNavigationGoal(target_position, min_distance)) {
            //                 last_goal_sent = target_position;
            //                 have_last_goal = true;
            //                 // Buraya ekle:
            //                 fallback_session_count_ = 0; 
            //             }
            //         }

            //         //─────────────────────────────────────────────────────────────────
            //         // STEP 3: Final check - if still no target found, stop
            //         // ─────────────────────────────────────────────────────────────────
            //         if (!found_target) {
            //             if (log_operations_enabled_ && experiment_logger_) {
            //                 experiment_logger_->logOperation("debug_no_target", 0, "no_frontiers_no_blacklist");
            //             }
            //             ROS_ERROR("❌ NO TARGETS REMAINING (no frontiers, no blacklist)");
            //             stop();
            //             return;
            //         }

            //         if (publish_maps_) publishMaps();
            //         if (visualize_) visualizeFrontiers(frontiers, target_position);

            //         // ════════════════════════════════════════════════════════════════
            //         // SEND NAVIGATION GOAL
            //         // ════════════════════════════════════════════════════════════════
                    
            //         static geometry_msgs::Point last_goal_sent;
            //         static bool have_last_goal = false;
            //         const double reissue_thresh = 0.20;

            //         if (found_target && (!have_last_goal || std::hypot(last_goal_sent.x - target_position.x, last_goal_sent.y - target_position.y) > reissue_thresh))
            //         {
            //             if (has_active_target_ && std::hypot(last_goal_sent.x - target_position.x, last_goal_sent.y - target_position.y) > 1.0) {
            //                 if (experiment_logger_) experiment_logger_->logTarget(current_target_, "changed_to_new_target");
            //             }

            //             current_target_ = target_position;
            //             target_start_time_ = ros::Time::now();
            //             target_start_distance_ = total_distance_traveled_;
            //             has_active_target_ = true;

            //             if (experiment_logger_) {
            //                 experiment_logger_->logTarget(target_position, "frontier_selected");
            //             }

            //             if (sendNavigationGoal(target_position, min_distance)) {
            //                 last_goal_sent = target_position;
            //                 have_last_goal = true;
            //             }
            //         }

            //         std::chrono::duration<double, std::milli> duration = std::chrono::duration<double, std::milli>(
            //             std::chrono::high_resolution_clock::now() - start_time);
            //         if (log_operations_enabled_ && experiment_logger_) 
            //             experiment_logger_->logOperation("makePlan_cycle", duration.count());
            //     }
            //     catch (const std::exception& e) { 
            //         ROS_ERROR("Exception in makePlan: %s", e.what()); 
            //     }
            // }

            void Explore::doneMovingCallback(const actionlib::SimpleClientGoalState& state, 
                                const move_base_msgs::MoveBaseResultConstPtr& result)
            {
                has_active_target_ = false;  // ✅ Hedef tamamlandı (başarılı veya başarısız)
                
                if (state == actionlib::SimpleClientGoalState::ABORTED ||
                    state == actionlib::SimpleClientGoalState::REJECTED)
                {
                    // Başarısız hedefi blacklist'e ekle
                    if (!goalOnBlacklist(current_target_)) {
                        frontier_blacklist_.push_back(
                            BlacklistEntry(current_target_, BlacklistReason::GOAL_ABORTED, 1.0));
                        
                        ROS_WARN("❌ Navigation ABORTED for goal (%.2f, %.2f), added to blacklist as GOAL_ABORTED (total: %zu)",
                                current_target_.x, current_target_.y, frontier_blacklist_.size());
                    } else {
                        ROS_WARN("❌ Navigation ABORTED for goal (%.2f, %.2f), already in blacklist",
                                current_target_.x, current_target_.y);
                    }
                }
                
                if (state == actionlib::SimpleClientGoalState::SUCCEEDED)
                {
                    ROS_DEBUG("✅ Navigation goal succeeded at (%.2f, %.2f)", 
                            current_target_.x, current_target_.y);
                }
                
                scheduleReplan();
            }

            // void Explore::makePlan()
            // {
            //     try
            //     {
            //         if (with_map_completion == 1) {
            //             ros::spinOnce();
            //         }

            //         costmap_2d::Costmap2D* cm = costmap_client_.getCostmap();
            //         if (!cm) {
            //             ROS_ERROR("Costmap pointer is null");
            //             return;
            //         }

            //         const unsigned int W = cm->getSizeInCellsX();
            //         const unsigned int H = cm->getSizeInCellsY();
            //         const double res = cm->getResolution();

            //         if (W == 0 || H == 0 || res <= 0.0) {
            //             ROS_ERROR("Invalid costmap dimensions");
            //             return;
            //         }

            //         // Robotun güncel konumunu al
            //         geometry_msgs::Pose pose = costmap_client_.getRobotPose();
            //         geometry_msgs::Point robot_pos = pose.position;
            //         updateTravelDistance(robot_pos);

            //         // Frontier araması yap
            //         std::vector<frontier_exploration::Frontier> frontiers = search_->searchFrom(robot_pos);
                    
            //         if (frontiers.empty()) {
            //             ROS_INFO("No explorable frontiers remaining");
            //             stop();
            //             return;
            //         }

            //         // Safest point atamaları
            //         for (size_t i = 0; i < frontiers.size(); ++i) {
            //             frontiers[i].safest_point = frontiers[i].centroid;
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // 1. FILTERING & BLACKLIST MANAGEMENT
            //         // ════════════════════════════════════════════════════════════════
            //         if (use_completed_map_ == 1 && use_filtering_ == 1) {
            //             // Eski artificial kayıtlarını temizle (her cycle'da yeniden değerlendirilecekler)
            //             frontier_blacklist_.erase(
            //                 std::remove_if(frontier_blacklist_.begin(), frontier_blacklist_.end(),
            //                     BlacklistReasonFilter(BlacklistReason::ARTIFICIAL_AREA)),
            //                 frontier_blacklist_.end());

            //             // Filtrelere takılanları blacklist'e ekle
            //             size_t added_count = 0;
            //             for (size_t i = 0; i < frontiers.size(); ++i) {
            //                 if (frontiers[i].isFlaggedByAnyFilter()) {
            //                     if (!goalOnBlacklist(frontiers[i].safest_point)) {
            //                         frontier_blacklist_.push_back(
            //                             BlacklistEntry(frontiers[i].safest_point, BlacklistReason::ARTIFICIAL_AREA, 1.0));
            //                         added_count++;
            //                     }
            //                 }
            //             }
            //             if (added_count > 0) {
            //                 ROS_INFO("🔍 Filtering: %zu frontiers moved to blacklist (ARTIFICIAL_AREA)", added_count);
            //             }
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // 2. TARGET SELECTION - RING-BASED FALLBACK STRATEGY
            //         // ════════════════════════════════════════════════════════════════
            //         geometry_msgs::Point target_position;
            //         bool found_target = false;
            //         double min_dist_param = 0.0;

            //         struct Ring { double min; double max; const char* name; };
            //         const Ring RINGS[] = {
            //             {0.0,  5.0,  "0-5m"},
            //             {5.0,  10.0, "5-10m"},
            //             {10.0, 15.0, "10-15m"},
            //             {15.0, 999999.0, "15m+"}
            //         };

            //         // Planlama servisi hazırlığı
            //         nav_msgs::GetPlan srv;
            //         srv.request.start.header.frame_id = "map";
            //         srv.request.start.pose.position = robot_pos;
            //         srv.request.start.pose.orientation.w = 1.0;
            //         srv.request.goal.header.frame_id = "map";
            //         srv.request.goal.pose.orientation.w = 1.0;
            //         srv.request.tolerance = 0.5;

            //         for (size_t ring_idx = 0; ring_idx < 4; ++ring_idx) {
            //             const Ring& ring = RINGS[ring_idx];

            //             // --- ADIM A: Bu halkada NORMAL (filtrelenmemiş) var mı? ---
            //             for (const auto& f : frontiers) {
            //                 if (!f.isFlaggedByAnyFilter() && !goalOnBlacklist(f.safest_point)) {
            //                     double d = std::hypot(f.safest_point.x - robot_pos.x, f.safest_point.y - robot_pos.y);
            //                     if (d >= ring.min && d < ring.max) {
            //                         target_position = f.safest_point;
            //                         min_dist_param = f.min_distance;
            //                         found_target = true;
            //                         ROS_INFO("✅ [Ring %s] Normal target found at (%.2f, %.2f)", ring.name, target_position.x, target_position.y);
            //                         break;
            //                     }
            //                 }
            //             }
            //             if (found_target) break;

            //             // --- ADIM B: Normal yoksa Blacklist'teki ARTIFICIAL olanları test et ---
            //             std::vector<std::pair<double, geometry_msgs::Point>> candidates;
            //             for (const auto& entry : frontier_blacklist_) {
            //                 if (entry.reason == BlacklistReason::ARTIFICIAL_AREA) {
            //                     double d = std::hypot(entry.position.x - robot_pos.x, entry.position.y - robot_pos.y);
            //                     if (d >= ring.min && d < ring.max) {
            //                         candidates.push_back({d, entry.position});
            //                     }
            //                 }
            //             }
            //             // Sadece mesafeye (first) göre sırala, Point mesajını (second) karşılaştırmaya çalışma
            //             std::sort(candidates.begin(), candidates.end(), 
            //                 [](const std::pair<double, geometry_msgs::Point>& a, 
            //                 const std::pair<double, geometry_msgs::Point>& b) {
            //                     return a.first < b.first;
            //                 });

            //             for (const auto& cand : candidates) {
            //                 // Eğer zaten bu noktaya gidiyorsak servisi çağırma, devam et
            //                 if (has_active_target_ && std::hypot(cand.second.x - current_target_.x, cand.second.y - current_target_.y) < 0.4) {
            //                     target_position = cand.second;
            //                     found_target = true;
            //                     break;
            //                 }

            //                 srv.request.goal.pose.position = cand.second;
            //                 if (make_plan_client_.call(srv) && !srv.response.plan.poses.empty()) {
            //                     target_position = cand.second;
            //                     min_dist_param = cand.first;
            //                     found_target = true;
            //                     ROS_WARN("✅ [Ring %s] Blacklist fallback success (Path found): (%.2f, %.2f)", ring.name, target_position.x, target_position.y);
            //                     break;
            //                 }
            //             }
            //             if (found_target) break;
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // 3. EXECUTION
            //         // ════════════════════════════════════════════════════════════════
            //         if (!found_target) {
            //             ROS_ERROR("❌ NO TARGETS FOUND in any ring. Stopping.");
            //             stop();
            //             return;
            //         }

            //         if (publish_maps_) publishMaps();
            //         if (visualize_) visualizeFrontiers(frontiers, target_position);

            //         // Hedef değişti mi veya çok mu uzakta?
            //         const double reissue_thresh = 0.25;
            //         double dist_to_last = std::hypot(current_target_.x - target_position.x, current_target_.y - target_position.y);

            //         if (!has_active_target_ || dist_to_last > reissue_thresh) {
            //             current_target_ = target_position;
            //             has_active_target_ = true;
            //             target_start_time_ = ros::Time::now();

            //             if (sendNavigationGoal(target_position, min_dist_param)) {
            //                 ROS_INFO("🚀 Navigation goal sent to move_base.");
            //             }
            //         }
            //     }
            //     catch (const std::exception& e) {
            //         ROS_ERROR("Exception in makePlan: %s", e.what());
            //     }
            // }

            // void Explore::makePlan()
            // {
            //     try
            //     {
            //         if (with_map_completion == 1) {
            //             ros::spinOnce();
            //         }

            //         costmap_2d::Costmap2D* cm = costmap_client_.getCostmap();
            //         if (!cm) {
            //             ROS_ERROR("Costmap pointer is null");
            //             return;
            //         }

            //         // Robotun güncel konumunu al
            //         geometry_msgs::Pose pose = costmap_client_.getRobotPose();
            //         geometry_msgs::Point robot_pos = pose.position;
            //         updateTravelDistance(robot_pos);

            //         // Frontier araması yap
            //         std::vector<frontier_exploration::Frontier> frontiers = search_->searchFrom(robot_pos);
                    
            //         if (frontiers.empty()) {
            //             ROS_INFO("No explorable frontiers remaining");
            //             stop();
            //             return;
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // 1. BLACKLIST YÖNETİMİ
            //         // ════════════════════════════════════════════════════════════════
                    
            //         // Sadece geçici filtreleri (ARTIFICIAL_AREA) temizle. 
            //         // GOAL_ABORTED (daha önce denenmiş ve yolu çizilememiş olanlar) listede KALMALI.
            //         frontier_blacklist_.erase(
            //             std::remove_if(frontier_blacklist_.begin(), frontier_blacklist_.end(),
            //                 [](const BlacklistEntry& e) { return e.reason == BlacklistReason::ARTIFICIAL_AREA; }),
            //             frontier_blacklist_.end());

            //         // Yeni filtrelenmiş (flagged) olanları geçici blacklist'e ekle
            //         for (size_t i = 0; i < frontiers.size(); ++i) {
            //             frontiers[i].safest_point = frontiers[i].centroid;
            //             if (frontiers[i].isFlaggedByAnyFilter()) {
            //                 // Eğer bu nokta zaten kalıcı blacklist'te (GOAL_ABORTED) değilse ekle
            //                 if (!goalOnBlacklist(frontiers[i].safest_point)) {
            //                     frontier_blacklist_.push_back(
            //                         BlacklistEntry(frontiers[i].safest_point, BlacklistReason::ARTIFICIAL_AREA, 1.0));
            //                 }
            //             }
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // 2. HALKA BAZLI TARGET SELECTION (+5m Artışla)
            //         // ════════════════════════════════════════════════════════════════
            //         geometry_msgs::Point target_position;
            //         bool found_target = false;
            //         double min_dist_param = 0.0;

            //         // Halkaları tanımla: 5 metre aralıklarla
            //         struct Ring { double min; double max; const char* name; };
            //         const Ring RINGS[] = {
            //             {0.0,  10.0,  "0-5m"},
            //             {10.0,  20.0, "5-10m"},
            //             {20.0, 30.0, "10-15m"},
            //             {30.0, 999.0, "15m+"}
            //         };

            //         // Planlama servisi hazırlığı
            //         nav_msgs::GetPlan srv;
            //         srv.request.start.header.frame_id = "map";
            //         srv.request.start.pose.position = robot_pos;
            //         srv.request.start.pose.orientation.w = 1.0;
            //         srv.request.goal.header.frame_id = "map";
            //         srv.request.goal.pose.orientation.w = 1.0;
            //         srv.request.tolerance = 0.5; // Hedefe tam gidemese de yakınına yol bulursa kabul et

            //         for (size_t ring_idx = 0; ring_idx < 4; ++ring_idx) {
            //             const Ring& ring = RINGS[ring_idx];

            //             // --- ADIM A: Bu halkada NORMAL (filtrelenmemiş) frontier var mı? ---
            //             for (const auto& f : frontiers) {
            //                 if (!f.isFlaggedByAnyFilter() && !goalOnBlacklist(f.safest_point)) {
            //                     double d = std::hypot(f.safest_point.x - robot_pos.x, f.safest_point.y - robot_pos.y);
            //                     if (d >= ring.min && d < ring.max) {
            //                         target_position = f.safest_point;
            //                         min_dist_param = f.min_distance;
            //                         found_target = true;
            //                         ROS_INFO("✅ [Ring %s] Normal Frontier Found at (%.2f, %.2f)", ring.name, target_position.x, target_position.y);
            //                         break;
            //                     }
            //                 }
            //             }
            //             if (found_target) break;

            //             // --- ADIM B: Normal yoksa BLACKLIST (Flagged) adayları test et ---
            //             std::vector<std::pair<double, geometry_msgs::Point>> candidates;
            //             for (const auto& entry : frontier_blacklist_) {
            //                 // Sadece "denenmemiş" (ARTIFICIAL_AREA) olanları al
            //                 if (entry.reason == BlacklistReason::ARTIFICIAL_AREA) {
            //                     double d = std::hypot(entry.position.x - robot_pos.x, entry.position.y - robot_pos.y);
            //                     if (d >= ring.min && d < ring.max) {
            //                         candidates.push_back({d, entry.position});
            //                     }
            //                 }
            //             }
                        
            //             // Mesafeye göre sırala (yakın olanı önce test et)
            //             std::sort(candidates.begin(), candidates.end(), 
            //                 [](const std::pair<double, geometry_msgs::Point>& a, const std::pair<double, geometry_msgs::Point>& b) {
            //                     return a.first < b.first;
            //                 });

            //             // --- [DÜZELTİLMİŞ BLACKLIST TEST BLOĞU] ---
            //             if (!candidates.empty()) {
            //                 for (const auto& cand : candidates) {
            //                     // ŞART 1: Eğer zaten bu noktaya gidiyorsak HİÇBİR ŞEY YAPMA, devam et!
            //                     if (has_active_target_ && std::hypot(cand.second.x - current_target_.x, cand.second.y - current_target_.y) < 0.3) {
            //                         target_position = cand.second;
            //                         found_target = true;
            //                         break; 
            //                     }

            //                     // ŞART 2: Yeni bir blacklist adayı test edilecekse move_base'i boşa çıkar
            //                     // Ama bunu SADECE test etmeden hemen önce yap
            //                     move_base_client_.cancelAllGoals();
            //                     ros::Duration(0.05).sleep(); // 0.1 çok uzun gelebilir, 0.05 deneyelim

            //                     srv.request.goal.pose.position = cand.second;
            //                     if (make_plan_client_.call(srv) && !srv.response.plan.poses.empty()) {
            //                         target_position = cand.second;
            //                         found_target = true;
            //                         break; 
            //                     } else {
            //                         // Yol yoksa kalıcı işaretle
            //                         for (auto& entry : frontier_blacklist_) {
            //                             if (std::hypot(entry.position.x - cand.second.x, entry.position.y - cand.second.y) < 0.2) {
            //                                 entry.reason = BlacklistReason::GOAL_ABORTED;
            //                             }
            //                         }
            //                     }
            //                 }
            //             }

            //             if (found_target) break;
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // 3. SONUÇ VE GÖNDERİM
            //         // ════════════════════════════════════════════════════════════════
            //         if (!found_target) {
            //             ROS_ERROR("❌ NO TARGETS FOUND in any ring (Normal or Blacklist). Exploration Finished.");
            //             stop();
            //             return;
            //         }

            //         if (publish_maps_) publishMaps();
            //         if (visualize_) visualizeFrontiers(frontiers, target_position);

            //         // Hedef değişimi kontrolü
            //         const double reissue_thresh = 0.25;
            //         if (!has_active_target_ || std::hypot(current_target_.x - target_position.x, current_target_.y - target_position.y) > reissue_thresh) {
            //             current_target_ = target_position;
            //             has_active_target_ = true;
            //             target_start_time_ = ros::Time::now();
                        
            //             if (sendNavigationGoal(target_position, min_dist_param)) {
            //                 ROS_INFO("🚀 Navigation goal sent to move_base.");
            //             }
            //         }
            //     }
            //     catch (const std::exception& e) {
            //         ROS_ERROR("Exception in makePlan: %s", e.what());
            //     }
            // }

            // void Explore::makePlan()
            // {
            //     try
            //     {
            //         // Harita tamamlama modu aktifse ROS callback'lerini işle
            //         if (with_map_completion == 1) {
            //             ros::spinOnce();
            //         }

            //         costmap_2d::Costmap2D* cm = costmap_client_.getCostmap();
            //         if (!cm) {
            //             ROS_ERROR("Costmap pointer is null");
            //             return;
            //         }

            //         // Robotun güncel konumu ve kat edilen mesafe güncellemesi
            //         geometry_msgs::Pose pose = costmap_client_.getRobotPose();
            //         geometry_msgs::Point robot_pos = pose.position;
            //         updateTravelDistance(robot_pos);

            //         // Frontier araması yap
            //         std::vector<frontier_exploration::Frontier> frontiers = search_->searchFrom(robot_pos);
                    
            //         if (frontiers.empty()) {
            //             ROS_INFO("No explorable frontiers remaining");
            //             stop();
            //             return;
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // 1. BLACKLIST GÜNCELLEME (Eksiksiz)
            //         // ════════════════════════════════════════════════════════════════
                    
            //         // Geçici filtreleri (ARTIFICIAL_AREA) temizle, kalıcı engeller (ABORTED) kalsın
            //         frontier_blacklist_.erase(
            //             std::remove_if(frontier_blacklist_.begin(), frontier_blacklist_.end(),
            //                 [](const BlacklistEntry& e) { return e.reason == BlacklistReason::ARTIFICIAL_AREA; }),
            //             frontier_blacklist_.end());

            //         // Yeni filtrelenmiş (flagged) olanları geçici listeye ekle
            //         for (size_t i = 0; i < frontiers.size(); ++i) {
            //             frontiers[i].safest_point = frontiers[i].centroid;
            //             if (frontiers[i].isFlaggedByAnyFilter()) {
            //                 if (!goalOnBlacklist(frontiers[i].safest_point)) {
            //                     frontier_blacklist_.push_back(
            //                         BlacklistEntry(frontiers[i].safest_point, BlacklistReason::ARTIFICIAL_AREA, 1.0));
            //                 }
            //             }
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // 2. HALKA BAZLI TARGET SELECTION (10m Artışlı & Karma Mantık)
            //         // ════════════════════════════════════════════════════════════════
            //         geometry_msgs::Point target_position;
            //         bool found_target = false;
            //         double min_dist_param = 0.0;

            //         struct Ring { double min; double max; const char* name; };
            //         const Ring RINGS[] = {
            //             {0.0, 10.0, "0-10m"}, 
            //             {10.0, 20.0, "10-20m"}, 
            //             {20.0, 30.0, "20-30m"}, 
            //             {30.0, 999.0, "30m+"}
            //         };

            //         nav_msgs::GetPlan srv;
            //         srv.request.start.header.frame_id = "map";
            //         srv.request.start.pose.position = robot_pos;
            //         srv.request.start.pose.orientation.w = 1.0;
            //         srv.request.goal.header.frame_id = "map";
            //         srv.request.goal.pose.orientation.w = 1.0;
            //         srv.request.tolerance = 0.5;

            //         for (const auto& ring : RINGS) {
            //             // Bu halkadaki tüm adayları (Normal + Flagged) tek bir listede topla
            //             std::vector<std::pair<double, geometry_msgs::Point>> ring_candidates;

            //             // ADIM A: Normal Frontier'ları ekle
            //             for (const auto& f : frontiers) {
            //                 if (!f.isFlaggedByAnyFilter() && !goalOnBlacklist(f.safest_point)) {
            //                     double d = std::hypot(f.safest_point.x - robot_pos.x, f.safest_point.y - robot_pos.y);
            //                     if (d >= ring.min && d < ring.max) {
            //                         ring_candidates.push_back({d, f.safest_point});
            //                     }
            //                 }
            //             }

            //             // ADIM B: Blacklist (Flagged) Frontier'ları ekle
            //             for (const auto& entry : frontier_blacklist_) {
            //                 if (entry.reason == BlacklistReason::ARTIFICIAL_AREA) {
            //                     double d = std::hypot(entry.position.x - robot_pos.x, entry.position.y - robot_pos.y);
            //                     if (d >= ring.min && d < ring.max) {
            //                         ring_candidates.push_back({d, entry.position});
            //                     }
            //                 }
            //             }

            //             // Mesafeye göre sırala (Halkadaki en yakın olanı önce deneyeceğiz)
            //             std::sort(ring_candidates.begin(), ring_candidates.end(), 
            //                 [](const auto& a, const auto& b) { return a.first < b.first; });

            //             // ADIM C: Adayları test et
            //             if (!ring_candidates.empty()) {
            //                 for (const auto& cand : ring_candidates) {
            //                     // Eğer mevcut hedefimize gidiyorsak ve mesafe farkı çok azsa plan sormadan devam et
            //                     if (has_active_target_ && std::hypot(cand.second.x - current_target_.x, cand.second.y - current_target_.y) < 0.3) {
            //                         target_position = cand.second;
            //                         found_target = true;
            //                         break;
            //                     }

            //                     // Yeni bir aday denenecekse move_base planlayıcısını boşa çıkar
            //                     move_base_client_.cancelAllGoals();
            //                     // 0.05 yetmemişti, burayı 0.1 yapıyoruz ki move_base 'inactive' olabilsin
            //                     ros::Duration(0.1).sleep(); 

            //                     srv.request.goal.pose.position = cand.second;
                                
            //                     // make_plan çağrısını yapıyoruz
            //                     if (make_plan_client_.call(srv)) {
            //                         // Eğer plan boş değilse hedefi kabul et
            //                         if (!srv.response.plan.poses.empty()) {
            //                             target_position = cand.second;
            //                             min_dist_param = cand.first;
            //                             found_target = true;
            //                             ROS_INFO("✅ [Ring %s] Target confirmed at (%.2f, %.2f)", ring.name, target_position.x, target_position.y);
            //                             break; 
            //                         } else {
            //                             // Yol çizilemiyorsa bu koordinatı kalıcı olarak GOAL_ABORTED yap
            //                             for (auto& entry : frontier_blacklist_) {
            //                                 if (std::hypot(entry.position.x - cand.second.x, entry.position.y - cand.second.y) < 0.2) {
            //                                     entry.reason = BlacklistReason::GOAL_ABORTED;
            //                                 }
            //                             }
            //                         }
            //                     } else {
            //                         // Eğer servis çağrısı "inactive state" hatası yüzünden başarısız olursa, 
            //                         // noktayı hemen öldürmeyelim, bir sonraki makePlan döngüsünde tekrar şans verelim.
            //                         ROS_WARN("Move_base is still busy, will retry in next cycle for (%.2f, %.2f)", cand.second.x, cand.second.y);
            //                     }
            //                 }
            //             }
            //             if (found_target) break; // Yakın halkada çözüm bulunduysa uzak halkaya geçme
            //         }

            //         // ════════════════════════════════════════════════════════════════
            //         // 3. GÖRSELLEŞTİRME VE HEDEF GÖNDERİMİ (Hiçbir Şey Eksilmedi)
            //         // ════════════════════════════════════════════════════════════════
            //         if (!found_target) {
            //             ROS_ERROR("❌ NO TARGETS FOUND in any ring. Exploration Finished.");
            //             stop();
            //             return;
            //         }

            //         // Rviz görselleştirmelerini yayınla
            //         if (publish_maps_) publishMaps();
            //         if (visualize_) visualizeFrontiers(frontiers, target_position);

            //         // Hedef değişimi eşiği (0.25m) kontrolü
            //         const double reissue_thresh = 0.25;
            //         if (!has_active_target_ || std::hypot(current_target_.x - target_position.x, current_target_.y - target_position.y) > reissue_thresh) {
            //             current_target_ = target_position;
            //             has_active_target_ = true;
            //             target_start_time_ = ros::Time::now();
                        
            //             if (sendNavigationGoal(target_position, min_dist_param)) {
            //                 ROS_INFO("🚀 Navigation goal sent to move_base.");
            //             }
            //         }
            //     }
            //     catch (const std::exception& e) {
            //         ROS_ERROR("Exception in makePlan: %s", e.what());
            //     }
            // }

            // 1. costmap ten frontier lar seçiliyor. 
            // 2. completed_map ten yararlanarak frontier cost ları hesaplanıyor. 
            // 3. eğer costmap e göre frotnier duvara çok yakınsa filrelenip blackliste atılıyor. balcklistte bir de gidilemeyenler 
            // var ama onlar filtrelenmiş flagged ine sahip değil. 
            // 4. target lar en iyi cost a göre seçiliyor. 
            // 5. tüm geçerli frontier lar bitince, fallback yapılıyor. 
            // 6. burada blacklistteki sadece filtrelenmiş olanlar tek tek deneniyor. amaç sahte duvarlardan dolayı 
            // yani costmap te olmayıp da completed_map te olan sahte duvarlardan dolayı filtreleme yapılmışsa oraya gidip 
            // haritayı tamamlamak. burada makePlan kullanılıyor ki gitmeden yol çizilebiliyor mu anlasın ve sadece çizilebiliyorsa gitsin. 
            // 7. eğer bu blacklistteki filtrelenmiş frontier a yol çizilemiyorsa onu artık erişilemiyor diye işaretleyerek blacklistte tutuyor. 
            // yani filtrelenmişleri tararken artık buna bakmayacak. 8. yol çizilebiliyorsa da onu seçip yol çiziyor ve döngüden çıkıyor. 
            // sonra kalanları deniyor. yol çizdiyse azten erase ile geçersiz frontier lar silindiği için o da balackliste olmayacak.

            void Explore::makePlan()
            {
                try {
                    if (with_map_completion == 1) ros::spinOnce();

                    geometry_msgs::Pose pose = costmap_client_.getRobotPose();
                    geometry_msgs::Point robot_pos = pose.position;
                    updateTravelDistance(robot_pos);

                    std::vector<frontier_exploration::Frontier> frontiers = search_->searchFrom(robot_pos);
                    if (frontiers.empty()) { stop(); return; }

                    // Safest point standardizasyonu (senin senaryonda centroid)
                    for (auto& f : frontiers) {
                        f.safest_point = f.centroid;
                    }

                    // ============================================================
                    // Local helpers
                    // ============================================================
                    auto samePoint = [](const geometry_msgs::Point& a,
                                        const geometry_msgs::Point& b,
                                        double eps) {
                        return std::hypot(a.x - b.x, a.y - b.y) < eps;
                    };

                    // eps'i resolution'a bağla (0.20 sabit çok bloklayıcı olabiliyor)
                    const double resolution = costmap_client_.getCostmap()->getResolution();
                    const double blacklist_eps = std::max(0.05, 2.0 * resolution);  // ~2 hücre

                    auto isOnBlacklist = [&](const geometry_msgs::Point& p) -> bool {
                        for (const auto& e : frontier_blacklist_) {
                            if (samePoint(e.position, p, blacklist_eps)) return true;
                        }
                        return false;
                    };

                    // ============================================================
                    // 1) BLACKLIST GÜNCELLEME (sadece ekle; silip sıfırlama YOK)
                    //    - flagged frontier => ARTIFICIAL_AREA entry (yoksa ekle)
                    //    - Daha önce GOAL_ABORTED olanı geri ARTIFICIAL_AREA yapma
                    // ============================================================
                    for (const auto& f : frontiers) {
                        if (!f.isFlaggedByAnyFilter()) continue;

                        bool exists_any_reason = false;
                        for (const auto& e : frontier_blacklist_) {
                            if (samePoint(e.position, f.safest_point, 0.05)) {
                                exists_any_reason = true;
                                break;
                            }
                        }

                        if (!exists_any_reason) {
                            BlacklistEntry be(f.safest_point, BlacklistReason::ARTIFICIAL_AREA, /*confidence*/ 1.0);
                            be.retry_count = 0;
                            frontier_blacklist_.push_back(be);
                        }
                    }

                    geometry_msgs::Point target_position;
                    bool found_target = false;
                    double min_dist_param = 0.0;

                    // ============================================================
                    // ADIM 1: NORMAL KEŞİF
                    // - frontiers zaten searchFrom içinde COST'a göre sıralı geliyor
                    // - flagged olmayan + blacklist olmayan ilk frontier seçilir
                    // ============================================================
                    for (const auto& f : frontiers) {
                        if (f.isFlaggedByAnyFilter()) continue;
                        if (isOnBlacklist(f.safest_point)) continue;

                        target_position = f.centroid;
                        min_dist_param = std::hypot(target_position.x - robot_pos.x,
                                                    target_position.y - robot_pos.y);
                        found_target = true;
                        break; // COST-min frontier bulundu
                    }

                    // ============================================================
                    // ADIM 2: NORMAL HEDEF BİTİNCE -> FALLBACK (BLACKLIST FLAGGED)
                    // - Sadece ARTIFICIAL_AREA olanlar
                    // - distance'a göre dene
                    // - makePlan ile erişilebilirlik kontrolü
                    // - erişilemezse retry_count++ ; 3'ten sonra GOAL_ABORTED
                    // - move_base ACTIVE/PENDING iken fallback deneme
                    // - ÖNEMLİ FIX: plan bulunduğu anda ilgili ARTIFICIAL_AREA entry'yi sil
                    // ============================================================
                    if (!found_target) {

                        auto state = move_base_client_.getState();
                        if (state == actionlib::SimpleClientGoalState::ACTIVE ||
                            state == actionlib::SimpleClientGoalState::PENDING) {
                            return;
                        }

                        const int MAX_ATTEMPTS_PER_ENTRY = 3;

                        // Adayları distance'a göre sırala
                        std::vector<size_t> cand_idx;
                        cand_idx.reserve(frontier_blacklist_.size());

                        for (size_t i = 0; i < frontier_blacklist_.size(); ++i) {
                            const auto& e = frontier_blacklist_[i];
                            if (e.reason != BlacklistReason::ARTIFICIAL_AREA) continue;
                            if (e.retry_count >= MAX_ATTEMPTS_PER_ENTRY) continue;
                            cand_idx.push_back(i);
                        }

                        std::sort(cand_idx.begin(), cand_idx.end(),
                                [&](size_t ia, size_t ib) {
                                    const auto& a = frontier_blacklist_[ia];
                                    const auto& b = frontier_blacklist_[ib];
                                    double da = std::hypot(a.position.x - robot_pos.x, a.position.y - robot_pos.y);
                                    double db = std::hypot(b.position.x - robot_pos.x, b.position.y - robot_pos.y);
                                    return da < db;
                                });

                        // start pose
                        nav_msgs::GetPlan srv;
                        srv.request.start.header.frame_id = "map";
                        srv.request.start.header.stamp = ros::Time(0);
                        srv.request.start.pose.position = robot_pos;
                        srv.request.start.pose.orientation.w = 1.0;

                        srv.request.goal.header.frame_id = "map";
                        srv.request.goal.header.stamp = ros::Time(0);
                        srv.request.goal.pose.orientation.w = 1.0;

                        bool erase_selected_artificial = false;
                        size_t erase_index = 0;

                        for (size_t k = 0; k < cand_idx.size(); ++k) {
                            const size_t idx = cand_idx[k];
                            auto& entry = frontier_blacklist_[idx];

                            // Aynı hedefe sürekli takılma guard'ı
                            if (has_active_target_ &&
                                std::hypot(current_target_.x - entry.position.x,
                                        current_target_.y - entry.position.y) < 0.05) {
                                continue;
                            }

                            move_base_client_.cancelAllGoals();
                            ros::Duration(0.3).sleep();

                            bool grid_success = false;
                            geometry_msgs::Point best_grid_point;

                            // 9x9 grid taraması (-4..4)
                            for (int i = -4; i <= 4 && !grid_success; ++i) {
                                for (int j = -4; j <= 4; ++j) {
                                    geometry_msgs::Point test_goal = entry.position;
                                    test_goal.x += i * resolution;
                                    test_goal.y += j * resolution;

                                    srv.request.goal.pose.position = test_goal;

                                    // 1) tolerance 0
                                    srv.request.tolerance = 0.0;
                                    if (make_plan_client_.call(srv) && !srv.response.plan.poses.empty()) {
                                        best_grid_point = test_goal;
                                        grid_success = true;
                                        break;
                                    }

                                    // 2) tolerance 0.15
                                    srv.request.tolerance = 0.15;
                                    if (make_plan_client_.call(srv) && !srv.response.plan.poses.empty()) {
                                        best_grid_point = srv.response.plan.poses.back().pose.position;
                                        grid_success = true;
                                        break;
                                    }
                                }
                            }

                            if (grid_success) {
                                target_position = best_grid_point;
                                min_dist_param = std::hypot(target_position.x - robot_pos.x,
                                                            target_position.y - robot_pos.y);
                                found_target = true;

                                ROS_INFO("✅ Fallback (ARTIFICIAL_AREA) icin gecis bulundu: (%.3f, %.3f) [attempt=%d/%d]",
                                        target_position.x, target_position.y,
                                        entry.retry_count + 1, MAX_ATTEMPTS_PER_ENTRY);

                                // FIX: Bu entry artık normal hedefleri bloklamasın diye SIL
                                erase_selected_artificial = true;
                                erase_index = idx;

                                break; // distance-min adaylardan ilk erişilebilen seçildi
                            } else {
                                entry.retry_count += 1;

                                if (entry.retry_count >= MAX_ATTEMPTS_PER_ENTRY) {
                                    entry.reason = BlacklistReason::GOAL_ABORTED;
                                    ROS_WARN("❌ Fallback hedefi erisilemez -> GOAL_ABORTED. (attempt=%d/%d)",
                                            entry.retry_count, MAX_ATTEMPTS_PER_ENTRY);
                                } else {
                                    ROS_WARN("❌ Fallback hedefi erisilemez -> tekrar denenecek. (attempt=%d/%d)",
                                            entry.retry_count, MAX_ATTEMPTS_PER_ENTRY);
                                }
                            }
                        }

                        if (erase_selected_artificial) {
                            if (erase_index < frontier_blacklist_.size()) {
                                frontier_blacklist_.erase(frontier_blacklist_.begin() + erase_index);
                            }
                        }
                    }

                    if (!found_target) { stop(); return; }

                    if (publish_maps_) publishMaps();
                    if (visualize_) visualizeFrontiers(frontiers, target_position);

                    if (!has_active_target_ ||
                        std::hypot(current_target_.x - target_position.x,
                                current_target_.y - target_position.y) > 0.1) {

                        current_target_ = target_position;
                        has_active_target_ = true;
                        sendNavigationGoal(target_position, min_dist_param);
                    }

                } catch (const std::exception& e) {
                    ROS_ERROR("Exception: %s", e.what());
                }
            }


            

            // Fixed goalOnBlacklist with bounds checking
            bool Explore::goalOnBlacklist(const geometry_msgs::Point& goal)
            {
                if (!std::isfinite(goal.x) || !std::isfinite(goal.y)) {
                    ////ROS_DEBUG("Goal has invalid coordinates");
                    return true; // Treat invalid goals as blacklisted
                }

                costmap_2d::Costmap2D* costmap2d = costmap_client_.getCostmap();
                if (!costmap2d) {
                    //ROS_WARN("Costmap is null in goalOnBlacklist");
                    return true;
                }

                double res = costmap_client_.getCostmap()->getResolution();
                const double tolerance_m = std::min(0.35, std::max(2.0*res, 0.20)); // ~2–3 cells
                
                for (const auto& frontier_goal : frontier_blacklist_) {
                    if (!std::isfinite(frontier_goal.x) || !std::isfinite(frontier_goal.y)) {
                        continue; // Skip invalid blacklisted goals
                    }
                    
                    double distance = std::hypot(goal.x - frontier_goal.x, goal.y - frontier_goal.y);
                    if (distance < tolerance_m) {
                        ////ROS_DEBUG("Goal (%.3f, %.3f) matches blacklisted goal (%.3f, %.3f), distance=%.3f",
                                //goal.x, goal.y, frontier_goal.x, frontier_goal.y, distance);
                        return true;
                    }
                }
                
                return false;
            }



            void Explore::reachedGoal(const actionlib::SimpleClientGoalState& status,
                                    const move_base_msgs::MoveBaseResultConstPtr& result,
                                    const geometry_msgs::Point& frontier_goal)
            {
                //ROS_INFO("Reached goal with status: %s at (%.2f, %.2f)", 
                    // status.toString().c_str(), frontier_goal.x, frontier_goal.y);
                
                // Enhanced debugging for failed goals
                if (status == actionlib::SimpleClientGoalState::ABORTED) {
                    //ROS_WARN("Goal ABORTED - analyzing failure reason:");
                    
                    // Check if goal is in free space according to costmap
                    unsigned int gx, gy;
                    auto* costmap = costmap_client_.getCostmap();
                    if (costmap && costmap->worldToMap(frontier_goal.x, frontier_goal.y, gx, gy)) {
                        unsigned char cost = costmap->getCost(gx, gy);
                        //ROS_WARN("Goal costmap value: %u (0=lethal, 253=neutral, 254=free, 255=unknown)", cost);
                        
                        // Check surrounding area
                        int free_neighbors = 0, total_neighbors = 0;
                        for (int dx = -2; dx <= 2; dx++) {
                            for (int dy = -2; dy <= 2; dy++) {
                                if (costmap->worldToMap(frontier_goal.x + dx*0.1, frontier_goal.y + dy*0.1, gx, gy)) {
                                    total_neighbors++;
                                    if (costmap->getCost(gx, gy) >= costmap_2d::FREE_SPACE) {
                                        free_neighbors++;
                                    }
                                }
                            }
                        }
                        //ROS_WARN("Goal neighborhood: %d/%d cells are free", free_neighbors, total_neighbors);
                    }
                    
                    // Test if make_plan can find a path to this goal
                    if (validate_with_makeplan_) {
                        auto robot_pose = costmap_client_.getRobotPose();
                        double path_length = dc_.computeDistanceUsingMakePlan(
                            robot_pose.position.x, robot_pose.position.y,
                            frontier_goal.x, frontier_goal.y);
                        
                        if (std::isfinite(path_length)) {
                            //ROS_WARN("make_plan found path of %.2f m - move_base issue", path_length);
                        } else {
                            //ROS_WARN("make_plan also failed - no valid path exists");
                        }
                    }
                    
                    frontier_blacklist_.push_back(frontier_goal);
                    //ROS_WARN("Added goal (%.2f, %.2f) to blacklist (total: %zu)", 
                            //frontier_goal.x, frontier_goal.y, frontier_blacklist_.size());
                }
                
                scheduleReplan();
            }
            
            void Explore::start()
            {
                exploring_timer_.start();
                beginClock = clock();
                //ROS_INFO("Start time: %s", to_string(beginClock).c_str());
            }

            void Explore::stop()
            {
                move_base_client_.cancelAllGoals();
                exploring_timer_.stop();
                endClock = clock();

                double elapsed_secs = double(endClock - beginClock) / CLOCKS_PER_SEC;
                //ROS_INFO("Elapsed time: %s", to_string(elapsed_secs).c_str());

                // Save elapsed time to a file
                // std::ofstream outfile;
                // outfile.open("/home/user/exploration_time.txt", std::ios::out | std::ios::app); // Append mode
                // if (outfile.is_open()) {
                //   outfile << "Elapsed time: " << elapsed_secs << " seconds\n";
                //   outfile.close();
                //   //ROS_INFO("Elapsed time saved to /home/user/exploration_time.txt");
                // } else {
                //   //ROS_ERROR("Failed to open file for writing elapsed time.");
                // }
                
                
                // Publish exploration completion message
                std_msgs::Int32 msg;
                msg.data = 1; // 1 indicates completion
                exploration_finished_pub_.publish(msg);

                //ROS_INFO("Exploration finished.");

                // Shut down the ROS node
                ros::shutdown();

            }



            // Helper function to check if target should be validated
            bool Explore::shouldValidateTarget(double grid_len_m) const
            {
                // Check move_base state
                auto state = move_base_client_.getState();
                bool client_ready = (state == actionlib::SimpleClientGoalState::SUCCEEDED ||
                                    state == actionlib::SimpleClientGoalState::ABORTED ||
                                    state == actionlib::SimpleClientGoalState::RECALLED ||
                                    state == actionlib::SimpleClientGoalState::PREEMPTED ||
                                    state == actionlib::SimpleClientGoalState::LOST ||
                                    state == actionlib::SimpleClientGoalState::PENDING);
                
                constexpr double kShortMeters = 1.5;
                return client_ready && std::isfinite(grid_len_m) && grid_len_m > kShortMeters;
            }

            // Helper function to validate target with make_plan
            bool Explore::validateTargetWithMakePlan(const geometry_msgs::Point& robot_pos,
                                                    const geometry_msgs::Point& target_pos,
                                                    double grid_len_m)
            {
                    // Throttle repeated checks
                    static geometry_msgs::Point last_checked_goal;
                    static ros::Time last_checked_ts(0);
                    
                    const bool same_goal = (std::fabs(last_checked_goal.x - target_pos.x) < 1e-3) &&
                                            (std::fabs(last_checked_goal.y - target_pos.y) < 1e-3);
                    const bool throttle_ok = (ros::Time::now() - last_checked_ts) > ros::Duration(1.5);
                    
                    if (same_goal && !throttle_ok) {
                        return true; // Skip validation, assume OK
                    }
                    
                    last_checked_goal = target_pos;
                    last_checked_ts = ros::Time::now();
                    
                    double plan_length = dc_.computeDistanceUsingMakePlan(
                        robot_pos.x, robot_pos.y, target_pos.x, target_pos.y);
                    
                    if (!std::isfinite(plan_length)) {
                        //ROS_WARN("make_plan unavailable; skipping validation (no blacklist)");
                        // Option A: allow proceed (best to avoid stalls early in exploration)
                        return true;

                        // Option B (safer): just replan without blacklisting
                        // scheduleReplan();
                        // return false;
                    }
                    
                    // Check for excessive detour
                    constexpr double kRatioMax = 1.8;
                    constexpr double kEps = 0.05;
                    if (grid_len_m > kEps && plan_length > kRatioMax * grid_len_m + kEps) {
                        //ROS_WARN("Blacklisting target: excessive detour (%.2fm vs grid %.2fm)",
                                //plan_length, grid_len_m);
                        frontier_blacklist_.push_back(target_pos);
                        scheduleReplan();
                        return false;
                    }
                    
                    return true;
            }

            // Helper function to send navigation goal
            bool Explore::sendNavigationGoal(const geometry_msgs::Point& target_position, double min_distance)
            {
                move_base_msgs::MoveBaseGoal goal;
                goal.target_pose.pose.position = target_position;
                goal.target_pose.pose.orientation.w = 1.0;
                goal.target_pose.header.frame_id = costmap_client_.getGlobalFrameID();
                goal.target_pose.header.stamp = ros::Time::now();

                // Progress tracking
                bool same_goal = (prev_goal_ == target_position);
                prev_goal_ = target_position;

                ROS_ERROR("min_distance: %f , prev_distance_: %f, time_since_progress: %f s, progress_timeout_: %f s", 
                        min_distance, prev_distance_, (ros::Time::now() - last_progress_).toSec(), progress_timeout_.toSec());

                if (!same_goal || prev_distance_ > min_distance) {
                    last_progress_ = ros::Time::now();
                    prev_distance_ = min_distance;
                    // if(!same_goal) ROS_ERROR("!same_goal");
                    // if(prev_distance_ > min_distance) ROS_ERROR("closer to target");

                    
                } 
                if (ros::Time::now() - last_progress_ > progress_timeout_) {
                    ROS_ERROR("TIMEOUT! Stalled for %.1f seconds (timeout: %.1f s)", 
                            (ros::Time::now() - last_progress_).toSec(), 
                            progress_timeout_.toSec());
                    frontier_blacklist_.push_back(target_position);
                    ROS_ERROR("BLACKLISTING frontier at (%.2f, %.2f) - Total: %zu", 
                        target_position.x, target_position.y, 
                        frontier_blacklist_.size() + 1);
                    scheduleReplan();
                    return false;
                }
                // else{
                //      ROS_ERROR("time_since_progress: %f s", (ros::Time::now() - last_progress_).toSec());
                // }

                // Send goal with callback
                move_base_client_.sendGoal(
                    goal,
                    [this, target_position](const actionlib::SimpleClientGoalState& status,
                                            const move_base_msgs::MoveBaseResultConstPtr& result) 
                                            {
                                                //ROS_ERROR("in sendGoal");
                        reachedGoal(status, result, target_position);
                    }
                );

               

                //ROS_INFO("Sent goal (%.3f, %.3f), estimated distance: %.3f m",
                        //target_position.x, target_position.y, min_distance);
                
                return true;
            }

            // Helper function to schedule replanning
            void Explore::scheduleReplan()
            {
                oneshot_.stop(); // ÖNCE DURDUR
                const double cd = 0.4; // or read from param ~replan_cooldown
                oneshot_ = relative_nh_.createTimer(
                        ros::Duration(cd),
                        [this](const ros::TimerEvent&){ makePlan(); },
                        true);

            }

            void Explore::floodFillFromFreeSpace(std::vector<int8_t>& grid, int width, int height)
            {
                // Step 1: Apply morphological closing to obstacles to fill small gaps
                // Create a binary obstacle map
                cv::Mat obstacle_map(height, width, CV_8UC1);
                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        int idx = y * width + x;
                        // Mark obstacles (100) as 255, everything else as 0
                        obstacle_map.at<unsigned char>(y, x) = (grid[idx] == 100) ? 255 : 0;
                    }
                }
                
                // Apply morphological closing to fill small gaps in walls
                cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3));
                cv::Mat closed_obstacles;
                cv::morphologyEx(obstacle_map, closed_obstacles, cv::MORPH_CLOSE, kernel);
                
                // Update grid with closed obstacles
                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        int idx = y * width + x;
                        if (closed_obstacles.at<unsigned char>(y, x) == 255 && grid[idx] != 100) {
                            // This cell became an obstacle after closing
                            grid[idx] = 100;
                        }
                    }
                }
                
                // Step 2: Now do flood fill with the closed obstacles
                std::vector<bool> reachable(width * height, false);
                
                // Find a seed point in known free space
                int seed_idx = -1;
                for (size_t i = 0; i < grid.size(); i++) {
                    if (grid[i] == 0) {  // Free space
                        seed_idx = i;
                        break;
                    }
                }
                
                if (seed_idx == -1) {
                    //ROS_WARN("No free space found in map for flood fill!");
                    return;
                }
                
                // BFS flood fill from free space
                std::queue<Point> queue;
                int seed_x = seed_idx % width;
                int seed_y = seed_idx / width;
                queue.push(Point(seed_x, seed_y));
                reachable[seed_idx] = true;
                
                // 4-connectivity (up, down, left, right)
                int dx[] = {0, 0, 1, -1};
                int dy[] = {1, -1, 0, 0};
                
                while (!queue.empty()) {
                    Point p = queue.front();
                    queue.pop();
                    
                    // Check all 4 neighbors
                    for (int i = 0; i < 4; i++) {
                        int nx = p.x + dx[i];
                        int ny = p.y + dy[i];
                        
                        // Check bounds
                        if (nx < 0 || nx >= width || ny < 0 || ny >= height)
                            continue;
                        
                        int idx = ny * width + nx;
                        
                        // Check if already visited
                        if (reachable[idx])
                            continue;
                        
                        // Check if traversable (free or unknown, not occupied)
                        if (grid[idx] == 0 || grid[idx] == -1) {
                            reachable[idx] = true;
                            queue.push(Point(nx, ny));
                        }
                    }
                }
                
                // Mark enclosed unknown cells as occupied
                int converted = 0;
                for (size_t i = 0; i < grid.size(); i++) {
                    if (grid[i] == -1 && !reachable[i]) {
                        grid[i] = 100;  // Enclosed unknown -> occupied
                        converted++;
                    }
                }
                
                //ROS_INFO("Morphological closing + flood fill converted %d enclosed cells to occupied", converted);
            }

        
            void Explore::publishMaps() 
            {
                // Costmap'in orijinal parametrelerini al
                auto* cm = costmap_client_.getCostmap();
                if (!cm) return;
                
                const double costmap_origin_x = cm->getOriginX();
                const double costmap_origin_y = cm->getOriginY();
                const double costmap_resolution = cm->getResolution();
                const std::string global_frame = costmap_client_.getGlobalFrameID();

                // ✅ COMPLETED_MAP: HER ZAMAN COSTMAP PARAMETRELERİNİ KULLAN
                if(use_completed_map_)
                {
                    cv::Mat completed_mat = search_->completedMapMat().clone();
                    if (!completed_mat.empty()) {
                        search_->publishMap(completed_mat, 
                                        completed_pub_, 
                                        global_frame,
                                        costmap_origin_x,    // COSTMAP origin kullan
                                        costmap_origin_y,    // COSTMAP origin kullan  
                                        costmap_resolution); // COSTMAP resolution kullan
                    }

                    
                }

                if(use_closed_live_map_ && publish_closed_live_map_)
                {
                    // ✅ CLOSED_MAP: HER ZAMAN COSTMAP PARAMETRELERİNİ KULLAN
                    cv::Mat closed_live_mat= search_->liveClosedMapMat().clone();
                    if (!closed_live_mat.empty()) {
                        search_->publishMap(closed_live_mat, 
                                        closed_live_pub_, 
                                        global_frame,
                                        costmap_origin_x,    // COSTMAP origin kullan
                                        costmap_origin_y,    // COSTMAP origin kullan  
                                        costmap_resolution); // COSTMAP resolution kullan
                    }
                }

                // ✅ GT_MAP: Eğer yüklüyse, AYNI COSTMAP PARAMETRELERİNİ kullan
                if (!gt_image_raw_.empty()) {
                    // GT'yi costmap koordinat sisteminde yayınla
                    search_->publishMap(gt_image_raw_, 
                                    gt_map_pub_, 
                                    global_frame,
                                    costmap_origin_x,    // AYNI origin
                                    costmap_origin_y,    // AYNI origin
                                    costmap_resolution); // AYNI resolution
                }
            }


            bool Explore::validateParameters()
            {
                bool valid = true;
                
                // Validate numeric parameters
                if (planner_frequency_ <= 0.0 || planner_frequency_ > 10.0) {
                    //ROS_ERROR("Invalid planner_frequency: %.2f (should be 0.1-10.0)", planner_frequency_);
                    planner_frequency_ = std::max(0.1, std::min(planner_frequency_, 10.0));  // Fixed
                    valid = false;
                }
                
                if (timeout <= 0.0 || timeout > 3600.0) {
                    //ROS_ERROR("Invalid progress_timeout: %.2f (should be 1.0-3600.0)", timeout);
                    timeout = std::max(1.0, std::min(timeout, 3600.0));  // Fixed
                    valid = false;
                }
                
                if (potential_scale_ < 0.0) {
                    //ROS_ERROR("Invalid potential_scale: %.6f (should be >= 0)", potential_scale_);
                    potential_scale_ = std::abs(potential_scale_);
                    valid = false;
                }
                
                if (gain_scale_ < 0.0) {
                    //ROS_ERROR("Invalid gain_scale: %.6f (should be >= 0)", gain_scale_);
                    gain_scale_ = std::abs(gain_scale_);
                    valid = false;
                }
                
                if (min_frontier_size < 0.01 || min_frontier_size > 100.0) {
                    //ROS_ERROR("Invalid min_frontier_size: %.3f (should be 0.01-100.0)", min_frontier_size);
                    min_frontier_size = std::max(0.01, std::min(min_frontier_size, 100.0));  // Fixed
                    valid = false;
                }
                
                // Validate GT parameters if GT is enabled
                if (!gt_image_path_.empty()) {
                    if (gt_resolution_ <= 0.0) {
                        //ROS_ERROR("Invalid gt_resolution: %.6f (should be > 0)", gt_resolution_);
                        gt_resolution_ = 0.1; // Reasonable default
                        valid = false;
                    }
                }
                
                // Validate completion parameters
                if (rect_size_ <= 0 || rect_size_ > 500) {
                    //ROS_ERROR("Invalid rect_size: %d (should be 1-500)", rect_size_);
                    rect_size_ = std::max(1, std::min(rect_size_, 500));  // Fixed
                    valid = false;
                }
                
                return valid;
            }


            bool Explore::preFlightCheckWithAstar(const geometry_msgs::Point& robot_pos,
                                            const geometry_msgs::Point& target_pos,
                                            double grid_len_m)
            {
                (void)grid_len_m; // şu an kullanılmıyor

                //ROS_WARN("=== preFlightCheckWithAstar DEBUG ===");
                //ROS_WARN("Robot: (%.3f, %.3f) -> Target: (%.3f, %.3f)", 
                        //robot_pos.x, robot_pos.y, target_pos.x, target_pos.y);

                costmap_2d::Costmap2D* cm = costmap_client_.getCostmap();
                if (!cm) {
                    //ROS_WARN("preFlightCheckWithAstar: no costmap");
                    return false;
                }

                unsigned int sx, sy, gx, gy;
                if (!cm->worldToMap(robot_pos.x,  robot_pos.y,  sx, sy)) {
                    //ROS_WARN("preFlightCheckWithAstar: start out of map (%.3f, %.3f)", robot_pos.x, robot_pos.y);
                    return false;
                }
                if (!cm->worldToMap(target_pos.x, target_pos.y, gx, gy)) {
                    //ROS_WARN("preFlightCheckWithAstar: goal out of map (%.3f, %.3f)", target_pos.x, target_pos.y);
                    return false;
                }

                //ROS_WARN("Map coords: start=(%u,%u), goal=(%u,%u)", sx, sy, gx, gy);

                const int W = static_cast<int>(cm->getSizeInCellsX());
                const int H = static_cast<int>(cm->getSizeInCellsY());
                const double res = cm->getResolution();
                
                //ROS_WARN("Map: %dx%d, resolution=%.3f", W, H, res);

                auto inb    = [&](int x, int y){ return (0 <= x && x < W && 0 <= y && y < H); };
                auto toIdx  = [&](int x, int y){ return y * W + x; };
                auto isObs  = [&](int x, int y)->bool {
                    const unsigned char c = cm->getCost(x, y);
                    // Sadece gerçek engelleri engel say: unknown serbest
                    return (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) && (c != costmap_2d::NO_INFORMATION);
                };

                // Başlangıç ve hedef cost kontrolü
                unsigned char start_cost = cm->getCost(sx, sy);
                unsigned char goal_cost = cm->getCost(gx, gy);
                
                //ROS_WARN("Start cost: %u, Goal cost: %u", start_cost, goal_cost);
                //ROS_WARN("Start blocked: %s, Goal blocked: %s", 
                        // isObs(sx, sy) ? "YES" : "NO", 
                        // isObs(gx, gy) ? "YES" : "NO");

                // Başlangıç engeldeyse direkt reddet
                if (isObs((int)sx, (int)sy)) {
                    //ROS_WARN("preFlightCheckWithAstar: FAILED - start cell is obstacle");
                    return false;
                }

                // --- Hedefi yakındaki bir FREE hücreye SNAP et (hedef engeldeyse) ---
                int gx_ok = static_cast<int>(gx), gy_ok = static_cast<int>(gy);
                if (isObs((int)gx, (int)gy)) {
                    //ROS_WARN("Goal is obstacle, attempting to snap to nearby free cell...");
                    
                    const double res_safe = std::max(cm->getResolution(), 1e-6);
                    const int snap_r_cells = std::max(1, (int)std::round(0.40 / res_safe)); // ~0.4 m yarıçap
                    
                    //ROS_WARN("Snap radius: %d cells (%.3f m)", snap_r_cells, snap_r_cells * res_safe);
                    
                    std::deque<std::pair<int,int>> q;
                    std::vector<uint8_t> vis((size_t)W*(size_t)H, 0);

                    q.emplace_back((int)gx, (int)gy);
                    vis[(size_t)toIdx((int)gx,(int)gy)] = 1;

                    bool found = false;
                    int snap_attempts = 0;
                    
                    while (!q.empty() && snap_attempts < 1000) {
                        // C++11 uyumlu structured binding yerine:
                        std::pair<int,int> current = q.front(); 
                        q.pop_front();
                        int cx = current.first;
                        int cy = current.second;
                        snap_attempts++;
                        
                        if (!isObs(cx, cy)) {
                            gx_ok = cx; gy_ok = cy;
                            found = true;
                            //ROS_WARN("Snap successful: (%u,%u)->(%d,%d) after %d attempts", 
                                //  gx, gy, gx_ok, gy_ok, snap_attempts);
                            break;
                        }
                        
                        // yarıçap kısıtı
                        const int dx0 = cx - (int)gx;
                        const int dy0 = cy - (int)gy;
                        if (dx0*dx0 + dy0*dy0 > snap_r_cells*snap_r_cells) continue;

                        static const int NX[8] = { 1, 1, 0,-1,-1,-1, 0, 1};
                        static const int NY[8] = { 0, 1, 1, 1, 0,-1,-1,-1};
                        for (int k=0;k<8;++k) {
                            const int nx = cx + NX[k];
                            const int ny = cy + NY[k];
                            if (!inb(nx,ny)) continue;
                            const size_t nidx = (size_t)toIdx(nx,ny);
                            if (vis[nidx]) continue;
                            vis[nidx] = 1;
                            q.emplace_back(nx,ny);
                        }
                    }

                    if (!found) {
                        //ROS_WARN("preFlightCheckWithAstar: FAILED - goal in obstacle and no nearby free cell found after %d attempts", snap_attempts);
                        return false;
                    }
                } else {
                    //ROS_WARN("Goal is already free, no snapping needed");
                }

                //ROS_WARN("Final goal coords: (%d,%d)", gx_ok, gy_ok);

                // --- A* (h=0 => Dijkstra), sadece costmap'e göre geçiş ---
                struct Node { int idx; double g; double f; bool operator<(const Node& o) const { return f > o.f; } };
                std::priority_queue<Node> open;
                const size_t N = (size_t)W * (size_t)H;
                std::vector<uint8_t>  closed(N, 0);
                std::vector<double>   g(N, std::numeric_limits<double>::infinity());

                static const int DX[8]   = { 1, 1, 0,-1,-1,-1, 0, 1};
                static const int DY[8]   = { 0, 1, 1, 1, 0,-1,-1,-1};
                static const double STEP[8] = {
                    1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0),
                    1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0)
                };

                const int sidx = toIdx((int)sx,(int)sy);
                const int gidx = toIdx(gx_ok, gy_ok);
                
                //ROS_WARN("A* search: sidx=%d, gidx=%d", sidx, gidx);
                
                g[sidx] = 0.0;
                open.push({sidx, 0.0, 0.0});

                size_t it = 0;
                size_t expansions = 0;
                const size_t it_max = std::max((size_t)100000, 2*N); // güvenli üst sınır

                while (!open.empty() && it++ < it_max) {
                    Node cur = open.top(); open.pop();
                    if (closed[cur.idx]) continue;
                    closed[cur.idx] = 1;
                    expansions++;

                    if (cur.idx == gidx) {
                        // reached
                        //ROS_WARN("preFlightCheckWithAstar: SUCCESS - path found after %zu expansions, cost=%.3f", 
                                //expansions, cur.g);
                        return true;
                    }

                    const int cx = cur.idx % W;
                    const int cy = cur.idx / W;

                    int valid_neighbors = 0;
                    for (int k=0;k<8;++k) {
                        const int nx = cx + DX[k];
                        const int ny = cy + DY[k];
                        if (!inb(nx,ny)) continue;

                        // köşe kesme: ortogonaller engelse izin verme
                        if (DX[k] != 0 && DY[k] != 0) {
                            if (isObs(cx + DX[k], cy) || isObs(cx, cy + DY[k])) continue;
                        }
                        if (isObs(nx,ny)) continue;

                        valid_neighbors++;

                        const int nidx = toIdx(nx,ny);
                        const double ng = cur.g + STEP[k];
                        if (!closed[nidx] && ng < g[nidx]) {
                            g[nidx] = ng;
                            // h=0 (sadece doğrulama)
                            open.push({nidx, ng, ng});
                        }
                    }
                    
                    // İlk birkaç expansion için detay
                    if (expansions <= 10) {
                        //ROS_WARN("Expansion %zu: cell (%d,%d), valid_neighbors=%d, open_size=%zu", 
                            // expansions, cx, cy, valid_neighbors, open.size());
                    }
                    
                    // Eğer hiç komşu yoksa stuck olabiliriz
                    if (valid_neighbors == 0 && expansions <= 5) {
                        //ROS_WARN("No valid neighbors found at (%d,%d) - checking surrounding costs:", cx, cy);
                        for (int k=0;k<8;++k) {
                            const int nx = cx + DX[k];
                            const int ny = cy + DY[k];
                            if (inb(nx,ny)) {
                                unsigned char cost = cm->getCost(nx, ny);
                                //ROS_WARN("  Neighbor (%d,%d): cost=%u, blocked=%s", 
                                    // nx, ny, cost, isObs(nx,ny) ? "YES" : "NO");
                            }
                        }
                    }
                }

                if (it >= it_max) {
                    //ROS_WARN("preFlightCheckWithAstar: FAILED - iteration cap reached (%zu expansions)", expansions);
                } else {
                    //ROS_WARN("preFlightCheckWithAstar: FAILED - no path found (%zu expansions, final open_size=%zu)", 
                        // expansions, open.size());
                }
                return false;
            }


            void Explore::metricsTimerCallback(const ros::TimerEvent&)
            {
                if (!experiment_logger_) return;
    
                double elapsed_sec = (ros::Time::now() - exploration_start_time_).toSec();
                double completion_percent = calculateExplorationProgress();
                
                // ✅ FULL GT boyutlarını kullan (SABİT!)
                int gt_w = full_gt_loaded_ ? full_gt_image_.cols : 0;
                int gt_h = full_gt_loaded_ ? full_gt_image_.rows : 0;
                
                // Costmap boyutları
                auto* cm = costmap_client_.getCostmap();
                int costmap_w = cm ? cm->getSizeInCellsX() : 0;
                int costmap_h = cm ? cm->getSizeInCellsY() : 0;
                
                // Log
                experiment_logger_->logMetrics(total_distance_traveled_, 
                                            completion_percent, 
                                            elapsed_sec,
                                            gt_w, gt_h,  // ✅ Artık sabit!
                                            costmap_w, costmap_h);
                
                // Check milestones
                int cp_int = static_cast<int>(std::floor(completion_percent));
                for (int th : completion_milestones_) {
                    if (reached_milestones_.count(th)) continue;
                    if (cp_int >= th) {
                        reached_milestones_.insert(th);
                        experiment_logger_->logMilestone(th, elapsed_sec, 
                                                        total_distance_traveled_, 
                                                        completion_percent);
                    }
                }
            }


            double Explore::calculateExplorationProgress() 
            { 
                if (!search_) return 0.0;
                
                auto costmap = costmap_client_.getCostmap();
                if (!costmap || !full_gt_loaded_) return 0.0;

                // ✅ ONE-TIME RESOLUTION VERIFICATION
                static bool resolution_verified = false;
                if (!resolution_verified) {
                    double costmap_res = costmap->getResolution();
                    double diff = std::abs(costmap_res - full_gt_resolution_);
                    
                    if (diff > 1e-6) {
                        ROS_ERROR("Resolution mismatch: Costmap=%.6f, GT=%.6f", 
                                costmap_res, full_gt_resolution_);
                        ROS_ERROR("   Completion calculation will be INCORRECT!");
                    } else {
                        ROS_INFO("Resolutions verified: both %.6f m/cell", costmap_res);
                    }
                    resolution_verified = true;
                }

                // ═══════════════════════════════════════════════════════════════
                // COUNT FULL GT KNOWN CELLS ONCE (CONSTANT)
                // ═══════════════════════════════════════════════════════════════
                static int FULL_GT_KNOWN_CELLS = 0;
                if (FULL_GT_KNOWN_CELLS == 0) {
                    for (int y = 0; y < full_gt_image_.rows; ++y) {
                        for (int x = 0; x < full_gt_image_.cols; ++x) {
                            if (full_gt_image_.at<unsigned char>(y, x) != 205) {
                                FULL_GT_KNOWN_CELLS++;
                            }
                        }
                    }
                    ROS_INFO("═══ FULL GT KNOWN CELLS = %d (CONSTANT) ═══", FULL_GT_KNOWN_CELLS);
                }
                
                if (FULL_GT_KNOWN_CELLS == 0) return 0.0;
                
                // ═══════════════════════════════════════════════════════════════
                // COUNT SCANNED CELLS FROM COSTMAP
                // ═══════════════════════════════════════════════════════════════
                const unsigned int W = costmap->getSizeInCellsX();
                const unsigned int H = costmap->getSizeInCellsY();
                const unsigned char* costmap_data = costmap->getCharMap();
                
                int scanned_cells = 0;
                
                // Iterate through COSTMAP
                for (unsigned int cy = 0; cy < H; ++cy) {
                    for (unsigned int cx = 0; cx < W; ++cx) {
                        
                        unsigned char cost_val = costmap_data[cy * W + cx];
                        
                        if (cost_val != costmap_2d::NO_INFORMATION) {
                            
                            double world_x, world_y;
                            costmap->mapToWorld(cx, cy, world_x, world_y);
                            
                            int gt_x = static_cast<int>((world_x - full_gt_origin_x_) / full_gt_resolution_);
                            int gt_y = static_cast<int>((world_y - full_gt_origin_y_) / full_gt_resolution_);
                            
                            if (gt_x >= 0 && gt_x < full_gt_image_.cols &&
                                gt_y >= 0 && gt_y < full_gt_image_.rows) {
                                
                                unsigned char gt_val = full_gt_image_.at<unsigned char>(
                                    full_gt_image_.rows - 1 - gt_y, gt_x);
                                
                                if (gt_val != 205) {
                                    scanned_cells++;
                                }
                            }
                        }
                    }
                }
                
                // // ═══════════════════════════════════════════════════════════════
                // // VISUALIZATION - SAVE DEBUG IMAGES
                // // ═══════════════════════════════════════════════════════════════
                
                // static int viz_counter = 0;
                // viz_counter++;
                
                // if (viz_counter % 10 == 0) {  // Her 10 hesaplamada bir kaydet
                    
                //     // Convert GT to color for visualization
                //     cv::Mat gt_color;
                //     cv::cvtColor(full_gt_image_, gt_color, cv::COLOR_GRAY2BGR);
                    
                //     // ─────────────────────────────────────────────────────────────
                //     // VIZ 1: BOUNDING BOX
                //     // ─────────────────────────────────────────────────────────────
                //     cv::Mat viz_bbox = gt_color.clone();
                    
                //     // Calculate costmap bounding box in GT coordinates
                //     double cm_min_x, cm_min_y, cm_max_x, cm_max_y;
                //     costmap->mapToWorld(0, 0, cm_min_x, cm_min_y);
                //     costmap->mapToWorld(W-1, H-1, cm_max_x, cm_max_y);
                    
                //     // Convert to GT pixel coordinates
                //     int gt_min_x = static_cast<int>((cm_min_x - full_gt_origin_x_) / full_gt_resolution_);
                //     int gt_min_y = static_cast<int>((cm_min_y - full_gt_origin_y_) / full_gt_resolution_);
                //     int gt_max_x = static_cast<int>((cm_max_x - full_gt_origin_x_) / full_gt_resolution_);
                //     int gt_max_y = static_cast<int>((cm_max_y - full_gt_origin_y_) / full_gt_resolution_);
                    
                //     // Flip Y for image coordinates
                //     int img_min_y = full_gt_image_.rows - 1 - gt_max_y;
                //     int img_max_y = full_gt_image_.rows - 1 - gt_min_y;
                    
                //     // Draw bounding box (CYAN)
                //     cv::rectangle(viz_bbox, 
                //                 cv::Point(gt_min_x, img_min_y),
                //                 cv::Point(gt_max_x, img_max_y),
                //                 cv::Scalar(255, 255, 0),  // Cyan
                //                 3);
                    
                //     // Add text
                //     std::string text = "Costmap BBox: " + std::to_string(W) + "x" + std::to_string(H);
                //     cv::putText(viz_bbox, text, cv::Point(10, 30),
                //             cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(255, 255, 0), 2);
                    
                //     // ─────────────────────────────────────────────────────────────
                //     // VIZ 2: OVERLAP (GT + COSTMAP BLENDED)
                //     // ─────────────────────────────────────────────────────────────
                //     cv::Mat viz_overlap = gt_color.clone();
                    
                //     // Draw scanned costmap cells on GT
                //     for (unsigned int cy = 0; cy < H; ++cy) {
                //         for (unsigned int cx = 0; cx < W; ++cx) {
                            
                //             unsigned char cost_val = costmap_data[cy * W + cx];
                            
                //             if (cost_val != costmap_2d::NO_INFORMATION) {
                                
                //                 double world_x, world_y;
                //                 costmap->mapToWorld(cx, cy, world_x, world_y);
                                
                //                 int gt_x = static_cast<int>((world_x - full_gt_origin_x_) / full_gt_resolution_);
                //                 int gt_y = static_cast<int>((world_y - full_gt_origin_y_) / full_gt_resolution_);
                                
                //                 if (gt_x >= 0 && gt_x < full_gt_image_.cols &&
                //                     gt_y >= 0 && gt_y < full_gt_image_.rows) {
                                    
                //                     int img_y = full_gt_image_.rows - 1 - gt_y;
                                    
                //                     unsigned char gt_val = full_gt_image_.at<unsigned char>(img_y, gt_x);
                                    
                //                     // Color coding:
                //                     if (gt_val == 205) {
                //                         // Costmap scanned but GT unknown area (shouldn't count)
                //                         viz_overlap.at<cv::Vec3b>(img_y, gt_x) = cv::Vec3b(0, 0, 255);  // RED
                //                     } else {
                //                         // Costmap scanned AND GT known area (COUNTS!)
                //                         viz_overlap.at<cv::Vec3b>(img_y, gt_x) = cv::Vec3b(0, 255, 0);  // GREEN
                //                     }
                //                 }
                //             }
                //         }
                //     }
                    
                //     // Add legend
                //     cv::putText(viz_overlap, "GREEN = Scanned & in GT", cv::Point(10, 30),
                //             cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0, 255, 0), 2);
                //     cv::putText(viz_overlap, "RED = Scanned but outside GT", cv::Point(10, 60),
                //             cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0, 0, 255), 2);
                    
                //     // ─────────────────────────────────────────────────────────────
                //     // VIZ 3: SIDE BY SIDE
                //     // ─────────────────────────────────────────────────────────────
                //     cv::Mat combined;
                //     cv::hconcat(viz_bbox, viz_overlap, combined);
                    
                //     // Add completion info
                //     std::string info = "Completion: " + std::to_string(scanned_cells) + "/" + 
                //                     std::to_string(FULL_GT_KNOWN_CELLS) + " = " +
                //                     std::to_string((100.0 * scanned_cells) / FULL_GT_KNOWN_CELLS) + "%";
                //     cv::putText(combined, info, cv::Point(10, combined.rows - 20),
                //             cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(255, 0, 255), 2);
                    
                //     // Save images
                //     std::string timestamp = std::to_string(ros::Time::now().toSec());
                //     std::string filename_bbox = "/home/selma/robotlar_ws/overlapped_GT_costmap/completion_bbox_" + timestamp + ".png";
                //     std::string filename_overlap = "/home/selma/robotlar_ws/overlapped_GT_costmap/completion_overlap_" + timestamp + ".png";
                //     std::string filename_combined = "/home/selma/robotlar_ws/overlapped_GT_costmap/completion_combined_" + timestamp + ".png";
                    
                //     cv::imwrite(filename_bbox, viz_bbox);
                //     cv::imwrite(filename_overlap, viz_overlap);
                //     cv::imwrite(filename_combined, combined);
                    
                //     ROS_INFO("Saved completion visualization: %s", filename_combined.c_str());
                // }
                
                // ═══════════════════════════════════════════════════════════════
                // COMPLETION WITH FIXED DENOMINATOR
                // ═══════════════════════════════════════════════════════════════
                double completion = (100.0 * scanned_cells) / FULL_GT_KNOWN_CELLS;
                
                ROS_INFO(">>> Completion: %d/%d = %.2f%%", scanned_cells, FULL_GT_KNOWN_CELLS, completion);
                
                return completion;
            }

            void Explore::updateTravelDistance(const geometry_msgs::Point& current_pos) 
            {
                    double dx = current_pos.x - last_robot_position_.x;
                    double dy = current_pos.y - last_robot_position_.y;
                    double dist = std::sqrt(dx*dx + dy*dy);
                    
                    // Only accumulate reasonable movements
                    if (dist > 0.01 && dist < 5.0) {
                        total_distance_traveled_ += dist;
                    }
                    
                    last_robot_position_ = current_pos;  // Always update
            }


            void Explore::addToFilteredCluster(const geometry_msgs::Point& frontier_point)
            {
                const double MATCH_EPS = 0.5;
                
                // Mevcut cluster'lardan birinde mi?
                for (auto& cluster : filtered_clusters_) {
                    // Cluster center'a yakın mı?
                    double dist_to_center = std::hypot(frontier_point.x - cluster.center.x,
                                                    frontier_point.y - cluster.center.y);
                    
                    if (dist_to_center < CLUSTER_RADIUS) {
                        // Bu cluster'a zaten ekli mi kontrol et
                        bool already_exists = false;
                        for (const auto& member : cluster.members) {
                            if (std::hypot(member.x - frontier_point.x, member.y - frontier_point.y) < MATCH_EPS) {
                                already_exists = true;
                                break;
                            }
                        }
                        
                        if (!already_exists) {
                            cluster.members.push_back(frontier_point);
                            cluster.updateCenter();
                            ROS_DEBUG("Added frontier to existing cluster (new center: %.2f, %.2f, members: %zu)",
                                    cluster.center.x, cluster.center.y, cluster.members.size());
                        }
                        return;
                    }
                }
                
                // Yeni cluster oluştur
                FilteredCluster new_cluster;
                new_cluster.members.push_back(frontier_point);
                new_cluster.updateCenter();
                filtered_clusters_.push_back(new_cluster);
                
                ROS_INFO("Created new filtered cluster at (%.2f, %.2f)",
                        new_cluster.center.x, new_cluster.center.y);
            }

            void Explore::cleanupFilteredClusters(const std::vector<frontier_exploration::Frontier>& current_frontiers)
            {
                const double MATCH_EPS = 0.5;
                
                // Her cluster'daki member'ları kontrol et
                for (auto& cluster : filtered_clusters_) {
                    cluster.members.erase(
                        std::remove_if(cluster.members.begin(), cluster.members.end(),
                            [&](const geometry_msgs::Point& member) {
                                // Bu member hala mevcut frontiers'da var mı?
                                for (const auto& f : current_frontiers) {
                                    if (std::hypot(f.safest_point.x - member.x, f.safest_point.y - member.y) < MATCH_EPS) {
                                        return false;  // Hala var, silme
                                    }
                                }
                                return true;  // Artık yok, sil
                            }),
                        cluster.members.end());
                    
                    // Member'lar güncellendiyse center'ı yeniden hesapla
                    if (!cluster.members.empty()) {
                        cluster.updateCenter();
                    }
                }
                
                // Boş cluster'ları sil
                filtered_clusters_.erase(
                    std::remove_if(filtered_clusters_.begin(), filtered_clusters_.end(),
                        [](const FilteredCluster& c) { return c.members.empty(); }),
                    filtered_clusters_.end());
            }
    }  // namespace explore

    int main(int argc, char** argv)
    {
        ros::init(argc, argv, "explore");
        if (ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME,
                                                ros::console::levels::Debug)) {
            ros::console::notifyLoggerLevelsChanged();
        }
        explore::Explore explore;
        ros::spin();

        return 0;
    }
