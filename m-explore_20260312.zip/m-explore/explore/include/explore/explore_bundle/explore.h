#ifndef NAV_EXPLORE_H_
#define NAV_EXPLORE_H_

#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include <actionlib/client/simple_action_client.h>
#include <geometry_msgs/PoseStamped.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <ros/ros.h>
#include <visualization_msgs/MarkerArray.h>

#include <explore/costmap_client.h>
#include <explore/frontier_search.h>

#include <map_completion_msgs/MapCompletion.h>
#include <sensor_msgs/Image.h>
#include <nav_msgs/OccupancyGrid.h>
#include <opencv2/opencv.hpp>
#include <cv_bridge/cv_bridge.h>

#include <costmap_2d/cost_values.h>
#include <costmap_2d/costmap_2d.h>
#include <geometry_msgs/Point.h>
#include <nav_msgs/Odometry.h>

#include <explore_lite/FrontierMsg.h>
#include <explore_lite/FrontierArray.h>
#include <explore_lite/CompletionMetrics.h>

#include <explore/distance_calculator.h>
#include <explore/experiment_logger.h>

#include <opencv2/imgproc/imgproc.hpp>

#include <unordered_set>
#include <queue>
#include <deque>
#include <algorithm>
//#include <atomic>


namespace explore
{



enum class BlacklistReason {
  // Path planning failures
  PREFLIGHT_FAILED,
  PATHFINDING_FAILED,       // A* couldn't find path
  MAKEPLAN_SERVICE_FAILED,  // make_plan service returned no path
  EXCESSIVE_DETOUR,         // path too long compared to grid estimate

  // Goal location issues
  TARGET_ON_WALL,           // target on wall, not doorway
  OUTSIDE_MAP_BOUNDS,       // target outside costmap
  BEYOND_WALL_ARTIFACT,     // behind wall due to mapping error
  ARTIFICIAL_AREA,          // completed map mismatch

  // Navigation failures
  GOAL_ABORTED,             // move_base aborted
  PROGRESS_TIMEOUT,         // no progress timeout

  // Quality filters
  NEAR_WALL,                // too close to walls
  TOO_SMALL,                // frontier too small

  USER_DEFINED
};

// Back-compat BlacklistEntry:
// - keeps geometry_msgs::Point position
// - ALSO exposes plain x/y so legacy code using .x /.y compiles
// - allows push_back(geometry_msgs::Point) via convenience ctor
struct BlacklistEntry {
  geometry_msgs::Point position;
  BlacklistReason reason;
  ros::Time timestamp;
  int retry_count;
  double confidence;

  // Back-compat plain coordinates (kept in sync on construction)
  double x;
  double y;

  // Default
  BlacklistEntry()
  : position()
  , reason(BlacklistReason::USER_DEFINED)
  , timestamp(ros::Time::now())
  , retry_count(1)
  , confidence(1.0)
  , x(position.x)
  , y(position.y)
  {}

  // Convenience: implicit from geometry_msgs::Point
  BlacklistEntry(const geometry_msgs::Point& pos)
  : position(pos)
  , reason(BlacklistReason::USER_DEFINED)
  , timestamp(ros::Time::now())
  , retry_count(1)
  , confidence(1.0)
  , x(pos.x)
  , y(pos.y)
  {}

  // Full constructor with reason & confidence
  BlacklistEntry(const geometry_msgs::Point& pos,
                 BlacklistReason r,
                 double conf = 1.0)
  : position(pos)
  , reason(r)
  , timestamp(ros::Time::now())
  , retry_count(1)
  , confidence(conf)
  , x(pos.x)
  , y(pos.y)
  {}
};

struct FilteredCluster {
    geometry_msgs::Point center;
    std::vector<geometry_msgs::Point> members;
    
    void updateCenter() {
        if (members.empty()) return;
        center.x = 0.0;
        center.y = 0.0;
        center.z = 0.0;
        for (const auto& m : members) {
            center.x += m.x;
            center.y += m.y;
        }
        center.x /= members.size();
        center.y /= members.size();
    }
};

struct BlacklistReasonFilter {
    BlacklistReason reason_;
    BlacklistReasonFilter(BlacklistReason r) : reason_(r) {}
    bool operator()(const BlacklistEntry& e) const {
        return e.reason == reason_;
    }
};

struct PositionMatcher {
    geometry_msgs::Point target_;
    double threshold_;
    PositionMatcher(const geometry_msgs::Point& t, double th) : target_(t), threshold_(th) {}
    bool operator()(const BlacklistEntry& e) const {
        return std::hypot(e.position.x - target_.x, e.position.y - target_.y) < threshold_;
    }
};

/**
 * @class Explore
 * @brief Moves the robot base to explore its environment.
 */
class Explore
{
public:
  Explore();
  ~Explore();

  void start();
  void stop();

private:
  // Planning
  void makePlan();

  // Visualization
  void visualizeFrontiers(const std::vector<frontier_exploration::Frontier>& frontiers,
                          geometry_msgs::Point target_position);

  void deleteAllFrontierMarkers();

  // Goal tracking / blacklist
  void reachedGoal(const actionlib::SimpleClientGoalState& status,
                   const move_base_msgs::MoveBaseResultConstPtr& result,
                   const geometry_msgs::Point& frontier_goal);
  bool goalOnBlacklist(const geometry_msgs::Point& goal);
  //void targetFrontierCallback(const explore_lite::FrontierMsg::ConstPtr& msg);
  void odomCallback(const nav_msgs::Odometry::ConstPtr& msg);
  void smartBlacklistCleanup();

  // Validation / navigation
  bool shouldValidateTarget(double grid_len_m) const;
  bool validateTargetWithMakePlan(const geometry_msgs::Point& robot_pos,
                                  const geometry_msgs::Point& target_pos,
                                  double grid_len_m);
  bool sendNavigationGoal(const geometry_msgs::Point& target_position, double min_distance);
  void scheduleReplan();
  void publishMaps();

  bool validateParameters();

  // Safety limits & helpers
  static constexpr size_t MAX_BLACKLIST_SIZE = 1000;
  static constexpr double MIN_VALID_COORDINATE = -1000.0;
  static constexpr double MAX_VALID_COORDINATE = 1000.0;

  void cleanupBlacklist() {
    if (frontier_blacklist_.size() > MAX_BLACKLIST_SIZE) {
      ROS_WARN("Blacklist size exceeded limit, clearing old entries");
      frontier_blacklist_.erase(frontier_blacklist_.begin(),
                                frontier_blacklist_.begin() + MAX_BLACKLIST_SIZE / 2);
    }
  }

  bool isValidCoordinate(double x, double y) const {
    return std::isfinite(x) && std::isfinite(y) &&
           x > MIN_VALID_COORDINATE && x < MAX_VALID_COORDINATE &&
           y > MIN_VALID_COORDINATE && y < MAX_VALID_COORDINATE;
  }

  bool preFlightCheckWithAstar(const geometry_msgs::Point& robot_pos,
                            const geometry_msgs::Point& target_pos,
                            double grid_len_m);


  // Prefer in-process A* instead of make_plan by default
  bool prefer_preflight_astar_ = true;

  bool pickApproachPoint(const geometry_msgs::Point& target_pos,
                         geometry_msgs::Point& out_approach,
                         double radius_m = 0.5,
                         int samples = 16) const;

  // Helpers
  bool isNearPotentialDoorway(unsigned int gx, unsigned int gy,
                              costmap_2d::Costmap2D* cm) const;

  void debugPathPoints(unsigned int sx, unsigned int sy,
                       unsigned int gx, unsigned int gy,
                       costmap_2d::Costmap2D* cm) const;

 

  // ROS + core members
  ros::NodeHandle private_nh_;
  ros::NodeHandle relative_nh_;
  ros::Publisher marker_array_publisher_;
  tf::TransformListener tf_listener_;

  Costmap2DClient costmap_client_;
  actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> move_base_client_;

  ros::ServiceClient service_client_;
  //frontier_exploration::FrontierSearch search_;
  std::unique_ptr<frontier_exploration::FrontierSearch> search_;
  ros::Timer exploring_timer_;
  ros::Timer oneshot_;

  // Blacklist now stores BlacklistEntry
  std::vector<BlacklistEntry> frontier_blacklist_;

  geometry_msgs::Point prev_goal_;
  double prev_distance_;
  ros::Time last_progress_;
  size_t last_markers_count_;
  size_t last_text_markers_count_; 

  // parameters
  double planner_frequency_;
  double potential_scale_, orientation_scale_, gain_scale_;
  ros::Duration progress_timeout_;
  bool visualize_;
  //ros::Publisher frontiers_pub_;

  // External target & completion / publishing
  //ros::Subscriber target_frontier_sub_;
  //ros::Publisher selected_frontier_pub_;
  ros::Publisher exploration_finished_pub_;

  explore_lite::FrontierMsg received_target_frontier;
  bool use_external_target = false;
  int  use_completed_map_;
  int use_closing_;
  int  use_closed_live_map_;
  int with_map_completion;
  std::mutex target_mutex_;
  frontier_exploration::DistanceCalculator dc_;
  uint64_t last_map_epoch_ = 0;
  bool validate_with_makeplan_ = true;

  int use_clustering_;
  int use_filtering_;

  // Logging
  std::shared_ptr<ExperimentLogger> experiment_logger_;

  ros::Subscriber odom_sub_;
  double timeout;
  double min_frontier_size;
  std::string distance_method;
  ros::Publisher completed_pub_;
  ros::Publisher closed_live_pub_;
  ros::Publisher gt_map_pub_;
  bool publish_maps_{};
  std::string gt_image_path_;
  std::string gt_dir_;
  double gt_origin_x_, gt_origin_y_, gt_resolution_;
  int rect_size_ = 32;
  double completion_known_scale_ = 1.0;
  double completion_obstacle_scale_ = 0.5;
  size_t last_roi_markers_count_;
  double door_min_cells_{0.70};
  double wall_unknown_obst_frac_{0.35};
  double preflight_max_stretch_{2.2};
  double preflight_min_cap_m_{3.0};
  double preflight_max_radius_m_{12.0};
  double obstacle_distance_threshold_{0.3};
  double door_threshold_m_{0.70};
  bool is_first_publish = true;
  double room_behind_wall_scale_;           // room signature için weight
  double barrier_penalty_scale_;            // barrier durumu için ceza weight'i
  double frontier_on_obstacle_penalty_scale_; // duvar üzerinde olma cezası

  double fine_dx = 0.0, fine_dy = 0.0;
  double alignment_search_radius, alignment_min_score, realignment_period;
  int alignment_min_pixels;

  double noise_in_room_threshold_;
  double check_distance_;
  
  double interior_noise_min_length_;
  double interior_noise_max_length_;
  double interior_noise_agreement_ratio_;
  double interior_noise_max_obstacle_ratio_;

  double exterior_noise_min_length_;
  int exterior_noise_max_thickness_cells_;
  double exterior_noise_unknown_lookahead_m_;
  double exterior_noise_wall_search_m_;
  double exterior_noise_agree_ratio_;
  double exterior_noise_island_radius_m_;
  int exterior_noise_island_cells_max_;

  double trapped_max_traversable_gap_m_;      // CRITICAL - robot specific
  double trapped_wall_detect_range_m_;
  double trapped_min_obstacle_ratio_;
  double trapped_min_samples_agree_;
  double trapped_min_frontier_length_;
  double trapped_max_frontier_length_;

  double bridge_min_length_;
  double bridge_max_thickness_per_side_m_;
  double bridge_wall_search_m_;
  double bridge_min_unknown_ratio_per_side_;
  double bridge_min_thin_ratio_;
  double bridge_min_unknown_ratio_;
  double bridge_unknown_lookahead_m_;
  int bridge_max_island_cells_;

  double corner_max_frontier_length_;
  double corner_max_unknown_depth_;
  double corner_max_unknown_volume_;
  double corner_min_wall_coverage_;
  double corner_angle_threshold_;
  double corner_min_confidence_;
  double corner_wall_search_distance_;  // Unified for both lambdas
  double corner_min_pocket_depth_;      // For consistency check

  std::atomic<bool> is_planning_{false}; 


  // [AYARLANABİLİR PARAMETRE]
  // Harita originlerinin (ROS'ta sol alt köşe) pikselin köşesine mi yoksa merkezine mi 
  // karşılık geldiği arasındaki farkı gidermek için kullanılır.
  // Genellikle 0.5 olmalıdır (birim pikselin yarısı). 
  // Eğer kayma devam ederse, 0.0 veya 1.0 ile deneyin.
  double pixel_center_offset = 0.5;


  ros::Timer completed_map_timer_; 

  bool loadBestGTFromDir(int cur_W, int cur_H, double cur_res);
 
  //bool loadGTOnce();
  void saveMapParameters(const std::string& filename, int width, int height, 
                       double origin_x, double origin_y, double resolution);


  // Blacklist helpers API
  void addToBlacklist(const geometry_msgs::Point& goal,
                      BlacklistReason reason,
                      double confidence = 1.0);

  bool shouldRetryBasedOnReason(const BlacklistEntry& entry) const;
  std::string reasonToString(BlacklistReason reason) const;

  struct Point {
        int x, y;
        Point(int x_, int y_) : x(x_), y(y_) {}
    };
    
  void floodFillFromFreeSpace(std::vector<int8_t>& grid, int width, int height);
  void publishPreprocessedMap();
  void debugCoordinateParameters();
  void metricsTimerCallback(const ros::TimerEvent&);
  double calculateExplorationProgress();
  void updateTravelDistance(const geometry_msgs::Point& current_pos);

  std::vector<FilteredCluster> filtered_clusters_;
  int fallback_attempt_count_;

  static constexpr int MAX_FALLBACK_ATTEMPTS = 3;
  static constexpr double CLUSTER_RADIUS = 15.0;

  std::vector<geometry_msgs::Point> fallback_candidates_;
  size_t fallback_current_index_;

  // Fallback system: Max 3 sessions × 3 attempts each
    int fallback_session_count_;                              // Completed sessions (0-3)
    int fallback_current_session_attempts_;                   // Attempts in current session (0-3)
    std::set<std::string> fallback_tried_positions_;          // All tried positions (hash key)
    std::vector<geometry_msgs::Point> fallback_current_session_targets_;  // Current session's 3 targets

  // Helper functions
  void addToFilteredCluster(const geometry_msgs::Point& frontier_point);
  void cleanupFilteredClusters(const std::vector<frontier_exploration::Frontier>& current_frontiers);
  void doneMovingCallback(const actionlib::SimpleClientGoalState& state, 
                                const move_base_msgs::MoveBaseResultConstPtr& result);
   
  ros::Publisher processed_map_pub_;
  cv::Mat gt_image_raw_;  // Raw GT image (loaded once)
  bool reload;
  

  // Logging için
  ros::Time exploration_start_time_;
  geometry_msgs::Point last_robot_position_;
  double total_distance_traveled_;
  ros::Timer metrics_timer_;

  // Parametreler
  bool log_metrics_enabled_;
  bool log_operations_enabled_;
  double metrics_log_interval_;

  geometry_msgs::Point current_target_;
  ros::Time target_start_time_;
  double target_start_distance_;
  bool has_active_target_;

  // milestone logging
  std::vector<int> completion_milestones_;
  std::unordered_set<int> reached_milestones_;

  int makeplan_count_ = 0;
  int frontier_switch_count_ = 0;
  int progress_timeout_count_ = 0;
  bool publish_closed_live_map_;
  double direction_consistency_weight_;
  double cluster_distance_threshold_;

  double gazebo_world_center_x_;
  double gazebo_world_center_y_;
  bool auto_correct_gt_origin_;
  double gt_rotation_degrees_; 

  // Add these to Explore class:
  cv::Mat full_gt_image_;           // Full GT loaded once
  double full_gt_origin_x_;         // Full GT origin
  double full_gt_origin_y_;
  double full_gt_resolution_;
  bool full_gt_loaded_;

  // Debug visualization for fallback goal
  geometry_msgs::Point last_fallback_goal_;
  bool has_last_fallback_goal_ = false;

  bool fallback_attempted_;  // 1 fallback tracking için
  std::set<std::string> attempted_artificial_positions_;  // Denenen filtered frontierlar
    
  // Helper: Position to key
  std::string positionToKey(const geometry_msgs::Point& p) {
        std::ostringstream oss;
        oss << (int)(p.x * 10) << "_" << (int)(p.y * 10);
        return oss.str();
  }
    
  ros::ServiceClient make_plan_client_;
  bool isReachable(const geometry_msgs::Point& from, const geometry_msgs::Point& to);
  std::mutex planning_mutex_;
  bool is_in_fallback_active_;





};

} // namespace explore  

#endif  // NAV_EXPLORE_H_
