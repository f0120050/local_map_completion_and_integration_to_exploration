#ifndef FRONTIER_SEARCH_H_
#define FRONTIER_SEARCH_H_

#include <ros/ros.h>
#include <costmap_2d/costmap_2d.h>
#include <geometry_msgs/Point.h>
#include <nav_msgs/OccupancyGrid.h>
#include <opencv2/core.hpp>

#include <cstdint>
#include <vector>
#include <queue>
#include <limits>
#include <memory>
#include <string>
#include <algorithm>

#include <explore/distance_calculator.h>
#include <unordered_map>
#include <functional>

// Forward declaration
namespace explore {
    class ExperimentLogger;
}

namespace frontier_exploration
{

  /**
  * @brief Represents a frontier
  */

  // Enum for obstacle checking source
    enum class ObstacleCheckSource {
        COMPLETED_MAP,      // Use completed_map_ (GT-based or model predictions)
        CLOSED_LIVE_MAP,    // Use closed_live_ (SLAM with gap closing)
        RAW_COSTMAP         // Use raw costmap from SLAM
    };
    

   // ✅ YENİ: Frontier Patch Management
      struct FrontierKey {
          int x, y;
          bool operator==(const FrontierKey& other) const {
              return x == other.x && y == other.y;
          }
      };

     
      // frontier_search.h'da FrontierPatchInfo struct'ını basitleştir
      struct FrontierPatchInfo {
          cv::Rect roi;
          cv::Mat gt_patch;
          ros::Time timestamp;
          bool active;
          
          // Hizalama ile uğraşma - direkt kullan
          FrontierPatchInfo() {}
      };

       // Hizalama sonucu yapısı
      struct AlignmentResult {
          int dx;           // X kaydırması (piksel)
          int dy;           // Y kaydırması (piksel)  
          double score;     // Hizalama skoru [0-1]
          bool valid;       // Geçerli hizalama bulundu mu?
          
          AlignmentResult() : dx(0), dy(0), score(0.0), valid(false) {}
      };

      // Hash fonksiyonu için specialization
      struct FrontierKeyHash {
          std::size_t operator()(const FrontierKey& k) const {
              return std::hash<int>()(k.x) ^ (std::hash<int>()(k.y) << 1);
          }
      };

      struct WallLine 
      {
          int position;      // Row number (horizontal) or Column number (vertical)
          bool is_horizontal; // true = horizontal wall, false = vertical wall
          bool is_slam;      // true = from SLAM, false = from GT
          int pixel_count;   // Number of obstacle pixels
          
          WallLine(int pos, bool horiz, bool slam, int count) 
              : position(pos), is_horizontal(horiz), is_slam(slam), pixel_count(count) {}
      };

      struct DuplicateWallPair {
          WallLine slam_wall;
          WallLine gt_wall;
          int distance;
          
          DuplicateWallPair(const WallLine& slam, const WallLine& gt, int dist)
              : slam_wall(slam), gt_wall(gt), distance(dist) {}
      };


      struct Frontier {
          std::uint32_t size{0};
          double min_distance{std::numeric_limits<double>::infinity()};
          double cost{0.0};
          double map_resolution{0.0};
          geometry_msgs::Point initial;
          geometry_msgs::Point centroid;
          geometry_msgs::Point middle;
          std::vector<geometry_msgs::Point> points;
          std::vector<geometry_msgs::Point> sample_points; 

          bool is_target{false};
          bool is_in_blacklist{false};

          // completion scoring
          double completion_known_score{0.0};
          double completion_obstacle_score{0.0};
          double completion_free_score{0.0};  

          // ✅ YENİ: Boşluk boyutuna göre ayrım
          bool has_wall;
          bool has_gap;           // Herhangi bir boşluk var mı?
          bool has_large_gap;     // Kapı boşluğu veya daha büyük
          bool has_small_gap;     // Küçük boşluk (gürültü)
          double gap_size;        // Metre cinsinden boşluk boyutu
          bool predicted_on_wall;
          double center_wall_density;

          bool too_close_to_obstacle = false;
          double distance_to_obstacle = 999.0;  // ADD THIS
          geometry_msgs::Point safest_point;

          // Individual filtering flags
          bool is_noisy_interior = false;
          bool is_noisy_exterior = false;
          bool is_trapped_between_walls = false;
          bool is_thin_bridge = false;
          bool is_small_corner_pocket = false;

          // Helper methods
          bool isFlaggedByAnyFilter() const {
              return is_noisy_interior || is_noisy_exterior || 
                    is_trapped_between_walls || is_thin_bridge || 
                    is_small_corner_pocket || too_close_to_obstacle;
          }

          

          std::string getPrimaryFilterType() const {
              if (too_close_to_obstacle) return "obstacle";
              if (is_noisy_interior) return "noisy_interior";
              if (is_noisy_exterior) return "noisy_exterior";
              if (is_trapped_between_walls) return "trapped";
              if (is_thin_bridge) return "bridge";
              if (is_small_corner_pocket) return "corner";
              return "none";
          }

          void clearAllFilterFlags() {
            filter_flags_ = 0;
          }

          int cluster_id = -1;             // Hangi kümeye ait olduğu
          double cluster_threshold = 0.0;  // Hangi mesafe eşiğiyle kümelendiği
          bool is_best_in_cluster = false; // Kümesinin lideri mi?
          uint8_t filter_flags_;  // Mevcut
      };


    struct ScopedTimer 
    {
        std::string name;
        std::chrono::high_resolution_clock::time_point start;
        std::function<void(const std::string&, double)> callback;
            
        ScopedTimer(const std::string& n, 
                        std::function<void(const std::string&, double)> cb)
            : name(n), callback(cb)
        {
            start = std::chrono::high_resolution_clock::now();
        }
            
        ~ScopedTimer() {
            auto end = std::chrono::high_resolution_clock::now();
            auto duration_ms = std::chrono::duration<double, std::milli>(end - start).count();
            if (callback) {
                callback(name, duration_ms);
            }
        }
    };

   
        
  
 

  /**
  * @brief Thread-safe implementation of a frontier-search task for an input costmap.
  */
  class FrontierSearch
  {
    public:
      FrontierSearch() = default;

      /**
      * @brief Constructor
      * @param costmap               Costmap to search
      * @param potential_scale       Weight for distance term in frontier cost
      * @param gain_scale            Weight for size term in frontier cost
      * @param min_frontier_size     Minimum frontier length (meters) to accept
      * @param distance_method       "dfield" | "multi_astar" | "astar_completion" | "dijkstra" | "euclidean"
      * @param rect_size             Patch side length (cells) around a frontier for completion scoring
      * @param completion_known_scale    Weight for known/free completion reward
      * @param completion_obstacle_scale Weight for obstacle completion penalty
      */
      FrontierSearch(costmap_2d::Costmap2D* costmap,
                    double potential_scale,
                    double gain_scale,
                    double min_frontier_size,
                    std::string distance_method,
                    int rect_size,
                    double completion_known_scale,
                    double completion_obstacle_scale,
                    double obstacle_distance_threshold,
                    double door_threshold_m,
                    int use_completed_map,
                    int use_closed_live_map,
                    int use_closing,
                    int use_filtering,                    
                    int use_clustering,                    
                    double room_behind_wall_scale,
                    double barrier_penalty_scale,
                    double frontier_on_obstacle_penalty_scale,
                    double check_distance,
                    std::shared_ptr<explore::ExperimentLogger> logger,
                    int with_map_completion,
                    double noise_in_room_threshold,
                    double direction_consistency_weight,
                    double cluster_distance_threshold,
                    double interior_noise_min_length,      
                    double interior_noise_max_length,      
                    double interior_noise_agreement_ratio, 
                    double interior_noise_max_obstacle_ratio,                                   
                    double exterior_noise_min_length,
                    int exterior_noise_max_thickness_cells,
                    double exterior_noise_unknown_lookahead_m,
                    double exterior_noise_wall_search_m,
                    double exterior_noise_agree_ratio,
                    double exterior_noise_island_radius_m,
                    int exterior_noise_island_cells_max,
                    double trapped_max_traversable_gap_m,
                    double trapped_wall_detect_range_m,
                    double trapped_min_obstacle_ratio,
                    double trapped_min_samples_agree,
                    double trapped_min_frontier_length,
                    double trapped_max_frontier_length,
                    double bridge_min_length,
                    double bridge_max_thickness_per_side_m,
                    double bridge_wall_search_m,
                    double bridge_min_unknown_ratio_per_side,
                    double bridge_min_thin_ratio,
                    double bridge_min_unknown_ratio,
                    double bridge_unknown_lookahead_m,
                    int bridge_max_island_cells,
                    double corner_max_frontier_length,
                    double corner_max_unknown_depth,
                    double corner_max_unknown_volume,
                    double corner_min_wall_coverage,
                    double corner_angle_threshold,
                    double corner_min_confidence,
                    double corner_wall_search_distance,
                    double corner_min_pocket_depth
                                    
                  );

      /**
      * @brief Run the search from a given world position
      */
      std::vector<Frontier> searchFrom(geometry_msgs::Point position);

      /// Invalidate cached distance field (call when map changes)
      void invalidateDistanceField() { distance_calculator_.invalidateDistanceField(); }

      // Configuration / inputs
      void setGtImage(const cv::Mat& gt);
      void setCompletedMap(const cv::Mat& cm);
      void setYamlOriginRes(double yaml_x, double yaml_y, double yaml_res);
      void setMapSaverOriginRes(double org_x, double org_y, double res, int pgm_w, int pgm_h);
      void setRectangleSize(int r);
      void setUseCompletedMap(int flag);
      void setCompletionScales(double known_scale, double obstacle_scale);
      std::vector<Frontier> clusterFrontiers(const std::vector<Frontier>& frontiers, double distance_threshold);
      void recomputeCostsForNewClusters(std::vector<Frontier>& frontiers);
      void calculateSamplePoints(Frontier& frontier);

      // Utilities for publishing/exports
      // bool buildGridFromMat(const cv::Mat& img_mat,
      //                               nav_msgs::OccupancyGrid& out_grid,
      //                               const std::string& frame_id = "map") const;

      // void publishMap(const cv::Mat& img_mat,
      //                         ros::Publisher& pub,
      //                         const std::string& frame_id = "map") const;

      bool buildGridFromMat(const cv::Mat& img_mat,
                                          nav_msgs::OccupancyGrid& out_grid,
                                          const std::string& frame_id,
                                          double origin_x,
                                          double origin_y,
                                          double resolution) const;

                                          
      void publishMap(const cv::Mat& img_mat,
                                  ros::Publisher& pub,
                                  const std::string& frame_id,
                                  double origin_x,
                                  double origin_y,
                                  double resolution) const;

      // Accessors for debug/visualization
      const cv::Mat& completedMapMat() const { return completed_map_; }
      const cv::Mat& liveClosedMapMat() const { return closed_live_; }
      const cv::Mat& gtMapMat() const { return gt_map_; }

      // Map seeding
      void seedCompletedMapFromCostmap(); // costmap -> completed_map_ (0/205/254) in OpenCV coords
      void seedClosedLiveMapFromCostmap();
      void seedGT();      // GT -> gt_map_ (reprojected to costmap grid)
      int  getRectSize() const { return rect_size_; }         // görselleştirme için
      void setRectSize(int s);

      std::vector<Frontier> completed_frontiers_;
      double door_threshold_m_;  // Minimum gap size to preserve (e.g., 0.7m)
      

      void closeSmallGapsInMap(cv::Mat& map_img,
                                         double door_threshold_m,
                                         bool seal_free_slits =true) const;

      void fillWallGaps(cv::Mat& map_img, double max_gap_width_m) const;
          
      double getDistanceToNearestObstacleInMap(double world_x, double world_y, 
                                                          const cv::Mat& map) const;
      double getObstacleThreshold() const { return obstacle_distance_threshold_; }

      // Profiling data storage
      mutable std::map<std::string, std::vector<double>> profiling_times_;
      mutable std::mutex profiling_mutex_;
        
      void recordTiming(const std::string& operation, double duration_ms) const {
            std::lock_guard<std::mutex> lock(profiling_mutex_);
            profiling_times_[operation].push_back(duration_ms);
        }
        
      void logProfilingStats() const;
      bool isFrontierTooCloseToObstacle(const Frontier& frontier, 
                                                    double min_distance_m,
                                                    ObstacleCheckSource source = ObstacleCheckSource::COMPLETED_MAP) const;
      double getWallProximityPenalty(const Frontier& f) const;
      double getMinDistanceToWall(const Frontier& f) const;
      double getMinDistanceToCompletedMapObstacle(const Frontier& f) const;

    protected:
      /**
      * @brief Starting from an initial cell, build a frontier from valid adjacent cells
      */
      Frontier buildNewFrontier(unsigned int initial_cell,
                                unsigned int reference,
                                std::vector<bool>& frontier_flag);

      /**
      * @brief Evaluate if candidate cell is a valid new frontier cell.
      */
      bool isNewFrontierCell(unsigned int idx, const std::vector<bool>& frontier_flag);

      /**
      * @brief Compute frontier cost (distance/size + completion terms)
      */
      double frontierCost(const Frontier& frontier);

      // Cluster nearby frontiers and keep only the best from each cluster
                    

    private:
      // --- Completion helpers ---
      bool getCompletedRegionAroundFrontier(double frontier_x, double frontier_y,
                                            cv::Mat& out_gt, cv::Mat& out_cur);
      bool cropFromCostmap(double wx, double wy, int P, cv::Mat& dst);

      // double patchAgreementScore(const cv::Mat& gt,
      //                           const cv::Mat& cur,
      //                           double* out_known_score = nullptr,   // reward (free)
      //                           double* out_obst_score  = nullptr);  // penalty (obstacle)

      double patchAgreementScore(const cv::Mat& completed, 
                                            const cv::Mat& cur,
                                            const cv::Mat& accessible_mask,  // ✅ YENİ
                                            double* out_known_score, 
                                            double* out_obst_score);

      void processCompletionScores(std::vector<Frontier>& frontier_list);

      // --- Distance orchestration and backends ---
      bool calculateFrontierDistances(std::vector<Frontier>& frontier_list,
                                      unsigned int mx_robot, unsigned int my_robot);

      bool calculateDistancesUsingField(std::vector<Frontier>& frontier_list,
                                        unsigned int mx_robot, unsigned int my_robot);

      bool calculateDistancesUsingMultiGoal(std::vector<Frontier>& frontier_list,
                                            unsigned int mx_robot, unsigned int my_robot);

      bool calculateDistancesEuclidean(std::vector<Frontier>& frontier_list,
                                      unsigned int mx_robot, unsigned int my_robot);

      bool calculateDistancesAstarCompletion(std::vector<Frontier>& frontier_list,
                                            const std::vector<std::pair<int,int>>& goals_xy,
                                            unsigned int mx_robot, unsigned int my_robot,
                                            double resolution);

      // Quick reachability sanity check (used optionally)
      bool isGoalReachable(const geometry_msgs::Point& goal, const geometry_msgs::Point& start) const;
      

      

      bool isNoisyInteriorFrontier(const Frontier& frontier, int total_frontiers_count) const;
      
      void analyzeWallsAndGaps(const cv::Mat& completed_patch, Frontier& f);

      // Small util retained for completeness
      static inline int clampInt(int v, int lo, int hi) {
        return std::max(lo, std::min(v, hi));
      }
      
      bool checkAlignmentReference(const cv::Mat& patch);
      double computeSimpleAlignmentScore(const cv::Mat& patch1, const cv::Mat& patch2);

      AlignmentResult findAlignmentUsingFrontierKnownRegion(
      const cv::Mat& costmap_patch,    // Costmap'ten alınan patch
      const cv::Mat& gt_patch,         // GT'den alınan patch
      int cx, int cy,                  // Frontier merkezi (piksel)
      int search_radius = 8);           // Arama yarıçapı (piksel);

      void mergeGTPatchToCompletedMap(
      const cv::Mat& gt_patch,
      const cv::Mat& costmap_patch, 
      const cv::Rect& roi,
      int alignment_dx,
      int alignment_dy,
      bool force_gt_walls);  // GT'deki duvarları zorla kullan

      bool hasWallPattern(const std::vector<uchar>& values, 
                                      int min_wall_pixels) const;
      std::vector<uchar> extractRow(const cv::Mat& mat, int row) const;
      std::vector<uchar> extractColumn(const cv::Mat& mat, int col) const;
      bool hasParallelDuplicateWalls(const cv::Mat& completed_patch, 
                                                const cv::Mat& costmap_patch) const;
      std::vector<DuplicateWallPair> findDuplicateWalls(
      const cv::Mat& completed_patch, 
      const cv::Mat& costmap_patch) const;

      

      mutable std::recursive_mutex data_mutex_;  // ✅ Aynı thread birden fazla kez lock alabilir

      // Live costmap (not owned)
      costmap_2d::Costmap2D* costmap_{nullptr};

      // Raw map view (from costmap)
      const unsigned char* map_{nullptr};
      unsigned int size_x_{0}, size_y_{0};

      // Scales / params
      double potential_scale_{1e-3};
      double gain_scale_{1.0};
      double min_frontier_size_{0.5};     // meters
      std::string distance_method_{"euclidean"}; // "dfield" | "multi_astar" | "astar_completion" | "dijkstra" | "euclidean"
      int rect_size_{32};                 // patch side (cells)

      // Completion scoring weights / behavior
      int    use_completed_map_{1};
      int    use_closing_{1};
      int    use_closed_live_map_{1};
      
      int use_clustering_{1};
      int use_filtering_{1};

      double completion_known_scale_{1.0};
      double completion_obstacle_scale_{0.5};
      int  completion_scenario_{1};      // 1=LMC, 2=LMC+LWC, 3=LMC+LWC+GWC
      bool navigation_only_mode_{false}; // if true, frontier cost uses only distance+size



      double room_behind_wall_scale_;           // room signature için weight
      double barrier_penalty_scale_;            // barrier durumu için ceza weight'i
      double frontier_on_obstacle_penalty_scale_; // duvar üzerinde olma cezası

      // Images (CV_8UC1 with 0/205/254)
      cv::Mat gt_image_;      // raw GT in its own origin/res
      cv::Mat completed_map_; // costmap-aligned (OpenCV coords)
      cv::Mat gt_map_;        // GT reprojected to costmap grid (OpenCV coords)
      cv::Mat closed_live_;       // gap-closed live map (no completion)      
      cv::Mat previous_closed_live_;  // For change detection

        
      

      // GT yaml/world params
      double yaml_x_{0.0}, yaml_y_{0.0}, yaml_res_{1.0};

      // Map_saver/world params aligned with costmap
      double map_org_x_{0.0}, map_org_y_{0.0}, map_res_{1.0};
      int    pgm_w_{0}, pgm_h_{0};

      // Distance helper
      DistanceCalculator distance_calculator_;

      double obstacle_distance_threshold_{0.3};
    

      geometry_msgs::Point last_frontier_centroid_;
      geometry_msgs::Point last_robot_position_;
      bool has_last_frontier_;
      double direction_consistency_weight_;  // ROS param 

      // Alignment debug için
      int last_alignment_dx_ = 0;
      int last_alignment_dy_ = 0;
      double last_alignment_score_ = 0.0;
      double check_distance_;
      double noise_in_room_threshold_;
      
      double interior_noise_min_length_;
      double interior_noise_max_length_;
      double interior_noise_agreement_ratio_;
      double interior_noise_max_obstacle_ratio_;

      // Exterior noise filtering parameters
      double exterior_noise_min_length_;
      int exterior_noise_max_thickness_cells_;
      double exterior_noise_unknown_lookahead_m_;
      double exterior_noise_wall_search_m_;
      double exterior_noise_agree_ratio_;
      double exterior_noise_island_radius_m_;
      int exterior_noise_island_cells_max_;

      double trapped_max_traversable_gap_m_;      // CRITICAL - robot specific
      double trapped_wall_detect_range_m_;
      double trapped_min_obstacle_ratio_;
      double trapped_min_samples_agree_;
      double trapped_min_frontier_length_;
      double trapped_max_frontier_length_;

      double bridge_min_length_;
      double bridge_max_thickness_per_side_m_;
      double bridge_wall_search_m_;
      double bridge_min_unknown_ratio_per_side_;
      double bridge_min_thin_ratio_;
      double bridge_min_unknown_ratio_;
      double bridge_unknown_lookahead_m_;
      int bridge_max_island_cells_;

      double corner_max_frontier_length_;
      double corner_max_unknown_depth_;
      double corner_max_unknown_volume_;
      double corner_min_wall_coverage_;
      double corner_angle_threshold_;
      double corner_min_confidence_;
      double corner_wall_search_distance_;  // Unified for both lambdas
      double corner_min_pocket_depth_;      // For consistency check
      
      // // Debug publishers (opsiyonel)
      // ros::Publisher alignment_quality_pub_;
      // ros::Publisher alignment_offset_pub_;
      // bool publish_alignment_debug_ = false;

      std::unordered_map<FrontierKey, FrontierPatchInfo, FrontierKeyHash> active_frontier_patches_;

      // ✅ YENİ: Patch yönetim metodları
      FrontierKey getFrontierKey(double world_x, double world_y);
      void validateAndCleanPatches();
      void clearPatchArea(const FrontierKey& key);
      bool hasWallNearby(const cv::Mat& gt_patch, int x, int y, int tolerance = 2);

      // Feature detection için
      std::vector<cv::Point2f> extractFeaturePoints(const cv::Mat& img);
      bool findFeatureCorrespondences(const std::vector<cv::Point2f>& pts1, 
                                    const std::vector<cv::Point2f>& pts2,
                                   std::vector<cv::Point2f>& matched_pts1,
                                   std::vector<cv::Point2f>& matched_pts2);

      struct AlignmentCandidate {
          cv::Rect roi;
          std::string name;
          double score;
          int dx, dy;
          
          AlignmentCandidate(cv::Rect r, std::string n, double s, int x, int y) 
              : roi(r), name(n), score(s), dx(x), dy(y) {}
      };
      
      // ✅ Method declarations
      bool performAdvancedAlignment(const cv::Mat& live_cm, const cv::Rect& roi_cm, cv::Mat& out_aligned_gt);
      void testAlignmentCandidates(const cv::Mat& live_cm, 
                                  const cv::Rect& search_roi,
                                  const cv::Rect& original_roi,
                                  const std::string& direction,
                                  int search_range,
                                  std::vector<AlignmentCandidate>& candidates);

      void adjustSingleWallFrontierToFreeCell(Frontier& frontier);
      cv::Point2i findNearestFreeCell(const cv::Mat& costmap, const cv::Point2i& frontier_pt, int search_radius);
     

      bool isNoisyExteriorLineFrontier(const Frontier& frontier) const;
      bool isTrappedBetweenWalls(const Frontier& frontier) const;
      bool isThinBridgeFrontier(const Frontier& frontier) const;
      bool isSmallCornerPocket(const Frontier& frontier) const;

      // GT patch hizalama parametreleri
      double alignment_search_radius_;
      double alignment_min_score_;
      int alignment_min_pixels_;
      double realignment_period_;
      cv::Mat slam_scanned_mask_;
      
      double cluster_distance_threshold_;

      std::shared_ptr<explore::ExperimentLogger> experiment_logger_;

      int with_map_completion_;
      ros::ServiceClient map_completion_batch_client_;
      
      // NEW: Cache for completed patches
      // frontier_search.h içinde FrontierSearch sınıfının 'private' veya 'public' bölümünde:
      struct CompletedPatchCache {
        cv::Mat patch;              // Hata veren 'patch' üyesi burada olmalı
        int predicted_free_count;   // Ön hesaplanmış sayı
        int current_free_count;     // Ön hesaplanmış sayı
        ros::Time timestamp;
        bool valid;
      };
      std::unordered_map<FrontierKey, CompletedPatchCache, FrontierKeyHash> completed_patch_cache_;
      
      // NEW: Batch completion function
      bool batchCompleteFrontierPatches(std::vector<Frontier>& frontiers);
      
      // NEW: Get cached or request patch
      bool getCompletedPatch(double frontier_x, double frontier_y, 
                            cv::Mat& out_completed, cv::Mat& out_partial);
      
      void cleanCompletedPatchCache() ;
      bool closed_live_gaps_closed_;

      void precomputeDistanceField(const cv::Mat& map);
      double getDistanceAtPoint(double world_x, double world_y) const;
      cv::Mat precomputed_distances_;
      
      
  };


} // namespace frontier_exploration

#endif // FRONTIER_SEARCH_H_
