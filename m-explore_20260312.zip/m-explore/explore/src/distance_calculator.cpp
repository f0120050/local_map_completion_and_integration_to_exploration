#include <explore/distance_calculator.h>
#include <costmap_2d/cost_values.h>
#include <geometry_msgs/PoseStamped.h>
#include <queue>
#include <unordered_map>
#include <cmath>
#include <mutex>   // for std::lock_guard
#include <opencv2/core.hpp>
#include <limits>
#include <opencv2/imgproc.hpp>   // for cv::integral


namespace {
constexpr unsigned char OBST_U8 = 0;
constexpr unsigned char UNK_U8  = 205;
constexpr unsigned char FREE_U8 = 254;

template<typename T> inline T clamp(T v, T lo, T hi){ return std::max(lo, std::min(v,hi)); }
}

using namespace costmap_2d;

namespace frontier_exploration
{

    bool DistanceCalculator::blocked(int x, int y, bool allow_unknown) const {
        unsigned char c = cm_->getCost(x, y);

        // A cell is blocked if it's an obstacle. This is always true regardless of allow_unknown.
        if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE && c != costmap_2d::NO_INFORMATION) {
            //ROS_INFO_STREAM("Cell (" << x << ", " << y << ") is blocked because it is an obstacle.");
            return true;
        }
        
        // A cell is also blocked if it's unknown and we do not allow unknown space.
        if (!allow_unknown && c == costmap_2d::NO_INFORMATION) {
            //ROS_INFO_STREAM("Cell (" << x << ", " << y << ") is blocked because it is NO_INFORMATION and we are not allowing unknown space.");
            return true;
        }

        // All other cases (free space or unknown space when allowed) are not blocked.
        //ROS_INFO_STREAM("Cell (" << x << ", " << y << ") is NOT blocked.");
        return false;
    }

    bool DistanceCalculator::planningBlocked(int x, int y,bool allow_unknown) const
    {
        unsigned char c = cm_->getCost(x, y);

        // A cell is blocked if it's an obstacle. This is always true regardless of allow_unknown.
        if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE && c != costmap_2d::NO_INFORMATION) {
            //ROS_INFO_STREAM("Cell (" << x << ", " << y << ") is blocked because it is an obstacle.");
            return true;
        }
        
        // A cell is also blocked if it's unknown and we do not allow unknown space.
        if (!allow_unknown && c == costmap_2d::NO_INFORMATION) {
            //ROS_INFO_STREAM("Cell (" << x << ", " << y << ") is blocked because it is NO_INFORMATION and we are not allowing unknown space.");
            return true;
        }

        // All other cases (free space or unknown space when allowed) are not blocked.
        //ROS_INFO_STREAM("Cell (" << x << ", " << y << ") is NOT blocked.");
        return false;
    }

    // bool DistanceCalculator::planningBlocked(int x, int y,
    //                                     bool allow_unknown,
    //                                     const cv::Mat& gt_map_aligned,
    //                                     int door_min_cells,
    //                                     double wall_obst_frac) const
    // {
    //     const unsigned char c = cm_->getCost(x, y);
        
    //     // 1) Gerçek engeller (unknown HARİÇ)
    //     if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE && c != costmap_2d::NO_INFORMATION) {
    //         return true;
    //     }
        
    //     // 2) Free/inflated space -> geçilebilir
    //     if (c != costmap_2d::NO_INFORMATION) {
    //         return false;
    //     }
        
    //     // 3) Buradan sonra: c == NO_INFORMATION (unknown)
        
    //     // 3a) allow_unknown=false ise ve GT yok ise -> blokla
    //     if (!allow_unknown && gt_map_aligned.empty()) {
    //         return true;
    //     }
        
    //     // 3b) allow_unknown=true ise ve GT yok ise -> izin ver (kapı olabilir)
    //     if (gt_map_aligned.empty()) {
    //         return allow_unknown ? false : true;
    //     }
        
    //     // 4) GT var, unknown hücre için GT'ye bak (duvar mı kapı mı?)
    //     const int W = (int)cm_->getSizeInCellsX();
    //     const int H = (int)cm_->getSizeInCellsY();
    //     if (x < 0 || y < 0 || x >= W || y >= H) return true;

    //     const int half = std::max(1, door_min_cells/2);
    //     const int x0 = std::max(0, x - half);
    //     const int y0 = std::max(0, y - half);
    //     const int x1 = std::min(W - 1, x + half);
    //     const int y1 = std::min(H - 1, y + half);

    //     int cnt = 0, c_obst = 0;
    //     for (int yy = y0; yy <= y1; ++yy) {
    //         const uchar* row = gt_map_aligned.ptr<uchar>(yy);
    //         for (int xx = x0; xx <= x1; ++xx) {
    //             const uchar v = row[xx];
    //             ++cnt;
    //             if (v >= 250) ++c_obst;  // GT'de obstacle
    //         }
    //     }
        
    //     if (cnt == 0) return false;
        
    //     const double obst_frac = (double)c_obst / (double)cnt;
        
    //     // GT'ye göre karar: yüksek obstacle oranı -> duvar
    //     if (obst_frac >= wall_obst_frac) {
    //         return true;  // Duvar-unknown, blokla
    //     }
        
    //     return false;  // Kapı olabilir, izin ver
    // }

  
    void DistanceCalculator::initMakePlanClient() 
    {
        if (!make_plan_client_.isValid()) {
        // 1. Change the default service name to "make_plan"
        //    We will let ROS's namespace resolution handle the rest.
        nh_.param<std::string>("makeplan_service", makeplan_service_,
                                std::string("make_plan"));
        nh_.param<double>("makeplan_tolerance", makeplan_tolerance_, 0.1);
        
        // 2. Use a private NodeHandle to ensure the client is created in the correct namespace.
        //    Or, if using a public NodeHandle, ensure the name is fully resolved.
        //    The simplest fix is to use the same logic as the service server.
        //    (assuming this method is called by the exploration node).
        //    In this case, a fully resolved name is best to be explicit.
        //    Since your planner service is named `planner_service_node`,
        //    the full name is `/planner_service_node/make_plan`.
        make_plan_client_ = nh_.serviceClient<nav_msgs::GetPlan>(makeplan_service_, /*persistent=*/true);

        // An alternative (if `initMakePlanClient` is called from a node that has a
        // private NodeHandle `private_nh_`) would be:
        // make_plan_client_ = private_nh_.serviceClient<nav_msgs::GetPlan>("make_plan", true);
        
        make_plan_client_.waitForExistence(ros::Duration(5.0));
        }
    }

    double DistanceCalculator::computeDistanceUsingMakePlan(double sx, double sy, double gx, double gy)
    {
        // (1) Ensure client exists and is connected
        if (!make_plan_client_.isValid()) {
        ////ROS_DEBUG("make_plan client invalid -> initializing (service param: %s)", makeplan_service_.c_str());
        initMakePlanClient();
        }

        // Try to (re)connect if needed
        if (!make_plan_client_.exists()) {
        ////ROS_DEBUG("Waiting for make_plan service to exist: %s", makeplan_service_.c_str());
        if (!make_plan_client_.waitForExistence(ros::Duration(3.0))) {
            //ROS_WARN_THROTTLE(2.0, "make_plan service not available at '%s' (resolved: '%s')",
                            //makeplan_service_.c_str(), make_plan_client_.getService().c_str());
            return std::numeric_limits<double>::infinity();
        }
        }

        // (2) Build request
        nav_msgs::GetPlan srv;
        const ros::Time stamp = ros::Time::now();

        srv.request.start.header.frame_id = global_frame_;
        srv.request.start.header.stamp    = stamp;
        srv.request.start.pose.position.x = sx;
        srv.request.start.pose.position.y = sy;
        srv.request.start.pose.orientation.w = 1.0;

        srv.request.goal.header.frame_id = global_frame_;
        srv.request.goal.header.stamp    = stamp;
        srv.request.goal.pose.position.x = gx;
        srv.request.goal.pose.position.y = gy;
        srv.request.goal.pose.orientation.w = 1.0;

        srv.request.tolerance = makeplan_tolerance_;

        ////ROS_DEBUG("Calling make_plan @ '%s' (resolved: '%s'), frame='%s', start=(%.3f,%.3f), goal=(%.3f,%.3f), tol=%.2f",
                // makeplan_service_.c_str(),
                // make_plan_client_.getService().c_str(),
                // global_frame_.c_str(), sx, sy, gx, gy, makeplan_tolerance_);

        // (3) Call service
        if (!make_plan_client_.call(srv)) {
        //ROS_WARN_THROTTLE(2.0, "make_plan call FAILED (service: %s | resolved: %s)",
                            //makeplan_service_.c_str(), make_plan_client_.getService().c_str());
        return std::numeric_limits<double>::infinity();
        }

        // (4) Inspect response
        const auto& poses = srv.response.plan.poses;
        ////ROS_DEBUG("make_plan call SUCCEEDED: %zu poses returned (service: %s | resolved: %s)",
                //poses.size(), makeplan_service_.c_str(), make_plan_client_.getService().c_str());

        if (poses.empty()) {
        // If you’re using a wrapper configured with `return_empty_on_failure: true`, this is the “no path” case.
        //ROS_WARN_THROTTLE(2.0, "make_plan returned an EMPTY path (no valid plan).");
        return std::numeric_limits<double>::infinity();
        }
        if (poses.size() == 1) {
        // start ≈ goal within tolerance
        ////ROS_DEBUG("make_plan returned a single pose (start≈goal) -> length=0.0 m");
        return 0.0;
        }

        // Optional: frame sanity
        const std::string resp_frame = poses.front().header.frame_id;
        if (!resp_frame.empty() && resp_frame != global_frame_) {
        //ROS_WARN_THROTTLE(2.0, "make_plan path frame ('%s') != expected global frame ('%s')",
                           // resp_frame.c_str(), global_frame_.c_str());
        }

        // (5) Sum length in METERS (straight segments between successive poses)
        double L = 0.0;
        for (size_t i = 1; i < poses.size(); ++i) {
        const auto& a = poses[i-1].pose.position;
        const auto& b = poses[i].pose.position;

        if (!std::isfinite(a.x) || !std::isfinite(a.y) ||
            !std::isfinite(b.x) || !std::isfinite(b.y)) {
            //ROS_WARN_THROTTLE(2.0, "make_plan produced non-finite coordinates at segment %zu; aborting length sum", i);
            return std::numeric_limits<double>::infinity();
        }
        L += std::hypot(b.x - a.x, b.y - a.y);
        }

        ////ROS_DEBUG("make_plan total length: %.3f m over %zu segments", L, poses.size()-1);
        return L;
    }

    // Fixed multiGoalDijkstra with better bounds checking and error handling
    void DistanceCalculator::multiGoalDijkstra(
        int sx, int sy,
        const std::vector<std::pair<int,int>>& goals_xy,
        std::vector<double>& out_dist,
        bool allow_unknown)
    {
        const double INF = std::numeric_limits<double>::infinity();
        out_dist.assign(goals_xy.size(), INF);
        
        if (!cm_ || goals_xy.empty()) {
            return;
        }

        std::lock_guard<costmap_2d::Costmap2D::mutex_t> lk(*cm_->getMutex());

        const int cols = static_cast<int>(cm_->getSizeInCellsX());
        const int rows = static_cast<int>(cm_->getSizeInCellsY());
        
        if (cols <= 0 || rows <= 0) {
            //ROS_ERROR("Invalid costmap dimensions in multiGoalDijkstra");
            return;
        }

        auto inb = [&](int x, int y) { return x >= 0 && x < cols && y >= 0 && y < rows; };
        auto toIdx = [&](int x, int y) { return y * cols + x; };

        if (!inb(sx, sy) || blocked(sx, sy, allow_unknown)) {
            return;
        }

        // Build goal map with validation
        std::unordered_map<int, std::vector<int>> goal_map;
        goal_map.reserve(goals_xy.size() * 2);
        
        for (size_t i = 0; i < goals_xy.size(); ++i) {
            const int gx = goals_xy[i].first;
            const int gy = goals_xy[i].second;
            
            if (!inb(gx, gy) || blocked(gx, gy, allow_unknown)) {
                continue;
            }
            
            goal_map[toIdx(gx, gy)].push_back(static_cast<int>(i));
        }
        
        if (goal_map.empty()) {
            return;
        }

        // Dijkstra implementation with bounds checking
        static const int DX[8] = { 1, 1, 0, -1, -1, -1,  0,  1};
        static const int DY[8] = { 0, 1, 1,  1,  0, -1, -1, -1};
        static const double STEP[8] = {
            1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0),
            1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0)
        };

        const size_t N = static_cast<size_t>(cols) * static_cast<size_t>(rows);
        std::vector<double> g;
        std::vector<uint8_t> closed;
        
        try {
            g.assign(N, INF);
            closed.assign(N, 0);
        } catch (const std::bad_alloc& e) {
            //ROS_ERROR("Memory allocation failed in multiGoalDijkstra: %s", e.what());
            return;
        }

        struct Node { 
            int idx; 
            double g; 
            bool operator<(const Node& o) const { return g > o.g; } 
        };
        std::priority_queue<Node> pq;

        const int sidx = toIdx(sx, sy);
        g[sidx] = 0.0;
        pq.push({sidx, 0.0});
        
        size_t remaining = goal_map.size();
        size_t processed = 0;
        const size_t max_iterations = N * 2;

        while (!pq.empty() && remaining > 0 && processed < max_iterations) {
            auto cur = pq.top();
            pq.pop();
            processed++;

            if (closed[cur.idx]) continue;
            closed[cur.idx] = 1;

            auto it = goal_map.find(cur.idx);
            if (it != goal_map.end()) {
                for (int gid : it->second) {
                    if (gid >= 0 && gid < static_cast<int>(out_dist.size())) {
                        out_dist[gid] = cur.g;
                    }
                }
                goal_map.erase(it);
                if (--remaining == 0) break;
            }

            const int cx = cur.idx % cols;
            const int cy = cur.idx / cols;
            
            for (int k = 0; k < 8; ++k) {
                const int nx = cx + DX[k];
                const int ny = cy + DY[k];
                
                if (!inb(nx, ny)) continue;
                
                // Check diagonal corner cutting
                if (DX[k] != 0 && DY[k] != 0) {
                    if (blocked(cx + DX[k], cy, allow_unknown) || 
                        blocked(cx, cy + DY[k], allow_unknown)) {
                        continue;
                    }
                }
                
                if (blocked(nx, ny, allow_unknown)) continue;

                const int nidx = toIdx(nx, ny);
                const double ng = cur.g + STEP[k];
                
                if (ng < g[nidx]) {
                    g[nidx] = ng;
                    pq.push({nidx, ng});
                }
            }
        }

        if (processed >= max_iterations) {
            //ROS_WARN("multiGoalDijkstra hit iteration limit");
        }
    }

  

    // We want to measure how far (shortest walking distance) from the robot (sx,sy)
    // to each "frontier tile" in goals_xy. We don't draw paths, just distances.
    // We explore the grid like a treasure hunt: keep a basket (open set) of places
    // to check next, and a stamp (closed set) for places we've already checked.

    void DistanceCalculator::multiGoalAstar(
        int sx, int sy,                                   // robot start tile
        const std::vector<std::pair<int,int>>& goals_xy,  // many frontier tiles (goals)
        std::vector<double>& out_dist,                    // answers: distance to each goal
        bool allow_unknown,                               // can we step on unknown tiles?
        double w)                                         // how much to trust the guess (heuristic weight)
    {
        const double INF = std::numeric_limits<double>::infinity();
        out_dist.assign(goals_xy.size(), INF);              // fill answers with ∞ first (unknown)
        if (!cm_ || goals_xy.empty()) return;              // if no map or no goals, go home.

        // Hold the map still so nobody changes it while we search.
        std::lock_guard<costmap_2d::Costmap2D::mutex_t> lk(*cm_->getMutex());

        // If the robot starts outside the map or on a blocked tile, we can't move.
        if (!inb(sx,sy) || blocked(sx,sy,allow_unknown)) return;

        // Map width/height and a helper to turn (x,y) into a single number (index).
        const int cols = (int)cm_->getSizeInCellsX();
        const int rows = (int)cm_->getSizeInCellsY();
        auto toIdx=[&](int x,int y){ return y*cols + x; };

        // Keep only the good goals: inside the map and not blocked.
        // goal_map: index -> which entries in out_dist this tile corresponds to.
        std::unordered_map<int,std::vector<int>> goal_map;
        goal_map.reserve(goals_xy.size()*2);
        std::vector<std::pair<int,int>> goals; goals.reserve(goals_xy.size());
        for (size_t i=0;i<goals_xy.size();++i){
        int gx=goals_xy[i].first, gy=goals_xy[i].second;
        if (!inb(gx,gy) || blocked(gx,gy,allow_unknown)) continue;
        goal_map[toIdx(gx,gy)].push_back((int)i);
        goals.emplace_back(gx,gy);
        }
        if (goal_map.empty()) return; // no reachable goals

        // Heuristic (h): a quick guess of how far a tile is to a goal if we can walk diagonally.
        auto h_oct = [](int x1,int y1,int x2,int y2){
        double dx = std::abs(x1-x2), dy = std::abs(y1-y2);
        return (dx+dy) + (std::sqrt(2.0)-2.0)*std::min(dx,dy); // "octile distance"
        };
        // For many goals, we guess distance to the *closest* goal.
        auto h_min_to_any = [&](int x,int y){
        double best=INF;
        for (auto& gxy : goals) {
            double h = h_oct(x,y,gxy.first,gxy.second);
            if (h<best) best=h;
        }
        return best;
        };

        // Moves we can make: 8 directions (N, NE, E, SE, S, SW, W, NW).
        static const int DX[8]={ 1, 1, 0,-1,-1,-1, 0, 1};
        static const int DY[8]={ 0, 1, 1, 1, 0,-1,-1,-1};
        static const double STEP[8]={ 1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0),
                                    1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0)};

        // One g-cost per tile (how far we've walked so far), and a "closed" stamp.
        const size_t N = (size_t)cols*rows;
        std::vector<double> g(N, INF);      // start as ∞ steps away
        std::vector<uint8_t> closed(N,0);   // 0 = not stamped, 1 = stamped (done)

        // The "open set" = our basket of places to check soon, ordered by f = g + w*h.
        struct QN{
        int idx; double g; double f;
        bool operator<(const QN& o)const{ return f>o.f; } // smallest f comes out first
        };
        std::priority_queue<QN> open;

        // Put the start tile into the basket.
        int sidx = toIdx(sx,sy);
        double h0 = h_min_to_any(sx,sy);
        g[sidx]=0.0;                          // we stand here: 0 steps so far
        open.push({sidx,0.0, 0.0 + w*h0});    // score f = g + w*h

        size_t remaining = goal_map.size();   // how many different goal tiles are left

        // Treasure hunt!
        while(!open.empty() && remaining>0){
        auto cur = open.top(); open.pop();  // pick the tile with best (smallest) score
        if (closed[cur.idx]) continue;      // if we already stamped it, skip
        closed[cur.idx]=1;                  // stamp it: we're done with this tile

        // Did we land on a goal tile?
        auto it = goal_map.find(cur.idx);
        if (it!=goal_map.end()){
            // Yes! Its g is the shortest distance from start to this goal.
            for (int gid : it->second) out_dist[gid]=cur.g;
            goal_map.erase(it);
            if (--remaining==0) break;        // found all goals—stop early!
        }

        // Try to step to all neighbors (8 directions).
        int cx = cur.idx % cols, cy = cur.idx / cols;
        for (int k=0;k<8;++k){
            int nx=cx+DX[k], ny=cy+DY[k];
            if (!inb(nx,ny)) continue;        // stay inside the map

            // If stepping diagonally, don't cut corners through walls.
            if (DX[k]!=0 && DY[k]!=0){
            if (blocked(cx+DX[k],cy,allow_unknown) 
                || blocked(cx,cy+DY[k],allow_unknown)) 
            continue;
            }
            if (blocked(nx,ny,allow_unknown)) continue; // can't step onto blocked tile

            int nidx = toIdx(nx,ny);
            double ng = cur.g + STEP[k];      // new g = steps so far + cost of this step
            if (ng < g[nidx]){                // if this is a better way to reach that tile
            g[nidx]=ng;
            double h = h_min_to_any(nx,ny); // guess how far left to the nearest goal
            open.push({nidx, ng, ng + w*h}); // put into basket with its new score
            }
        }
        }
    }


    void DistanceCalculator::multiGoalAstarCompletionHeuristic(
        int sx, int sy,
        const std::vector<std::pair<int,int>>& goals_xy,
        std::vector<double>& out_dist,
        bool allow_unknown,
        double w,
        const cv::Mat& gt_map_aligned,
        int patch,
        double meters_per_cell,
        double bias_k,
        double free_weight,
        double obst_weight)
    {
        const double INF = std::numeric_limits<double>::infinity();
        out_dist.assign(goals_xy.size(), INF);

        if (!cm_ || goals_xy.empty()) return;

        std::lock_guard<costmap_2d::Costmap2D::mutex_t> lk(*cm_->getMutex());

        const int W = (int)cm_->getSizeInCellsX();
        const int H = (int)cm_->getSizeInCellsY();

        // ✅ ADD THESE CONSTANTS
        const unsigned char KNOWN_U8 = 254;
        const unsigned char UNKNOWN_U8 = 205;
        const unsigned char OBSTACLE_U8 = 0;

        auto inb = [&](int x,int y){ return (unsigned)x < (unsigned)W && (unsigned)y < (unsigned)H; };

        // Sanity checks
        if (gt_map_aligned.empty() || gt_map_aligned.type()!=CV_8UC1 ||
            gt_map_aligned.cols!=W || gt_map_aligned.rows!=H) {
            //ROS_ERROR("A*: GT alignment failed - falling back to Dijkstra");
            multiGoalDijkstra(sx, sy, goals_xy, out_dist, allow_unknown);
            for (auto& d : out_dist) d *= meters_per_cell;
            return;
        }

        // Build current map unknown mask
        cv::Mat U(H, W, CV_8U, cv::Scalar(0));
        {
            const unsigned char* m = cm_->getCharMap();
            for (int y=0; y<H; ++y) {
                uchar* row = U.ptr<uchar>(y);
                for (int x=0; x<W; ++x) 
                    row[x] = (m[y*W+x]==costmap_2d::NO_INFORMATION) ? 255 : 0;
            }
        }

        // GT masks
        // ✅ UPDATED: GT masks - handle all three pixel values
        cv::Mat F(H, W, CV_8U, cv::Scalar(0));   // Free (254)
        cv::Mat O(H, W, CV_8U, cv::Scalar(0));   // Obstacle (0)
        cv::Mat UK(H, W, CV_8U, cv::Scalar(0));  // Model uncertain (205)

        cv::compare(gt_map_aligned, KNOWN_U8, F, cv::CMP_EQ);      // 254
        cv::compare(gt_map_aligned, OBSTACLE_U8, O, cv::CMP_EQ);   // 0
        cv::compare(gt_map_aligned, UNKNOWN_U8, UK, cv::CMP_EQ);   // 205

        // ✅ UPDATED: Integral images for O(1) patch sums - add third mask
        cv::Mat UF, UO, UUK;
        cv::bitwise_and(U, F, UF);   // Unknown in costmap AND free in model
        cv::bitwise_and(U, O, UO);   // Unknown in costmap AND obstacle in model
        cv::bitwise_and(U, UK, UUK); // Unknown in costmap AND uncertain in model

        cv::Mat iiUF, iiUO, iiUUK;
        cv::integral(UF, iiUF, CV_32S);
        cv::integral(UO, iiUO, CV_32S);
        cv::integral(UUK, iiUUK, CV_32S);

        // ✅ UPDATED: Debug statistics - add model uncertainty
        int total_unknown = cv::countNonZero(U);
        int total_free_gt = cv::countNonZero(F);
        int total_obst_gt = cv::countNonZero(O);
        int total_uncertain_gt = cv::countNonZero(UK);
        int unknown_free_overlap = cv::countNonZero(UF);
        int unknown_obst_overlap = cv::countNonZero(UO);
        int unknown_uncertain_overlap = cv::countNonZero(UUK);

        // //ROS_WARN("Map analysis: unknown=%d/%d (%.1f%%), GT_free=%d (%.1f%%), GT_obst=%d (%.1f%%), GT_uncertain=%d (%.1f%%)",
        //         total_unknown, W*H, 100.0*total_unknown/(W*H),
        //         total_free_gt, 100.0*total_free_gt/(W*H),
        //         total_obst_gt, 100.0*total_obst_gt/(W*H),
        //         total_uncertain_gt, 100.0*total_uncertain_gt/(W*H));
        // //ROS_WARN("Overlap: unknown∩GT_free=%d, unknown∩GT_obst=%d, unknown∩GT_uncertain=%d", 
        //         unknown_free_overlap, unknown_obst_overlap, unknown_uncertain_overlap);

        auto rectSum255 = [&](const cv::Mat& ii, int x0,int y0,int x1,int y1)->int {
            x0 = std::max(0, std::min(x0, W));
            x1 = std::max(0, std::min(x1, W));
            y0 = std::max(0, std::min(y0, H));
            y1 = std::max(0, std::min(y1, H));
            if (x1 <= x0 || y1 <= y0) return 0;
            const int A = ii.at<int>(y0, x0), B = ii.at<int>(y0, x1),
                    C = ii.at<int>(y1, x0), D = ii.at<int>(y1, x1);
            return (D - B - C + A);
        };

        const int P = std::max(1, std::min(patch, std::min(W,H)));

        // Build valid goals
        auto toIdx=[&](int x,int y){ return y*W + x; };
        std::unordered_map<int,std::vector<int>> goal_map;
        std::vector<std::pair<int,int>> goals;
        goal_map.reserve(goals_xy.size()*2);
        goals.reserve(goals_xy.size());

        for (size_t i=0;i<goals_xy.size();++i){
            int gx = goals_xy[i].first, gy = goals_xy[i].second;
            if (!inb(gx,gy) || blocked(gx,gy,allow_unknown)) continue;
            
            goal_map[toIdx(gx,gy)].push_back((int)i);
            goals.emplace_back(gx,gy);
        }
        
        if (goal_map.empty()) return;

        // Completion heuristic
        // ✅ UPDATED: Completion heuristic with model uncertainty handling
        auto patchBiasAt = [&](int cx, int cy) -> double {
            if (P <= 1) return 1.0;

            const int h = P/2;
            const int x0 = cx-h, y0 = cy-h, x1 = x0+P, y1 = y0+P;

            const int sUF = rectSum255(iiUF, x0, y0, x1, y1);    // Model says FREE
            const int sUO = rectSum255(iiUO, x0, y0, x1, y1);    // Model says OBSTACLE
            const int sUUK = rectSum255(iiUUK, x0, y0, x1, y1);  // Model UNCERTAIN
            
            const double cells = double(
                std::max(0, std::min(x1,W) - std::max(0,x0)) *
                std::max(0, std::min(y1,H) - std::max(0,y0))
            );
            
            if (cells <= 0.0) return 1.0;

            const double fracUF = (sUF/255.0)/cells;    // Fraction: unknown→predicted free
            const double fracUO = (sUO/255.0)/cells;    // Fraction: unknown→predicted obstacle
            const double fracUUK = (sUUK/255.0)/cells;  // Fraction: unknown→model uncertain

            // Heuristic contributions
            double free_contribution = bias_k * free_weight * (1.0 - fracUF);  // Lower cost for predicted free
            double obst_contribution = bias_k * obst_weight * fracUO;          // Higher cost for predicted obstacles
            double uncertain_contribution = bias_k * 0.3 * fracUUK;            // Slight penalty for model uncertainty
            
            double completion_cost = free_contribution + obst_contribution + uncertain_contribution;

            return std::max(0.1, std::min(completion_cost, 50.0));
        };

        // Track goal heuristics
        double min_bias = INF, max_bias = -INF, total_bias = 0.0;
        int valid_goals = 0;

        for (const auto& goal : goals) {
            double bias = patchBiasAt(goal.first, goal.second);
            min_bias = std::min(min_bias, bias);
            max_bias = std::max(max_bias, bias);
            total_bias += bias;
            valid_goals++;
        }

        double avg_bias = total_bias / valid_goals;
        //ROS_WARN("Goal heuristic stats: min=%.3f, max=%.3f, avg=%.3f, range=%.3f, valid_goals=%d/%zu",
               // min_bias, max_bias, avg_bias, max_bias - min_bias, valid_goals, goals_xy.size());

        // A* search
        static const int DX[8]={ 1, 1, 0,-1,-1,-1, 0, 1};
        static const int DY[8]={ 0, 1, 1, 1, 0,-1,-1,-1};
        static const double STEP[8]={ 1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0),
                                    1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0)};

        if (!inb(sx,sy) || blocked(sx,sy,allow_unknown)) return;

        const size_t N = (size_t)W*H;
        std::vector<double> g(N, INF);
        std::vector<uint8_t> closed(N,0);

        struct QN{ int idx; double g; double f; };
        struct Cmp{ bool operator()(const QN&a,const QN&b)const{ return a.f>b.f; } };
        std::priority_queue<QN, std::vector<QN>, Cmp> open;

        const int sidx = toIdx(sx,sy);
        g[sidx] = 0.0;
        const double h0 = w * patchBiasAt(sx,sy);
        //ROS_WARN("Start node (%d,%d): h0=%.3f (weighted: %.3f)", sx, sy, h0/w, h0);
        
        open.push({sidx, 0.0, 0.0 + h0});

        size_t remaining = goal_map.size();
        size_t expansions = 0;
        double total_h_computed = 0.0;
        size_t h_computations = 0;

        while (!open.empty() && remaining>0 && expansions < N*2){
            QN cur = open.top(); open.pop();
            if (closed[cur.idx]) continue;
            closed[cur.idx]=1;
            expansions++;

            auto hit = goal_map.find(cur.idx);
            if (hit!=goal_map.end()){
                for (int gid : hit->second) {
                    out_dist[gid] = cur.g * meters_per_cell;
                    //ROS_WARN("Reached goal %d: g=%.3f cells, distance=%.3f m", 
                            // gid, cur.g, out_dist[gid]);
                }
                goal_map.erase(hit);
                if (--remaining==0) break;
            }

            int cx = cur.idx % W, cy = cur.idx / W;
            
            for (int k=0;k<8;++k){
                int nx=cx+DX[k], ny=cy+DY[k];
                if (!inb(nx,ny)) continue;

                // Diagonal corner check with debug
                if (DX[k]!=0 && DY[k]!=0) {
                    bool corner1_blocked = planningBlocked(cx+DX[k], cy, allow_unknown);
                    bool corner2_blocked = planningBlocked(cx, cy+DY[k], allow_unknown);
                    
                    if (corner1_blocked || corner2_blocked) {
                        if (expansions <= 5) {
                            //ROS_WARN("Diagonal blocked (%d,%d): corner1=%s, corner2=%s",
                                    // nx, ny, corner1_blocked?"YES":"NO", corner2_blocked?"YES":"NO");
                        }
                        continue;
                    }
                }
                
                bool is_blocked = planningBlocked(nx, ny, allow_unknown);
                if (is_blocked) {
                    if (expansions <= 5) {
                        unsigned char cm_cost = cm_->getCost(nx, ny);
                        unsigned char gt_val = gt_map_aligned.at<uchar>(ny, nx);
                        //ROS_WARN("Cell (%d,%d) blocked: costmap=%u, GT=%u", nx, ny, cm_cost, gt_val);
                    }
                    continue;
                }

                int nidx = toIdx(nx,ny);
                double ng = cur.g + STEP[k];
                if (ng < g[nidx]){
                    g[nidx]=ng;
                    double h = w * patchBiasAt(nx,ny);
                    total_h_computed += h/w;
                    h_computations++;
                    open.push({nidx, ng, ng + h});
                }
            }
        }

        double avg_h = h_computations > 0 ? total_h_computed / h_computations : 0.0;
        //ROS_WARN("A* completed: expansions=%zu/%zu, avg_h=%.3f, h_computations=%zu", 
                // expansions, N, avg_h, h_computations);
        
        int reachable = 0;
        for (size_t i = 0; i < out_dist.size(); i++) {
            if (std::isfinite(out_dist[i])) reachable++;
        }
        //ROS_WARN("Final: %d/%zu goals reachable", reachable, out_dist.size());
    }

    double DistanceCalculator::euclideanDistance(double x1, double y1, double x2, double y2) {
        return std::hypot(x1 - x2, y1 - y2);
    }

    double DistanceCalculator::manhattanDistance(double x1, double y1, double x2, double y2) {
        return std::abs(x1 - x2) + std::abs(y1 - y2);
    }

    double DistanceCalculator::chebyshevDistance(double x1, double y1, double x2, double y2) {
        return std::max(std::abs(x1 - x2), std::abs(y1 - y2));
    }

    double DistanceCalculator::squaredEuclideanDistance(double x1, double y1, double x2, double y2) {
        double dx = x1 - x2, dy = y1 - y2;
        return dx*dx + dy*dy;
    }

    // Fixed ensureDistanceField with better memory management and error handling
    void DistanceCalculator::ensureDistanceField(int sx, int sy, bool allow_unknown)
    {
        if (!cm_) {
            field_valid_ = false;
            return;
        }

        std::lock_guard<costmap_2d::Costmap2D::mutex_t> lk(*cm_->getMutex());

        const int cols = static_cast<int>(cm_->getSizeInCellsX());
        const int rows = static_cast<int>(cm_->getSizeInCellsY());
        
        if (cols <= 0 || rows <= 0) {
            //ROS_ERROR("Invalid costmap dimensions: %dx%d", cols, rows);
            field_valid_ = false;
            return;
        }

        auto inb_local = [&](int x, int y) { 
            return x >= 0 && x < cols && y >= 0 && y < rows; 
        };
        auto toIdx = [&](int x, int y) { return y * cols + x; };

        // Check if we can reuse cached field
        if (field_valid_ &&
            field_cols_ == cols && 
            field_rows_ == rows &&
            field_start_idx_ == toIdx(sx, sy) &&
            field_allow_unknown_ == allow_unknown) {
            return; // Cache hit
        }

        // Validate start position
        if (!inb_local(sx, sy) || blocked(sx, sy, allow_unknown)) {
            field_valid_ = false;
            return;
        }

        // Update cache parameters
        field_cols_ = cols;
        field_rows_ = rows;
        field_start_idx_ = toIdx(sx, sy);
        field_allow_unknown_ = allow_unknown;

        const size_t N = static_cast<size_t>(cols) * static_cast<size_t>(rows);
        const double INF = std::numeric_limits<double>::infinity();

        // Efficient memory allocation - reserve if needed, otherwise reuse
        if (dist_field_.size() != N) {
            try {
                dist_field_.assign(N, INF);
            } catch (const std::bad_alloc& e) {
                //ROS_ERROR("Failed to allocate distance field: %s", e.what());
                field_valid_ = false;
                return;
            }
        } else {
            std::fill(dist_field_.begin(), dist_field_.end(), INF);
        }

        // Dijkstra's algorithm with proper bounds checking
        struct Node { 
            int idx; 
            double g; 
            bool operator<(const Node& o) const { return g > o.g; } 
        };
        std::priority_queue<Node> pq;

        static const int DX[8] = { 1, 1, 0, -1, -1, -1,  0,  1};
        static const int DY[8] = { 0, 1, 1,  1,  0, -1, -1, -1};
        static const double STEP[8] = {
            1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0),
            1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0)
        };

        const int start_idx = field_start_idx_;
        dist_field_[start_idx] = 0.0;
        pq.push({start_idx, 0.0});

        size_t processed = 0;
        const size_t max_iterations = N * 2; // Prevent infinite loops

        while (!pq.empty() && processed < max_iterations) {
            auto cur = pq.top();
            pq.pop();
            processed++;

            // Skip outdated entries
            if (cur.g > dist_field_[cur.idx] + 1e-9) {
                continue;
            }

            const int cx = cur.idx % cols;
            const int cy = cur.idx / cols;

            for (int k = 0; k < 8; ++k) {
                const int nx = cx + DX[k];
                const int ny = cy + DY[k];

                if (!inb_local(nx, ny)) continue;

                // Pass allow_unknown to match the signature bool blocked(int,int,bool) const
                if (DX[k] != 0 && DY[k] != 0) {
                    if (this->blocked(cx + DX[k], cy, allow_unknown) ||
                        this->blocked(cx,          cy + DY[k], allow_unknown)) continue;
                }
                if (this->blocked(nx, ny, allow_unknown)) continue;

                const int nidx = toIdx(nx, ny);
                const double ng = cur.g + STEP[k];
                
                if (ng < dist_field_[nidx]) {
                    dist_field_[nidx] = ng;
                    pq.push({nidx, ng});
                }
            }
        }

        if (processed >= max_iterations) {
            //ROS_WARN("Distance field computation hit iteration limit");
        }

        field_valid_ = true;
    }

    // Add to distance_calculator.cpp - optimized distance field with early termination
    void DistanceCalculator::ensureDistanceFieldOptimized(int sx, int sy, bool allow_unknown,double max_distance)
    {
        if (!cm_) {
            field_valid_ = false;
            return;
        }

        std::lock_guard<costmap_2d::Costmap2D::mutex_t> lk(*cm_->getMutex());

        const int cols = static_cast<int>(cm_->getSizeInCellsX());
        const int rows = static_cast<int>(cm_->getSizeInCellsY());
        
        if (cols <= 0 || rows <= 0) {
            field_valid_ = false;
            return;
        }

        // Check cache validity
        auto toIdx = [&](int x, int y) { return y * cols + x; };

        if (field_valid_ &&
            field_cols_ == cols && field_rows_ == rows &&
            field_start_idx_ == toIdx(sx, sy) &&
            field_allow_unknown_ == allow_unknown) {
            return; // Cache hit
        }

        if (!inb(sx, sy) || blocked(sx, sy, allow_unknown)) {
            field_valid_ = false;
            return;
        }

        // Update cache parameters
        field_cols_ = cols;
        field_rows_ = rows;
        field_start_idx_ = toIdx(sx, sy);
        field_allow_unknown_ = allow_unknown;

        const size_t N = static_cast<size_t>(cols) * static_cast<size_t>(rows);
        const double INF = std::numeric_limits<double>::infinity();

        // Efficient memory management
        if (dist_field_.size() != N) {
            try {
                dist_field_.assign(N, INF);
            } catch (const std::bad_alloc& e) {
                //ROS_ERROR("Memory allocation failed: %s", e.what());
                field_valid_ = false;
                return;
            }
        } else {
            std::fill(dist_field_.begin(), dist_field_.end(), INF);
        }

        // Dijkstra with early termination option
        struct Node { 
            int idx; 
            double g; 
            bool operator<(const Node& o) const { return g > o.g; } 
        };
        std::priority_queue<Node> pq;

        static const int DX[8] = { 1, 1, 0, -1, -1, -1,  0,  1};
        static const int DY[8] = { 0, 1, 1,  1,  0, -1, -1, -1};
        static const double STEP[8] = {
            1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0),
            1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0)
        };

        const int start_idx = field_start_idx_;
        dist_field_[start_idx] = 0.0;
        pq.push({start_idx, 0.0});

        size_t processed = 0;
        const size_t max_iterations = N * 2;
        const double max_dist = (max_distance > 0) ? max_distance : std::numeric_limits<double>::infinity();

        while (!pq.empty() && processed < max_iterations) {
            auto cur = pq.top();
            pq.pop();
            processed++;

            // Early termination if we've exceeded max distance
            if (cur.g > max_dist) {
                break;
            }

            // Skip outdated entries
            if (cur.g > dist_field_[cur.idx] + 1e-9) {
                continue;
            }

            const int cx = cur.idx % cols;
            const int cy = cur.idx / cols;

            for (int k = 0; k < 8; ++k) {
                const int nx = cx + DX[k];
                const int ny = cy + DY[k];

                if (!inb(nx, ny)) continue;

                // Prevent diagonal corner cutting
                if (DX[k] != 0 && DY[k] != 0) {
                    if (blocked(cx + DX[k], cy, allow_unknown) || 
                        blocked(cx, cy + DY[k], allow_unknown)) {
                        continue;
                    }
                }

                if (blocked(nx, ny, allow_unknown)) continue;

                const int nidx = toIdx(nx, ny);
                const double ng = cur.g + STEP[k];
                
                if (ng < dist_field_[nidx] && ng <= max_dist) {
                    dist_field_[nidx] = ng;
                    pq.push({nidx, ng});
                }
            }
        }

        field_valid_ = true;
    }


    double DistanceCalculator::computeDistanceUsingMakePlanSafe(double sx, double sy, double gx, double gy)
    {
        const double INF = std::numeric_limits<double>::infinity();
        
        // Input validation
        if (!std::isfinite(sx) || !std::isfinite(sy) || !std::isfinite(gx) || !std::isfinite(gy)) {
            //ROS_WARN("Invalid coordinates for make_plan: start(%.3f,%.3f) goal(%.3f,%.3f)", sx, sy, gx, gy);
            return INF;
        }

        // Service availability check with timeout
        if (!make_plan_client_.isValid()) {
            initMakePlanClient();
        }

        if (!make_plan_client_.exists()) {
            if (!make_plan_client_.waitForExistence(ros::Duration(3.0))) {
                //ROS_WARN_THROTTLE(5.0, "make_plan service not available: %s", makeplan_service_.c_str());
                return INF;
            }
        }

        // Build service request with validation
        nav_msgs::GetPlan srv;
        const ros::Time stamp = ros::Time::now();

        srv.request.start.header.frame_id = global_frame_;
        srv.request.start.header.stamp = stamp;
        srv.request.start.pose.position.x = sx;
        srv.request.start.pose.position.y = sy;
        srv.request.start.pose.position.z = 0.0;
        srv.request.start.pose.orientation.x = 0.0;
        srv.request.start.pose.orientation.y = 0.0;
        srv.request.start.pose.orientation.z = 0.0;
        srv.request.start.pose.orientation.w = 1.0;

        srv.request.goal.header.frame_id = global_frame_;
        srv.request.goal.header.stamp = stamp;
        srv.request.goal.pose.position.x = gx;
        srv.request.goal.pose.position.y = gy;
        srv.request.goal.pose.position.z = 0.0;
        srv.request.goal.pose.orientation.x = 0.0;
        srv.request.goal.pose.orientation.y = 0.0;
        srv.request.goal.pose.orientation.z = 0.0;
        srv.request.goal.pose.orientation.w = 1.0;

        srv.request.tolerance = std::max(0.01, std::min(makeplan_tolerance_, 1.0)); // Clamp tolerance

        // Service call with retry (ROS ServiceClient doesn't support timeout in call())
        bool call_success = false;
        int retry_count = 0;
        const int max_retries = 2;
        
        while (!call_success && retry_count < max_retries) {
            try {
                // Simple call without timeout - ROS will use default timeout
                call_success = make_plan_client_.call(srv);
            } catch (const std::exception& e) {
                //ROS_WARN("Exception in make_plan service call (attempt %d): %s", retry_count + 1, e.what());
            }
            
            if (!call_success) {
                retry_count++;
                if (retry_count < max_retries) {
                    ros::Duration(0.1).sleep(); // Brief delay before retry
                }
            }
        }

        if (!call_success) {
            //ROS_WARN_THROTTLE(2.0, "make_plan call failed after %d attempts (service: %s)", 
                         //   max_retries, makeplan_service_.c_str());
            return INF;
        }

        // Validate response
        const auto& poses = srv.response.plan.poses;
        if (poses.empty()) {
            ////ROS_DEBUG("make_plan returned empty path");
            return INF;
        }

        if (poses.size() == 1) {
            ////ROS_DEBUG("make_plan: start ≈ goal within tolerance");
            return 0.0;
        }

        // Validate path and compute length
        double total_length = 0.0;
        const size_t max_poses = 10000; // Prevent excessive computation
        const size_t actual_poses = std::min(poses.size(), max_poses);
        
        for (size_t i = 1; i < actual_poses; ++i) {
            const auto& a = poses[i-1].pose.position;
            const auto& b = poses[i].pose.position;

            // Validate coordinates
            if (!std::isfinite(a.x) || !std::isfinite(a.y) || !std::isfinite(a.z) ||
                !std::isfinite(b.x) || !std::isfinite(b.y) || !std::isfinite(b.z)) {
                //ROS_WARN("make_plan returned path with invalid coordinates at segment %zu", i);
                return INF;
            }

            const double dx = b.x - a.x;
            const double dy = b.y - a.y;
            const double segment_length = std::hypot(dx, dy);
            
            // Sanity check segment length
            if (!std::isfinite(segment_length) || segment_length < 0.0 || segment_length > 100.0) {
                //ROS_WARN("Invalid segment length %.3f at segment %zu", segment_length, i);
                return INF;
            }
            
            total_length += segment_length;
            
            // Prevent excessive path lengths
            if (total_length > 1000.0) {
                //ROS_WARN("Path length exceeds reasonable limit: %.3f m", total_length);
                return INF;
            }
        }

        if (actual_poses < poses.size()) {
            //ROS_WARN("Path truncated due to length limit: %zu/%zu poses processed", 
                    // actual_poses, poses.size());
        }

        ////ROS_DEBUG("make_plan success: %.3f m over %zu segments", total_length, actual_poses - 1);
        return total_length;
    }


    /*
        // ---------- Multi-goal Dijkstra (8-connected, corner-safe) ----------
        // void DistanceCalculator::multiGoalDijkstra(
        //     int sx, int sy,
        //     const std::vector<std::pair<int,int>>& goals_xy,
        //     std::vector<double>& out_dist,
        //     bool allow_unknown)
        // {
        //   const double INF = std::numeric_limits<double>::infinity();
        //   out_dist.assign(goals_xy.size(), INF);
        //   if (!cm_ || !inb(sx,sy) || goals_xy.empty()) return;
        //   if (blocked(sx,sy,allow_unknown)) return;

        //   const int cols = (int)cm_->getSizeInCellsX();
        //   const int rows = (int)cm_->getSizeInCellsY();
        //   auto toIdx=[&](int x,int y){ return y*cols + x; };

        //   std::unordered_map<int,std::vector<int>> goal_map;
        //   goal_map.reserve(goals_xy.size()*2);
        //   for (size_t i=0;i<goals_xy.size();++i){
        //     int gx=goals_xy[i].first, gy=goals_xy[i].second;
        //     if (!inb(gx,gy) || blocked(gx,gy,allow_unknown)) continue;
        //     goal_map[toIdx(gx,gy)].push_back((int)i);
        //   }
        //   if (goal_map.empty()) return;

        //   static const int DX[8]={ 1, 1, 0,-1,-1,-1, 0, 1};
        //   static const int DY[8]={ 0, 1, 1, 1, 0,-1,-1,-1};
        //   static const double STEP[8]={1.0,std::sqrt(2.0),1.0,std::sqrt(2.0),
        //                               1.0,std::sqrt(2.0),1.0,std::sqrt(2.0)};

        //   const size_t N = (size_t)cols*rows;
        //   std::vector<double> g(N, INF);
        //   std::vector<uint8_t> closed(N,0);

        //   struct Node { int idx; double g; bool operator<(const Node& o)const{return g>o.g;} };
        //   std::priority_queue<Node> pq;

        //   int sidx = toIdx(sx,sy);
        //   g[sidx]=0.0; pq.push({sidx,0.0});
        //   size_t remaining = goal_map.size();

        //   while(!pq.empty() && remaining>0){
        //     auto cur = pq.top(); pq.pop();
        //     if (closed[cur.idx]) continue;
        //     closed[cur.idx]=1;

        //     auto it = goal_map.find(cur.idx);
        //     if (it!=goal_map.end()){
        //       for (int gid : it->second) out_dist[gid]=cur.g;
        //       goal_map.erase(it);
        //       --remaining;
        //       if (remaining==0) break;
        //     }

        //     int cx = cur.idx % cols, cy = cur.idx / cols;
        //     for (int k=0;k<8;++k){
        //       int nx=cx+DX[k], ny=cy+DY[k];
        //       if (!inb(nx,ny)) continue;
        //       if (DX[k]!=0 && DY[k]!=0){ // no corner-cut
        //         if (blocked(cx+DX[k],cy,allow_unknown) || blocked(cx,cy+DY[k],allow_unknown)) continue;
        //       }
        //       if (blocked(nx,ny,allow_unknown)) continue;

        //       int nidx = toIdx(nx,ny);
        //       double ng = cur.g + STEP[k];
        //       if (ng < g[nidx]) { g[nidx]=ng; pq.push({nidx,ng}); }
        //     }
        //   }
        // }

        // ---------- Multi-goal A* (octile heuristic, weighted) ----------
        // void DistanceCalculator::multiGoalAstar(
        //     int sx, int sy,
        //     const std::vector<std::pair<int,int>>& goals_xy,
        //     std::vector<double>& out_dist,
        //     bool allow_unknown,
        //     double w)
        // {
        //   const double INF = std::numeric_limits<double>::infinity();
        //   out_dist.assign(goals_xy.size(), INF);
        //   if (!cm_ || !inb(sx,sy) || goals_xy.empty()) return;
        //   if (blocked(sx,sy,allow_unknown)) return;

        //   const int cols = (int)cm_->getSizeInCellsX();
        //   const int rows = (int)cm_->getSizeInCellsY();
        //   auto toIdx=[&](int x,int y){ return y*cols + x; };

        //   std::unordered_map<int,std::vector<int>> goal_map;
        //   goal_map.reserve(goals_xy.size()*2);
        //   std::vector<std::pair<int,int>> goals;
        //   goals.reserve(goals_xy.size());
        //   for (size_t i=0;i<goals_xy.size();++i){
        //     int gx=goals_xy[i].first, gy=goals_xy[i].second;
        //     if (!inb(gx,gy) || blocked(gx,gy,allow_unknown)) continue;
        //     goal_map[toIdx(gx,gy)].push_back((int)i);
        //     goals.emplace_back(gx,gy);
        //   }
        //   if (goal_map.empty()) return;

        //   auto h_oct = [](int x1,int y1,int x2,int y2){
        //     double dx = std::abs(x1-x2), dy = std::abs(y1-y2);
        //     return (dx+dy) + (std::sqrt(2.0)-2.0)*std::min(dx,dy);
        //   };
        //   auto h_min_to_any = [&](int x,int y){
        //     double best=INF;
        //     for (auto& gxy : goals) {
        //       double h = h_oct(x,y,gxy.first,gxy.second);
        //       if (h<best) best=h;
        //     }
        //     return best;
        //   };

        //   static const int DX[8]={ 1, 1, 0,-1,-1,-1, 0, 1};
        //   static const int DY[8]={ 0, 1, 1, 1, 0,-1,-1,-1};
        //   static const double STEP[8]={1.0,std::sqrt(2.0),1.0,std::sqrt(2.0),
        //                               1.0,std::sqrt(2.0),1.0,std::sqrt(2.0)};

        //   const size_t N = (size_t)cols*rows;
        //   std::vector<double> g(N, INF);
        //   std::vector<uint8_t> closed(N,0);

        //   struct QN{ int idx; double g; double f; bool operator<(const QN& o)const{return f>o.f;} };
        //   std::priority_queue<QN> open;

        //   int sidx = toIdx(sx,sy);
        //   double h0 = h_min_to_any(sx,sy);
        //   g[sidx]=0.0; open.push({sidx,0.0, 0.0 + w*h0});

        //   size_t remaining = goal_map.size();

        //   while(!open.empty() && remaining>0){
        //     auto cur = open.top(); open.pop();
        //     if (closed[cur.idx]) continue;
        //     closed[cur.idx]=1;

        //     auto it = goal_map.find(cur.idx);
        //     if (it!=goal_map.end()){
        //       for (int gid : it->second) out_dist[gid]=cur.g;
        //       goal_map.erase(it);
        //       --remaining;
        //       if (remaining==0) break;
        //     }

        //     int cx = cur.idx % cols, cy = cur.idx / cols;
        //     for (int k=0;k<8;++k){
        //       int nx=cx+DX[k], ny=cy+DY[k];
        //       if (!inb(nx,ny)) continue;
        //       if (DX[k]!=0 && DY[k]!=0){ // no corner-cut
        //         if (blocked(cx+DX[k],cy,allow_unknown) || blocked(cx,cy+DY[k],allow_unknown)) continue;
        //       }
        //       if (blocked(nx,ny,allow_unknown)) continue;

        //       int nidx = toIdx(nx,ny);
        //       double ng = cur.g + STEP[k];
        //       if (ng < g[nidx]){
        //         g[nidx]=ng;
        //         double h = h_min_to_any(nx,ny);
        //         open.push({nidx, ng, ng + w*h});
        //       }
        //     }
        //   }
        // }

        // double DistanceCalculator::computeDistanceUsingMakePlan(double sx, double sy, double gx, double gy) {

        //   // Ensure the client exists and is healthy
        //   if (!make_plan_client_.isValid()) {
        //     initMakePlanClient();
        //   }


        //   nav_msgs::GetPlan srv;
        //   srv.request.start.header.frame_id = global_frame_;
        //   srv.request.goal.header.frame_id  = global_frame_;
        //   const ros::Time stamp = ros::Time::now();
        //   srv.request.start.header.stamp = stamp;
        //   srv.request.goal.header.stamp  = stamp;

        //   srv.request.start.pose.position.x = sx;
        //   srv.request.start.pose.position.y = sy;
        //   srv.request.start.pose.orientation.w = 1.0;

        //   srv.request.goal.pose.position.x = gx;
        //   srv.request.goal.pose.position.y = gy;
        //   srv.request.goal.pose.orientation.w = 1.0;

        //   srv.request.tolerance = makeplan_tolerance_;

            
        //   if (!make_plan_client_.call(srv)) {
        //     //ROS_WARN_THROTTLE(2.0, "make_plan call failed (service: %s)", makeplan_service_.c_str());
        //     return std::numeric_limits<double>::infinity();
        //   }
        //   else{
        //     //ROS_INFO("make_plan service has called successfully.");
        //   }

        //   const auto& poses = srv.response.plan.poses;
        //   if (poses.size() < 2) {
        //     ////ROS_WARN_THROTTLE(2.0, "make_plan returned no path (poses=%zu)", poses.size());
        //     return std::numeric_limits<double>::infinity();
        //     if (poses.size() == 1) return 0.0;  // start≈goal within tolerance
        //   }

        //   double L = 0.0;
        //   // Optional: cap to avoid excessive work if you only need up to some length
        //   // const double kMaxLen = 1e6; // meters (set if desired)

        //   for (size_t i = 1; i < poses.size(); ++i) {
        //     const auto& a = poses[i-1].pose.position;
        //     const auto& b = poses[i].pose.position;

        //     // Guard against NaNs or identical points
        //     if (!std::isfinite(a.x) || !std::isfinite(a.y) ||
        //         !std::isfinite(b.x) || !std::isfinite(b.y)) {
        //       //ROS_WARN_THROTTLE(2.0, "make_plan produced non-finite coordinates; aborting length sum");
        //       return std::numeric_limits<double>::infinity();
        //     }

        //     const double dx = b.x - a.x;
        //     const double dy = b.y - a.y;
        //     L += std::hypot(dx, dy);

        //     // if (L > kMaxLen) return L; // optional early exit
        //   }

        //   return L; // meters
        // }
    */

}

