#include <explore/experiment_logger.h>
#include <iomanip>
#include <ros/ros.h>
#include <locale>

namespace explore {

ExperimentLogger::ExperimentLogger(const std::string& filename) {
  file_.open(filename, std::ios::out | std::ios::trunc);
  if (!file_.is_open()) {
    ROS_ERROR_STREAM("Failed to open log file: " << filename);
  } else {
    file_.imbue(std::locale::classic());            // ensure '.' decimal
    // CSV header - all event types share these columns
    file_ << "type,timestamp,distance_m,completion_percent,elapsed_sec,gt_width,gt_height,costmap_width,costmap_height,info\n";
    file_.flush();
    ROS_INFO("ExperimentLogger initialized: %s", filename.c_str());
  }
}

ExperimentLogger::~ExperimentLogger() {
  std::lock_guard<std::mutex> lk(mtx_);
  if (file_.is_open()) file_.close();
}

void ExperimentLogger::logTarget(const geometry_msgs::Point& target, const std::string& method) {
  std::lock_guard<std::mutex> lk(mtx_);
  if (!file_.is_open()) return;
  const double t = ros::Time::now().toSec();
  file_ << "target," << std::fixed << std::setprecision(3) << t << ","
        << target.x << "," << target.y << ",,,,,,"
        << std::quoted(method) << "\n";
  file_.flush();
}

void ExperimentLogger::logTrajectoryPoint(const geometry_msgs::Point& position, double timestamp) {
  std::lock_guard<std::mutex> lk(mtx_);
  if (!file_.is_open()) return;
  file_ << "trajectory," << std::fixed << std::setprecision(3) << timestamp << ","
        << position.x << "," << position.y << ",,,,,,\n";
  file_.flush();
}

// void ExperimentLogger::logMetrics(double distance_m, double completion_percent, double elapsed_sec) {
//   std::lock_guard<std::mutex> lk(mtx_);
//   if (!file_.is_open()) return;
//   const double t = ros::Time::now().toSec();
//   file_ << "metrics," << std::fixed << std::setprecision(3) << t << ","
//         << distance_m << "," << completion_percent << "," << elapsed_sec << ",\n";
//   file_.flush();
// }

void ExperimentLogger::logMetrics(double distance, double completion_percent, double elapsed_time,
                                   int gt_width, int gt_height, int costmap_width, int costmap_height) 
{
    std::lock_guard<std::mutex> lk(mtx_);
    if (!file_.is_open()) return;
    
    file_ << "metrics,"
      << std::fixed << std::setprecision(3)
      << ros::Time::now().toSec() << ","
      << distance << ","
      << completion_percent << ","
      << elapsed_time << ","
      << gt_width << ","
      << gt_height << ","
      << costmap_width << ","
      << costmap_height << ","
      << "\n";
    file_.flush();
}

void ExperimentLogger::logOperation(const std::string& operation_name, double duration_ms, const std::string& info) {
  std::lock_guard<std::mutex> lk(mtx_);
  if (!file_.is_open()) return;
  const double t = ros::Time::now().toSec();
  
  std::string combined_name = operation_name;
  if (!info.empty()) {
    combined_name += ":" + info;  // debug_filtering:total_frontiers=25,...
  }
  
  file_ << "operation," << std::fixed << std::setprecision(3) << t << ","
        << duration_ms << ",,,,,,," << std::quoted(combined_name) << "\n";
  file_.flush();
}

void ExperimentLogger::logTargetReached(const geometry_msgs::Point& target, 
                                        double travel_time_sec, 
                                        double travel_distance_m) {
  std::lock_guard<std::mutex> lk(mtx_);
  if (!file_.is_open()) return;
  const double t = ros::Time::now().toSec();
  file_ << "target_reached," << std::fixed << std::setprecision(3) << t << ","
        << target.x << "," << target.y << "," << travel_time_sec << ",,,,"
        << std::quoted(std::to_string(travel_distance_m)) << "\n";
  file_.flush();
}


void ExperimentLogger::logMilestone(int threshold_percent, 
                                     double elapsed_sec,
                                     double total_distance_m,
                                     double measured_completion_percent) {
  std::lock_guard<std::mutex> lk(mtx_);
  if (!file_.is_open()) return;
  
  const double t = ros::Time::now().toSec();
  // type, timestamp, threshold%, elapsed_sec, distance_m, measured_completion%
  file_ << "milestone," << std::fixed << std::setprecision(3) << t << ","
        << threshold_percent << "," << elapsed_sec << "," << total_distance_m << ",,,,"
        << std::quoted(std::to_string(measured_completion_percent)) << "\n";
  file_.flush();
  
  ROS_INFO("✓ Milestone reached: %d%% completion at %.1fs, distance: %.2fm, actual: %.2f%%",
           threshold_percent, elapsed_sec, total_distance_m, measured_completion_percent);
}

void ExperimentLogger::logExperimentStart(const std::string& distance_method,
                                          const std::string& map_name) {
  std::lock_guard<std::mutex> lk(mtx_);
  if (!file_.is_open()) return;
  
  const double t = ros::Time::now().toSec();
  std::stringstream info;
  info << "method:" << distance_method ;
  if (!map_name.empty()) {
    info << ",map:" << map_name;
  }
  
  // type, timestamp, -, -, -, info
  file_ << "experiment_start," << std::fixed << std::setprecision(3) << t << ",,,,,,,"
        << std::quoted(info.str()) << "\n";
  file_.flush();
  
  ROS_INFO("✓ Experiment started - Method: %s", 
           distance_method.c_str());
}

void ExperimentLogger::logExperimentEnd(double total_time_sec,
                                        double total_distance_m,
                                        double final_completion_percent,
                                        int frontiers_visited,
                                        int navigation_failures) {
  std::lock_guard<std::mutex> lk(mtx_);
  if (!file_.is_open()) return;
  
  const double t = ros::Time::now().toSec();
  std::stringstream info;
  info << "frontiers:" << frontiers_visited 
       << ",failures:" << navigation_failures;
  
  // type, timestamp, total_time, distance, completion%, info
  file_ << "experiment_end," << std::fixed << std::setprecision(3) << t << ","
        << total_time_sec << "," << total_distance_m << "," << final_completion_percent << ",,,,"
        << std::quoted(info.str()) << "\n";
  file_.flush();
  
  ROS_INFO("✓ Experiment ended - Time: %.1fs, Distance: %.2fm, Completion: %.2f%%, Frontiers: %d",
           total_time_sec, total_distance_m, final_completion_percent, frontiers_visited);
}

void ExperimentLogger::flush() {
  std::lock_guard<std::mutex> lk(mtx_);
  if (file_.is_open()) file_.flush();
}

} // namespace explore
