    /*********************************************************************
    *
    * Software License Agreement (BSD License)
    *
    *  Copyright (c) 2008, Robert Bosch LLC.
    *  Copyright (c) 2015-2016, Jiri Horner.
    *  All rights reserved.
    *
    *  Redistribution and use in source and binary forms, with or without
    *  modification, are permitted provided that the following conditions
    *  are met:
    *
    *   * Redistributions of source code must retain the above copyright
    *     notice, this list of conditions and the following disclaimer.
    *   * Redistributions in binary form must reproduce the above
    *     copyright notice, this list of conditions and the following
    *     disclaimer in the documentation and/or other materials provided
    *     with the distribution.
    *   * Neither the name of the Jiri Horner nor the names of its
    *     contributors may be used to endorse or promote products derived
    *     from this software without specific prior written permission.
    *
    *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
    *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
    *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
    *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
    *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
    *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
    *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
    *  POSSIBILITY OF SUCH DAMAGE.
    *
    *********************************************************************/

    #include <explore/explore.h>



    #include <thread>
    #include <iostream> 
    #include <opencv2/opencv.hpp> 
    #include <ctime>
    #include <iostream>
    #include <fstream>
    #include <std_msgs/Int32.h>
    #include <chrono>
    #include <geometry_msgs/PoseArray.h>
    #include <cmath>

    #include <atomic>
    #include <iomanip>
    #include <sstream>
    #include <cstdlib>
    #include <regex>
    #include <boost/filesystem.hpp>
    namespace fs = boost::filesystem;

    #include <yaml-cpp/yaml.h>
    #include <costmap_2d/cost_values.h>  // FREE_SPACE, LETHAL_OBSTACLE, NO_INFORMATION

    #include <limits> //(NaN kontrolü için)




    using namespace cv; 
    using namespace std; 

    #include <ctime>

    clock_t beginClock, endClock;



    inline static bool operator==(const geometry_msgs::Point& one,
                                const geometry_msgs::Point& two)
    {
    double dx = one.x - two.x;
    double dy = one.y - two.y;
    double dist = sqrt(dx * dx + dy * dy);
    return dist < 0.01;
    }

    namespace explore
    {

            Explore::Explore()
                : private_nh_("~")
                , tf_listener_(ros::Duration(10.0))
                , costmap_client_(private_nh_, relative_nh_, &tf_listener_)  
                , move_base_client_("move_base")  // Initialize here with hardcoded name
                , prev_distance_(0.0) 
                , last_markers_count_(0)
                ,  last_roi_markers_count_(0)
                , last_text_markers_count_(0)
                , fallback_attempt_count_(0) 
                , fallback_attempted_(false)
                , fallback_current_index_(0)
                , fallback_session_count_(0)              
                , fallback_current_session_attempts_(0)  
                , ring_initialized_(false)
            {
                
                private_nh_.param("planner_frequency", planner_frequency_, 1.0);
                private_nh_.param("progress_timeout", timeout, 60.0); // default = 30.0
                progress_timeout_ = ros::Duration(timeout);
                private_nh_.param("visualize", visualize_, true);
                private_nh_.param("potential_scale", potential_scale_, 1e-3);
                private_nh_.param("orientation_scale", orientation_scale_, 0.0);
                private_nh_.param("gain_scale", gain_scale_, 1.0);
                private_nh_.param("min_frontier_size", min_frontier_size, 0.5);
                private_nh_.param("with_map_completion", with_map_completion, 0);
                private_nh_.param<std::string>("distance_method", distance_method, std::string("euclidean"));
                private_nh_.param("validate_with_makeplan", validate_with_makeplan_, false);
                private_nh_.param("publish_maps", publish_maps_, true);
                private_nh_.param("gt_image_path", gt_image_path_, std::string(""));
                private_nh_.param("gt_dir", gt_dir_, std::string(""));

                private_nh_.param("use_completed_map", use_completed_map_, 1);
                private_nh_.param("use_closed_live_map", use_closed_live_map_, 1);
                private_nh_.param("use_closing", use_closing_, 1);
                private_nh_.param("use_clustering", use_clustering_, 1);
                private_nh_.param("use_filtering", use_filtering_, 1);
                

                // ---- GT görüntü & referans koordinatları ----  
                
                private_nh_.param("gt_origin_x", gt_origin_x_, -26.0);     
                private_nh_.param("gt_origin_y", gt_origin_y_, -26.0);     
                private_nh_.param("gt_resolution", gt_resolution_, 0.1);  
                private_nh_.param("rect_size", rect_size_, 32);
                

                private_nh_.param("completion_known_scale", completion_known_scale_, 1.0);  
                private_nh_.param("completion_obstacle_scale", completion_obstacle_scale_, 0.5);


                private_nh_.param("prefer_preflight_astar", prefer_preflight_astar_, true);
                private_nh_.param("preflight_max_stretch",  preflight_max_stretch_,  2.2);
                private_nh_.param("preflight_min_cap_m",    preflight_min_cap_m_,    3.0);
                private_nh_.param("preflight_max_radius_m", preflight_max_radius_m_, 12.0);
                private_nh_.param("door_threshold_m",       door_threshold_m_,       0.70);

                private_nh_.param("room_behind_wall_scale", room_behind_wall_scale_, 5.0);
                private_nh_.param("barrier_penalty_scale", barrier_penalty_scale_, 2.0);
                private_nh_.param("frontier_on_obstacle_penalty_scale", frontier_on_obstacle_penalty_scale_, 0.3);

                private_nh_.param("obstacle_distance_threshold", obstacle_distance_threshold_, 0.3);
                private_nh_.param("publish_closed_live_map", publish_closed_live_map_, true);

                private_nh_.param("gt_fine_dx", fine_dx, 0.0);
                private_nh_.param("gt_fine_dy", fine_dy, 0.0);

                private_nh_.param("alignment_search_radius", alignment_search_radius, 5.0);
                private_nh_.param("alignment_min_score", alignment_min_score, 0.3);
                private_nh_.param("alignment_min_pixels", alignment_min_pixels, 20);
                private_nh_.param("realignment_period", realignment_period, 30.0);
                

                // Logging parametreleri
                private_nh_.param("log_metrics_enabled", log_metrics_enabled_, true);
                private_nh_.param("log_operations_enabled", log_operations_enabled_, true);
                private_nh_.param("metrics_log_interval", metrics_log_interval_, 5.0); // 5 saniyede bir

                private_nh_.param("noise_in_room_threshold", noise_in_room_threshold_, 0.6);
                private_nh_.param("check_distance", check_distance_, 0.4);
                private_nh_.param("interior_noise_min_length", interior_noise_min_length_, 0.15);
                private_nh_.param("interior_noise_max_length", interior_noise_max_length_, 0.40);
                private_nh_.param("interior_noise_agreement_ratio", interior_noise_agreement_ratio_, 0.80);
                private_nh_.param("interior_noise_max_obstacle_ratio", interior_noise_max_obstacle_ratio_, 0.08);

                private_nh_.param("exterior_noise_min_length", exterior_noise_min_length_, 0.15);
                private_nh_.param("exterior_noise_max_thickness_cells", exterior_noise_max_thickness_cells_, 2);
                private_nh_.param("exterior_noise_unknown_lookahead_m", exterior_noise_unknown_lookahead_m_, 0.6);
                private_nh_.param("exterior_noise_wall_search_m", exterior_noise_wall_search_m_, 0.6);
                private_nh_.param("exterior_noise_agree_ratio", exterior_noise_agree_ratio_, 0.4);
                private_nh_.param("exterior_noise_island_radius_m", exterior_noise_island_radius_m_, 0.5);
                private_nh_.param("exterior_noise_island_cells_max", exterior_noise_island_cells_max_, 25);

                private_nh_.param("trapped_max_traversable_gap_m", trapped_max_traversable_gap_m_, 0.35);
                private_nh_.param("trapped_wall_detect_range_m", trapped_wall_detect_range_m_, 0.6);
                private_nh_.param("trapped_min_obstacle_ratio", trapped_min_obstacle_ratio_, 0.6);
                private_nh_.param("trapped_min_samples_agree", trapped_min_samples_agree_, 0.7);
                private_nh_.param("trapped_min_frontier_length", trapped_min_frontier_length_, 0.15);
                private_nh_.param("trapped_max_frontier_length", trapped_max_frontier_length_, 1.5);

                private_nh_.param("bridge_min_length", bridge_min_length_, 0.12);
                private_nh_.param("bridge_max_thickness_per_side_m", bridge_max_thickness_per_side_m_, 0.10);
                private_nh_.param("bridge_wall_search_m", bridge_wall_search_m_, 0.6);
                private_nh_.param("bridge_min_unknown_ratio_per_side", bridge_min_unknown_ratio_per_side_, 0.65);
                private_nh_.param("bridge_min_thin_ratio", bridge_min_thin_ratio_, 0.70);
                private_nh_.param("bridge_min_unknown_ratio", bridge_min_unknown_ratio_, 0.70);
                private_nh_.param("bridge_unknown_lookahead_m", bridge_unknown_lookahead_m_, 0.4);
                private_nh_.param("bridge_max_island_cells", bridge_max_island_cells_, 30);

                private_nh_.param("corner_max_frontier_length", corner_max_frontier_length_, 0.35);
                private_nh_.param("corner_max_unknown_depth", corner_max_unknown_depth_, 0.30);
                private_nh_.param("corner_max_unknown_volume", corner_max_unknown_volume_, 0.08);
                private_nh_.param("corner_min_wall_coverage", corner_min_wall_coverage_, 0.60);
                private_nh_.param("corner_angle_threshold", corner_angle_threshold_, 120.0);
                private_nh_.param("corner_min_confidence", corner_min_confidence_, 0.65);
                private_nh_.param("corner_wall_search_distance", corner_wall_search_distance_, 0.25);
                private_nh_.param("corner_min_pocket_depth", corner_min_pocket_depth_, 0.05);


                private_nh_.param("direction_consistency_weight", direction_consistency_weight_, 0.6);
                private_nh_.param("cluster_distance_threshold", cluster_distance_threshold_, 2.0);
                private_nh_.param("bucket_size_m", bucket_size_m_, 15.0);

                private_nh_.param("ring_radius", ring_radius_, 10.0);

               
                // Başlangıç değerleri
                total_distance_traveled_ = 0.0;
                last_robot_position_.x = 0.0;
                last_robot_position_.y = 0.0;
                last_robot_position_.z = 0.0;

                last_progress_ = ros::Time::now();
                prev_goal_.x = 0;
                prev_goal_.y = 0;
                prev_goal_.z = 0;

                // ═══════════════════════════════════════════════════════════════
                // EXTRACT ENVIRONMENT NAME FROM GT_DIR (for log filename)
                // ═══════════════════════════════════════════════════════════════
                std::string env_name = "unknown";
                if (!gt_dir_.empty() && boost::filesystem::exists(gt_dir_)) {
                    // Find PGM file in directory
                    for (boost::filesystem::directory_iterator it(gt_dir_), end; it != end; ++it) {
                        std::string ext = it->path().extension().string();
                        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
                        
                        if (ext == ".pgm") {
                            env_name = it->path().stem().string();  // "4bb7447766005e95922e3d51c4a5b6fa"
                            ROS_INFO("Environment name for logging: %s", env_name.c_str());
                            break;  // First PGM found
                        }
                    }
                }

                // Logger oluştur
                if (log_metrics_enabled_ || log_operations_enabled_) {
                    const char* base_dir = std::getenv("EXPLORATION_LOG_DIR");
                    if (!base_dir) base_dir = std::getenv("HOME");
                    if (!base_dir) base_dir = "/tmp";
                    
                    std::string log_dir = std::string(base_dir) + "/exploration_logs";
                    boost::filesystem::create_directories(log_dir);
                    
                    // CREATE LOG FILENAME WITH ENVIRONMENT NAME
                    auto now = std::chrono::system_clock::now();
                    auto now_c = std::chrono::system_clock::to_time_t(now);
                    std::stringstream log_filename;
                    log_filename << log_dir << "/" << env_name << "_";  // ← env_name BAŞTA!

                    log_filename << distance_method 
                                    << "_use" << use_completed_map_ 
                                    << "_with" << with_map_completion 
                                    << "_live" << use_closed_live_map_ 
                                    << "_closing" << use_closing_ 
                                    << "_clustering" << use_clustering_
                                    << "_filtering" << use_filtering_
                                    << "_"
                                    << std::put_time(std::localtime(&now_c), "%Y%m%d_%H%M%S") << ".csv";

                    experiment_logger_ = std::make_unique<ExperimentLogger>(log_filename.str());
                    ROS_INFO("✓ Unified logger initialized: %s", log_filename.str().c_str());
                    
                    experiment_logger_->logExperimentStart(distance_method);
                    
                    // Milestones
                    completion_milestones_.clear();
                    reached_milestones_.clear();
                    for (int p = 5; p <= 50; p += 5) completion_milestones_.push_back(p);
                    for (int p = 55; p <= 90; p += 5) completion_milestones_.push_back(p);
                    for (int p = 92; p <= 100; p += 2) completion_milestones_.push_back(p);
                }

                

                //ROS_INFO("rect_size param = %d", rect_size_);


                is_in_fallback_active_ = false;
                
                search_ = std::make_unique<frontier_exploration::FrontierSearch>(costmap_client_.getCostmap(),
                                                            potential_scale_, 
                                                            gain_scale_,
                                                            min_frontier_size,
                                                            distance_method,
                                                            rect_size_,
                                                            completion_known_scale_,
                                                            completion_obstacle_scale_,
                                                            obstacle_distance_threshold_,
                                                            door_threshold_m_,
                                                            use_completed_map_,
                                                            use_closed_live_map_,
                                                            use_closing_,
                                                            use_filtering_,
                                                            use_clustering_,
                                                            room_behind_wall_scale_,
                                                            barrier_penalty_scale_,
                                                            frontier_on_obstacle_penalty_scale_,
                                                            check_distance_,
                                                            experiment_logger_,
                                                            with_map_completion,
                                                            noise_in_room_threshold_,
                                                            direction_consistency_weight_,
                                                            cluster_distance_threshold_,
                                                            interior_noise_min_length_,           
                                                            interior_noise_max_length_,           
                                                            interior_noise_agreement_ratio_,      
                                                            interior_noise_max_obstacle_ratio_,
                                                            exterior_noise_min_length_,
                                                            exterior_noise_max_thickness_cells_,
                                                            exterior_noise_unknown_lookahead_m_,
                                                            exterior_noise_wall_search_m_,
                                                            exterior_noise_agree_ratio_,
                                                            exterior_noise_island_radius_m_,
                                                            exterior_noise_island_cells_max_,
                                                            trapped_max_traversable_gap_m_,
                                                            trapped_wall_detect_range_m_,
                                                            trapped_min_obstacle_ratio_,
                                                            trapped_min_samples_agree_,
                                                            trapped_min_frontier_length_,
                                                            trapped_max_frontier_length_,
                                                            bridge_min_length_,
                                                            bridge_max_thickness_per_side_m_,
                                                            bridge_wall_search_m_,
                                                            bridge_min_unknown_ratio_per_side_,
                                                            bridge_min_thin_ratio_,
                                                            bridge_min_unknown_ratio_,
                                                            bridge_unknown_lookahead_m_,
                                                            bridge_max_island_cells_,
                                                            corner_max_frontier_length_,
                                                            corner_max_unknown_depth_,
                                                            corner_max_unknown_volume_,
                                                            corner_min_wall_coverage_,
                                                            corner_angle_threshold_,
                                                            corner_min_confidence_,
                                                            corner_wall_search_distance_,
                                                            corner_min_pocket_depth_ );

                
                                                            search_->setRectSize(rect_size_);  // <- zinciri senkronla

                has_active_target_ = false;
                target_start_distance_ = 0.0;

                // Metrics timer başlat
                if (log_metrics_enabled_) {
                    exploration_start_time_ = ros::Time::now();


                    

                    metrics_timer_ = private_nh_.createTimer(
                        ros::Duration(metrics_log_interval_),
                        &Explore::metricsTimerCallback, this);
                    //ROS_INFO("Metrics logging enabled with interval: %.1f seconds", metrics_log_interval_);
                }

                //ROS_INFO("Explore: rect_size param = %d (propagated to FrontierSearch)", search_->getRectSize());

                last_roi_markers_count_=0;



                // ═══════════════════════════════════════════════════════════════
                // LOAD FULL GT ONCE IN CONSTRUCTOR
                // ═══════════════════════════════════════════════════════════════
                full_gt_loaded_ = false;

                if (!gt_dir_.empty() && boost::filesystem::exists(gt_dir_)) {
                    // Find PGM and YAML files
                    std::string pgm_file, yaml_file;
                    
                    for (boost::filesystem::directory_iterator it(gt_dir_), end; it != end; ++it) {
                        std::string ext = it->path().extension().string();
                        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
                        
                        if (ext == ".pgm") pgm_file = it->path().string();
                        else if (ext == ".yaml") yaml_file = it->path().string();
                    }
                    
                    if (!pgm_file.empty()) {
                        // Load FULL GT image
                        full_gt_image_ = cv::imread(pgm_file, cv::IMREAD_GRAYSCALE);
                        
                        if (!full_gt_image_.empty()) {
                            // Read YAML metadata
                            full_gt_origin_x_ = gt_origin_x_;  // Default from launch file
                            full_gt_origin_y_ = gt_origin_y_;
                            full_gt_resolution_ = gt_resolution_;
                            
                            if (!yaml_file.empty() && boost::filesystem::exists(yaml_file)) {
                                try {
                                    YAML::Node yaml_doc = YAML::LoadFile(yaml_file);
                                    
                                    if (yaml_doc["resolution"]) {
                                        full_gt_resolution_ = yaml_doc["resolution"].as<double>();
                                    }
                                    
                                    if (yaml_doc["origin"] && yaml_doc["origin"].IsSequence() && 
                                        yaml_doc["origin"].size() >= 2) {
                                        full_gt_origin_x_ = yaml_doc["origin"][0].as<double>();
                                        full_gt_origin_y_ = yaml_doc["origin"][1].as<double>();
                                    }
                                } catch (...) {
                                    ROS_WARN("Failed to parse GT YAML, using launch file params");
                                }
                            }
                            
                            full_gt_loaded_ = true;
                            ROS_INFO("✓ Full GT loaded ONCE: %dx%d, origin=(%.3f, %.3f), res=%.4f",
                                    full_gt_image_.cols, full_gt_image_.rows,
                                    full_gt_origin_x_, full_gt_origin_y_, full_gt_resolution_);
                        }
                    }
                }



                dc_.setCostmap(costmap_client_.getCostmap());                 
                dc_.setGlobalFrame(costmap_client_.getGlobalFrameID());   
             


                if (visualize_) {
                    marker_array_publisher_ =
                        private_nh_.advertise<visualization_msgs::MarkerArray>("/frontiers", 10);
                }
                

                exploration_finished_pub_ = private_nh_.advertise<std_msgs::Int32>("exploration_finished", 10);
                
                

                completed_pub_ = private_nh_.advertise<nav_msgs::OccupancyGrid>("/completed_map", 1, /*latch=*/true);
                closed_live_pub_ = private_nh_.advertise<nav_msgs::OccupancyGrid>("/closed_live_map", 1, /*latch=*/true);
                gt_map_pub_ = private_nh_.advertise<nav_msgs::OccupancyGrid>("/gt_map", 1, /*latch=*/true);
                processed_map_pub_ = private_nh_.advertise<nav_msgs::OccupancyGrid>("/processed_map", 1, true); // latched

                if (publish_maps_) {
                    // costmap boyutlarında matrisleri hazırla (boşsa)
                    // if(use_completed_map_)
                    // {
                    //     search_->seedCompletedMapFromCostmap();
                    // }

                    if(use_closed_live_map_)
                    {
                        search_->seedClosedLiveMapFromCostmap();
                    }
                          
                    publishMaps();
                }

                
                //ROS_INFO("Waiting to connect to move_base server");
                move_base_client_.waitForServer();
                //ROS_INFO("Connected to move_base server");

                // In the Explore constructor and makePlan(), add:
                const unsigned int W = costmap_client_.getCostmap()->getSizeInCellsX();
                const unsigned int H = costmap_client_.getCostmap()->getSizeInCellsY();
            
                // Explore constructor içinde
                make_plan_client_ = private_nh_.serviceClient<nav_msgs::GetPlan>("/move_base/make_plan");

                exploring_timer_ =
                    relative_nh_.createTimer(ros::Duration(1. / planner_frequency_),
                                            [this](const ros::TimerEvent&) { 
                                            makePlan(); 
                                            });



            }


            Explore::~Explore()
            {
                // Log experiment end before cleanup
                if (experiment_logger_) {
                    double elapsed_sec = (ros::Time::now() - exploration_start_time_).toSec();
                    double completion = calculateExplorationProgress();
                    experiment_logger_->logExperimentEnd(
                        elapsed_sec,
                        total_distance_traveled_,
                        completion,
                        frontier_switch_count_,
                        progress_timeout_count_
                    );
                }


                try {
                    stop();
                    
                    // Clean up timers
                    oneshot_.stop();
                    exploring_timer_.stop();
                    
                    // Clear blacklist to free memory
                    frontier_blacklist_.clear();
                    frontier_blacklist_.shrink_to_fit();
                    

                    move_base_client_.cancelAllGoals();
                    if (visualize_) {
                        deleteAllFrontierMarkers();
                    }

                    ROS_WARN("Waiting 10s - check RViz now!");
                    ros::Duration(10.0).sleep();
                    
                } catch (const std::exception& e) {
                    //ROS_ERROR("Exception in Explore destructor: %s", e.what());
                } catch (...) {
                    //ROS_ERROR("Unknown exception in Explore destructor");
                }
            }


            bool isSamePoint(const geometry_msgs::Point& p1, const geometry_msgs::Point& p2, double tolerance = 1e-3) 
            {
                return (std::abs(p1.x - p2.x) < tolerance &&
                        std::abs(p1.y - p2.y) < tolerance &&
                        std::abs(p1.z - p2.z) < tolerance);
            }

         

            void Explore::visualizeFrontiers(const std::vector<frontier_exploration::Frontier>& frontiers,
                                 geometry_msgs::Point target_position)
            {
                visualization_msgs::MarkerArray markers;
                
                // Tüm önceki marker'ları sil
                visualization_msgs::Marker delete_marker;
                delete_marker.header.frame_id = costmap_client_.getGlobalFrameID();
                delete_marker.header.stamp = ros::Time::now();
                delete_marker.ns = "exploration_markers"; 
                delete_marker.action = visualization_msgs::Marker::DELETEALL;
                markers.markers.push_back(delete_marker);
                
                int marker_id = 0;

                // Frontier'ları görselleştir
                for (const auto& f : frontiers) {
                    bool in_ring = false;
                    bool is_partial = false;
                    std::vector<geometry_msgs::Point> samples_in_ring;
                    
                    // Bu frontier seçilmiş mi kontrol et
                    bool is_selected = false;
                    if (is_partial) {
                        for (const auto& p : samples_in_ring) {
                            if (std::hypot(p.x - target_position.x, p.y - target_position.y) < 0.3) {
                                is_selected = true;
                                break;
                            }
                        }
                    } else {
                        is_selected = (std::hypot(f.safest_point.x - target_position.x, 
                                                f.safest_point.y - target_position.y) < 0.3);
                    }

                    // 1. SAFEST_POINT (her frontier için)
                    visualization_msgs::Marker m;
                    m.header.frame_id = costmap_client_.getGlobalFrameID();
                    m.header.stamp = ros::Time::now();
                    m.ns = "exploration_markers";
                    m.id = marker_id++;
                    m.type = visualization_msgs::Marker::SPHERE;
                    m.action = visualization_msgs::Marker::ADD;
                    m.pose.position = f.safest_point;
                    m.pose.orientation.w = 1.0;

                    if (f.too_close_to_obstacle || goalOnBlacklist(f.safest_point)) {
                        // Blacklist
                        m.scale.x = m.scale.y = m.scale.z = in_ring ? 0.35 : 0.25;
                        if (is_selected) {
                            m.color.r = 0.0; m.color.g = 0.0; m.color.b = 1.0;  // MAVİ
                            m.color.a = 1.0;
                        } else {
                            m.color.r = 1.0; m.color.g = 0.0; m.color.b = 0.0;  // KIRMIZI
                            m.color.a = in_ring ? 0.9 : 0.5;
                        }
                    } else {
                        // Normal
                        m.scale.x = m.scale.y = m.scale.z = in_ring ? 0.35 : 0.25;
                        if (is_selected) {
                            m.color.r = 0.0; m.color.g = 1.0; m.color.b = 1.0;  // TURKUAZ
                            m.color.a = 1.0;
                        } else {
                            m.color.r = 0.0; m.color.g = 1.0; m.color.b = 0.0;  // YEŞİL
                            m.color.a = in_ring ? 1.0 : 0.6;
                        }
                    }
                    markers.markers.push_back(m);

                    // 2. SAMPLE POINTS (sadece partial frontier'larda)
                    if (is_partial && !samples_in_ring.empty()) {
                        for (const auto& sample : samples_in_ring) {
                            if (is_selected) {
                                // TURKUAZ border
                                visualization_msgs::Marker border;
                                border.header.frame_id = costmap_client_.getGlobalFrameID();
                                border.header.stamp = ros::Time::now();
                                border.ns = "exploration_markers";
                                border.id = marker_id++;
                                border.type = visualization_msgs::Marker::SPHERE;
                                border.action = visualization_msgs::Marker::ADD;
                                border.pose.position = sample;
                                border.pose.orientation.w = 1.0;
                                border.scale.x = border.scale.y = border.scale.z = 0.25;
                                border.color.r = 0.0; border.color.g = 1.0; border.color.b = 1.0;
                                border.color.a = 0.6;
                                markers.markers.push_back(border);
                                
                                // SARI merkez
                                visualization_msgs::Marker core;
                                core.header.frame_id = costmap_client_.getGlobalFrameID();
                                core.header.stamp = ros::Time::now();
                                core.ns = "exploration_markers";
                                core.id = marker_id++;
                                core.type = visualization_msgs::Marker::SPHERE;
                                core.action = visualization_msgs::Marker::ADD;
                                core.pose.position = sample;
                                core.pose.orientation.w = 1.0;
                                core.scale.x = core.scale.y = core.scale.z = 0.15;
                                core.color.r = 1.0; core.color.g = 1.0; core.color.b = 0.0;
                                core.color.a = 1.0;
                                markers.markers.push_back(core);
                            } else {
                                // SARI
                                visualization_msgs::Marker sm;
                                sm.header.frame_id = costmap_client_.getGlobalFrameID();
                                sm.header.stamp = ros::Time::now();
                                sm.ns = "exploration_markers";
                                sm.id = marker_id++;
                                sm.type = visualization_msgs::Marker::SPHERE;
                                sm.action = visualization_msgs::Marker::ADD;
                                sm.pose.position = sample;
                                sm.pose.orientation.w = 1.0;
                                sm.scale.x = sm.scale.y = sm.scale.z = 0.2;
                                sm.color.r = 1.0; sm.color.g = 1.0; sm.color.b = 0.0;
                                sm.color.a = 0.8;
                                markers.markers.push_back(sm);
                            }
                        }
                    }
                }
                
                // TARGET marker - CYAN
                visualization_msgs::Marker t;
                t.header.frame_id = costmap_client_.getGlobalFrameID();
                t.header.stamp = ros::Time::now();
                t.ns = "exploration_markers";
                t.id = 9999; 
                t.type = visualization_msgs::Marker::SPHERE;
                t.action = visualization_msgs::Marker::ADD;
                t.pose.position = target_position;
                t.pose.orientation.w = 1.0;
                t.scale.x = t.scale.y = t.scale.z = 0.5;
                t.color.r = 0.0; t.color.g = 1.0; t.color.b = 1.0; t.color.a = 1.0;
                markers.markers.push_back(t);

                if (marker_array_publisher_) marker_array_publisher_.publish(markers);
            }

            void Explore::deleteAllFrontierMarkers()
            {
                visualization_msgs::MarkerArray markers;
                
                // Delete all namespaces
                std::vector<std::string> namespaces = {
                    "frontiers",
                    "safest_points",
                    "cluster_centers",
                    "cluster_text",
                    "fallback_status"
                };
                
                for (const auto& ns : namespaces) {
                    visualization_msgs::Marker delete_marker;
                    delete_marker.header.frame_id = costmap_client_.getGlobalFrameID();
                    delete_marker.header.stamp = ros::Time::now();
                    delete_marker.ns = ns;
                    delete_marker.action = visualization_msgs::Marker::DELETEALL;
                    markers.markers.push_back(delete_marker);
                }
                
                if (marker_array_publisher_) {
                    marker_array_publisher_.publish(markers);
                }
                
                last_markers_count_ = 0;
            }


            bool Explore::loadBestGTFromDir(int cur_W, int cur_H, double cur_res)
            {
                // --- Costmap origin and parameters ---
                auto* cm = costmap_client_.getCostmap();
                const double cur_origin_x = cm->getOriginX();
                const double cur_origin_y = cm->getOriginY();

                if (gt_dir_.empty() || !fs::exists(gt_dir_)) {
                    ROS_WARN("gt_dir is empty or does not exist: %s", gt_dir_.c_str());
                    return false;
                }

                // ═══════════════════════════════════════════════════════════════
                // SIMPLIFIED: Find the single PGM file in directory
                // ═══════════════════════════════════════════════════════════════
                std::string pgm_file;
                std::string yaml_file;
                
                for (fs::directory_iterator it(gt_dir_), end; it != end; ++it) {
                    std::string ext = it->path().extension().string();
                    std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
                    
                    if (ext == ".pgm") {
                        pgm_file = it->path().string();
                    } else if (ext == ".yaml") {
                        yaml_file = it->path().string();
                    }
                }
                
                if (pgm_file.empty()) {
                    ROS_ERROR("No PGM file found in: %s", gt_dir_.c_str());
                    return false;
                }

                // ═══════════════════════════════════════════════════════════════
                // Load image
                // ═══════════════════════════════════════════════════════════════
                cv::Mat img = cv::imread(pgm_file, cv::IMREAD_GRAYSCALE);
                if (img.empty()) {
                    ROS_ERROR("Failed to load GT image: %s", pgm_file.c_str());
                    return false;
                }

                // ═══════════════════════════════════════════════════════════════
                // Read YAML metadata if exists
                // ═══════════════════════════════════════════════════════════════
                double ox = 0.0, oy = 0.0, res = cur_res;
                double theta = 0.0;
                bool has_yaml = false;
                
                if (!yaml_file.empty() && fs::exists(yaml_file)) {
                    try {
                        YAML::Node n = YAML::LoadFile(yaml_file);
                        
                        if (n["resolution"]) {
                            res = n["resolution"].as<double>();
                        }
                        
                        if (n["origin"] && n["origin"].IsSequence() && n["origin"].size() >= 2) {
                            ox = n["origin"][0].as<double>();
                            oy = n["origin"][1].as<double>();
                            if (n["origin"].size() >= 3 && n["origin"][2].IsScalar()) {
                                try { theta = n["origin"][2].as<double>(); } catch (...) { theta = 0.0; }
                            }
                        }
                        
                        has_yaml = true;
                    } catch (...) {
                        ROS_WARN("Failed to parse YAML: %s, using defaults", yaml_file.c_str());
                    }
                }

                // ═══════════════════════════════════════════════════════════════
                // AFFINE TRANSFORM - EXACT SAME AS BEFORE
                // ═══════════════════════════════════════════════════════════════
                const int W_orig = img.cols, H_orig = img.rows;
                
                // Resolution scale factor
                const double scale = cur_res / res;
                
                // Flip GT on Y-axis (ROS->OpenCV conversion)
                cv::Mat flipped;
                cv::flip(img, flipped, 0);
                
                // Create affine transform matrix
                cv::Mat M = cv::Mat::zeros(2, 3, CV_64F);
                
                // Scale component
                M.at<double>(0, 0) = scale;
                M.at<double>(1, 1) = scale;
                
                // Translation component
                double world_dx = -cur_origin_x + ox;
                double world_dy = cur_origin_y - oy;
                
                double pixel_tx = world_dx / cur_res;
                double pixel_ty = world_dy / cur_res;

                // Apply fine-tuning parameters
                pixel_tx += fine_dx;
                pixel_ty -= fine_dy;
                
                M.at<double>(0, 2) = pixel_tx;
                M.at<double>(1, 2) = -pixel_ty;
                
                // Apply transform
                cv::Mat aligned;
                cv::warpAffine(flipped, aligned, M, cv::Size(cur_W, cur_H), 
                            cv::INTER_NEAREST,
                            cv::BORDER_CONSTANT,
                            cv::Scalar(205));
                
                // Flip back (OpenCV->ROS)
                cv::flip(aligned, gt_image_raw_, 0);
                
                // Update metadata - use COSTMAP parameters
                gt_origin_x_ = cur_origin_x;
                gt_origin_y_ = cur_origin_y;
                gt_resolution_ = cur_res;
                
                return true;
            }

           
            
            // Helper: Check if target is reachable (no obstacles in straight line)
            bool Explore::isReachable(const geometry_msgs::Point& from, const geometry_msgs::Point& to) 
            {
                costmap_2d::Costmap2D* cm = costmap_client_.getCostmap();
                if (!cm) return false;
                
                unsigned int x0, y0, x1, y1;
                if (!cm->worldToMap(from.x, from.y, x0, y0)) return false;
                if (!cm->worldToMap(to.x, to.y, x1, y1)) return false;
                
                // Bresenham algoritması başlangıcı
                int dx = abs((int)x1 - (int)x0);
                int dy = abs((int)y1 - (int)y0);
                int sx = x0 < x1 ? 1 : -1;
                int sy = y0 < y1 ? 1 : -1;
                int err = dx - dy;
                
                unsigned int x = x0, y = y0;
                while (true) {
                    unsigned char cost = cm->getCost(x, y);
                    
                    // KRİTİK DÜZELTME: Sadece 254 (duvar) değil, 
                    // 253 (robotun sığamayacağı kadar yakın alan) kontrol edilmeli.
                    if (cost >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                        return false; // Doğrudan bir engel var veya yol çok dar
                    }
                    
                    if (x == x1 && y == y1) break;
                    
                    int e2 = 2 * err;
                    if (e2 > -dy) { err -= dy; x += sx; }
                    if (e2 < dx) { err += dx; y += sy; }
                }
                
                return true; // Yol temiz (Görüş hattı açık)
            }

           

            void Explore::doneMovingCallback(const actionlib::SimpleClientGoalState& state, 
                                const move_base_msgs::MoveBaseResultConstPtr& result)
            {
                has_active_target_ = false;  // ✅ Hedef tamamlandı (başarılı veya başarısız)
                
                if (state == actionlib::SimpleClientGoalState::ABORTED ||
                    state == actionlib::SimpleClientGoalState::REJECTED)
                {
                    // Başarısız hedefi blacklist'e ekle
                    if (!goalOnBlacklist(current_target_)) {
                        frontier_blacklist_.push_back(
                            BlacklistEntry(current_target_, BlacklistReason::GOAL_ABORTED, 1.0));
                        
                        ROS_WARN("❌ Navigation ABORTED for goal (%.2f, %.2f), added to blacklist as GOAL_ABORTED (total: %zu)",
                                current_target_.x, current_target_.y, frontier_blacklist_.size());
                    } else {
                        ROS_WARN("❌ Navigation ABORTED for goal (%.2f, %.2f), already in blacklist",
                                current_target_.x, current_target_.y);
                    }
                }
                
                if (state == actionlib::SimpleClientGoalState::SUCCEEDED)
                {
                    ROS_DEBUG("✅ Navigation goal succeeded at (%.2f, %.2f)", 
                            current_target_.x, current_target_.y);
                }
                
                scheduleReplan();
            }

          

            std::string Explore::reasonToString(BlacklistReason reason) const {
                switch (reason) {
                    case BlacklistReason::PREFLIGHT_FAILED:         return "PREFLIGHT_FAILED";
                    case BlacklistReason::PATHFINDING_FAILED:       return "PATHFINDING_FAILED";
                    case BlacklistReason::MAKEPLAN_SERVICE_FAILED:  return "MAKEPLAN_SERVICE_FAILED";
                    case BlacklistReason::EXCESSIVE_DETOUR:         return "EXCESSIVE_DETOUR";
                    case BlacklistReason::TARGET_ON_WALL:           return "TARGET_ON_WALL";
                    case BlacklistReason::OUTSIDE_MAP_BOUNDS:       return "OUTSIDE_MAP_BOUNDS";
                    case BlacklistReason::BEYOND_WALL_ARTIFACT:     return "BEYOND_WALL_ARTIFACT";
                    case BlacklistReason::ARTIFICIAL_AREA:          return "ARTIFICIAL_AREA";
                    case BlacklistReason::GOAL_ABORTED:             return "GOAL_ABORTED";
                    case BlacklistReason::PROGRESS_TIMEOUT:         return "PROGRESS_TIMEOUT";
                    case BlacklistReason::NEAR_WALL:                return "NEAR_WALL";
                    case BlacklistReason::TOO_SMALL:                return "TOO_SMALL";
                    case BlacklistReason::USER_DEFINED:             return "USER_DEFINED";
                    case BlacklistReason::PERMANENTLY_UNREACHABLE:  return "PERMANENTLY_UNREACHABLE";
                    default:                                        return "UNKNOWN_REASON";
                }
            }

            // explore.cpp dosyasına, sınıfın diğer metodlarının yanına ekle
            void Explore::addToBlacklist(const geometry_msgs::Point& goal,
                                BlacklistReason reason,
                                double confidence)
            {
                // Koordinat geçersiz mi kontrol et (önceki kodlarından esinlenerek)
                if (!isValidCoordinate(goal.x, goal.y)) {
                    ROS_WARN("Invalid coordinate for blacklist: (%.2f, %.2f)", goal.x, goal.y);
                    return;
                }

                // Aynı pozisyonda zaten var mı? (duplicate önleme)
                for (const auto& entry : frontier_blacklist_) {
                    if (std::hypot(entry.position.x - goal.x, entry.position.y - goal.y) < 0.1 &&
                        entry.reason == reason) {
                        ROS_DEBUG("Duplicate blacklist entry skipped: (%.2f, %.2f)", goal.x, goal.y);
                        return;
                    }
                }

                // Yeni entry ekle
                BlacklistEntry new_entry(goal, reason, confidence);
                frontier_blacklist_.push_back(new_entry);

                // Blacklist boyutu sınırı (mevcut kodundan)
                cleanupBlacklist();

                ROS_DEBUG("Added to blacklist: (%.2f, %.2f), reason=%s, conf=%.2f",
                        goal.x, goal.y, reasonToString(reason).c_str(), confidence);
            }

           

            



            // Line segment intersection helper
            bool Explore::lineSegmentIntersection(
                double x1, double y1, double x2, double y2,  // Segment 1
                double x3, double y3, double x4, double y4,  // Segment 2
                geometry_msgs::Point& intersection)
            {
                double denom = (x1-x2)*(y3-y4) - (y1-y2)*(x3-x4);
                if (std::abs(denom) < 1e-10) return false;  // Parallel
                
                double t = ((x1-x3)*(y3-y4) - (y1-y3)*(x3-x4)) / denom;
                double u = -((x1-x2)*(y1-y3) - (y1-y2)*(x1-x3)) / denom;
                
                if (t >= 0.0 && t <= 1.0 && u >= 0.0 && u <= 1.0) {
                    intersection.x = x1 + t * (x2 - x1);
                    intersection.y = y1 + t * (y2 - y1);
                    intersection.z = 0.0;
                    return true;
                }
                return false;
            }

            // Frontier ile kare kesişimlerini bul
            void Explore::findRingIntersections(frontier_exploration::Frontier& f)
            {
                f.sample_points.clear();
                
                if (f.points.size() < 2) {
                    f.sample_points.push_back(f.safest_point);
                    return;
                }
                
                // Kare köşeleri
                double left   = ring_center_.x - ring_radius_;
                double right  = ring_center_.x + ring_radius_;
                double bottom = ring_center_.y - ring_radius_;
                double top    = ring_center_.y + ring_radius_;
                
                // ERKEN ÇIKIŞ: Her segment için hızlı bounding box kontrolü
                for (size_t i = 1; i < f.points.size(); ++i) {
                    geometry_msgs::Point p1 = f.points[i-1];
                    geometry_msgs::Point p2 = f.points[i];
                    
                    // Bu segment kareyle hiç overlap etmiyor mu? Skip!
                    double seg_min_x = std::min(p1.x, p2.x);
                    double seg_max_x = std::max(p1.x, p2.x);
                    double seg_min_y = std::min(p1.y, p2.y);
                    double seg_max_y = std::max(p1.y, p2.y);
                    
                    if (seg_max_x < left || seg_min_x > right ||
                        seg_max_y < bottom || seg_min_y > top) {
                        continue;  // Bu segment kareyi kesmiyor, skip!
                    }
                    
                    geometry_msgs::Point intersection;
                    
                    // Sol kenar (x = left)
                    if (lineSegmentIntersection(p1.x, p1.y, p2.x, p2.y,
                                            left, bottom, left, top, intersection)) {
                        f.sample_points.push_back(intersection);
                    }
                    
                    // Sağ kenar (x = right)
                    if (lineSegmentIntersection(p1.x, p1.y, p2.x, p2.y,
                                            right, bottom, right, top, intersection)) {
                        f.sample_points.push_back(intersection);
                    }
                    
                    // Alt kenar (y = bottom)
                    if (lineSegmentIntersection(p1.x, p1.y, p2.x, p2.y,
                                            left, bottom, right, bottom, intersection)) {
                        f.sample_points.push_back(intersection);
                    }
                    
                    // Üst kenar (y = top)
                    if (lineSegmentIntersection(p1.x, p1.y, p2.x, p2.y,
                                            left, top, right, top, intersection)) {
                        f.sample_points.push_back(intersection);
                    }
                }
                
                // Kesişim noktalarını kare içine doğru çek (0.4m)
                // const double PULL_INSIDE = 0.4;  // Kare içine çekme mesafesi
                // for (auto& p : f.sample_points) {
                //     // Ring merkezine doğru vektör
                //     double dx = ring_center_.x - p.x;
                //     double dy = ring_center_.y - p.y;
                //     double dist = std::hypot(dx, dy);
                    
                //     if (dist > 0.01) {  // Sıfır bölme kontrolü
                //         // 0.4m içeri çek
                //         p.x += (dx / dist) * PULL_INSIDE;
                //         p.y += (dy / dist) * PULL_INSIDE;
                //     }
                // }
                
                // Duplicate'leri temizle (aynı köşeden 2 kenar kesişebilir)
                if (f.sample_points.size() > 1) {
                    std::vector<geometry_msgs::Point> unique_points;
                    for (const auto& p : f.sample_points) {
                        bool is_duplicate = false;
                        for (const auto& up : unique_points) {
                            if (std::hypot(p.x - up.x, p.y - up.y) < 0.01) {  // 1cm threshold
                                is_duplicate = true;
                                break;
                            }
                        }
                        if (!is_duplicate) {
                            unique_points.push_back(p);
                        }
                    }
                    f.sample_points = unique_points;
                }
                
                // Fallback: Kesişim yoksa safest_point kullan
                if (f.sample_points.empty()) {
                    f.sample_points.push_back(f.safest_point);
                }
            }


            BlacklistEntry* Explore::findBlacklistEntry(const geometry_msgs::Point& pos, double tolerance) {
                for (auto& entry : frontier_blacklist_) {
                    if (std::hypot(entry.position.x - pos.x, entry.position.y - pos.y) < tolerance) {
                        return &entry;
                    }
                }
                return nullptr;
            }

           

            void Explore::makePlan()
            {
                try {
                    if (with_map_completion == 1) { ros::spinOnce(); }
                    costmap_2d::Costmap2D* cm = costmap_client_.getCostmap();
                    if (!cm) return;

                    geometry_msgs::Pose pose = costmap_client_.getRobotPose();
                    geometry_msgs::Point robot_pos = pose.position;
                    updateTravelDistance(robot_pos);

                    std::vector<frontier_exploration::Frontier> frontiers = search_->searchFrom(robot_pos);

                    if (frontiers.empty()) { 
                        experiment_logger_->logOperation("EXPLORATION_FINISHED", 0, "No more frontiers.");
                        stop(); 
                        return; 
                    }

                    // ============================================================
                    // BLACKLIST FİLTRELEME
                    // ============================================================
                    auto frontier_it = std::find_if_not(
                        frontiers.begin(), frontiers.end(),
                        [this](const frontier_exploration::Frontier& f) {
                            return goalOnBlacklist(f.safest_point);
                        }
                    );
                    
                    if (frontier_it == frontiers.end()) {
                        experiment_logger_->logOperation("ALL_BLACKLISTED", 0, "All frontiers blacklisted.");
                        stop(); 
                        return;
                    }

                    geometry_msgs::Point target_position = frontier_it->safest_point;
                    double min_dist_param = std::hypot(target_position.x - robot_pos.x, 
                                                        target_position.y - robot_pos.y);
                    bool found_target = true;

                    // ============================================================
                    // KRİTİK KOORDİNAT LOGLAMA (YENİLENDİ)
                    // ============================================================
                    if (experiment_logger_) {
                        // Analiz için standart format: pos=(x.xx,y.yy)
                        std::string pos_info = "pos=(" + std::to_string(target_position.x) + "," + std::to_string(target_position.y) + ")";
                        
                        if (use_completed_map_ != 1) {
                            // Baseline modunda da artık koordinatları görebileceğiz
                            experiment_logger_->logOperation("BASELINE_TARGET", min_dist_param, pos_info);
                        } else {
                            // Model modunda koordinat loglama
                            experiment_logger_->logOperation("MODEL_TARGET", min_dist_param, pos_info);
                        }
                    }

                    if (!found_target) { 
                        experiment_logger_->logOperation("NO_TARGET_FOUND", 0, "No targets reachable.");
                        stop(); 
                        return; 
                    }

                    // ============================================================
                    // TIMEOUT MEKANİZMASI 
                    // ============================================================
                    bool same_goal = (std::abs(prev_goal_.x - target_position.x) < 0.05 && 
                                    std::abs(prev_goal_.y - target_position.y) < 0.05);

                    if (!same_goal) {
                        prev_goal_ = target_position;
                        prev_distance_ = min_dist_param;
                        last_progress_ = ros::Time::now();
                        ROS_DEBUG("[new goal] timer sıfırlandı");
                    } 
                    else {
                        double distance_now = min_dist_param;
                        // İlerleme kontrolü: %8 yaklaşma veya 30cm katetme veya 20sn limit
                        if (distance_now < prev_distance_ * 0.92 ||               
                            prev_distance_ - distance_now > 0.30 ||               
                            (ros::Time::now() - last_progress_).toSec() > 20.0) { 

                            last_progress_ = ros::Time::now();
                            prev_distance_ = distance_now;
                            ROS_DEBUG("[progress] timer sıfırlandı - mesafe: %.2f m", distance_now);
                        }
                    }

                    ros::Duration time_since_progress = ros::Time::now() - last_progress_;
                    if (time_since_progress > progress_timeout_) {
                        addToBlacklist(target_position, BlacklistReason::PROGRESS_TIMEOUT, 1.0);
                        if (experiment_logger_) {  
                            experiment_logger_->logOperation("BLACKLIST_TIMEOUT", 
                                time_since_progress.toSec(),
                                "No progress. Blacklisting pos=(" + std::to_string(target_position.x) + "," + std::to_string(target_position.y) + ")");
                        }
                        makePlan(); // Yeni hedef için tekrar dene
                        return;
                    }

                    if (same_goal) {
                        return;
                    }

                    // ============================================================
                    // GÖRSELLEŞTİRME VE HEDEF GÖNDERME
                    // ============================================================
                    //if (publish_maps_) publishMaps();
                    visualizeFrontiers(frontiers, target_position);

                    // Reissue threshold: Navigasyonun kararlılığı için 0.45 yapıldı.
                    const double reissue_thresh = 0.45;
                    if (!has_active_target_ || std::hypot(current_target_.x - target_position.x, 
                        current_target_.y - target_position.y) > reissue_thresh) {
                        
                        current_target_ = target_position;
                        has_active_target_ = true;
                        current_target_start_time_ = ros::Time::now();
                        is_tracking_target_ = true;
                        sendNavigationGoal(target_position, min_dist_param);
                    }
                } 
                catch (const std::exception& e) { 
                    ROS_ERROR("Critical Error in makePlan: %s", e.what());
                    if (experiment_logger_) experiment_logger_->logOperation("CRITICAL_ERROR", 0, e.what());
                }
            }

            

            bool Explore::goalOnBlacklist(const geometry_msgs::Point& goal)
            {
                // ═══════════════════════════════════════════════════════════════
                // DEBUG LOG - SORUN TESPİTİ İÇİN
                // ═══════════════════════════════════════════════════════════════
                ROS_ERROR("🔍 goalOnBlacklist CHECK: goal=(%.3f, %.3f)", goal.x, goal.y);
                
                if (!std::isfinite(goal.x) || !std::isfinite(goal.y)) {
                    ROS_ERROR("  ❌ BLACKLISTED: Invalid coordinates (NaN/Inf)!");
                    return true;
                }

                costmap_2d::Costmap2D* costmap2d = costmap_client_.getCostmap();
                if (!costmap2d) {
                    ROS_ERROR("  ❌ BLACKLISTED: Costmap is NULL!");
                    return true;
                }

                double res = costmap_client_.getCostmap()->getResolution();
                const double tolerance_m = 0.10;  // 10cm tolerance
                
                ROS_ERROR("  📏 Resolution: %.3fm, Tolerance: %.3fm", res, tolerance_m);
                ROS_ERROR("  📋 Blacklist size: %zu items", frontier_blacklist_.size());
                
                for (size_t i = 0; i < frontier_blacklist_.size(); i++) {
                    const auto& bl_entry = frontier_blacklist_[i];
                    const auto& frontier_goal = bl_entry.position;  // ✅ BlacklistEntry.position
                    
                    if (!std::isfinite(frontier_goal.x) || !std::isfinite(frontier_goal.y)) {
                        ROS_ERROR("    [%zu] SKIP: Invalid blacklist entry", i);
                        continue;
                    }
                    
                    double distance = std::hypot(goal.x - frontier_goal.x, 
                                                goal.y - frontier_goal.y);
                    
                    ROS_ERROR("    [%zu] Distance to (%.3f, %.3f): %.3fm", 
                            i, frontier_goal.x, frontier_goal.y, distance);
                    
                    if (distance < tolerance_m) {
                        ROS_ERROR("  ❌ BLACKLISTED: Too close to blacklist[%zu] (%.3fm < %.3fm)!", 
                                i, distance, tolerance_m);
                        return true;
                    }
                }
                
                ROS_ERROR("  ✅ NOT BLACKLISTED: Goal is valid!");
                return false;
            }



            void Explore::scheduleReplan()
            {
                oneshot_.stop(); // ÖNCE DURDUR
                const double cd = 0.4; // or read from param ~replan_cooldown
                oneshot_ = relative_nh_.createTimer(
                        ros::Duration(cd),
                        [this](const ros::TimerEvent&){ makePlan(); },
                        true);

            }

            void Explore::reachedGoal(const actionlib::SimpleClientGoalState& status,
                          const move_base_msgs::MoveBaseResultConstPtr& result,
                          const geometry_msgs::Point& frontier_goal)
            {
                // LOGLAMA
                if (status == actionlib::SimpleClientGoalState::SUCCEEDED) {
                    if (is_tracking_target_) {
                        double duration_ms = (ros::Time::now() - current_target_start_time_).toSec() * 1000.0;
                        std::string info = "pos=(" + std::to_string(frontier_goal.x) + "," + std::to_string(frontier_goal.y) + ")";
                        experiment_logger_->logOperation("TARGET_REACHED", duration_ms, info);
                        is_tracking_target_ = false;
                        ROS_INFO("[REACHED] Goal SUCCEEDED at (%.2f, %.2f)", frontier_goal.x, frontier_goal.y);
                    }
                } else if (status == actionlib::SimpleClientGoalState::ABORTED) {
                    if (is_tracking_target_) {
                        double duration_ms = (ros::Time::now() - current_target_start_time_).toSec() * 1000.0;
                        std::string info = "pos=(" + std::to_string(frontier_goal.x) + "," + std::to_string(frontier_goal.y) + ")";
                        experiment_logger_->logOperation("TARGET_ABANDONED", duration_ms, info);
                        is_tracking_target_ = false;
                        ROS_WARN("[REACHED] Goal ABORTED at (%.2f, %.2f)", frontier_goal.x, frontier_goal.y);
                    }
                }

                // ABORTED için kalıcı blacklist
                if (status == actionlib::SimpleClientGoalState::ABORTED) {
                    // Eski debug kodları korunabilir (yorum satırında bırak)
               

                    // KALICI EKLEME
                    addToBlacklist(frontier_goal, BlacklistReason::GOAL_ABORTED, 1.0);
                    ROS_WARN("[BLACKLIST] Added aborted goal (%.2f, %.2f) as PERMANENTLY_UNREACHABLE", 
                            frontier_goal.x, frontier_goal.y);
                }
                
                scheduleReplan();
            }
                        
            void Explore::start()
            {
                exploring_timer_.start();
                beginClock = clock();
                //ROS_INFO("Start time: %s", to_string(beginClock).c_str());
            }

            void Explore::stop()
            {
                move_base_client_.cancelAllGoals();
                exploring_timer_.stop();
                endClock = clock();

                double elapsed_secs = double(endClock - beginClock) / CLOCKS_PER_SEC;
       
                
                // Publish exploration completion message
                std_msgs::Int32 msg;
                msg.data = 1; // 1 indicates completion
                exploration_finished_pub_.publish(msg);

                //ROS_INFO("Exploration finished.");

                // Shut down the ROS node
                ros::shutdown();

            }



            // Helper function to check if target should be validated
            bool Explore::shouldValidateTarget(double grid_len_m) const
            {
                // Check move_base state
                auto state = move_base_client_.getState();
                bool client_ready = (state == actionlib::SimpleClientGoalState::SUCCEEDED ||
                                    state == actionlib::SimpleClientGoalState::ABORTED ||
                                    state == actionlib::SimpleClientGoalState::RECALLED ||
                                    state == actionlib::SimpleClientGoalState::PREEMPTED ||
                                    state == actionlib::SimpleClientGoalState::LOST ||
                                    state == actionlib::SimpleClientGoalState::PENDING);
                
                constexpr double kShortMeters = 1.5;
                return client_ready && std::isfinite(grid_len_m) && grid_len_m > kShortMeters;
            }

            // Helper function to validate target with make_plan
            bool Explore::validateTargetWithMakePlan(const geometry_msgs::Point& robot_pos,
                                                    const geometry_msgs::Point& target_pos,
                                                    double grid_len_m)
            {
                    // Throttle repeated checks
                    static geometry_msgs::Point last_checked_goal;
                    static ros::Time last_checked_ts(0);
                    
                    const bool same_goal = (std::fabs(last_checked_goal.x - target_pos.x) < 1e-3) &&
                                            (std::fabs(last_checked_goal.y - target_pos.y) < 1e-3);
                    const bool throttle_ok = (ros::Time::now() - last_checked_ts) > ros::Duration(1.5);
                    
                    if (same_goal && !throttle_ok) {
                        return true; // Skip validation, assume OK
                    }
                    
                    last_checked_goal = target_pos;
                    last_checked_ts = ros::Time::now();
                    
                    double plan_length = dc_.computeDistanceUsingMakePlan(
                        robot_pos.x, robot_pos.y, target_pos.x, target_pos.y);
                    
                    if (!std::isfinite(plan_length)) {
                        //ROS_WARN("make_plan unavailable; skipping validation (no blacklist)");
                        // Option A: allow proceed (best to avoid stalls early in exploration)
                        return true;

                        // Option B (safer): just replan without blacklisting
                        // scheduleReplan();
                        // return false;
                    }
                    
                    // Check for excessive detour
                    constexpr double kRatioMax = 1.8;
                    constexpr double kEps = 0.05;
                    if (grid_len_m > kEps && plan_length > kRatioMax * grid_len_m + kEps) {
                        //ROS_WARN("Blacklisting target: excessive detour (%.2fm vs grid %.2fm)",
                                //plan_length, grid_len_m);
                        frontier_blacklist_.push_back(target_pos);
                        scheduleReplan();
                        return false;
                    }
                    
                    return true;
            }

            bool Explore::sendNavigationGoal(const geometry_msgs::Point& target_position, double min_distance)
            {
                move_base_msgs::MoveBaseGoal goal;
                goal.target_pose.pose.position = target_position;
                goal.target_pose.pose.orientation.w = 1.0;
                goal.target_pose.header.frame_id = costmap_client_.getGlobalFrameID();
                goal.target_pose.header.stamp = ros::Time::now();

                // Send goal with callback
                move_base_client_.sendGoal(
                    goal,
                    [this, target_position](const actionlib::SimpleClientGoalState& status,
                                            const move_base_msgs::MoveBaseResultConstPtr& result) {
                        reachedGoal(status, result, target_position);
                    }
                );

                ROS_INFO("Sent goal (%.3f, %.3f), estimated distance: %.3f m",
                        target_position.x, target_position.y, min_distance);
                
                return true;
            }


            void Explore::floodFillFromFreeSpace(std::vector<int8_t>& grid, int width, int height)
            {
                // Step 1: Apply morphological closing to obstacles to fill small gaps
                // Create a binary obstacle map
                cv::Mat obstacle_map(height, width, CV_8UC1);
                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        int idx = y * width + x;
                        // Mark obstacles (100) as 255, everything else as 0
                        obstacle_map.at<unsigned char>(y, x) = (grid[idx] == 100) ? 255 : 0;
                    }
                }
                
                // Apply morphological closing to fill small gaps in walls
                cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3));
                cv::Mat closed_obstacles;
                cv::morphologyEx(obstacle_map, closed_obstacles, cv::MORPH_CLOSE, kernel);
                
                // Update grid with closed obstacles
                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        int idx = y * width + x;
                        if (closed_obstacles.at<unsigned char>(y, x) == 255 && grid[idx] != 100) {
                            // This cell became an obstacle after closing
                            grid[idx] = 100;
                        }
                    }
                }
                
                // Step 2: Now do flood fill with the closed obstacles
                std::vector<bool> reachable(width * height, false);
                
                // Find a seed point in known free space
                int seed_idx = -1;
                for (size_t i = 0; i < grid.size(); i++) {
                    if (grid[i] == 0) {  // Free space
                        seed_idx = i;
                        break;
                    }
                }
                
                if (seed_idx == -1) {
                    //ROS_WARN("No free space found in map for flood fill!");
                    return;
                }
                
                // BFS flood fill from free space
                std::queue<Point> queue;
                int seed_x = seed_idx % width;
                int seed_y = seed_idx / width;
                queue.push(Point(seed_x, seed_y));
                reachable[seed_idx] = true;
                
                // 4-connectivity (up, down, left, right)
                int dx[] = {0, 0, 1, -1};
                int dy[] = {1, -1, 0, 0};
                
                while (!queue.empty()) {
                    Point p = queue.front();
                    queue.pop();
                    
                    // Check all 4 neighbors
                    for (int i = 0; i < 4; i++) {
                        int nx = p.x + dx[i];
                        int ny = p.y + dy[i];
                        
                        // Check bounds
                        if (nx < 0 || nx >= width || ny < 0 || ny >= height)
                            continue;
                        
                        int idx = ny * width + nx;
                        
                        // Check if already visited
                        if (reachable[idx])
                            continue;
                        
                        // Check if traversable (free or unknown, not occupied)
                        if (grid[idx] == 0 || grid[idx] == -1) {
                            reachable[idx] = true;
                            queue.push(Point(nx, ny));
                        }
                    }
                }
                
                // Mark enclosed unknown cells as occupied
                int converted = 0;
                for (size_t i = 0; i < grid.size(); i++) {
                    if (grid[i] == -1 && !reachable[i]) {
                        grid[i] = 100;  // Enclosed unknown -> occupied
                        converted++;
                    }
                }
                
                //ROS_INFO("Morphological closing + flood fill converted %d enclosed cells to occupied", converted);
            }

        
            void Explore::publishMaps() 
            {
                // Costmap'in orijinal parametrelerini al
                auto* cm = costmap_client_.getCostmap();
                if (!cm) return;
                
                const double costmap_origin_x = cm->getOriginX();
                const double costmap_origin_y = cm->getOriginY();
                const double costmap_resolution = cm->getResolution();
                const std::string global_frame = costmap_client_.getGlobalFrameID();

                // ✅ COMPLETED_MAP: HER ZAMAN COSTMAP PARAMETRELERİNİ KULLAN
                if(use_completed_map_)
                {
                    cv::Mat completed_mat = search_->completedMapMat().clone();
                    if (!completed_mat.empty()) {
                        search_->publishMap(completed_mat, 
                                        completed_pub_, 
                                        global_frame,
                                        costmap_origin_x,    // COSTMAP origin kullan
                                        costmap_origin_y,    // COSTMAP origin kullan  
                                        costmap_resolution); // COSTMAP resolution kullan
                    }

                    
                }

                if(use_closed_live_map_ && publish_closed_live_map_)
                {
                    // ✅ CLOSED_MAP: HER ZAMAN COSTMAP PARAMETRELERİNİ KULLAN
                    cv::Mat closed_live_mat= search_->liveClosedMapMat().clone();
                    if (!closed_live_mat.empty()) {
                        search_->publishMap(closed_live_mat, 
                                        closed_live_pub_, 
                                        global_frame,
                                        costmap_origin_x,    // COSTMAP origin kullan
                                        costmap_origin_y,    // COSTMAP origin kullan  
                                        costmap_resolution); // COSTMAP resolution kullan
                    }
                }

                // ✅ GT_MAP: Eğer yüklüyse, AYNI COSTMAP PARAMETRELERİNİ kullan
                if (!gt_image_raw_.empty()) {
                    // GT'yi costmap koordinat sisteminde yayınla
                    search_->publishMap(gt_image_raw_, 
                                    gt_map_pub_, 
                                    global_frame,
                                    costmap_origin_x,    // AYNI origin
                                    costmap_origin_y,    // AYNI origin
                                    costmap_resolution); // AYNI resolution
                }
            }


            bool Explore::validateParameters()
            {
                bool valid = true;
                
                // Validate numeric parameters
                if (planner_frequency_ <= 0.0 || planner_frequency_ > 10.0) {
                    //ROS_ERROR("Invalid planner_frequency: %.2f (should be 0.1-10.0)", planner_frequency_);
                    planner_frequency_ = std::max(0.1, std::min(planner_frequency_, 10.0));  // Fixed
                    valid = false;
                }
                
                if (timeout <= 0.0 || timeout > 3600.0) {
                    //ROS_ERROR("Invalid progress_timeout: %.2f (should be 1.0-3600.0)", timeout);
                    timeout = std::max(1.0, std::min(timeout, 3600.0));  // Fixed
                    valid = false;
                }
                
                if (potential_scale_ < 0.0) {
                    //ROS_ERROR("Invalid potential_scale: %.6f (should be >= 0)", potential_scale_);
                    potential_scale_ = std::abs(potential_scale_);
                    valid = false;
                }
                
                if (gain_scale_ < 0.0) {
                    //ROS_ERROR("Invalid gain_scale: %.6f (should be >= 0)", gain_scale_);
                    gain_scale_ = std::abs(gain_scale_);
                    valid = false;
                }
                
                if (min_frontier_size < 0.01 || min_frontier_size > 100.0) {
                    //ROS_ERROR("Invalid min_frontier_size: %.3f (should be 0.01-100.0)", min_frontier_size);
                    min_frontier_size = std::max(0.01, std::min(min_frontier_size, 100.0));  // Fixed
                    valid = false;
                }
                
                // Validate GT parameters if GT is enabled
                if (!gt_image_path_.empty()) {
                    if (gt_resolution_ <= 0.0) {
                        //ROS_ERROR("Invalid gt_resolution: %.6f (should be > 0)", gt_resolution_);
                        gt_resolution_ = 0.1; // Reasonable default
                        valid = false;
                    }
                }
                
                // Validate completion parameters
                if (rect_size_ <= 0 || rect_size_ > 500) {
                    //ROS_ERROR("Invalid rect_size: %d (should be 1-500)", rect_size_);
                    rect_size_ = std::max(1, std::min(rect_size_, 500));  // Fixed
                    valid = false;
                }
                
                return valid;
            }


            bool Explore::preFlightCheckWithAstar(const geometry_msgs::Point& robot_pos,
                                            const geometry_msgs::Point& target_pos,
                                            double grid_len_m)
            {
                (void)grid_len_m; // şu an kullanılmıyor

                //ROS_WARN("=== preFlightCheckWithAstar DEBUG ===");
                //ROS_WARN("Robot: (%.3f, %.3f) -> Target: (%.3f, %.3f)", 
                        //robot_pos.x, robot_pos.y, target_pos.x, target_pos.y);

                costmap_2d::Costmap2D* cm = costmap_client_.getCostmap();
                if (!cm) {
                    //ROS_WARN("preFlightCheckWithAstar: no costmap");
                    return false;
                }

                unsigned int sx, sy, gx, gy;
                if (!cm->worldToMap(robot_pos.x,  robot_pos.y,  sx, sy)) {
                    //ROS_WARN("preFlightCheckWithAstar: start out of map (%.3f, %.3f)", robot_pos.x, robot_pos.y);
                    return false;
                }
                if (!cm->worldToMap(target_pos.x, target_pos.y, gx, gy)) {
                    //ROS_WARN("preFlightCheckWithAstar: goal out of map (%.3f, %.3f)", target_pos.x, target_pos.y);
                    return false;
                }

                //ROS_WARN("Map coords: start=(%u,%u), goal=(%u,%u)", sx, sy, gx, gy);

                const int W = static_cast<int>(cm->getSizeInCellsX());
                const int H = static_cast<int>(cm->getSizeInCellsY());
                const double res = cm->getResolution();
                
                //ROS_WARN("Map: %dx%d, resolution=%.3f", W, H, res);

                auto inb    = [&](int x, int y){ return (0 <= x && x < W && 0 <= y && y < H); };
                auto toIdx  = [&](int x, int y){ return y * W + x; };
                auto isObs  = [&](int x, int y)->bool {
                    const unsigned char c = cm->getCost(x, y);
                    // Sadece gerçek engelleri engel say: unknown serbest
                    return (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) && (c != costmap_2d::NO_INFORMATION);
                };

                // Başlangıç ve hedef cost kontrolü
                unsigned char start_cost = cm->getCost(sx, sy);
                unsigned char goal_cost = cm->getCost(gx, gy);
                
                //ROS_WARN("Start cost: %u, Goal cost: %u", start_cost, goal_cost);
                //ROS_WARN("Start blocked: %s, Goal blocked: %s", 
                        // isObs(sx, sy) ? "YES" : "NO", 
                        // isObs(gx, gy) ? "YES" : "NO");

                // Başlangıç engeldeyse direkt reddet
                if (isObs((int)sx, (int)sy)) {
                    //ROS_WARN("preFlightCheckWithAstar: FAILED - start cell is obstacle");
                    return false;
                }

                // --- Hedefi yakındaki bir FREE hücreye SNAP et (hedef engeldeyse) ---
                int gx_ok = static_cast<int>(gx), gy_ok = static_cast<int>(gy);
                if (isObs((int)gx, (int)gy)) {
                    //ROS_WARN("Goal is obstacle, attempting to snap to nearby free cell...");
                    
                    const double res_safe = std::max(cm->getResolution(), 1e-6);
                    const int snap_r_cells = std::max(1, (int)std::round(0.40 / res_safe)); // ~0.4 m yarıçap
                    
                    //ROS_WARN("Snap radius: %d cells (%.3f m)", snap_r_cells, snap_r_cells * res_safe);
                    
                    std::deque<std::pair<int,int>> q;
                    std::vector<uint8_t> vis((size_t)W*(size_t)H, 0);

                    q.emplace_back((int)gx, (int)gy);
                    vis[(size_t)toIdx((int)gx,(int)gy)] = 1;

                    bool found = false;
                    int snap_attempts = 0;
                    
                    while (!q.empty() && snap_attempts < 1000) {
                        // C++11 uyumlu structured binding yerine:
                        std::pair<int,int> current = q.front(); 
                        q.pop_front();
                        int cx = current.first;
                        int cy = current.second;
                        snap_attempts++;
                        
                        if (!isObs(cx, cy)) {
                            gx_ok = cx; gy_ok = cy;
                            found = true;
                            //ROS_WARN("Snap successful: (%u,%u)->(%d,%d) after %d attempts", 
                                //  gx, gy, gx_ok, gy_ok, snap_attempts);
                            break;
                        }
                        
                        // yarıçap kısıtı
                        const int dx0 = cx - (int)gx;
                        const int dy0 = cy - (int)gy;
                        if (dx0*dx0 + dy0*dy0 > snap_r_cells*snap_r_cells) continue;

                        static const int NX[8] = { 1, 1, 0,-1,-1,-1, 0, 1};
                        static const int NY[8] = { 0, 1, 1, 1, 0,-1,-1,-1};
                        for (int k=0;k<8;++k) {
                            const int nx = cx + NX[k];
                            const int ny = cy + NY[k];
                            if (!inb(nx,ny)) continue;
                            const size_t nidx = (size_t)toIdx(nx,ny);
                            if (vis[nidx]) continue;
                            vis[nidx] = 1;
                            q.emplace_back(nx,ny);
                        }
                    }

                    if (!found) {
                        //ROS_WARN("preFlightCheckWithAstar: FAILED - goal in obstacle and no nearby free cell found after %d attempts", snap_attempts);
                        return false;
                    }
                } else {
                    //ROS_WARN("Goal is already free, no snapping needed");
                }

                //ROS_WARN("Final goal coords: (%d,%d)", gx_ok, gy_ok);

                // --- A* (h=0 => Dijkstra), sadece costmap'e göre geçiş ---
                struct Node { int idx; double g; double f; bool operator<(const Node& o) const { return f > o.f; } };
                std::priority_queue<Node> open;
                const size_t N = (size_t)W * (size_t)H;
                std::vector<uint8_t>  closed(N, 0);
                std::vector<double>   g(N, std::numeric_limits<double>::infinity());

                static const int DX[8]   = { 1, 1, 0,-1,-1,-1, 0, 1};
                static const int DY[8]   = { 0, 1, 1, 1, 0,-1,-1,-1};
                static const double STEP[8] = {
                    1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0),
                    1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0)
                };

                const int sidx = toIdx((int)sx,(int)sy);
                const int gidx = toIdx(gx_ok, gy_ok);
                
                //ROS_WARN("A* search: sidx=%d, gidx=%d", sidx, gidx);
                
                g[sidx] = 0.0;
                open.push({sidx, 0.0, 0.0});

                size_t it = 0;
                size_t expansions = 0;
                const size_t it_max = std::max((size_t)100000, 2*N); // güvenli üst sınır

                while (!open.empty() && it++ < it_max) {
                    Node cur = open.top(); open.pop();
                    if (closed[cur.idx]) continue;
                    closed[cur.idx] = 1;
                    expansions++;

                    if (cur.idx == gidx) {
                        // reached
                        //ROS_WARN("preFlightCheckWithAstar: SUCCESS - path found after %zu expansions, cost=%.3f", 
                                //expansions, cur.g);
                        return true;
                    }

                    const int cx = cur.idx % W;
                    const int cy = cur.idx / W;

                    int valid_neighbors = 0;
                    for (int k=0;k<8;++k) {
                        const int nx = cx + DX[k];
                        const int ny = cy + DY[k];
                        if (!inb(nx,ny)) continue;

                        // köşe kesme: ortogonaller engelse izin verme
                        if (DX[k] != 0 && DY[k] != 0) {
                            if (isObs(cx + DX[k], cy) || isObs(cx, cy + DY[k])) continue;
                        }
                        if (isObs(nx,ny)) continue;

                        valid_neighbors++;

                        const int nidx = toIdx(nx,ny);
                        const double ng = cur.g + STEP[k];
                        if (!closed[nidx] && ng < g[nidx]) {
                            g[nidx] = ng;
                            // h=0 (sadece doğrulama)
                            open.push({nidx, ng, ng});
                        }
                    }
                    
                    // İlk birkaç expansion için detay
                    if (expansions <= 10) {
                        //ROS_WARN("Expansion %zu: cell (%d,%d), valid_neighbors=%d, open_size=%zu", 
                            // expansions, cx, cy, valid_neighbors, open.size());
                    }
                    
                    // Eğer hiç komşu yoksa stuck olabiliriz
                    if (valid_neighbors == 0 && expansions <= 5) {
                        //ROS_WARN("No valid neighbors found at (%d,%d) - checking surrounding costs:", cx, cy);
                        for (int k=0;k<8;++k) {
                            const int nx = cx + DX[k];
                            const int ny = cy + DY[k];
                            if (inb(nx,ny)) {
                                unsigned char cost = cm->getCost(nx, ny);
                                //ROS_WARN("  Neighbor (%d,%d): cost=%u, blocked=%s", 
                                    // nx, ny, cost, isObs(nx,ny) ? "YES" : "NO");
                            }
                        }
                    }
                }

                if (it >= it_max) {
                    //ROS_WARN("preFlightCheckWithAstar: FAILED - iteration cap reached (%zu expansions)", expansions);
                } else {
                    //ROS_WARN("preFlightCheckWithAstar: FAILED - no path found (%zu expansions, final open_size=%zu)", 
                        // expansions, open.size());
                }
                return false;
            }


            void Explore::metricsTimerCallback(const ros::TimerEvent&)
            {
                if (!experiment_logger_) return;
    
                double elapsed_sec = (ros::Time::now() - exploration_start_time_).toSec();
                double completion_percent = calculateExplorationProgress();
                
                // ✅ FULL GT boyutlarını kullan (SABİT!)
                int gt_w = full_gt_loaded_ ? full_gt_image_.cols : 0;
                int gt_h = full_gt_loaded_ ? full_gt_image_.rows : 0;
                
                // Costmap boyutları
                auto* cm = costmap_client_.getCostmap();
                int costmap_w = cm ? cm->getSizeInCellsX() : 0;
                int costmap_h = cm ? cm->getSizeInCellsY() : 0;
                
                // Log
                experiment_logger_->logMetrics(total_distance_traveled_, 
                                            completion_percent, 
                                            elapsed_sec,
                                            gt_w, gt_h,  // ✅ Artık sabit!
                                            costmap_w, costmap_h);
                
                // Check milestones
                int cp_int = static_cast<int>(std::floor(completion_percent));
                for (int th : completion_milestones_) {
                    if (reached_milestones_.count(th)) continue;
                    if (cp_int >= th) {
                        reached_milestones_.insert(th);
                        experiment_logger_->logMilestone(th, elapsed_sec, 
                                                        total_distance_traveled_, 
                                                        completion_percent);
                    }
                }
            }


            double Explore::calculateExplorationProgress() 
            { 
                if (!search_) return 0.0;
                
                auto costmap = costmap_client_.getCostmap();
                if (!costmap || !full_gt_loaded_) return 0.0;

                // ✅ ONE-TIME RESOLUTION VERIFICATION
                static bool resolution_verified = false;
                if (!resolution_verified) {
                    double costmap_res = costmap->getResolution();
                    double diff = std::abs(costmap_res - full_gt_resolution_);
                    
                    if (diff > 1e-6) {
                        ROS_ERROR("Resolution mismatch: Costmap=%.6f, GT=%.6f", 
                                costmap_res, full_gt_resolution_);
                        ROS_ERROR("   Completion calculation will be INCORRECT!");
                    } else {
                        ROS_INFO("Resolutions verified: both %.6f m/cell", costmap_res);
                    }
                    resolution_verified = true;
                }

                // ═══════════════════════════════════════════════════════════════
                // COUNT FULL GT KNOWN CELLS ONCE (CONSTANT)
                // ═══════════════════════════════════════════════════════════════
                static int FULL_GT_KNOWN_CELLS = 0;
                if (FULL_GT_KNOWN_CELLS == 0) {
                    for (int y = 0; y < full_gt_image_.rows; ++y) {
                        for (int x = 0; x < full_gt_image_.cols; ++x) {
                            if (full_gt_image_.at<unsigned char>(y, x) != 205) {
                                FULL_GT_KNOWN_CELLS++;
                            }
                        }
                    }
                    ROS_INFO("═══ FULL GT KNOWN CELLS = %d (CONSTANT) ═══", FULL_GT_KNOWN_CELLS);
                }
                
                if (FULL_GT_KNOWN_CELLS == 0) return 0.0;
                
                // ═══════════════════════════════════════════════════════════════
                // COUNT SCANNED CELLS FROM COSTMAP
                // ═══════════════════════════════════════════════════════════════
                const unsigned int W = costmap->getSizeInCellsX();
                const unsigned int H = costmap->getSizeInCellsY();
                const unsigned char* costmap_data = costmap->getCharMap();
                
                int scanned_cells = 0;
                
                // Iterate through COSTMAP
                for (unsigned int cy = 0; cy < H; ++cy) {
                    for (unsigned int cx = 0; cx < W; ++cx) {
                        
                        unsigned char cost_val = costmap_data[cy * W + cx];
                        
                        if (cost_val != costmap_2d::NO_INFORMATION) {
                            
                            double world_x, world_y;
                            costmap->mapToWorld(cx, cy, world_x, world_y);
                            
                            int gt_x = static_cast<int>((world_x - full_gt_origin_x_) / full_gt_resolution_);
                            int gt_y = static_cast<int>((world_y - full_gt_origin_y_) / full_gt_resolution_);
                            
                            if (gt_x >= 0 && gt_x < full_gt_image_.cols &&
                                gt_y >= 0 && gt_y < full_gt_image_.rows) {
                                
                                unsigned char gt_val = full_gt_image_.at<unsigned char>(
                                    full_gt_image_.rows - 1 - gt_y, gt_x);
                                
                                if (gt_val != 205) {
                                    scanned_cells++;
                                }
                            }
                        }
                    }
                }
                
             
                double completion = (100.0 * scanned_cells) / FULL_GT_KNOWN_CELLS;
                
                ROS_INFO(">>> Completion: %d/%d = %.2f%%", scanned_cells, FULL_GT_KNOWN_CELLS, completion);
                
                return completion;
            }

            void Explore::updateTravelDistance(const geometry_msgs::Point& current_pos) 
            {
                    double dx = current_pos.x - last_robot_position_.x;
                    double dy = current_pos.y - last_robot_position_.y;
                    double dist = std::sqrt(dx*dx + dy*dy);
                    
                    // Only accumulate reasonable movements
                    if (dist > 0.01 && dist < 5.0) {
                        total_distance_traveled_ += dist;
                    }
                    
                    last_robot_position_ = current_pos;  // Always update
            }


            void Explore::addToFilteredCluster(const geometry_msgs::Point& frontier_point)
            {
                const double MATCH_EPS = 0.5;
                
                // Mevcut cluster'lardan birinde mi?
                for (auto& cluster : filtered_clusters_) {
                    // Cluster center'a yakın mı?
                    double dist_to_center = std::hypot(frontier_point.x - cluster.center.x,
                                                    frontier_point.y - cluster.center.y);
                    
                    if (dist_to_center < CLUSTER_RADIUS) {
                        // Bu cluster'a zaten ekli mi kontrol et
                        bool already_exists = false;
                        for (const auto& member : cluster.members) {
                            if (std::hypot(member.x - frontier_point.x, member.y - frontier_point.y) < MATCH_EPS) {
                                already_exists = true;
                                break;
                            }
                        }
                        
                        if (!already_exists) {
                            cluster.members.push_back(frontier_point);
                            cluster.updateCenter();
                            ROS_DEBUG("Added frontier to existing cluster (new center: %.2f, %.2f, members: %zu)",
                                    cluster.center.x, cluster.center.y, cluster.members.size());
                        }
                        return;
                    }
                }
                
                // Yeni cluster oluştur
                FilteredCluster new_cluster;
                new_cluster.members.push_back(frontier_point);
                new_cluster.updateCenter();
                filtered_clusters_.push_back(new_cluster);
                
                ROS_INFO("Created new filtered cluster at (%.2f, %.2f)",
                        new_cluster.center.x, new_cluster.center.y);
            }

            void Explore::cleanupFilteredClusters(const std::vector<frontier_exploration::Frontier>& current_frontiers)
            {
                const double MATCH_EPS = 0.5;
                
                // Her cluster'daki member'ları kontrol et
                for (auto& cluster : filtered_clusters_) {
                    cluster.members.erase(
                        std::remove_if(cluster.members.begin(), cluster.members.end(),
                            [&](const geometry_msgs::Point& member) {
                                // Bu member hala mevcut frontiers'da var mı?
                                for (const auto& f : current_frontiers) {
                                    if (std::hypot(f.safest_point.x - member.x, f.safest_point.y - member.y) < MATCH_EPS) {
                                        return false;  // Hala var, silme
                                    }
                                }
                                return true;  // Artık yok, sil
                            }),
                        cluster.members.end());
                    
                    // Member'lar güncellendiyse center'ı yeniden hesapla
                    if (!cluster.members.empty()) {
                        cluster.updateCenter();
                    }
                }
                
                // Boş cluster'ları sil
                filtered_clusters_.erase(
                    std::remove_if(filtered_clusters_.begin(), filtered_clusters_.end(),
                        [](const FilteredCluster& c) { return c.members.empty(); }),
                    filtered_clusters_.end());
            }
    }  // namespace explore

    int main(int argc, char** argv)
    {
        ros::init(argc, argv, "explore");
        if (ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME,
                                                ros::console::levels::Debug)) {
            ros::console::notifyLoggerLevelsChanged();
        }
        explore::Explore explore;
        ros::spin();

        return 0;
    }
