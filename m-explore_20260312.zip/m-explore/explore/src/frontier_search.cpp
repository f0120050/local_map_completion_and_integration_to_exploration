#include <explore/frontier_search.h>

#include <mutex>
#include <cmath>
#include <algorithm>

#include <costmap_2d/costmap_2d.h>
#include <geometry_msgs/Point.h>
#include <costmap_2d/cost_values.h>
#include <opencv2/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/calib3d.hpp>
#include <tf2/LinearMath/Quaternion.h>

#include <explore/costmap_tools.h>   // nhood4, nhood8, nearestCell
#include <queue>

#include <boost/filesystem.hpp>
namespace fs = boost::filesystem;
#include <cstdio>   // snprintf için
#include <numeric>  // For std::accumulate

#include <explore_lite/MapCompletionBatch.h>


namespace frontier_exploration
{
    using costmap_2d::FREE_SPACE;
    using costmap_2d::NO_INFORMATION;

    static constexpr unsigned char OBSTACLE_U8 = 0;   // OpenCV mat
    static constexpr unsigned char UNKNOWN_U8  = 205;
    static constexpr unsigned char KNOWN_U8    = 254;




    // frontier_search.cpp (üst kısımlar)
    static inline int clampInt(int v, int lo, int hi) { return std::max(lo, std::min(v, hi)); }

    // Dünya -> resim pikseli (üstten sayan OpenCV satır dizini için flipY=true)
    static inline bool worldToImagePxPy(double wx, double wy,
                                        double origin_x, double origin_y, double res,
                                        int img_w, int img_h,
                                        int& px, int& py, bool flipY = true)
    {
    if (!(res > 0.0) || img_w <= 0 || img_h <= 0) return false;
    // Kolon (x): soldan sağa
    px = static_cast<int>( std::floor((wx - origin_x) / res) );
    // Satır (y): OpenCV yukarıdan aşağı saydığı için, haritanın alt kökenini üstten sayana çevirmek:
    if (flipY) {
        py = img_h - 1 - static_cast<int>( std::floor((wy - origin_y) / res) );
    } else {
        py = static_cast<int>( std::floor((wy - origin_y) / res) );
    }
    return true;
    }

    // Resimden merkez (cx,cy) etrafında patch_size x patch_size yama çıkar.
    // Resmin dışına taşan kısımlar UNKNOWN_U8 ile pad edilir.
    // dst her zaman patch_size x patch_size olarak döner. Mevcut veri hiç kesilemiyorsa yine pad döner (true).
    static inline bool cropWithPad(const cv::Mat& src,
                                int cx, int cy, int patch_size,
                                unsigned char pad_value,
                                cv::Mat& dst)
    {
    if (src.empty() || src.type() != CV_8UC1 || patch_size <= 0) return false;

    dst = cv::Mat(patch_size, patch_size, CV_8UC1, cv::Scalar(pad_value));

    const int half = patch_size / 2;
    const int x0 = cx - half;
    const int y0 = cy - half;
    const int x1 = x0 + patch_size;
    const int y1 = y0 + patch_size;

    // Kaynaktaki geçerli (kesişen) dikdörtgen
    const int sx0 = clampInt(x0, 0, src.cols);
    const int sy0 = clampInt(y0, 0, src.rows);
    const int sx1 = clampInt(x1, 0, src.cols);
    const int sy1 = clampInt(y1, 0, src.rows);

    const int copy_w = sx1 - sx0;
    const int copy_h = sy1 - sy0;
    if (copy_w <= 0 || copy_h <= 0) {
        // Tümü dışarıdaysa: tamamen pad’li yama döndür (geçerli ama boş kopya)
        return true;
    }

    cv::Rect roi_src(sx0, sy0, copy_w, copy_h);
    // Hedefte nereye yapıştıracağız?
    const int dx0 = sx0 - x0;
    const int dy0 = sy0 - y0;
    cv::Rect roi_dst(dx0, dy0, copy_w, copy_h);

    src(roi_src).copyTo(dst(roi_dst));
    return true;
    }

    FrontierSearch::FrontierSearch(costmap_2d::Costmap2D* costmap,
                                    double potential_scale,
                                    double gain_scale,
                                    double min_frontier_size,
                                    std::string distance_method,
                                    int rect_size,
                                    double completion_known_scale,
                                    double completion_obstacle_scale,
                                    double obstacle_distance_threshold,
                                    double door_threshold_m,
                                    int use_completed_map,
                                    int use_closed_live_map,
                                    int use_closing,
                                    int use_filtering,                                    
                                    int use_clustering,
                                    double room_behind_wall_scale,
                                    double barrier_penalty_scale,
                                    double frontier_on_obstacle_penalty_scale,
                                    double check_distance,
                                    std::shared_ptr<explore::ExperimentLogger> logger,
                                    int with_map_completion,
                                    double noise_in_room_threshold,
                                    double direction_consistency_weight,
                                    double cluster_distance_threshold,
                                    double interior_noise_min_length,      
                                    double interior_noise_max_length,      
                                    double interior_noise_agreement_ratio, 
                                    double interior_noise_max_obstacle_ratio,                                   
                                    double exterior_noise_min_length,
                                    int exterior_noise_max_thickness_cells,
                                    double exterior_noise_unknown_lookahead_m,
                                    double exterior_noise_wall_search_m,
                                    double exterior_noise_agree_ratio,
                                    double exterior_noise_island_radius_m,
                                    int exterior_noise_island_cells_max,
                                    double trapped_max_traversable_gap_m,
                                    double trapped_wall_detect_range_m,
                                    double trapped_min_obstacle_ratio,
                                    double trapped_min_samples_agree,
                                    double trapped_min_frontier_length,
                                    double trapped_max_frontier_length,
                                    double bridge_min_length,
                                    double bridge_max_thickness_per_side_m,
                                    double bridge_wall_search_m,
                                    double bridge_min_unknown_ratio_per_side,
                                    double bridge_min_thin_ratio,
                                    double bridge_min_unknown_ratio,
                                    double bridge_unknown_lookahead_m,
                                    int bridge_max_island_cells,
                                    double corner_max_frontier_length,
                                    double corner_max_unknown_depth,
                                    double corner_max_unknown_volume,
                                    double corner_min_wall_coverage,
                                    double corner_angle_threshold,
                                    double corner_min_confidence,
                                    double corner_wall_search_distance,
                                    double corner_min_pocket_depth)
    : costmap_(costmap)
    , potential_scale_(potential_scale)
    , gain_scale_(gain_scale)
    , min_frontier_size_(min_frontier_size)
    , distance_method_(std::move(distance_method))
    , rect_size_(rect_size)
    , completion_known_scale_(completion_known_scale)
    , completion_obstacle_scale_(completion_obstacle_scale)
    , obstacle_distance_threshold_(obstacle_distance_threshold)
    , door_threshold_m_(door_threshold_m)
    , use_completed_map_(use_completed_map)
    , use_closing_(use_closing)
    , use_filtering_(use_filtering)    
    , use_closed_live_map_(use_closed_live_map)
    , use_clustering_(use_clustering)
    , room_behind_wall_scale_(room_behind_wall_scale)
    , barrier_penalty_scale_(barrier_penalty_scale)
    , frontier_on_obstacle_penalty_scale_(frontier_on_obstacle_penalty_scale)
    , check_distance_(check_distance)
    , experiment_logger_(logger)
    , with_map_completion_(with_map_completion)
    , noise_in_room_threshold_(noise_in_room_threshold)
    , direction_consistency_weight_(direction_consistency_weight)
    , cluster_distance_threshold_(cluster_distance_threshold)
    , interior_noise_min_length_(interior_noise_min_length)           // NEW
    , interior_noise_max_length_(interior_noise_max_length)           // NEW
    , interior_noise_agreement_ratio_(interior_noise_agreement_ratio) // NEW
    , interior_noise_max_obstacle_ratio_(interior_noise_max_obstacle_ratio) // NEW
    , exterior_noise_min_length_(exterior_noise_min_length)
    , exterior_noise_max_thickness_cells_(exterior_noise_max_thickness_cells)
    , exterior_noise_unknown_lookahead_m_(exterior_noise_unknown_lookahead_m)
    , exterior_noise_wall_search_m_(exterior_noise_wall_search_m)
    , exterior_noise_agree_ratio_(exterior_noise_agree_ratio)
    , exterior_noise_island_radius_m_(exterior_noise_island_radius_m)
    , exterior_noise_island_cells_max_(exterior_noise_island_cells_max)
    , trapped_max_traversable_gap_m_(trapped_max_traversable_gap_m)
    , trapped_wall_detect_range_m_(trapped_wall_detect_range_m)
    , trapped_min_obstacle_ratio_(trapped_min_obstacle_ratio)
    , trapped_min_samples_agree_(trapped_min_samples_agree)
    , trapped_min_frontier_length_(trapped_min_frontier_length)
    , trapped_max_frontier_length_(trapped_max_frontier_length)
    , bridge_min_length_(bridge_min_length)
    , bridge_max_thickness_per_side_m_(bridge_max_thickness_per_side_m)
    , bridge_wall_search_m_(bridge_wall_search_m)
    , bridge_min_unknown_ratio_per_side_(bridge_min_unknown_ratio_per_side)
    , bridge_min_thin_ratio_(bridge_min_thin_ratio)
    , bridge_min_unknown_ratio_(bridge_min_unknown_ratio)
    , bridge_unknown_lookahead_m_(bridge_unknown_lookahead_m)
    , bridge_max_island_cells_(bridge_max_island_cells)
    
    {
    
    distance_calculator_.setCostmap(costmap_);

    // Initialize batch completion service client
        if (with_map_completion_ == 1) {
            ros::NodeHandle nh;
            map_completion_batch_client_ = 
                nh.serviceClient<explore_lite::MapCompletionBatch>("/complete_map_batch");
            
            // Wait for service (with timeout)
            if (map_completion_batch_client_.waitForExistence(ros::Duration(5.0))) {
                ROS_INFO("✓ Connected to batch map completion service");
            } else {
                ROS_WARN("⚠ Batch completion service not available.");
            }
        }

    

    }

    // ✅ YENİ: Patch bölgesini temizle
    void FrontierSearch::clearPatchArea(const FrontierKey& key) {
        auto it = active_frontier_patches_.find(key);
        if (it == active_frontier_patches_.end()) return;
        
        cv::Rect roi = it->second.roi;
        
        // Bu bölgeyi completed_map'ten resetle
        for (int y = 0; y < roi.height; ++y) {
            for (int x = 0; x < roi.width; ++x) {
                int gx = roi.x + x;
                int gy = roi.y + y;
                if (gx >= 0 && gx < completed_map_.cols && gy >= 0 && gy < completed_map_.rows) {
                    completed_map_.at<uchar>(gy, gx) = UNKNOWN_U8;
                }
            }
        }
        
        //ROS_DEBUG("Cleared inconsistent patch at (%d, %d)", key.x, key.y);
    }

    FrontierKey FrontierSearch::getFrontierKey(double world_x, double world_y) {
        // 0.5 metre grid resolution ile frontier key oluştur
        const double grid_size = 0.5; // metre
        FrontierKey key;
        key.x = static_cast<int>(std::round(world_x / grid_size));
        key.y = static_cast<int>(std::round(world_y / grid_size));
        return key;
    }

    
    

  
   


    bool FrontierSearch::isFrontierTooCloseToObstacle(const Frontier& frontier, 
                                                double min_distance_m,
                                                ObstacleCheckSource source) const
    {
        if (!costmap_) return true;

        unsigned int mx, my;
        if (!costmap_->worldToMap(frontier.safest_point.x, frontier.safest_point.y, mx, my)) return true;

        const int MIN_PIXEL_THRESHOLD = 2; // En az 4 yönde engel varsa "yakın" de

        // 8 yön: Sağ, Sol, Yukarı, Aşağı, 4 diagonal
        int dx[] = {1, -1,  0,  0,  1,  1, -1, -1};
        int dy[] = {0,  0,  1, -1,  1, -1,  1, -1};

        cv::Mat check_map;
        bool use_opencv_map = false;

        switch (source) {
            case frontier_exploration::ObstacleCheckSource::COMPLETED_MAP:
                if (completed_map_.empty()) return false;
                check_map = completed_map_;
                use_opencv_map = true;
                break;
            case frontier_exploration::ObstacleCheckSource::CLOSED_LIVE_MAP:
                if (closed_live_.empty()) return false;
                check_map = closed_live_;
                use_opencv_map = true;
                break;
            case frontier_exploration::ObstacleCheckSource::RAW_COSTMAP:
                use_opencv_map = false;
                break;
        }

        // min_distance_m'yi pixel'e çevir
        const double res = costmap_->getResolution();
        double resolution = use_opencv_map ? res : costmap_->getResolution();
        int max_pixels = static_cast<int>(std::ceil(min_distance_m / resolution));

        int obstacle_directions = 0; // Kaç yönde engel var

        // Her yön için kontrol
        for (int dir = 0; dir < 8; ++dir) {
            bool obstacle_in_this_direction = false;

            // Bu yönde max_pixels kadar ilerle
            for (int step = 1; step <= max_pixels; ++step) {
                int cm_x = static_cast<int>(mx) + dx[dir] * step;
                int cm_y = static_cast<int>(my) + dy[dir] * step;

                if (use_opencv_map) {
                    int cv_x = cm_x;
                    int cv_y = check_map.rows - 1 - cm_y;

                    if (cv_x < 0 || cv_x >= check_map.cols || cv_y < 0 || cv_y >= check_map.rows) {
                        break; // Harita dışı, bu yönü bitir
                    }

                    unsigned char val = check_map.at<uchar>(cv_y, cv_x);
                    const int OBSTACLE_TOLERANCE = 10; // Ayarlanabilir yapabilirsin
                    if (val < OBSTACLE_U8 + OBSTACLE_TOLERANCE) { 
                        obstacle_in_this_direction = true;
                        break;
                    }
                } else {
                    if (cm_x < 0 || cm_x >= (int)costmap_->getSizeInCellsX() || 
                        cm_y < 0 || cm_y >= (int)costmap_->getSizeInCellsY()) {
                        break; // Harita dışı
                    }

                    unsigned char cost = costmap_->getCost(cm_x, cm_y);
                   if (cost > 0 && cost < 255) { // 
                        obstacle_in_this_direction = true;
                        break;
                    }
                }
            }

            if (obstacle_in_this_direction) {
                obstacle_directions++;
                if (obstacle_directions >= MIN_PIXEL_THRESHOLD) {
                    return true; // Erkenden çık
                }
            }
        }

        return false;
    }


    void FrontierSearch::calculateSamplePoints(Frontier& frontier) {
        frontier.sample_points.clear();
        
        if (frontier.points.empty()) {
            // Fallback: en azından safest_point'i ekle
            frontier.sample_points.push_back(frontier.safest_point);
            return;
        }
        
        // Çok kısa frontier - sadece başlangıç ve bitiş
        if (frontier.points.size() <= 2) {
            frontier.sample_points.push_back(frontier.points.front());
            if (frontier.points.size() == 2) {
                frontier.sample_points.push_back(frontier.points.back());
            }
            return;
        }
        
        // Toplam uzunluğu hesapla
        double total_length = 0.0;
        for (size_t i = 1; i < frontier.points.size(); ++i) {
            double dx = frontier.points[i].x - frontier.points[i-1].x;
            double dy = frontier.points[i].y - frontier.points[i-1].y;
            total_length += std::hypot(dx, dy);
        }
        
        // Uzunluğa göre sample sayısı belirle
        int num_samples;
        if (total_length < 2.0) {
            num_samples = 2;  // Çok kısa: başlangıç + bitiş
        } else if (total_length < 5.0) {
            num_samples = 3;  // Kısa: başlangıç + orta + bitiş
        } else if (total_length < 10.0) {
            num_samples = 4;  // Orta: 4 nokta
        } else {
            num_samples = 5;  // Uzun: 5 nokta
        }
        
        // Point sayısından fazla sample alamayız
        num_samples = std::min(num_samples, static_cast<int>(frontier.points.size()));
        
        // Tek noktalı frontier
        if (num_samples < 2) {
            frontier.sample_points.push_back(frontier.points.front());
            return;
        }
        
        double interval_length = total_length / (num_samples - 1);
        
        // İlk noktayı ekle
        frontier.sample_points.push_back(frontier.points.front());
        
        double accumulated = 0.0;
        double next_sample_at = interval_length;
        
        for (size_t i = 1; i < frontier.points.size() && frontier.sample_points.size() < num_samples - 1; ++i) {
            double dx = frontier.points[i].x - frontier.points[i-1].x;
            double dy = frontier.points[i].y - frontier.points[i-1].y;
            double segment_len = std::hypot(dx, dy);
            
            while (accumulated + segment_len >= next_sample_at - 1e-6 && frontier.sample_points.size() < num_samples - 1) {
                // Bu segment'te sample noktası var
                double ratio = (next_sample_at - accumulated) / segment_len;
                if (ratio > 1.0) ratio = 1.0;
                
                geometry_msgs::Point sample;
                sample.x = frontier.points[i-1].x + ratio * dx;
                sample.y = frontier.points[i-1].y + ratio * dy;
                sample.z = 0.0;
                frontier.sample_points.push_back(sample);
                
                next_sample_at += interval_length;
            }
            accumulated += segment_len;
        }
        
        // Son noktayı ekle
        frontier.sample_points.push_back(frontier.points.back());
    }
 

    // void FrontierSearch::processCompletionScores(std::vector<Frontier>& frontier_list, const cv::Mat& global_live_cm)
    // {
    //     const bool need_completion = (use_completed_map_ == 1);
    //     if (!need_completion || frontier_list.empty()) {
    //         for (auto &f : frontier_list) {
    //             f.completion_known_score = 0.0;
    //             f.completion_obstacle_score = 0.0;
    //             f.completion_free_score = 0.0;
    //         }
    //         return;
    //     }

    //     const unsigned char UNKNOWN_U8 = 205;
    //     const unsigned char OCC_THRESHOLD = 100;

    //     for (auto &f : frontier_list) {
    //         // En kritik senkronizasyon: safest_point'i orta noktaya (centroid) çekiyoruz
    //         //f.safest_point = f.centroid;

    //         cv::Mat completed_patch;
    //         cv::Mat cur_patch;
    //         bool ok = false;

    //         try {
    //             ok = getCompletedRegionAroundFrontier(f.centroid.x, f.centroid.y, completed_patch, cur_patch, global_live_cm);
    //         }
    //         catch (const std::exception &e) { ok = false; }

    //         if (!ok || completed_patch.empty()) continue;

    //         const int rows = completed_patch.rows;
    //         const int cols = completed_patch.cols;
    //         int known_count = 0, obstacle_count = 0, free_count = 0;

    //         for (int r = 0; r < rows; ++r) {
    //             const unsigned char *row_ptr = completed_patch.ptr<unsigned char>(r);
    //             for (int c = 0; c < cols; ++c) {
    //                 unsigned char v = row_ptr[c];
    //                 if (v == UNKNOWN_U8) continue;
                    
    //                 known_count++;
                    
    //                 // ✅ DOĞRU MANTIK: Koyu renk (<100) engeldir, açık renk (>100) boşluktur.
    //                 if (v < OCC_THRESHOLD) {
    //                     obstacle_count++;
    //                 } else {
    //                     free_count++;
    //                 }
    //             }
    //         }

    //         // Patch'in tam orta noktası model tarafından duvar (obstacle) olarak tahmin edilmiş mi?
            
    //         const int mid_r = rows / 2;
    //         const int mid_c = cols / 2;
    //         const unsigned char OCC_THRESHOLD = 100;

    //         // ✅ YENİ: MERKEZ KOMŞULUĞUNDA DUVAR TARAMASI (Örn: 5x5 alan)
    //         int center_obstacle_pixels = 0;
    //         int kernel_size = 2; // merkezden 2 birim her yöne (toplam 5x5 alan)
    //         int total_kernel_pixels = 0;

    //         for (int kr = -kernel_size; kr <= kernel_size; ++kr) {
    //             for (int kc = -kernel_size; kc <= kernel_size; ++kc) {
    //                 int r = mid_r + kr;
    //                 int c = mid_c + kc;
    //                 if (r >= 0 && r < rows && c >= 0 && c < cols) {
    //                     total_kernel_pixels++;
    //                     if (completed_patch.at<uchar>(r, c) < OCC_THRESHOLD) {
    //                         center_obstacle_pixels++;
    //                     }
    //                 }
    //             }
    //         }

    //         // Eğer merkezin 5x5'lik alanının %40'ından fazlası duvarda kalıyorsa 'on_wall' diyelim
    //         f.predicted_on_wall = (static_cast<double>(center_obstacle_pixels) / total_kernel_pixels > 0.4);



    //         double total_pixels = (double)(rows * cols);
    //         // if (total_pixels > 0) {
    //         //     f.completion_known_score = static_cast<double>(known_count) / total_pixels;
    //         //     f.completion_obstacle_score = static_cast<double>(obstacle_count) / total_pixels;
    //         //     f.completion_free_score = static_cast<double>(free_count) / total_pixels;
    //         // }

    //         if (known_count > 0) {
    //             f.completion_known_score  = static_cast<double>(known_count)  / total_pixels; // bu kalabilir, "ne kadar tahmin edildi"
    //             f.completion_obstacle_score = static_cast<double>(obstacle_count) / known_count;
    //             f.completion_free_score     = static_cast<double>(free_count)     / known_count;
    //         }

    //         //analyzeWallsAndGaps(completed_patch, f);
    //     }
    // }  

    bool FrontierSearch::cropFromCostmap(double wx, double wy, int P, cv::Mat& dst) {
    unsigned int mx, my;
        if (!costmap_->worldToMap(wx, wy, mx, my)) return false;

        dst = cv::Mat(P, P, CV_8UC1, cv::Scalar(205)); // Varsayılan: Unknown
        int half = P / 2;
        
        for (int dy = -half; dy < half + (P % 2); ++dy) {
            for (int dx = -half; dx < half + (P % 2); ++dx) {
                int cur_mx = (int)mx + dx;
                int cur_my = (int)my + dy;
                
                if (cur_mx >= 0 && cur_mx < (int)costmap_->getSizeInCellsX() &&
                    cur_my >= 0 && cur_my < (int)costmap_->getSizeInCellsY()) {
                    
                    unsigned char c = costmap_->getCost(cur_mx, cur_my);
                    unsigned char v;
                    if (c == 255) v = 205;      // Unknown
                    else if (c == 0) v = 254;   // Free
                    else v = 0;                 // Obstacle
                    
                    // OpenCV koordinatlarına çevir (Y eksenini çevirerek)
                    int py = (P - 1) - (dy + half);
                    int px = dx + half;
                    if (py >= 0 && py < P && px >= 0 && px < P) {
                        dst.at<uchar>(py, px) = v;
                    }
                }
            }
        }
        return true;
    }

    void FrontierSearch::processCompletionScores(std::vector<Frontier>& frontier_list)
    {
        const unsigned char OCC_THRESHOLD = 100;
        const int P = rect_size_;
        const int mid = P / 2;

        for (auto &f : frontier_list) {
            FrontierKey key = getFrontierKey(f.centroid.x, f.centroid.y);
            auto cache_it = completed_patch_cache_.find(key);
            
            if (cache_it == completed_patch_cache_.end() || !cache_it->second.valid) continue;
            
            const auto& cache_data = cache_it->second;

            // ✅ 5x5 KERNEL DUVAR KONTROLÜ (Maliyet için hayati)
            int center_obs_pixels = 0;
            for (int r = mid-2; r <= mid+2; ++r) {
                for (int c = mid-2; c <= mid+2; ++c) {
                    // Sınır kontrolüne gerek yok çünkü yamalar her zaman PxP
                    // frontier_search.cpp:587 civarı
                    if (cache_data.patch.at<unsigned char>(r, c) < OCC_THRESHOLD) { 
                        center_obs_pixels++;
                    }
                }
            }
            f.predicted_on_wall = (center_obs_pixels > 8); 
            //f.center_wall_density = center_obs_pixels / 25.0;

            // ✅ FREE REWARD HESABI (Sıfır Döngü, Sadece Matematik!)
            // P*P'ye bölerek 0.0 - 1.0 arası bir skor elde ediyoruz
            f.completion_free_score = static_cast<double>(
                std::max(0, cache_data.predicted_free_count - cache_data.current_free_count)
            ) / (P * P);
        }
    }


    void FrontierSearch::closeSmallGapsInMap(cv::Mat& map_img,
                                         double door_threshold_m,
                                         bool seal_free_slits /*=false*/) const
    {
        if (map_img.empty() || map_img.type() != CV_8UC1) return;
        if (!costmap_) return;

        const double res = costmap_->getResolution();
        if (!(res > 0.0)) return;

        // kernel size in cells (odd, >=3)
        int cells = static_cast<int>(std::round(door_threshold_m / res));
        cells = std::max(3, cells);
        if ((cells & 1) == 0) cells += 1; // force odd

        // Build foreground=OBSTACLE mask (255=obstacle, 0=else)
        cv::Mat obst_fg(map_img.rows, map_img.cols, CV_8UC1);
        for (int y = 0; y < map_img.rows; ++y) {
            const uchar* src = map_img.ptr<uchar>(y);
            uchar* dst = obst_fg.ptr<uchar>(y);
            for (int x = 0; x < map_img.cols; ++x) {
                dst[x] = (src[x] == OBSTACLE_U8) ? 255 : 0;
            }
        }

        // Morphological closing on "walls" (foreground)
        cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(cells, cells));
        cv::Mat closed_fg;
        cv::morphologyEx(obst_fg, closed_fg, cv::MORPH_CLOSE, kernel);

        // Pixels that became wall due to closing (newly-added wall)
        // new_wall_mask = closed_fg==255 AND obst_fg==0
        cv::Mat new_wall_mask;
        {
            cv::Mat was_not_wall;
            cv::compare(obst_fg, 255, was_not_wall, cv::CMP_NE);   // 255 where obst_fg != 255
            cv::Mat is_wall_now;
            cv::compare(closed_fg, 255, is_wall_now, cv::CMP_EQ);  // 255 where closed_fg == 255
            cv::bitwise_and(is_wall_now, was_not_wall, new_wall_mask);
        }

        int sealed_unknown = 0, sealed_free = 0;

        // Apply sealing: UNKNOWN → OBSTACLE; optionally FREE → OBSTACLE
        for (int y = 0; y < map_img.rows; ++y) {
            uchar* m = map_img.ptr<uchar>(y);
            const uchar* add = new_wall_mask.ptr<uchar>(y);
            for (int x = 0; x < map_img.cols; ++x) {
                if (add[x] == 255) {
                    if (m[x] == UNKNOWN_U8) {
                        m[x] = OBSTACLE_U8;
                        ++sealed_unknown;
                    } else if (seal_free_slits && m[x] == KNOWN_U8) {
                        m[x] = OBSTACLE_U8;
                        ++sealed_free;
                    }
                }
            }
        }

        ROS_INFO("Gap closing: kernel=%dx%d (%.2fm), sealed UNKNOWN=%d, sealed FREE=%d (seal_free=%s)",
                 cells, cells, cells*res, sealed_unknown, sealed_free,
                 seal_free_slits ? "true" : "false");
    }

    void FrontierSearch::fillWallGaps(cv::Mat& map_img, double max_gap_width_m) const
    {
        if (map_img.empty() || !costmap_) {
            ROS_ERROR("Map is empty or costmap is null!");
            return;
        }
        
        const double res = costmap_->getResolution();
        const int max_gap = static_cast<int>(std::round(max_gap_width_m / res));
        
        ROS_INFO("fillWallGaps: threshold=%.2fm=%d cells, map=%dx%d", 
                max_gap_width_m, max_gap, map_img.cols, map_img.rows);
        
        // Check what OBSTACLE_U8 value is
        ROS_INFO("OBSTACLE_U8 value: %d", (int)OBSTACLE_U8);
        
        const int rows = map_img.rows;
        const int cols = map_img.cols;
        
        std::vector<cv::Point> pixels_to_fill;
        
        // For EVERY pixel in the map
        for (int y = 0; y < rows; ++y) {
            for (int x = 0; x < cols; ++x) {
                
                uchar center = map_img.at<uchar>(y, x);
                
                // Skip if this pixel is already an obstacle
                if (center == OBSTACLE_U8) continue;
                
                // Check 4 directions: up, down, left, right
                // UP: check if there's an obstacle above and below within max_gap
                if (y >= max_gap && y < rows - max_gap) {
                    bool obstacle_above = false;
                    bool obstacle_below = false;
                    int dist_above = 0;
                    int dist_below = 0;
                    
                    for (int d = 1; d <= max_gap; ++d) {
                        if (map_img.at<uchar>(y - d, x) == OBSTACLE_U8) {
                            obstacle_above = true;
                            dist_above = d;
                            break;
                        }
                    }
                    
                    for (int d = 1; d <= max_gap; ++d) {
                        if (map_img.at<uchar>(y + d, x) == OBSTACLE_U8) {
                            obstacle_below = true;
                            dist_below = d;
                            break;
                        }
                    }
                    
                    if (obstacle_above && obstacle_below && (dist_above + dist_below) <= max_gap) {
                        pixels_to_fill.push_back(cv::Point(x, y));
                        continue;
                    }
                }
                
                // LEFT-RIGHT: check if there's an obstacle left and right within max_gap
                if (x >= max_gap && x < cols - max_gap) {
                    bool obstacle_left = false;
                    bool obstacle_right = false;
                    int dist_left = 0;
                    int dist_right = 0;
                    
                    for (int d = 1; d <= max_gap; ++d) {
                        if (map_img.at<uchar>(y, x - d) == OBSTACLE_U8) {
                            obstacle_left = true;
                            dist_left = d;
                            break;
                        }
                    }
                    
                    for (int d = 1; d <= max_gap; ++d) {
                        if (map_img.at<uchar>(y, x + d) == OBSTACLE_U8) {
                            obstacle_right = true;
                            dist_right = d;
                            break;
                        }
                    }
                    
                    if (obstacle_left && obstacle_right && (dist_left + dist_right) <= max_gap) {
                        pixels_to_fill.push_back(cv::Point(x, y));
                    }
                }
            }
        }
        
        // Fill the pixels
        for (const auto& pt : pixels_to_fill) {
            map_img.at<uchar>(pt.y, pt.x) = OBSTACLE_U8;
        }
        
        ROS_INFO("Filled %zu gap pixels", pixels_to_fill.size());
    }





    // Detects frontiers inside narrow gaps between parallel walls that robot can't navigate.
    // Wall A ║         ║ Wall B
    //        ║         ║
    //        ║ gap<35cm║
    //        ║    ↓    ║
    //        ║ FRONTIER║
    //        ║    ║    ║
    //        ║    ║    ║
    //        ║         ║

    // ╔════════════════════════════════╗
    // ║          Room                  ║
    // ║                                ║
    // ║  ╔══╗  ←gap→  ╔══╗            ║
    // ║  ║  ║ FRONTIER ║  ║            ║  ← Narrow corridor
    // ║  ║  ║    ↓     ║  ║            ║     (frontier trapped)
    // ║  ║  ║    ║     ║  ║            ║
    // ║  ╚══╝          ╚══╝            ║
    // ╚════════════════════════════════╝
    bool FrontierSearch::isTrappedBetweenWalls(const Frontier& frontier) const
    {
        if (!costmap_ || frontier.points.size() < 3) return false;

        const double res = costmap_->getResolution();
        
        const double max_traversable_gap_m = trapped_max_traversable_gap_m_;
        const double wall_detect_range_m = trapped_wall_detect_range_m_;
        const double min_obstacle_ratio = trapped_min_obstacle_ratio_;
        const double min_samples_agree = trapped_min_samples_agree_;
        const double min_frontier_length = trapped_min_frontier_length_;
        const double max_frontier_length = trapped_max_frontier_length_;
        const int min_samples = 7;  // Keep hardcoded
        
        // --- Frontier orientation ---
        const auto& a = frontier.points.front();
        const auto& b = frontier.points.back();
        double dx = b.x - a.x;
        double dy = b.y - a.y;
        double L = std::hypot(dx, dy);
        
        if (L < min_frontier_length || L > max_frontier_length) return false;

        // Normalize tangent (along frontier)
        double tx = dx / L;
        double ty = dy / L;

        // Perpendicular (toward walls)
        double nx = -ty;
        double ny = tx;

        const int samples = std::max(min_samples, 
                                    std::min((int)(L / 0.1), (int)frontier.points.size()));

        // --- IMPROVED: Measure actual distance to walls on each side ---
        auto measureDistanceToWall = [&](double sign_nx, double sign_ny) -> double {
            int steps = (int)(wall_detect_range_m / res);
            std::vector<double> distances;
            
            for (int i = 0; i < samples; ++i) {
                int idx = (i * frontier.points.size()) / samples;
                const auto& pt = frontier.points[idx];
                
                // Cast ray perpendicular to frontier
                for (int s = 1; s <= steps; ++s) {
                    double wx = pt.x + sign_nx * s * res;
                    double wy = pt.y + sign_ny * s * res;
                    unsigned int mx, my;
                    if (!costmap_->worldToMap(wx, wy, mx, my)) break;
                    
                    unsigned char c = costmap_->getCost(mx, my);
                    if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                        // Found wall at distance s * res
                        distances.push_back(s * res);
                        break;
                    }
                }
            }
            
            if (distances.empty()) return -1.0; // No wall found
            
            // Return median distance (robust to outliers)
            std::sort(distances.begin(), distances.end());
            return distances[distances.size() / 2];
        };

        double left_wall_dist = measureDistanceToWall(+nx, +ny);
        double right_wall_dist = measureDistanceToWall(-nx, -ny);

        // --- CHECK 1: Both sides must have walls within range ---
        if (left_wall_dist < 0 || right_wall_dist < 0) return false;

        // --- CHECK 2: Total gap width must be too narrow ---
        double total_gap_width = left_wall_dist + right_wall_dist;
        if (total_gap_width >= max_traversable_gap_m) {
            return false; // Gap is wide enough, not trapped
        }

        // --- CHECK 3: Per-sample consistency check ---
        auto checkConsistentWalls = [&](double sign_nx, double sign_ny) -> bool {
            int steps = (int)(wall_detect_range_m / res);
            int samples_with_wall = 0;
            
            for (int i = 0; i < samples; ++i) {
                int idx = (i * frontier.points.size()) / samples;
                const auto& pt = frontier.points[idx];
                
                int obstacle_count = 0;
                int total = 0;
                
                for (int s = 1; s <= steps; ++s) {
                    double wx = pt.x + sign_nx * s * res;
                    double wy = pt.y + sign_ny * s * res;
                    unsigned int mx, my;
                    if (!costmap_->worldToMap(wx, wy, mx, my)) continue;
                    
                    total++;
                    unsigned char c = costmap_->getCost(mx, my);
                    if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                        obstacle_count++;
                    }
                }
                
                if (total > 0 && (double)obstacle_count / total > min_obstacle_ratio) {
                    samples_with_wall++;
                }
            }
            
            return (double)samples_with_wall / samples >= min_samples_agree;
        };

        bool left_consistent = checkConsistentWalls(+nx, +ny);
        bool right_consistent = checkConsistentWalls(-nx, -ny);

        if (!left_consistent || !right_consistent) return false;

        // --- CHECK 4: Verify no openings/gaps in walls ---
        // If gap is truly trapped, walls should be continuous
        auto hasOpenings = [&]() -> bool {
            // Check if there are breaks in the wall pattern along the frontier
            for (int i = 0; i < samples - 1; ++i) {
                int idx1 = (i * frontier.points.size()) / samples;
                int idx2 = ((i + 1) * frontier.points.size()) / samples;
                
                const auto& pt1 = frontier.points[idx1];
                const auto& pt2 = frontier.points[idx2];
                
                // Check if consecutive points have very different wall distances
                // This would indicate an opening/doorway
                auto checkPoint = [&](const auto& pt, double sign) -> double {
                    int steps = (int)(wall_detect_range_m / res);
                    for (int s = 1; s <= steps; ++s) {
                        unsigned int mx, my;
                        if (!costmap_->worldToMap(pt.x + sign * nx * s * res, 
                                                pt.y + sign * ny * s * res, mx, my)) break;
                        if (costmap_->getCost(mx, my) >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                            return s * res;
                        }
                    }
                    return -1.0;
                };
                
                double d1_left = checkPoint(pt1, +1.0);
                double d2_left = checkPoint(pt2, +1.0);
                
                // If one point has wall and next doesn't, there's an opening
                if ((d1_left > 0 && d2_left < 0) || (d1_left < 0 && d2_left > 0)) {
                    return true;
                }
            }
            return false;
        };

        if (hasOpenings()) return false; // There's a gap/opening, not fully trapped

        // --- PASSED ALL CHECKS: This is a trapped frontier ---
        // ROS_INFO_THROTTLE(5.0,
        //     "Filtered trapped frontier at (%.2f, %.2f): "
        //     "gap_width=%.2fm (left=%.2fm, right=%.2fm), length=%.2fm",
        //     frontier.centroid.x, frontier.centroid.y,
        //     total_gap_width, left_wall_dist, right_wall_dist, L);
        
        return true;
    }

    // Detects thin obstacle artifacts (SLAM noise) that falsely connect two separate walls.
    // Wall A              Wall B
    //           ║                   ║
    //           ║                   ║
    //     Unknown ═══THIN═════ Unknown
    //           ║   BRIDGE      ║
    //           ║  (artifact)    ║
    //           ║   ↑FRONTIER    ║
    //           ║                   ║

    // 1) İlk resim için: Unknown içinde ince known çizgi üzerindeki frontier'ları ele
    //
    // Senaryо: Unknown alanda, bir duvardan diğer duvara uzanan ince known/lethal "köprü"
    // üzerinde oluşan frontier. SLAM noise'dan kaynaklanan sahte duvar parçaları.
    //
    // ╔════════╗              ╔════════╗
    // ║ Room A ║              ║ Room B ║
    // ║        ║              ║        ║
    // ║     Unknown    ═══    Unknown  ║  ← Thin bridge artifact
    // ║        ║       ↑      ║        ║     (frontier here)
    // ║        ║   FRONTIER   ║        ║
    // ╚════════╝              ╚════════╝
    bool FrontierSearch::isThinBridgeFrontier(const Frontier& frontier) const
    {
        if (!costmap_ || frontier.points.size() < 3) return false;

        const double res = costmap_->getResolution();
        
        // ✅ USE PARAMETERS
        const double min_length_m = bridge_min_length_;
        const double max_thickness_per_side_m = bridge_max_thickness_per_side_m_;
        const double wall_search_m = bridge_wall_search_m_;
        const double min_unknown_ratio_per_side = bridge_min_unknown_ratio_per_side_;
        const double min_thin_ratio = bridge_min_thin_ratio_;
        const double min_unknown_ratio = bridge_min_unknown_ratio_;
        const int samples = std::min(9, (int)frontier.points.size());  // Keep max=9 hardcoded
        const int max_island_cells = bridge_max_island_cells_;
        const double unknown_lookahead_m = bridge_unknown_lookahead_m_;  // ✅ NEW - was hardcoded in lambda

        // Frontier length check
        const auto& a = frontier.points.front();
        const auto& b = frontier.points.back();
        double L = std::hypot(b.x - a.x, b.y - a.y);
        if (L < min_length_m) return false;

        // Frontier orientation
        double tx = (b.x - a.x) / L;
        double ty = (b.y - a.y) / L;
        
        // Normal vectors
        double nx1 = -ty, ny1 = tx;
        double nx2 = ty, ny2 = -tx;

        int thin_samples = 0;
        int unknown_both_sides_samples = 0;

        for (int i = 0; i < samples; ++i) {
            int idx = (i * frontier.points.size()) / samples;
            const auto& p = frontier.points[idx];

            // --- FIXED: Measure thickness PER SIDE ---
            auto measureThicknessPerSide = [&](double nx, double ny) -> double {
                int steps = (int)(max_thickness_per_side_m / res) + 2;
                int known = 0;
                for (int s = 1; s <= steps; ++s) {
                    unsigned int mx, my;
                    if (!costmap_->worldToMap(p.x + nx*res*s, p.y + ny*res*s, mx, my)) break;
                    unsigned char c = costmap_->getCost(mx, my);
                    if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                        known++;
                    } else {
                        break;
                    }
                }
                return known * res;
            };

            double thick1 = measureThicknessPerSide(nx1, ny1);
            double thick2 = measureThicknessPerSide(nx2, ny2);
            
            // BOTH sides must be individually thin
            if (thick1 <= max_thickness_per_side_m && thick2 <= max_thickness_per_side_m) {
                thin_samples++;
            }

            // --- FIXED: Unknown must be on BOTH SIDES SEPARATELY ---
            auto hasUnknownOnBothSides = [&]() -> bool {
                int steps = (int)(unknown_lookahead_m / res);  // Look 0.4m deep
                
                auto unknownRatioOnSide = [&](double nx, double ny) -> double {
                    int unk = 0, total = 0;
                    for (int s = 2; s <= steps; ++s) { // Skip immediate obstacle
                        unsigned int mx, my;
                        if (!costmap_->worldToMap(p.x + nx*res*s, p.y + ny*res*s, mx, my)) continue;
                        unsigned char c = costmap_->getCost(mx, my);
                        total++;
                        if (c == costmap_2d::NO_INFORMATION) unk++;
                    }
                    return (total > 0) ? (double)unk / total : 0.0;
                };
                
                double unk1 = unknownRatioOnSide(nx1, ny1);
                double unk2 = unknownRatioOnSide(nx2, ny2);
                
                // BOTH sides must have >65% unknown separately
                return (unk1 > min_unknown_ratio_per_side) && 
                    (unk2 > min_unknown_ratio_per_side);
            };

            if (hasUnknownOnBothSides()) {
                unknown_both_sides_samples++;
            }
        }

        // --- STRICT THRESHOLDS: 70% agreement required ---
        bool is_thin = (double)thin_samples / samples >= min_thin_ratio;
        bool has_unknown = (double)unknown_both_sides_samples / samples >= min_unknown_ratio;

        if (!is_thin || !has_unknown) return false;

        // --- IMPROVED: Wall detection perpendicular to frontier ---
        auto hasWallPerpendicular = [&](const geometry_msgs::Point& endpoint) -> bool {
            int steps = (int)(wall_search_m / res);
            
            // Check perpendicular directions (along frontier direction)
            // This detects if bridge connects two walls
            int wall_found = 0;
            
            // Forward direction
            for (int s = 1; s <= steps; ++s) {
                unsigned int mx, my;
                if (!costmap_->worldToMap(endpoint.x + tx*res*s, endpoint.y + ty*res*s, mx, my)) break;
                unsigned char c = costmap_->getCost(mx, my);
                if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                    wall_found++;
                    break;
                }
            }
            
            // Backward direction
            for (int s = 1; s <= steps; ++s) {
                unsigned int mx, my;
                if (!costmap_->worldToMap(endpoint.x - tx*res*s, endpoint.y - ty*res*s, mx, my)) break;
                unsigned char c = costmap_->getCost(mx, my);
                if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                    wall_found++;
                    break;
                }
            }
            
            return wall_found >= 2; // Walls on both ends (bridge pattern)
        };

        bool wall_at_start = hasWallPerpendicular(a);
        bool wall_at_end = hasWallPerpendicular(b);

        // --- NEW: Island size check (similar to exterior noise) ---
        auto checkIslandSize = [&]() -> bool {
            // Sample middle point
            int mid_idx = frontier.points.size() / 2;
            const auto& mid = frontier.points[mid_idx];
            unsigned int mx, my;
            if (!costmap_->worldToMap(mid.x, mid.y, mx, my)) return false;
            
            // Find first obstacle near frontier
            for (int s = 1; s <= 3; ++s) {
                unsigned int tx, ty;
                if (costmap_->worldToMap(mid.x + nx1*res*s, mid.y + ny1*res*s, tx, ty)) {
                    if (costmap_->getCost(tx, ty) >= costmap_2d::LETHAL_OBSTACLE) {
                        // Use same island check as exterior noise
                        // (you'd need to expose lethalIslandSize or duplicate it)
                        // For now, simplified version:
                        return true; // Placeholder - implement full check
                    }
                }
            }
            return true;
        };

        return wall_at_start && wall_at_end && is_thin && has_unknown;
    }

    // 2) İkinci resim için: Köşede kalan küçük unknown üçgen/alan
    //
    // Senaryo: L-şeklindeki duvar köşesinde, küçük görülmemiş alan nedeniyle
    // oluşan frontier. Unknown alan çok küçük, frontier kısa.
    //
    bool FrontierSearch::isSmallCornerPocket(const Frontier& frontier) const
    {
        if (!costmap_ || frontier.points.size() < 2) return false;

        const double res = costmap_->getResolution();
        
        const double max_frontier_length = corner_max_frontier_length_;
        const double max_unknown_depth = corner_max_unknown_depth_;
        const double max_unknown_volume = corner_max_unknown_volume_;
        const double min_wall_coverage = corner_min_wall_coverage_;
        const double corner_angle_threshold = corner_angle_threshold_;
        const double min_corner_confidence = corner_min_confidence_;
        const int samples = std::min(7, (int)frontier.points.size());
        const double wall_search_distance = corner_wall_search_distance_;  
        const double min_pocket_depth = corner_min_pocket_depth_; 

        // --- Frontier length check ---
        const auto& a = frontier.points.front();
        const auto& b = frontier.points.back();
        double L = std::hypot(b.x - a.x, b.y - a.y);
        if (L > max_frontier_length) return false;

        // --- Frontier orientation ---
        double tx = (b.x - a.x) / L;
        double ty = (b.y - a.y) / L;
        double nx1 = -ty, ny1 = tx;
        double nx2 = ty, ny2 = -tx;

        // --- IMPROVED: Multi-point depth measurement ---
        auto measureUnknownDepth = [&](double nx, double ny) -> std::vector<double> {
            std::vector<double> depths;
            int max_steps = (int)(max_unknown_depth / res);
            
            for (int i = 0; i < samples; ++i) {
                int idx = (i * frontier.points.size()) / samples;
                const auto& pt = frontier.points[idx];
                
                int unk_count = 0;
                for (int s = 1; s <= max_steps; ++s) {
                    unsigned int mx, my;
                    if (!costmap_->worldToMap(pt.x + nx*res*s, pt.y + ny*res*s, mx, my)) break;
                    unsigned char c = costmap_->getCost(mx, my);
                    
                    if (c == costmap_2d::NO_INFORMATION) {
                        unk_count++;
                    } else if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                        break; // Hit wall
                    } else {
                        break; // Hit free space (not a pocket)
                    }
                }
                
                if (unk_count > 0) {
                    depths.push_back(unk_count * res);
                }
            }
            return depths;
        };

        auto depths1 = measureUnknownDepth(nx1, ny1);
        auto depths2 = measureUnknownDepth(nx2, ny2);

        // Choose unknown side (more depth measurements)
        auto& depths = (depths1.size() >= depths2.size()) ? depths1 : depths2;
        
        if (depths.empty()) return false; // No unknown space detected

        // --- IMPROVED: Statistical depth analysis ---
        double avg_depth = std::accumulate(depths.begin(), depths.end(), 0.0) / depths.size();
        double max_depth = *std::max_element(depths.begin(), depths.end());
        
        if (max_depth > max_unknown_depth) return false;

        // --- IMPROVED: Volume estimation using trapezoidal approximation ---
        // Sort depths to get profile
        std::vector<double> sorted_depths = depths;
        std::sort(sorted_depths.begin(), sorted_depths.end());
        
        // Estimate volume as sum of rectangular slices
        double segment_length = L / std::max(1, (int)depths.size() - 1);
        double estimated_volume = 0.0;
        for (double d : depths) {
            estimated_volume += segment_length * d;
        }
        
        if (estimated_volume > max_unknown_volume) return false;

        // --- NEW: Corner angle detection ---
        auto detectCornerAngle = [&](const geometry_msgs::Point& point) -> double {
            const double search_dist = wall_search_distance; 
            int steps = (int)(search_dist / res);
            
            // Find walls in different directions
            std::vector<double> wall_angles;
            
            for (int dir = 0; dir < 8; ++dir) {
                double angle = dir * M_PI / 4.0;
                double dx = std::cos(angle);
                double dy = std::sin(angle);
                
                for (int s = 1; s <= steps; ++s) {
                    unsigned int mx, my;
                    if (!costmap_->worldToMap(point.x + dx*res*s, point.y + dy*res*s, mx, my)) break;
                    unsigned char c = costmap_->getCost(mx, my);
                    
                    if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                        wall_angles.push_back(angle);
                        break;
                    }
                }
            }
            
            if (wall_angles.size() < 2) return 180.0; // No corner detected
            
            // Find minimum angle between any two walls
            double min_angle = 180.0;
            for (size_t i = 0; i < wall_angles.size(); ++i) {
                for (size_t j = i + 1; j < wall_angles.size(); ++j) {
                    double diff = std::abs(wall_angles[i] - wall_angles[j]) * 180.0 / M_PI;
                    // Handle wrap-around
                    if (diff > 180.0) diff = 360.0 - diff;
                    min_angle = std::min(min_angle, diff);
                }
            }
            
            return min_angle;
        };

        // Check corner angle at centroid
        double corner_angle = detectCornerAngle(frontier.centroid);
        if (corner_angle > corner_angle_threshold) {
            return false; // Not a sharp corner (obtuse or no corner)
        }

        // --- IMPROVED: Wall coverage with directional analysis ---
        auto analyzeWallCoverage = [&]() -> std::tuple<double, bool> {
            const double search_radius = wall_search_distance;
            int steps = (int)(search_radius / res);
            int wall_directions = 0;
            const int total_directions = 8;
            
            std::vector<bool> has_wall(total_directions, false);
            
            for (int dir = 0; dir < total_directions; ++dir) {
                double angle = dir * M_PI / 4.0;
                double dx = std::cos(angle);
                double dy = std::sin(angle);
                
                for (int s = 1; s <= steps; ++s) {
                    unsigned int mx, my;
                    if (!costmap_->worldToMap(frontier.centroid.x + dx*res*s, 
                                            frontier.centroid.y + dy*res*s, mx, my)) break;
                    unsigned char c = costmap_->getCost(mx, my);
                    
                    if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                        has_wall[dir] = true;
                        wall_directions++;
                        break;
                    }
                }
            }
            
            double wall_ratio = (double)wall_directions / total_directions;
            
            // Check for corner pattern: adjacent walls with gaps
            // True corner should have 3-5 directions with walls (not all 8)
            bool corner_pattern = (wall_directions >= 3 && wall_directions <= 6);
            
            return std::make_tuple(wall_ratio, corner_pattern);
        };

        double wall_ratio;
        bool is_corner_pattern;
        std::tie(wall_ratio, is_corner_pattern) = analyzeWallCoverage();
            
        if (wall_ratio < min_wall_coverage) return false;
        if (!is_corner_pattern) return false; // Not a corner topology

        // --- NEW: Pocket consistency check ---
        // All samples should show similar pocket characteristics
        int pocket_samples = 0;
        for (const double& d : depths) {
            if (d > min_pocket_depth && d <= max_unknown_depth) {
                pocket_samples++;
            }
        }
        
        double pocket_consistency = (double)pocket_samples / depths.size();
        if (pocket_consistency < min_corner_confidence) return false;

        // --- PASSED ALL CHECKS ---
        ROS_INFO_THROTTLE(5.0,
            "Filtered small corner pocket at (%.2f, %.2f): "
            "length=%.2fm, avg_depth=%.2fm, max_depth=%.2fm, volume=%.3fm², "
            "corner_angle=%.1f°, wall_coverage=%.1f%%",
            frontier.centroid.x, frontier.centroid.y,
            L, avg_depth, max_depth, estimated_volume,
            corner_angle, wall_ratio * 100.0);
        
        return true;
    }

    void FrontierSearch::setRectSize(int s) { rect_size_ = std::max(1, s); }

    bool FrontierSearch::isNewFrontierCell(unsigned int idx,
                                        const std::vector<bool>& frontier_flag)
    {
        // Check if cell is within map bounds and is not already marked.
        // We can combine these with an early return.
        if (idx >= size_x_ * size_y_ || frontier_flag[idx]) {
            return false;
        }

        // A frontier cell must be an unknown space.
        if (map_[idx] != NO_INFORMATION) {
            return false;
        }

        // It must be adjacent to a free space.
        // The loop returns true immediately upon finding a free neighbor.
        for (unsigned nbr : nhood4(idx, *costmap_)) {
            // Check if neighbor is within bounds and is a free space.
            if (nbr < size_x_ * size_y_ && map_[nbr] == FREE_SPACE) {
            return true;
            }
        }

        // If the loop finishes without finding a free neighbor, it's not a frontier.
        return false;
    }

    void FrontierSearch::setGtImage(const cv::Mat& gt) { 
        gt_image_ = gt.clone(); 

    }
    
    void FrontierSearch::setCompletedMap(const cv::Mat& cm) { 
        std::lock_guard<std::recursive_mutex> lock(data_mutex_);
        completed_map_ = cm.clone(); 

        ROS_DEBUG("completed_map_ set externally");
    }
    
    void FrontierSearch::setYamlOriginRes(double yaml_x, double yaml_y, double yaml_res) {
        yaml_x_ = yaml_x; yaml_y_ = yaml_y; yaml_res_ = yaml_res;
    }
    
    void FrontierSearch::setMapSaverOriginRes(double org_x, double org_y, double res,
                                int pgm_w, int pgm_h) {
        map_org_x_ = org_x; map_org_y_ = org_y; map_res_ = res;
        pgm_w_ = pgm_w; pgm_h_ = pgm_h;
    }
    
    void FrontierSearch::setRectangleSize(int r) { rect_size_ = std::max(1, r); }
    
    void FrontierSearch::setUseCompletedMap(int flag) { 
        std::lock_guard<std::recursive_mutex> lock(data_mutex_);
        use_completed_map_ = flag; 
    }
    
    void FrontierSearch::setCompletionScales(double known_scale, double obstacle_scale) { 
        completion_known_scale_ = known_scale; 
        completion_obstacle_scale_ = obstacle_scale;
    } 

    /**
    * @brief Check if a row/column has a wall-like pattern (even fragmented)
    * @param values Pixel values along a row or column
    * @param min_wall_pixels Minimum number of obstacle pixels to consider it a wall
    * @return true if wall-like pattern detected
    */
    bool FrontierSearch::hasWallPattern(const std::vector<uchar>& values, 
                                        int min_wall_pixels) const {
        int obstacle_count = 0;
        int total_pixels = values.size();
        
        for (uchar val : values) {
            if (val == OBSTACLE_U8) {
                obstacle_count++;
            }
        }
        
        // Wall pattern if:
        // 1. Has minimum number of obstacle pixels, OR
        // 2. Has at least 25% obstacle density (for fragmented walls)
        return (obstacle_count >= min_wall_pixels) || 
            (obstacle_count >= total_pixels / 4);
    }

    std::vector<uchar> FrontierSearch::extractRow(const cv::Mat& mat, int row) const {
        std::vector<uchar> values;
        if (row < 0 || row >= mat.rows) return values;
        
        values.reserve(mat.cols);
        for (int x = 0; x < mat.cols; x++) {
            values.push_back(mat.at<uchar>(row, x));
        }
        return values;
    }

    std::vector<uchar> FrontierSearch::extractColumn(const cv::Mat& mat, int col) const {
        std::vector<uchar> values;
        if (col < 0 || col >= mat.cols) return values;
        
        values.reserve(mat.rows);
        for (int y = 0; y < mat.rows; y++) {
            values.push_back(mat.at<uchar>(y, col));
        }
        return values;
    }

    // ----------------------------------------------------------------------------
    // IMPROVED: Detect duplicate walls (handles fragmented & zigzag)
    // ----------------------------------------------------------------------------

    /**
    * @brief Detect if there are duplicate walls from GT shift
    * Handles fragmented SLAM walls (. . . .) and zigzags (1-3 pixel offset)
    * 
    * @param completed_patch Current completed_map patch (has GT + SLAM data)
    * @param costmap_patch Current costmap patch (only SLAM data)
    * @return true if duplicate walls detected (GT wall + SLAM wall nearby)
    */
    bool FrontierSearch::hasParallelDuplicateWalls(const cv::Mat& completed_patch, 
                                                const cv::Mat& costmap_patch) const {
        if (completed_patch.empty() || costmap_patch.empty()) return false;
        if (completed_patch.rows != costmap_patch.rows || 
            completed_patch.cols != costmap_patch.cols) return false;
        
        const int rows = completed_patch.rows;
        const int cols = completed_patch.cols;
        
        // Minimum wall length (must span at least 1/3 of patch)
        const int min_wall_length = std::min(rows, cols) / 3;
        //ROS_WARN("min_wall_length %d:", min_wall_length);
        
        // Maximum distance between walls to consider them duplicates
        // Increased to 5 pixels to handle zigzags
        const int max_wall_distance = 5;
        
        // =========================================================================
        // STEP 1: Find wall rows in completed_map (GT + SLAM combined)
        // =========================================================================
        std::vector<int> completed_wall_rows;
        for (int y = 0; y < rows; y++) {
            std::vector<uchar> row_values = extractRow(completed_patch, y);
            if (hasWallPattern(row_values, min_wall_length)) {
                completed_wall_rows.push_back(y);
            }
        }
        
        // =========================================================================
        // STEP 2: Find wall rows in costmap (SLAM only)
        // =========================================================================
        std::vector<int> slam_wall_rows;
        for (int y = 0; y < rows; y++) {
            std::vector<uchar> row_values = extractRow(costmap_patch, y);
            if (hasWallPattern(row_values, min_wall_length)) {
                slam_wall_rows.push_back(y);
            }
        }
        
        // =========================================================================
        // STEP 3: Check for duplicates in HORIZONTAL walls
        // =========================================================================
        // For each completed_map wall row, check if there's a SLAM wall within range
        for (int completed_row : completed_wall_rows) {
            for (int slam_row : slam_wall_rows) {
                int distance = std::abs(completed_row - slam_row);
                
                // If walls are within max_wall_distance, check if they're actually different
                if (distance > 0 && distance <= max_wall_distance) {
                    // Check if completed_map has MORE wall pixels than SLAM at completed_row
                    // This indicates GT added a wall that SLAM doesn't fully have
                    
                    int completed_walls = 0, slam_walls_at_completed = 0;
                    for (int x = 0; x < cols; x++) {
                        if (completed_patch.at<uchar>(completed_row, x) == OBSTACLE_U8) {
                            completed_walls++;
                        }
                        if (costmap_patch.at<uchar>(completed_row, x) == OBSTACLE_U8) {
                            slam_walls_at_completed++;
                        }
                    }
                    
                    // If completed_map has a solid wall but SLAM doesn't at this row,
                    // and SLAM has a wall nearby, they're duplicates
                    if (completed_walls >= min_wall_length && 
                        slam_walls_at_completed < min_wall_length / 2) {
                        
                        // ROS_WARN("🔍 Duplicate HORIZONTAL walls detected:");
                        // ROS_WARN("   Completed map row %d: %d wall pixels (likely GT)", 
                        //          completed_row, completed_walls);
                        // ROS_WARN("   SLAM wall at row %d: distance=%d pixels", 
                        //          slam_row, distance);
                        // ROS_WARN("   SLAM has %d pixels at GT row (fragmented/shifted)", 
                        //          slam_walls_at_completed);
                        return true;
                    }
                }
            }
        }
        
        // =========================================================================
        // STEP 4: Find wall columns in completed_map (GT + SLAM combined)
        // =========================================================================
        std::vector<int> completed_wall_cols;
        for (int x = 0; x < cols; x++) {
            std::vector<uchar> col_values = extractColumn(completed_patch, x);
            if (hasWallPattern(col_values, min_wall_length)) {
                completed_wall_cols.push_back(x);
            }
        }
        
        // =========================================================================
        // STEP 5: Find wall columns in costmap (SLAM only)
        // =========================================================================
        std::vector<int> slam_wall_cols;
        for (int x = 0; x < cols; x++) {
            std::vector<uchar> col_values = extractColumn(costmap_patch, x);
            if (hasWallPattern(col_values, min_wall_length)) {
                slam_wall_cols.push_back(x);
            }
        }
        
        // =========================================================================
        // STEP 6: Check for duplicates in VERTICAL walls
        // =========================================================================
        for (int completed_col : completed_wall_cols) {
            for (int slam_col : slam_wall_cols) {
                int distance = std::abs(completed_col - slam_col);
                
                if (distance > 0 && distance <= max_wall_distance) {
                    int completed_walls = 0, slam_walls_at_completed = 0;
                    for (int y = 0; y < rows; y++) {
                        if (completed_patch.at<uchar>(y, completed_col) == OBSTACLE_U8) {
                            completed_walls++;
                        }
                        if (costmap_patch.at<uchar>(y, completed_col) == OBSTACLE_U8) {
                            slam_walls_at_completed++;
                        }
                    }
                    
                    if (completed_walls >= min_wall_length && 
                        slam_walls_at_completed < min_wall_length / 2) {
                        
                        // ROS_WARN("🔍 Duplicate VERTICAL walls detected:");
                        // ROS_WARN("   Completed map col %d: %d wall pixels (likely GT)", 
                        //          completed_col, completed_walls);
                        // ROS_WARN("   SLAM wall at col %d: distance=%d pixels", 
                        //          slam_col, distance);
                        // ROS_WARN("   SLAM has %d pixels at GT col (fragmented/shifted)", 
                        //          slam_walls_at_completed);
                        return true;
                    }
                }
            }
        }
        
        return false;
    }

    std::vector<DuplicateWallPair> FrontierSearch::findDuplicateWalls(
        const cv::Mat& completed_patch, 
        const cv::Mat& costmap_patch) const {
        
        std::vector<DuplicateWallPair> duplicates;
        
        if (completed_patch.empty() || costmap_patch.empty()) return duplicates;
        if (completed_patch.rows != costmap_patch.rows || 
            completed_patch.cols != costmap_patch.cols) return duplicates;
        
        const int rows = completed_patch.rows;
        const int cols = completed_patch.cols;
        const int min_wall_length = std::min(rows, cols) / 3;
        const int max_wall_distance = 5;
        
        // =========================================================================
        // Find HORIZONTAL walls
        // =========================================================================
        
        std::vector<WallLine> completed_h_walls, slam_h_walls;
        
        for (int y = 0; y < rows; y++) {
            // Check completed_map
            std::vector<uchar> completed_row = extractRow(completed_patch, y);
            int completed_count = std::count(completed_row.begin(), completed_row.end(), OBSTACLE_U8);
            if (hasWallPattern(completed_row, min_wall_length)) {
                completed_h_walls.push_back(WallLine(y, true, false, completed_count));
            }
            
            // Check SLAM
            std::vector<uchar> slam_row = extractRow(costmap_patch, y);
            int slam_count = std::count(slam_row.begin(), slam_row.end(), OBSTACLE_U8);
            if (hasWallPattern(slam_row, min_wall_length)) {
                slam_h_walls.push_back(WallLine(y, true, true, slam_count));
            }
        }
        
        // Find horizontal duplicates
        for (const auto& comp_wall : completed_h_walls) {
            for (const auto& slam_wall : slam_h_walls) {
                int distance = std::abs(comp_wall.position - slam_wall.position);
                
                if (distance > 0 && distance <= max_wall_distance) {
                    // Check if completed has more pixels than SLAM at GT position
                    // This means GT filled in a wall that SLAM doesn't fully have
                    std::vector<uchar> slam_at_gt = extractRow(costmap_patch, comp_wall.position);
                    int slam_count_at_gt = std::count(slam_at_gt.begin(), slam_at_gt.end(), OBSTACLE_U8);
                    
                    if (comp_wall.pixel_count >= min_wall_length && 
                        slam_count_at_gt < min_wall_length / 2) {
                        duplicates.push_back(DuplicateWallPair(slam_wall, comp_wall, distance));
                    }
                }
            }
        }
        
        // =========================================================================
        // Find VERTICAL walls
        // =========================================================================
        
        std::vector<WallLine> completed_v_walls, slam_v_walls;
        
        for (int x = 0; x < cols; x++) {
            // Check completed_map
            std::vector<uchar> completed_col = extractColumn(completed_patch, x);
            int completed_count = std::count(completed_col.begin(), completed_col.end(), OBSTACLE_U8);
            if (hasWallPattern(completed_col, min_wall_length)) {
                completed_v_walls.push_back(WallLine(x, false, false, completed_count));
            }
            
            // Check SLAM
            std::vector<uchar> slam_col = extractColumn(costmap_patch, x);
            int slam_count = std::count(slam_col.begin(), slam_col.end(), OBSTACLE_U8);
            if (hasWallPattern(slam_col, min_wall_length)) {
                slam_v_walls.push_back(WallLine(x, false, true, slam_count));
            }
        }
        
        // Find vertical duplicates
        for (const auto& comp_wall : completed_v_walls) {
            for (const auto& slam_wall : slam_v_walls) {
                int distance = std::abs(comp_wall.position - slam_wall.position);
                
                if (distance > 0 && distance <= max_wall_distance) {
                    std::vector<uchar> slam_at_gt = extractColumn(costmap_patch, comp_wall.position);
                    int slam_count_at_gt = std::count(slam_at_gt.begin(), slam_at_gt.end(), OBSTACLE_U8);
                    
                    if (comp_wall.pixel_count >= min_wall_length && 
                        slam_count_at_gt < min_wall_length / 2) {
                        duplicates.push_back(DuplicateWallPair(slam_wall, comp_wall, distance));
                    }
                }
            }
        }
        
        return duplicates;
    }

    // Heuristic: filter skinny exterior line frontiers (wall-echo "antenna" lines).
    // Works best when frontier.points are ordered along the frontier.
    //
    // Tunables (all defaults are reasonable starting points):
    //  - max_thickness_cells: max obstacle thickness to call it a "thin line"
    //  - unknown_lookahead_m: how far into the unknown we look after the thin line
    //  - wall_search_m: how far toward the free side we search for a real wall
    //  - agree_ratio: fraction of sampled points that must agree to reject
    //
    // Assumptions:
    //  - costmap_ uses costmap_2d semantics (FREE_SPACE, NO_INFORMATION, obstacle >= INSCRIBED_INFLATED_OBSTACLE)
    //  - frontier.points are in world coords (x,y)

    bool FrontierSearch::isNoisyExteriorLineFrontier(const Frontier& frontier) const
    {
        if (!costmap_ || frontier.points.size() < 3) return false;


        // USE PARAMETERS
        const int max_thickness_cells = exterior_noise_max_thickness_cells_;
        const double unknown_lookahead_m = exterior_noise_unknown_lookahead_m_;
        const double wall_search_m = exterior_noise_wall_search_m_;
        const double agree_ratio = exterior_noise_agree_ratio_;
        const int max_samples = 9;  // Keep hardcoded
        const double min_length_m = exterior_noise_min_length_;
        const double island_radius_m = exterior_noise_island_radius_m_;
        const int island_cells_max = exterior_noise_island_cells_max_;

        const double res = costmap_->getResolution();
        const int unknown_lookahead_steps = std::max(1, (int)std::round(unknown_lookahead_m / res));
        const int wall_search_steps = std::max(1, (int)std::round(wall_search_m / res));
        const int island_radius_steps = std::max(1, (int)std::round(island_radius_m / res));

        // Orientation from endpoints
        const auto& a = frontier.points.front();
        const auto& b = frontier.points.back();
        double dx = b.x - a.x, dy = b.y - a.y;
        double L  = std::hypot(dx, dy);
        if (L < min_length_m) return false;
        double tx = dx / L, ty = dy / L;

        // Candidate normals
        double nx1 = -ty, ny1 =  tx;
        double nx2 =  ty, ny2 = -tx;

        // Helpers
        auto readCost = [&](double wx, double wy, unsigned int& mx, unsigned int& my, unsigned char& c)->bool {
            if (!costmap_->worldToMap(wx, wy, mx, my)) return false;
            c = costmap_->getCost(mx, my);
            return true;
        };
        auto isLethal = [&](unsigned char c)->bool {
            return c >= costmap_2d::LETHAL_OBSTACLE; // ignore inflated cells
        };

        // Choose the UNKNOWN side by comparing UNKNOWN ratios over a short window
        auto pickUnknownSide = [&](const geometry_msgs::Point& p)->int {
            auto unknownRatioAlong = [&](double nx, double ny)->double {
                int unk=0, tot=0;
                for (int s=1; s<=std::min(unknown_lookahead_steps, 4); ++s) {
                    unsigned int mx,my; unsigned char c;
                    if (!readCost(p.x + nx*res*s, p.y + ny*res*s, mx, my, c)) continue;
                    ++tot; if (c == costmap_2d::NO_INFORMATION) ++unk;
                }
                return (tot==0) ? 0.0 : (double)unk/tot;
            };
            double r1 = unknownRatioAlong(nx1, ny1);
            double r2 = unknownRatioAlong(nx2, ny2);
            return (r1 >= r2) ? +1 : -1;
        };

        // Small island (lethal-only) connected component size around a seed
        auto lethalIslandSize = [&](unsigned int sx, unsigned int sy)->int {
            const unsigned int w = costmap_->getSizeInCellsX();
            const unsigned int h = costmap_->getSizeInCellsY();
            std::vector<std::pair<unsigned int,unsigned int>> q;
            q.reserve(64);
            std::vector<uint8_t> vis((size_t)w*h, 0);
            auto idx = [&](unsigned int x, unsigned int y)->size_t { return (size_t)y*w + x; };

            auto push = [&](unsigned int x, unsigned int y){
                if (x>=w || y>=h) return;
                if (vis[idx(x,y)]) return;
                unsigned char c = costmap_->getCost(x,y);
                if (!isLethal(c)) return;
                vis[idx(x,y)] = 1;
                q.emplace_back(x,y);
            };

            push(sx,sy);
            for (size_t i=0; i<q.size(); ++i) {
                unsigned int x = q[i].first;
                unsigned int y = q[i].second; 
                // stop exploring far away
                if (std::abs((int)x-(int)sx) > island_radius_steps ||
                    std::abs((int)y-(int)sy) > island_radius_steps) continue;

                if (q.size() > (size_t)island_cells_max) break;
                if (x>0)   push(x-1,y);
                if (x+1<w) push(x+1,y);
                if (y>0)   push(x,y-1);
                if (y+1<h) push(x,y+1);
            }
            return (int)q.size();
        };

        const int samples = std::min(max_samples, (int)frontier.points.size());
        int agree = 0;

        for (int i = 0; i < samples; ++i)
        {
            const int idxp = (i * (int)frontier.points.size()) / samples;
            const auto& p  = frontier.points[idxp];

            // Decide UNKNOWN and FREE sides
            int sgn  = pickUnknownSide(p);
            double unx = (sgn > 0) ? nx1 : nx2, uny = (sgn > 0) ? ny1 : ny2;
            double fnx = -unx,      fny = -uny;

            // --- A) Thin lethal ribbon into UNKNOWN, then UNKNOWN behind it ---
            int obs_run = 0;
            bool ok_thin_then_unknown = false;
            for (int s=1; s<=unknown_lookahead_steps; ++s) {
                unsigned int mx,my; unsigned char c;
                if (!readCost(p.x + unx*res*s, p.y + uny*res*s, mx, my, c)) continue;

                if (isLethal(c)) {
                    ++obs_run;
                    if (obs_run > max_thickness_cells) { ok_thin_then_unknown = false; break; }
                } else if (c == costmap_2d::NO_INFORMATION) {
                    if (obs_run >= 1) { ok_thin_then_unknown = true; break; } // thin ribbon then unknown
                    else { ok_thin_then_unknown = false; break; }              // unknown immediately
                } else { // FREE behind the ribbon -> not an exterior thin line
                    ok_thin_then_unknown = false; break;
                }
            }
            if (!ok_thin_then_unknown) continue;

            // --- B) The lethal ribbon is a tiny island (ignore inflated skirt) ---
            // Seed = first lethal cell we encountered on UNKNOWN side
            bool tiny_island = false;
            for (int s=1; s<=unknown_lookahead_steps; ++s) {
                unsigned int mx,my; unsigned char c;
                if (!readCost(p.x + unx*res*s, p.y + uny*res*s, mx, my, c)) continue;
                if (isLethal(c)) {
                    int comp = lethalIslandSize(mx,my);
                    if (comp <= island_cells_max) tiny_island = true;
                    break;
                } else if (c == costmap_2d::NO_INFORMATION) {
                    break;
                }
            }
            if (!tiny_island) continue;

            // --- C) Real wall near FREE side (lethal or inflated) ---
            bool wall_near = false; int consec_obs = 0;
            for (int s=1; s<=wall_search_steps; ++s) {
                unsigned int mx,my; unsigned char c;
                if (!readCost(p.x + fnx*res*s, p.y + fny*res*s, mx, my, c)) continue;
                if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                    if (++consec_obs >= 2) { wall_near = true; break; }
                } else if (c == costmap_2d::FREE_SPACE) {
                    consec_obs = 0;
                }
            }
            if (!wall_near) continue;

            ++agree;
        }

        return (samples > 0) && ((double)agree / (double)samples >= agree_ratio);
    }

    std::vector<Frontier> FrontierSearch::clusterFrontiers(
    const std::vector<Frontier>& frontiers, 
    double distance_threshold)
    {
        if (frontiers.empty()) {
            return frontiers;
        }
        
        std::vector<Frontier> clustered_frontiers;
        std::vector<bool> processed(frontiers.size(), false);

        // if(frontiers.size() <=30)
        // {
        //     distance_threshold = distance_threshold /2.0;
        // }
        
        for (size_t i = 0; i < frontiers.size(); ++i) {
            if (processed[i]) continue;
            
            // Start new cluster with current frontier
            std::vector<size_t> cluster_indices;
            cluster_indices.push_back(i);
            processed[i] = true;
            
            // Find all frontiers close to this one
            for (size_t j = i + 1; j < frontiers.size(); ++j) {
                if (processed[j]) continue;
                
                double dx = frontiers[i].centroid.x - frontiers[j].centroid.x;
                double dy = frontiers[i].centroid.y - frontiers[j].centroid.y;
                double distance = std::sqrt(dx*dx + dy*dy);
                
                if (distance < distance_threshold) {
                    cluster_indices.push_back(j);
                    processed[j] = true;
                }
            }
            
            // Find frontier with minimum cost in this cluster
            size_t best_idx = cluster_indices[0];
            double min_cost = frontiers[best_idx].cost;
            
            for (size_t idx : cluster_indices) {
                if (frontiers[idx].cost < min_cost) {
                    min_cost = frontiers[idx].cost;
                    best_idx = idx;
                }
            }
            
            // Keep only the best frontier from this cluster
            clustered_frontiers.push_back(frontiers[best_idx]);
        }
        
        ROS_INFO("Frontier clustering: %zu -> %zu frontiers (threshold: %.2fm)", 
                frontiers.size(), clustered_frontiers.size(), distance_threshold);
        
        return clustered_frontiers;
    }

   

    void FrontierSearch::recomputeCostsForNewClusters(std::vector<Frontier>& frontiers)
    {
        for (auto& f : frontiers) {
            // Sadece lider olanları kontrol ediyoruz
            if (f.is_best_in_cluster) {
                // Sadece maliyeti daha önce hesaplanmamış (infinity) olanlar için işlem yap
                if (std::isinf(f.cost)) {
                    f.cost = frontierCost(f);
                }
            }
        }
    }

    std::vector<Frontier> FrontierSearch::searchFrom(geometry_msgs::Point position)
    {

        // Clean old cache entries
        if(with_map_completion_ == 1)
        {
            cleanCompletedPatchCache();
        }
    

        // ROS_ERROR("=== FRONTIER SEARCH START ===");
        // ROS_ERROR("Active patches count: %zu", active_frontier_patches_.size());
        // ROS_ERROR("Completed map size: %dx%d", completed_map_.cols, completed_map_.rows);
        // ROS_ERROR("GT map size: %dx%d", gt_map_.cols, gt_map_.rows);

        //auto op_start = std::chrono::high_resolution_clock::now();

        auto search_start = std::chrono::high_resolution_clock::now();

        std::vector<Frontier> frontier_list;

        // Validate input position
        if (!std::isfinite(position.x) || !std::isfinite(position.y)) {
            //ROS_ERROR("Robot position has invalid coordinates: (%.6f, %.6f)", 
                    //   position.x, position.y);
            return frontier_list;
        }

        if (!costmap_) {
            //ROS_ERROR("Costmap is null in searchFrom");
            return frontier_list;
        }

        // Check if robot is within costmap bounds
        unsigned int mx_robot, my_robot;
        if (!costmap_->worldToMap(position.x, position.y, mx_robot, my_robot)) {
            //ROS_ERROR("Robot out of costmap bounds (%.2f, %.2f)", position.x, position.y);
            return frontier_list;
        }

        ////ROS_DEBUG("Robot in map coords: (%u, %u)", mx_robot, my_robot);

        // Lock costmap for the entire search operation
        std::lock_guard<costmap_2d::Costmap2D::mutex_t> lock(*(costmap_->getMutex()));


        // live_cm matrisini BURADA BİR KEZ oluşturun:
        // const unsigned int W = costmap_->getSizeInCellsX();
        // const unsigned int H = costmap_->getSizeInCellsY();
        // cv::Mat global_live_cm(H, W, CV_8UC1, cv::Scalar(UNKNOWN_U8));
        // const unsigned char* raw = costmap_->getCharMap();
        // for (unsigned int y = 0; y < H; ++y) {
        //     uchar* dst = global_live_cm.ptr<uchar>(H - 1 - y);
        //     for (unsigned int x = 0; x < W; ++x) {
        //         unsigned char c = raw[y*W + x];
        //         if (c == costmap_2d::NO_INFORMATION)      dst[x] = UNKNOWN_U8;
        //         else if (c == costmap_2d::FREE_SPACE)     dst[x] = KNOWN_U8;
        //         else                                      dst[x] = OBSTACLE_U8;
        //     }
        // }

        // ✅ YENİ: Patch history'sini validate et (ek güvenlik için)
        // if(use_completed_map_==1)
        // {
        //     seedCompletedMapFromCostmap();
            
        // }

        if(use_closed_live_map_==1)
        {
            seedClosedLiveMapFromCostmap();
        }


        try {
            // map_ = costmap_->getCharMap();
            // size_x_ = costmap_->getSizeInCellsX();
            // size_y_ = costmap_->getSizeInCellsY();

            // // ========== NEW: PREPROCESS MAP ==========
            // Convert costmap to CV image format
            const unsigned int W = costmap_->getSizeInCellsX();
            const unsigned int H = costmap_->getSizeInCellsY();
        
            map_ = costmap_->getCharMap(); // Doğrudan ham veri
            size_x_ = costmap_->getSizeInCellsX();
            size_y_ = costmap_->getSizeInCellsY();
            



            if (size_x_ == 0 || size_y_ == 0 || !map_) {
                //ROS_ERROR("Invalid costmap data: size=%ux%u, map_ptr=%p", 
                        // size_x_, size_y_, static_cast<const void*>(map_));
                return frontier_list;
            }

            ////ROS_DEBUG("Map size: %u x %u", size_x_, size_y_);


            const size_t map_size = static_cast<size_t>(size_x_) * static_cast<size_t>(size_y_);
            std::vector<bool> frontier_flag, visited_flag;
            
            try {
                frontier_flag.assign(map_size, false);
                visited_flag.assign(map_size, false);
            } catch (const std::bad_alloc& e) {
                ROS_ERROR("Failed to allocate search flags for %zu cells: %s", map_size, e.what());
                return frontier_list;
            }

            // Find starting position for BFS
            std::queue<unsigned int> bfs;
            unsigned int clear, pos = costmap_->getIndex(mx_robot, my_robot);
            
            if (pos >= map_size) {
                ROS_ERROR("Robot position index out of bounds: %u >= %zu", pos, map_size);
                return frontier_list;
            }

            if (nearestCell(clear, pos, FREE_SPACE, *costmap_)) {
                if (clear >= map_size) {
                    ROS_WARN("Nearest clear cell index out of bounds: %u >= %zu", clear, map_size);
                    clear = pos; // Fallback to robot position
                }
                //ROS_DEBUG("Nearest clear cell: %u", clear);
                bfs.push(clear);
            } else {
                ROS_WARN("Could not find nearby clear cell, starting from robot cell (%u)", pos);
                bfs.push(pos);
            }
            
            visited_flag[bfs.front()] = true;

            // BFS exploration with limits to prevent infinite loops and excessive memory usage
            size_t expansions = 0;
            size_t frontier_candidates = 0;
            const size_t max_expansions = map_size * 2; // Safety limit
            const size_t max_frontiers = 1000;          // Memory limit

            while (!bfs.empty() && expansions < max_expansions && frontier_list.size() < max_frontiers) {
                unsigned int idx = bfs.front();
                bfs.pop();
                ++expansions;

                if (idx >= map_size) {
                    ROS_WARN("BFS index out of bounds: %u >= %zu", idx, map_size);
                    continue;
                }

                for (unsigned nbr : nhood4(idx, *costmap_)) {
                    if (nbr >= map_size) {
                        ROS_WARN("Neighbor index out of bounds: %u >= %zu", nbr, map_size);
                        continue;
                    }

                    // Explore free neighbors
                    if (!visited_flag[nbr] && map_[nbr] == FREE_SPACE) {
                        visited_flag[nbr] = true;
                        bfs.push(nbr);
                    }
                    // Detect frontier cells
                    else if (isNewFrontierCell(nbr, frontier_flag)) {
                        frontier_flag[nbr] = true;
                        Frontier f = buildNewFrontier(nbr, pos, frontier_flag);
                        ++frontier_candidates;

                        if (f.size == 0) {
                            //ROS_DEBUG("Skipping invalid frontier");
                            continue;
                        }

                        const double frontier_size_m = f.size * costmap_->getResolution();
                        // ROS_DEBUG("New frontier: size=%.2f m, centroid=(%.2f, %.2f)",
                        //           frontier_size_m, f.centroid.x, f.centroid.y);

                        if (frontier_size_m >= min_frontier_size_) {

                            //calculateSamplePoints(f); 
                            frontier_list.push_back(std::move(f));
                            // ROS_INFO("Accepted frontier %zu: size=%.2f m, centroid=(%.2f, %.2f)",
                            //         frontier_list.size(), frontier_size_m,
                            //         frontier_list.back().centroid.x,
                            //         frontier_list.back().centroid.y);
                        } else {
                            // ROS_DEBUG("Rejected frontier (too small: %.2f m < %.2f m)",
                            //         frontier_size_m, min_frontier_size_);
                        }
                    }
                }
            }

            // Log warnings if limits were hit
            if (expansions >= max_expansions) {
                ROS_WARN("BFS hit expansion limit (%zu)", max_expansions);
            }
            if (frontier_list.size() >= max_frontiers) {
                ROS_WARN("Frontier limit reached (%zu)", max_frontiers);
            }

            // ROS_INFO("BFS: %zu expansions, %zu candidates, %zu accepted frontiers",
            //          expansions, frontier_candidates, frontier_list.size());

        } catch (const std::exception& e) {
            ROS_ERROR("Exception in frontier search: %s", e.what());
            return std::vector<Frontier>{}; // Return empty list on error
        }

        // ═══════════════════════════════════════════════════════════
        // PROFILING: Frontier detection time
        // ═══════════════════════════════════════════════════════════
        {
            auto detect_end = std::chrono::high_resolution_clock::now();
            auto duration_ms = std::chrono::duration<double, std::milli>(detect_end - search_start).count();
            recordTiming("frontier_detection", duration_ms);
            ROS_INFO("⏱️ Frontier detection: %.2f ms, found %zu frontiers", 
                    duration_ms, frontier_list.size());
        }

        // Early return if no frontiers found
        if (frontier_list.empty()) {
            ROS_WARN("No frontiers found");
            return frontier_list;
        }

        if(!navigation_only_mode_ && use_clustering_)
        {
            // ============================================================
            // TIMING: Clustering
            // ============================================================
            auto cluster_start = std::chrono::high_resolution_clock::now();
                
            frontier_list = clusterFrontiers(frontier_list, cluster_distance_threshold_);
                
            auto cluster_end = std::chrono::high_resolution_clock::now();
            auto cluster_duration_ms = std::chrono::duration<double, std::milli>(
                cluster_end - cluster_start).count();
                
            recordTiming("frontier_clustering", cluster_duration_ms);
            ROS_INFO("⏱️ Frontier clustering: %.2f ms, %zu frontiers", 
                        cluster_duration_ms, frontier_list.size());
            }   
            


        if(use_completed_map_==1)
        {
            
            // ============================================================
            // TIMING: Map Completion
            // ============================================================
            auto completion_start = std::chrono::high_resolution_clock::now();
            
            bool success = batchCompleteFrontierPatches(frontier_list);

            auto completion_end = std::chrono::high_resolution_clock::now();
            auto completion_duration_ms = std::chrono::duration<double, std::milli>(
                completion_end - completion_start).count();
            
            recordTiming("map_completion", completion_duration_ms);
            // ROS_INFO("⏱️ Map completion: %.2f ms (%s)", 
            //         completion_duration_ms, success ? "success" : "failed");
        }

       

        if(use_closed_live_map_==1)
        {
            if (!closed_live_.empty()) {
                closeSmallGapsInMap(closed_live_, door_threshold_m_);
                //ROS_DEBUG("🔧 Gap closing on closed_live_ (fresh from costmap)");
            }
            
        }

    
        {
            
            std::lock_guard<std::recursive_mutex> data_lock(data_mutex_); 

            if(use_completed_map_==1 && use_closing_==1)
            {
                if (!completed_map_.empty()) {
                   ROS_DEBUG("🔧 Gap closing on completed_map_ (fresh)");
                    closeSmallGapsInMap(completed_map_, door_threshold_m_);
               }
            }

            if(use_completed_map_==1)
            {
                
                //if (!completed_map_.empty()) {

                    // Process completion scores safely
                    if (use_completed_map_ == 1) 
                    {
                        try {
                            processCompletionScores(frontier_list);
                        } catch (const std::exception& e) {
                            ROS_WARN("Exception in completion score processing: %s", e.what());
                            //Continue without completion scores - set them to zero
                            for (auto& f : frontier_list) {
                                f.completion_known_score = 0.0;
                                f.completion_obstacle_score = 0.0;
                            }
                        }
                    }
                //}
            }

            {
                for (auto& f : frontier_list) {
                    f.too_close_to_obstacle = false;
                    f.is_noisy_interior = false;
                    f.is_noisy_exterior = false;
                    f.is_trapped_between_walls = false;
                    f.is_thin_bridge = false;
                    f.is_small_corner_pocket = false;
                    //f.safest_point = f.centroid;
                }
            }


            if(use_filtering_==1)
            {
                
                {
                        auto it = frontier_list.begin();      
                        ROS_INFO("=== FRONTIER FILTERING START: %lu frontiers to check ===", (unsigned long)frontier_list.size());
                        size_t original_count = frontier_list.size();
                        // size_t filtered_count = 0;
                        // size_t kept_count = 0;

                        size_t marked_count = 0;
                        size_t safe_count = 0;
                        
                        auto filtering_start = std::chrono::high_resolution_clock::now();
                    
                        size_t total_filtered = 0;
                        while (it != frontier_list.end()) {
                            // ─────────────────────────────────────────────────────────────────
                            // STEP 1: Initialize flags (start fresh for each frontier)
                            // ─────────────────────────────────────────────────────────────────
                            it->too_close_to_obstacle = false;
                            it->is_noisy_interior = false;
                            it->is_noisy_exterior = false;
                            it->is_trapped_between_walls = false;
                            it->is_thin_bridge = false;
                            it->is_small_corner_pocket = false;
                                        
                            // ─────────────────────────────────────────────────────────────────
                            // STEP 2: Check obstacle proximity with appropriate map source
                            // ─────────────────────────────────────────────────────────────────
                            ObstacleCheckSource check_source;

                            if (use_completed_map_ == 1) {
                                check_source = ObstacleCheckSource::COMPLETED_MAP;
                            } else if (use_closed_live_map_ == 1) {
                                // Use gap-closed SLAM map
                                check_source = ObstacleCheckSource::CLOSED_LIVE_MAP;
                            } else {
                                // Use raw SLAM costmap
                                check_source = ObstacleCheckSource::RAW_COSTMAP;
                            }

                           
                                    
                                    
                            //it->safest_point = it->centroid;
                         
                                        
                            // ─────────────────────────────────────────────────────────────────
                            // STEP 4: Calculate robot-to-frontier distance
                            // ─────────────────────────────────────────────────────────────────
                            unsigned int mx_robot, my_robot;
                            costmap_->worldToMap(position.x, position.y, mx_robot, my_robot);
                            unsigned int clear, pos = costmap_->getIndex(mx_robot, my_robot);
                                        
                            unsigned int rx, ry;
                            double reference_x, reference_y;
                            costmap_->indexToCells(pos, rx, ry);
                            costmap_->mapToWorld(rx, ry, reference_x, reference_y);
                                        
                            double dx = it->safest_point.x - reference_x;
                            double dy = it->safest_point.y - reference_y;
                            it->min_distance = std::sqrt(dx*dx + dy*dy);
                                        
                            // // ─────────────────────────────────────────────────────────────────
                            // // STEP 5: Apply geometric filtering rules (if enabled)
                            // // ─────────────────────────────────────────────────────────────────

                                        

                                        
                            ++it;  // Move to next frontier
                        }

                        auto filtering_end = std::chrono::high_resolution_clock::now();
                        auto filter_duration_ms = std::chrono::duration<double, std::milli>(
                            filtering_end - filtering_start).count();
                                    
                        recordTiming("filtering_total", filter_duration_ms);
                        ROS_INFO("⏱️ Filtering: %.2f ms, flagged %zu/%zu frontiers", 
                                filter_duration_ms, total_filtered, frontier_list.size());
                                    

                        // ─────────────────────────────────────────────────────────────────
                        // STEP 6: Summary statistics
                        // ─────────────────────────────────────────────────────────────────
                        size_t total_flagged = 0;
                        size_t obstacle_count = 0;
                        size_t interior_count = 0;
                        size_t exterior_count = 0;
                        size_t trapped_count = 0;
                        size_t bridge_count = 0;
                        size_t corner_count = 0;

                        for (const auto& f : frontier_list) {
                            if (f.isFlaggedByAnyFilter()) {
                                total_flagged++;
                                if (f.too_close_to_obstacle) obstacle_count++;
                                // if (f.is_noisy_interior) interior_count++;
                                // if (f.is_noisy_exterior) exterior_count++;
                                // if (f.is_trapped_between_walls) trapped_count++;
                                // if (f.is_thin_bridge) bridge_count++;
                                // if (f.is_small_corner_pocket) corner_count++;
                            }
                        }

                        ROS_INFO("=== FRONTIER FILTERING SUMMARY ===");
                        ROS_INFO("  Total frontiers: %lu", (unsigned long)frontier_list.size());
                        ROS_INFO("  Flagged: %lu (%.1f%%)", total_flagged, 
                                100.0 * total_flagged / std::max(1ul, frontier_list.size()));
                        ROS_INFO("  Breakdown:");
                        ROS_INFO("    - Too close to obstacle: %lu", obstacle_count);
                        ROS_INFO("    - Noisy interior: %lu", interior_count);
                        ROS_INFO("    - Noisy exterior: %lu", exterior_count);
                        ROS_INFO("    - Trapped between walls: %lu", trapped_count);
                        ROS_INFO("    - Thin bridge: %lu", bridge_count);
                        ROS_INFO("    - Small corner pocket: %lu", corner_count);
                        ROS_INFO("==================================");
                }
                
            }
        }




        // ═══════════════════════════════════════════════════════════
        // PROFILING: Distance calculation time
        // ═══════════════════════════════════════════════════════════
        {
            auto dist_start = std::chrono::high_resolution_clock::now();
            
            unsigned int mx_robot, my_robot;
            costmap_->worldToMap(position.x, position.y, mx_robot, my_robot);
            calculateFrontierDistances(frontier_list, mx_robot, my_robot);
            
            auto dist_end = std::chrono::high_resolution_clock::now();
            auto duration_ms = std::chrono::duration<double, std::milli>(
                dist_end - dist_start).count();
            
            recordTiming("distance_calculation", duration_ms);
            ROS_INFO("⏱️ Distance calculation: %.2f ms (method: %s)", 
                     duration_ms, distance_method_.c_str());
        }


        // Final scoring and sorting with error handling
        try {
            auto cost_start = std::chrono::high_resolution_clock::now();
            for (auto& f : frontier_list) {
                f.cost = frontierCost(f);
                if (!std::isfinite(f.cost)) {
                    ROS_WARN("Invalid cost computed for frontier at (%.2f, %.2f)",
                            f.centroid.x, f.centroid.y);
                    f.cost = std::numeric_limits<double>::infinity();
                }
            }

            auto cost_end = std::chrono::high_resolution_clock::now();
            auto duration_ms = std::chrono::duration<double, std::milli>(
                cost_end - cost_start).count();
            
            recordTiming("cost_calculation", duration_ms);
            //ROS_INFO("⏱️ Cost calculation: %.2f ms", duration_ms);

            std::sort(frontier_list.begin(), frontier_list.end(),
                    [](const Frontier& a, const Frontier& b) { 
                        return a.cost < b.cost; 
                    });
                    
        } catch (const std::exception& e) {
            ROS_ERROR("Exception in frontier sorting: %s", e.what());
            //Continue without sorting - frontier order may be suboptimal but functional
        }

        // ===== NEW: Save last frontier selection =====
        if (!frontier_list.empty()) {
            // Best frontier is first (lowest cost after sorting)
            last_frontier_centroid_ = frontier_list.front().centroid;
            last_robot_position_ = position;
            has_last_frontier_ = true;
            
            // ROS_DEBUG("Saved direction context: robot=(%.2f, %.2f), frontier=(%.2f, %.2f)",
            //          position.x, position.y,
            //          last_frontier_centroid_.x, last_frontier_centroid_.y);
        }

     
        auto search_end = std::chrono::high_resolution_clock::now();
        auto total_duration_ms = std::chrono::duration<double, std::milli>(
            search_end - search_start).count();
        
        recordTiming("search_total", total_duration_ms);
        //ROS_INFO("⏱️ TOTAL searchFrom: %.2f ms", total_duration_ms);
        
        // Periodically log statistics (every 10 calls)
        static int call_count = 0;
        if (++call_count % 10 == 0) {
            logProfilingStats();
        }

        return frontier_list;
    }





    

    // FrontierSearch.cpp içinde yeni bir yardımcı metot
    void FrontierSearch::precomputeDistanceField(const cv::Mat& map) {
        if (map.empty()) return;

        // Engel maskesi (Sadece engeller 0, diğerleri 255)
        cv::Mat obstacle_mask;
        cv::compare(map, 0, obstacle_mask, cv::CMP_EQ); // val == 0 olanlar 255, diğerleri 0 olur
        // distanceTransform engellerin (0 olanlar) mesafesini hesaplar, 
        // bu yüzden maskeyi ters çevirmeliyiz (engeller 0 olmalı)
        cv::bitwise_not(obstacle_mask, obstacle_mask);

        // Tüm harita için mesafeleri bir kez hesapla
        cv::distanceTransform(obstacle_mask, precomputed_distances_, cv::DIST_L2, cv::DIST_MASK_PRECISE);
    }

    double FrontierSearch::getDistanceAtPoint(double world_x, double world_y) const {
        unsigned int mx, my;
        if (!costmap_->worldToMap(world_x, world_y, mx, my)) return 0.0;
        
        int cv_x = mx;
        int cv_y = (costmap_->getSizeInCellsY() - 1) - my;

        if (cv_x < 0 || cv_x >= precomputed_distances_.cols || cv_y < 0 || cv_y >= precomputed_distances_.rows) {
            return 0.0;
        }

        // Hazır matristen değeri oku (Milisaniyeden çok daha hızlı!)
        return precomputed_distances_.at<float>(cv_y, cv_x) * costmap_->getResolution();
    }

    double FrontierSearch::getDistanceToNearestObstacleInMap(double world_x, double world_y, 
                                                          const cv::Mat& map) const
    {
        if (!costmap_ || map.empty()) {
            return std::numeric_limits<double>::infinity();
        }
        
        const double res = costmap_->getResolution();
        const unsigned int W = costmap_->getSizeInCellsX();
        const unsigned int H = costmap_->getSizeInCellsY();
        
        // World → Costmap grid
        unsigned int mx, my;
        if (!costmap_->worldToMap(world_x, world_y, mx, my)) {
            return std::numeric_limits<double>::infinity();
        }
        
        // Costmap grid → OpenCV coords (flip Y)
        int cv_x = static_cast<int>(mx);
        int cv_y = H - 1 - static_cast<int>(my);
        
        if (cv_x < 0 || cv_x >= map.cols || cv_y < 0 || cv_y >= map.rows) {
            return std::numeric_limits<double>::infinity();
        }
        
        // Create binary obstacle mask (0=obstacle, 255=free/unknown)
        cv::Mat obstacle_mask(map.rows, map.cols, CV_8UC1);
        for (int y = 0; y < map.rows; ++y) {
            for (int x = 0; x < map.cols; ++x) {
                unsigned char val = map.at<uchar>(y, x);
                obstacle_mask.at<uchar>(y, x) = (val == 0) ? 0 : 255; // 0=obstacle, 255=free
            }
        }
        
        // Distance transform
        cv::Mat dist_transform;
        cv::distanceTransform(obstacle_mask, dist_transform, cv::DIST_L2, cv::DIST_MASK_PRECISE);
        
        // Get distance at query point (in pixels)
        float dist_pixels = dist_transform.at<float>(cv_y, cv_x);
        
        // Convert to meters
        double dist_meters = dist_pixels * res;
        
        return dist_meters;
    }

   

    bool FrontierSearch::isGoalReachable(const geometry_msgs::Point& goal, 
                                        const geometry_msgs::Point& start) const
    {
        if (!costmap_) {
            //ROS_WARN("isGoalReachable: costmap is null");
            return false;
        }
        
        unsigned int gx, gy, sx, sy;
        if (!costmap_->worldToMap(goal.x, goal.y, gx, gy)) {
            //ROS_WARN("Goal (%.2f, %.2f) is outside costmap bounds", goal.x, goal.y);
            return false;
        }
        if (!costmap_->worldToMap(start.x, start.y, sx, sy)) {
            //ROS_WARN("Start (%.2f, %.2f) is outside costmap bounds", start.x, start.y);
            return false;
        }
        
        // Check if goal itself is in free space
        unsigned char goal_cost = costmap_->getCost(gx, gy);
        if (goal_cost >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
            //ROS_WARN("Goal (%.2f, %.2f) has cost %u >= %u (blocked)", 
                    //  goal.x, goal.y, goal_cost, costmap_2d::INSCRIBED_INFLATED_OBSTACLE);
            return false;
        }
        
        // REDUCED clearance check - was too strict
        const int clearance_cells = 1; // Reduced from 3 to 1
        int blocked_cells = 0, total_cells = 0;
        
        for (int dx = -clearance_cells; dx <= clearance_cells; dx++) {
            for (int dy = -clearance_cells; dy <= clearance_cells; dy++) {
                int cx = (int)gx + dx;
                int cy = (int)gy + dy;
                
                // Skip out of bounds cells instead of rejecting entire goal
                if (cx < 0 || cx >= (int)costmap_->getSizeInCellsX() || 
                    cy < 0 || cy >= (int)costmap_->getSizeInCellsY()) {
                    continue; 
                }
                
                total_cells++;
                unsigned char cost = costmap_->getCost((unsigned int)cx, (unsigned int)cy);
                if (cost >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                    blocked_cells++;
                }
            }
        }
        
        // Allow goal if majority of surrounding cells are free
        double blocked_ratio = total_cells > 0 ? (double)blocked_cells / total_cells : 0.0;
        bool reachable = (blocked_ratio < 0.5); // Allow if less than 50% of area is blocked
        
        //ROS_WARN("Goal (%.2f, %.2f): %d/%d cells blocked (%.1f%%) - %s", 
                //  goal.x, goal.y, blocked_cells, total_cells, blocked_ratio*100.0,
                //  reachable ? "REACHABLE" : "BLOCKED");
        
        return reachable;
    }

    // OBSTACLE_U8 = 0, KNOWN_U8 = 254, UNKNOWN_U8 = 205 varsayımına göre
    // Canlı ve GT'den geniş ROI alıp, sadece OBSTACLE maskelerinde eşleştirme yapar.
    static bool estimateLocalTranslation(
        const cv::Mat& live_roi,   // CV_8UC1, HxW, 0/205/254
        const cv::Mat& gt_roi,     // CV_8UC1, HxW, 0/205/254
        int search_px,             // +- kaç piksel taranacak (örn 6)
        cv::Point* best_shift,     // çıkış: (dx,dy)  (gt -> live)
        double* best_score)        // çıkış: normalize skor (CCOEFF_NORMED)
    {
        if (best_shift) *best_shift = cv::Point(0,0);
        if (best_score) *best_score = 0.0;

        if (live_roi.empty() || gt_roi.empty()) return false;
        if (live_roi.type()!=CV_8UC1 || gt_roi.type()!=CV_8UC1) return false;
        if (live_roi.size()!=gt_roi.size()) return false;

        // Sadece "engel" maskeleri ile eşleştir (gürültü azalır)
        cv::Mat live_obs = (live_roi == OBSTACLE_U8);
        cv::Mat gt_obs   = (gt_roi   == OBSTACLE_U8);

        // Eşleştirme için template boyutu, arama penceresinden küçük olmalı.
        // Basit yöntem: template = gt_obs (iç ROI), result = match(live_obs, template)
        // Ancak (dx,dy) sınırlı olsun diye, ROI’yi search_px kadar "valid" kırpıyoruz.
        const int H = live_obs.rows, W = live_obs.cols;
        const int pad = search_px;

        if (H <= 2*pad+4 || W <= 2*pad+4) {
            // çok küçükse vazgeç
            return false;
        }

        // Şablon: gt tarafında pad..H-pad, pad..W-pad
        cv::Rect templ_r(pad, pad, W - 2*pad, H - 2*pad);
        cv::Mat templ = gt_obs(templ_r);

        // Arama resmi: live tarafı aynı boy, matchTemplate OK (kayma sonucu dx,dy bulmak için)
        cv::Mat result;
        cv::matchTemplate(live_obs, templ, result, cv::TM_CCOEFF_NORMED);

        // Sonuç boyutu: (W - templ_w + 1) x (H - templ_h + 1) = (2*pad+1) x (2*pad+1)
        double maxVal; cv::Point maxLoc;
        cv::minMaxLoc(result, nullptr, &maxVal, nullptr, &maxLoc);

        if (best_score) *best_score = maxVal;

        // maxLoc, live içinde şablonun sol-üst konumu.
        // Gerçek piksel kayması: (dx,dy) = maxLoc - templ_r.tl()
        cv::Point tl_templ = templ_r.tl(); // (pad,pad)
        cv::Point shift = maxLoc - tl_templ; // gt'den live'a kayma

        // Güven eşiği: çok zayıf korelasyon ise hizalamayı uygulama
        if (maxVal < 0.50) { // istersen 0.4–0.6 arası ayarlanabilir
            return false;
        }

        if (best_shift) *best_shift = shift; // (dx,dy)
        return true;
    }

    cv::Point2i FrontierSearch::findNearestFreeCell(const cv::Mat& costmap, const cv::Point2i& frontier_pt, int search_radius)
    {
        int H = costmap.rows, W = costmap.cols;
        int best_dist = INT_MAX;
        cv::Point2i best_pt = cv::Point2i(-1, -1);

        const unsigned char* costmap_data = costmap.data;

        for (int dy = -search_radius; dy <= search_radius; ++dy) {
            for (int dx = -search_radius; dx <= search_radius; ++dx) {
                int nx = frontier_pt.x + dx;
                int ny = frontier_pt.y + dy;
                
                if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;

                unsigned char cost = costmap_data[ny * W + nx];
                
                // FREE_SPACE kontrolü (FREE_SPACE = 0)
                if (cost == costmap_2d::FREE_SPACE) {
                    int dist = dx*dx + dy*dy;
                    if (dist < best_dist) {
                        best_dist = dist;
                        best_pt = cv::Point2i(nx, ny);
                    }
                }
            }
        }

        return best_pt;  // Bulunamazsa (-1,-1) dönecek
    }

    void FrontierSearch::adjustSingleWallFrontierToFreeCell(Frontier& frontier)
    {
        unsigned int gx, gy;
        if (!costmap_->worldToMap(frontier.centroid.x, frontier.centroid.y, gx, gy)) {
            return;
        }

        unsigned char cost = costmap_->getCost(gx, gy);
        bool is_blocked = (cost >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE && cost != costmap_2d::NO_INFORMATION) || 
                        (cost == costmap_2d::NO_INFORMATION);

        // Sadece engelli ise düzelt
        if (is_blocked) {
            const int W = costmap_->getSizeInCellsX();
            const int H = costmap_->getSizeInCellsY();
            cv::Mat costmap_cv(H, W, CV_8U, (void*)costmap_->getCharMap());
            
            cv::Point2i corrected = findNearestFreeCell(costmap_cv, cv::Point2i(gx, gy), 15);

            if (corrected.x >= 0 && corrected.y >= 0) {
                double new_x, new_y;
                costmap_->mapToWorld(corrected.x, corrected.y, new_x, new_y);

                // ROS_WARN("✓ Adjusted single wall frontier from (%.2f, %.2f) to nearest free cell (%.2f, %.2f) - grid (%d,%d)->(%d,%d)",
                //          frontier.centroid.x, frontier.centroid.y, new_x, new_y, gx, gy, corrected.x, corrected.y);

                // Frontier konumunu güncelle
                frontier.centroid.x = new_x;
                frontier.centroid.y = new_y;
                frontier.middle.x = new_x;
                frontier.middle.y = new_y;
                
                // İlk noktayı da güncelle (eğer points listesi varsa)
                if (!frontier.points.empty()) {
                    frontier.initial.x = new_x;
                    frontier.initial.y = new_y;
                }
            } else {
                ROS_WARN("✗ Could not find free cell for single wall frontier at (%d,%d)", gx, gy);
            }
        }
    }

    // Helper function to calculate frontier distances
    bool FrontierSearch::calculateFrontierDistances(std::vector<Frontier>& frontier_list,
                                                unsigned int mx_robot, unsigned int my_robot)
    {
        const bool use_dfield = (distance_method_ == "dfield");
        const bool use_mga = (distance_method_ == "multi_astar" || 
                            distance_method_ == "astar_completion" ||
                            distance_method_ == "dijkstra");

        try {
            if (use_dfield) {
                return calculateDistancesUsingField(frontier_list, mx_robot, my_robot);
            } else if (use_mga) {
                return calculateDistancesUsingMultiGoal(frontier_list, mx_robot, my_robot);
            } else if (distance_method_ == "euclidean") {
                return calculateDistancesEuclidean(frontier_list, mx_robot, my_robot);
            } else {
                //ROS_ERROR("Unknown distance method: %s", distance_method_.c_str());
                return false;
            }
        } catch (const std::exception& e) {
            //ROS_ERROR("Exception in distance calculation: %s", e.what());
            return false;
        }
    }

    void FrontierSearch::analyzeWallsAndGaps(const cv::Mat& completed_patch, Frontier& f)
    {
        if (completed_patch.empty()) return;
        
        const int rows = completed_patch.rows;
        const int cols = completed_patch.cols;
        
        // ✅ Define correct pixel value constants
        const unsigned char UNKNOWN_U8 = 205;
        const unsigned char OCC_THR = 100;  // Obstacle threshold
        
        const double res = costmap_->getResolution();
        
        // Initialize
        f.has_wall = false;
        f.has_gap = false;
        f.has_large_gap = false;
        f.has_small_gap = false;
        f.gap_size = 0.0;
        
        // Analyze 4 cardinal directions from center
        const int cx = cols / 2;
        const int cy = rows / 2;
        const int max_ray_length = std::min(cols, rows) / 2;
        
        int total_wall_pixels = 0;
        int total_gap_pixels = 0;
        double max_gap_size = 0.0;
        
        // Check 4 cardinal directions: E, W, S, N
        const int dirs[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        
        for (int d = 0; d < 4; ++d) {
            int dx = dirs[d][0];
            int dy = dirs[d][1];
            
            bool found_wall = false;
            int wall_pixels = 0;
            int gap_pixels = 0;
            bool in_gap = false;
            
            // Cast ray from center outward
            for (int step = 1; step < max_ray_length; ++step) {
                int x = cx + dx * step;
                int y = cy + dy * step;
                
                if (x < 0 || x >= cols || y < 0 || y >= rows) break;
                
                unsigned char v = completed_patch.at<unsigned char>(y, x);
                
                // ✅ CORRECT: Skip unknown pixels
                if (v == UNKNOWN_U8) {
                    // Don't count unknown as wall or free
                    continue;
                }
                
                if (v >= OCC_THR) {
                    // Hit obstacle/wall
                    if (!found_wall) {
                        found_wall = true;
                    }
                    wall_pixels++;
                    
                    // If we were in a gap, gap ended
                    if (in_gap) {
                        in_gap = false;
                    }
                    
                } else {
                    // Free space (v < OCC_THR)
                    if (found_wall) {
                        // Found free space after wall (potential gap)
                        if (!in_gap) {
                            in_gap = true;
                        }
                        gap_pixels++;
                    }
                }
            }
            
            // Accumulate results from this direction
            if (found_wall && wall_pixels > 2) {
                total_wall_pixels += wall_pixels;
                
                if (gap_pixels > 0) {
                    double gap_size_m = gap_pixels * res;
                    max_gap_size = std::max(max_gap_size, gap_size_m);
                    total_gap_pixels += gap_pixels;
                }
            }
        }
        
        // Determine wall presence (at least 8 obstacle pixels total)
        if (total_wall_pixels > 8) {
            f.has_wall = true;
        }
        
        // Determine gap characteristics
        if (f.has_wall && total_gap_pixels > 0) {
            f.has_gap = true;
            f.gap_size = max_gap_size;
            
            // Classify gap size (using door_threshold_m_ parameter)
            if (max_gap_size >= door_threshold_m_) {
                f.has_large_gap = true;  // Door-sized or larger
            } else {
                f.has_small_gap = true;  // Smaller than door (noise)
            }
        }
    }

    bool FrontierSearch::calculateDistancesUsingMultiGoal(std::vector<Frontier>& frontier_list,
                                                        unsigned int mx_robot, unsigned int my_robot)
    {
        // Build goal positions with validation
        std::vector<std::pair<int,int>> goals_xy;
        goals_xy.reserve(frontier_list.size());
        
        for (const auto& frontier : frontier_list) {
            unsigned int gx, gy;
            if (costmap_->worldToMap(frontier.centroid.x, frontier.centroid.y, gx, gy)) {
                goals_xy.emplace_back(static_cast<int>(gx), static_cast<int>(gy));
            } else {
                goals_xy.emplace_back(-1, -1); // Invalid marker
            }
        }

        const double resolution = costmap_->getResolution();
        if (resolution <= 0.0) {
            //ROS_ERROR("Invalid costmap resolution: %.6f", resolution);
            return false;
        }

        try {
            if (distance_method_ == "astar_completion") {
                return calculateDistancesAstarCompletion(frontier_list, goals_xy, mx_robot, my_robot, resolution);
            } else {
                std::vector<double> distances;
                
                if (distance_method_ == "multi_astar") {
                    distance_calculator_.multiGoalAstar(static_cast<int>(mx_robot), static_cast<int>(my_robot),
                                                    goals_xy, distances, true, 1.0);
                } else {
                    distance_calculator_.multiGoalDijkstra(static_cast<int>(mx_robot), static_cast<int>(my_robot),
                                                        goals_xy, distances, true);
                }

                // Convert to meters and assign
                for (size_t i = 0; i < frontier_list.size(); ++i) {
                    if (i < distances.size() && std::isfinite(distances[i]) && distances[i] >= 0.0) {
                        frontier_list[i].min_distance = distances[i] * resolution;
                    } else {
                        frontier_list[i].min_distance = std::numeric_limits<double>::infinity();
                    }
                }
                return true;
            }
        } catch (const std::exception& e) {
            //ROS_ERROR("Exception in multi-goal distance calculation: %s", e.what());
            return false;
        }
    }

    bool FrontierSearch::calculateDistancesEuclidean(std::vector<Frontier>& frontier_list,
                                                unsigned int mx_robot, unsigned int my_robot)
    {
        double robot_x, robot_y;
        costmap_->mapToWorld(mx_robot, my_robot, robot_x, robot_y);
        
        for (auto& f : frontier_list) {
            f.min_distance = distance_calculator_.euclideanDistance(
                f.centroid.x, f.centroid.y, robot_x, robot_y);
            
            if (!std::isfinite(f.min_distance) || f.min_distance < 0.0) {
                //ROS_WARN("Invalid Euclidean distance computed for frontier at (%.2f, %.2f)",
                        // f.centroid.x, f.centroid.y);
                f.min_distance = std::numeric_limits<double>::infinity();
            }
        }
        return true;
    }

    bool FrontierSearch::calculateDistancesAstarCompletion(
        std::vector<Frontier>& frontier_list,
        const std::vector<std::pair<int,int>>& goals_xy,
        unsigned int mx_robot, unsigned int my_robot,
        double resolution)
    {
        // ✅ Single frontier wall adjustment
        if (frontier_list.size() == 1) {
            adjustSingleWallFrontierToFreeCell(frontier_list[0]);
        }

        // Filter valid goals
        std::vector<std::pair<int,int>> goals_valid;
        std::vector<size_t> map_back;
        goals_valid.reserve(goals_xy.size());
        map_back.reserve(goals_xy.size());
        
        for (size_t i = 0; i < goals_xy.size(); ++i) {
            if (goals_xy[i].first >= 0 && goals_xy[i].second >= 0) {
                goals_valid.push_back(goals_xy[i]);
                map_back.push_back(i);
            }
        }

        if (goals_valid.empty()) {
            //ROS_WARN("A*: no valid goals for completion heuristic");
            return false;
        }

        std::vector<double> distances_tmp(goals_valid.size(), std::numeric_limits<double>::infinity());

        // Get current costmap dimensions
        const unsigned int W = costmap_->getSizeInCellsX();
        const unsigned int H = costmap_->getSizeInCellsY();

        // ✅ CRITICAL: Choose the correct map based on model status
        cv::Mat map_for_astar;
        const char* map_source = nullptr;
        
        if (with_map_completion_ == 1) {
            // Model is ACTIVE → Use completed_map_ (contains model predictions)
            std::lock_guard<std::recursive_mutex> lock(data_mutex_);
            
            if (!completed_map_.empty() && completed_map_.type() == CV_8UC1 &&
                completed_map_.cols == static_cast<int>(W) && 
                completed_map_.rows == static_cast<int>(H)) {
                
                map_for_astar = completed_map_.clone();
                map_source = "MODEL predictions";
                ROS_DEBUG_THROTTLE(30.0, "A*: Using MODEL predictions for heuristic");
                
            } else {
                // Model active but completed_map_ not ready → fallback to Dijkstra
                ROS_WARN_THROTTLE(10.0, "A*: Model active but completed_map_ not ready - using Dijkstra");
                
                distance_calculator_.multiGoalDijkstra(
                    static_cast<int>(mx_robot), static_cast<int>(my_robot),
                    goals_valid, distances_tmp, true);
                
                for (size_t j = 0; j < map_back.size(); ++j) {
                    if (j < distances_tmp.size()) {
                        frontier_list[map_back[j]].min_distance = distances_tmp[j] * resolution;
                    }
                }
                return true;
            }
            
        } else {
            // Model is INACTIVE → Use GT as oracle (or fallback to Dijkstra)
            if (!gt_map_.empty() && gt_map_.type() == CV_8UC1 &&
                gt_map_.cols == static_cast<int>(W) && gt_map_.rows == static_cast<int>(H)) {
                
                map_for_astar = gt_map_.clone();
                map_source = "GT (oracle mode)";
                ROS_DEBUG_THROTTLE(30.0, "A*: Using GT as oracle for heuristic");
                
            } else {
                // Try to rebuild GT
                ROS_DEBUG_THROTTLE(10.0, "A*: GT map needs rebuild");
                
                try {
                    seedGT();
                    
                    if (!gt_map_.empty() && gt_map_.type() == CV_8UC1 &&
                        gt_map_.cols == static_cast<int>(W) && 
                        gt_map_.rows == static_cast<int>(H)) {
                        
                        map_for_astar = gt_map_.clone();
                        map_source = "GT (oracle mode, rebuilt)";
                        ROS_DEBUG("A*: GT map successfully rebuilt");
                        
                    } else {
                        // GT rebuild failed → fallback to Dijkstra
                        ROS_WARN_THROTTLE(10.0, "A*: GT rebuild failed - using Dijkstra");
                        
                        distance_calculator_.multiGoalDijkstra(
                            static_cast<int>(mx_robot), static_cast<int>(my_robot),
                            goals_valid, distances_tmp, true);
                        
                        for (size_t j = 0; j < map_back.size(); ++j) {
                            if (j < distances_tmp.size()) {
                                frontier_list[map_back[j]].min_distance = distances_tmp[j] * resolution;
                            }
                        }
                        return true;
                    }
                    
                } catch (const std::exception& e) {
                    ROS_ERROR("A*: Exception during GT rebuild: %s", e.what());
                    
                    distance_calculator_.multiGoalDijkstra(
                        static_cast<int>(mx_robot), static_cast<int>(my_robot),
                        goals_valid, distances_tmp, true);
                    
                    for (size_t j = 0; j < map_back.size(); ++j) {
                        if (j < distances_tmp.size()) {
                            frontier_list[map_back[j]].min_distance = distances_tmp[j] * resolution;
                        }
                    }
                    return true;
                }
            }
        }

        // Validate resolution
        if (!std::isfinite(resolution) || resolution <= 0.0) {
            ROS_ERROR("A*: Invalid resolution: %.6f", resolution);
            return false;
        }

        // ✅ Now use the correct map (model predictions OR GT oracle)
        try {
            ROS_DEBUG_THROTTLE(30.0, "A*: Computing distances using %s", map_source);
            
            distance_calculator_.multiGoalAstarCompletionHeuristic(
                static_cast<int>(mx_robot), static_cast<int>(my_robot),
                goals_valid, distances_tmp,
                /*allow_unknown=*/true,
                /*w=*/1.0,
                map_for_astar,              // ✅ CORRECT: Model predictions or GT oracle
                rect_size_,                  
                resolution,
                /*bias_k=*/0.8,             
                completion_known_scale_,     
                completion_obstacle_scale_  
            );

            // Write back results
            for (size_t j = 0; j < map_back.size(); ++j) {
                if (j < distances_tmp.size()) {
                    frontier_list[map_back[j]].min_distance = distances_tmp[j];
                    
                    if (!std::isfinite(frontier_list[map_back[j]].min_distance)) {
                        frontier_list[map_back[j]].min_distance = std::numeric_limits<double>::infinity();
                    }
                }
            }

            return true;
            
        } catch (const std::exception& e) {
            ROS_ERROR("A*: Exception in completion heuristic: %s", e.what());
            
            // Final fallback to Dijkstra
            distance_calculator_.multiGoalDijkstra(
                static_cast<int>(mx_robot), static_cast<int>(my_robot),
                goals_valid, distances_tmp, true);
            
            for (size_t j = 0; j < map_back.size(); ++j) {
                if (j < distances_tmp.size()) {
                    frontier_list[map_back[j]].min_distance = distances_tmp[j] * resolution;
                }
            }
            return true;
        }
    }
    
    // Helper functions for different distance calculation methods
    bool FrontierSearch::calculateDistancesUsingField(std::vector<Frontier>& frontier_list,
                                                    unsigned int mx_robot, unsigned int my_robot)
    {
        //ROS_DEBUG("Using distance field method");
        
        try {
            distance_calculator_.ensureDistanceField(static_cast<int>(mx_robot), 
                                                static_cast<int>(my_robot), true);

            const double resolution = costmap_->getResolution();
            if (resolution <= 0.0) {
                //ROS_ERROR("Invalid costmap resolution: %.6f", resolution);
                return false;
            }

            for (auto& f : frontier_list) {
                f.min_distance = std::numeric_limits<double>::infinity();
                
                // Try centroid first
                unsigned int gx, gy;
                if (costmap_->worldToMap(f.centroid.x, f.centroid.y, gx, gy)) {
                    double d_cells = distance_calculator_.distToCell(static_cast<int>(gx), static_cast<int>(gy));
                    if (std::isfinite(d_cells) && d_cells >= 0.0) {
                        f.min_distance = d_cells * resolution;
                        continue;
                    }
                }

                // Fallback to checking all frontier points
                for (const auto& point : f.points) {
                    if (costmap_->worldToMap(point.x, point.y, gx, gy)) {
                        double d_cells = distance_calculator_.distToCell(static_cast<int>(gx), static_cast<int>(gy));
                        if (std::isfinite(d_cells) && d_cells >= 0.0) {
                            double d_meters = d_cells * resolution;
                            if (d_meters < f.min_distance) {
                                f.min_distance = d_meters;
                            }
                        }
                    }
                }
            }
            return true;
        } catch (const std::exception& e) {
            //ROS_ERROR("Exception in distance field calculation: %s", e.what());
            return false;
        }
    }

    Frontier FrontierSearch::buildNewFrontier(unsigned int initial_cell,
                                        unsigned int reference,
                                        std::vector<bool>& frontier_flag)
    {
        const size_t map_size = size_x_ * size_y_;
        
        if (initial_cell >= map_size || reference >= map_size) {
            ROS_WARN("Invalid cell indices: initial=%u, reference=%u, map_size=%zu", 
                    initial_cell, reference, map_size);
            return {};
        }

        if (!costmap_) {
            ROS_ERROR("Costmap is null in buildNewFrontier");
            return {};
        }

        Frontier output;
        output.size = 0;
        output.min_distance = std::numeric_limits<double>::infinity();
        output.map_resolution = costmap_->getResolution();
        output.centroid.x = 0.0;
        output.centroid.y = 0.0;
        output.completion_known_score = 0.0;
        output.completion_obstacle_score = 0.0;

        output.has_wall = false;
        output.has_gap = false;
        output.has_large_gap = false;
        output.has_small_gap = false;
        output.gap_size = 0.0;

        if (output.map_resolution <= 0.0) {
            ROS_ERROR("Invalid map resolution: %.6f", output.map_resolution);
            return {};
        }

        unsigned int ix, iy;
        costmap_->indexToCells(initial_cell, ix, iy);
        costmap_->mapToWorld(ix, iy, output.initial.x, output.initial.y);

        unsigned int rx, ry;
        double reference_x, reference_y;
        costmap_->indexToCells(reference, rx, ry);
        costmap_->mapToWorld(rx, ry, reference_x, reference_y);

        std::queue<unsigned int> bfs;
        bfs.push(initial_cell);

        double best_middle_d2 = std::numeric_limits<double>::infinity();
        const size_t max_frontier_size = 10000;

        try {
            while (!bfs.empty() && output.size < max_frontier_size) {
                unsigned int idx = bfs.front();
                bfs.pop();

                for (unsigned int nbr : nhood8(idx, *costmap_)) {
                    if (nbr >= map_size) continue;

                    if (isNewFrontierCell(nbr, frontier_flag)) {
                        frontier_flag[nbr] = true;

                        unsigned int mx, my;
                        double wx, wy;
                        costmap_->indexToCells(nbr, mx, my);
                        costmap_->mapToWorld(mx, my, wx, wy);

                        if (!std::isfinite(wx) || !std::isfinite(wy)) continue;

                        geometry_msgs::Point p;
                        p.x = wx; p.y = wy; p.z = 0.0;
                        output.points.push_back(p);
                        output.size++;

                        output.centroid.x += wx;
                        output.centroid.y += wy;

                        const double dx = wx - reference_x;
                        const double dy = wy - reference_y;
                        const double d2 = dx * dx + dy * dy;
                        
                        if (d2 < best_middle_d2) {
                            best_middle_d2 = d2;
                            output.middle.x = wx;
                            output.middle.y = wy;
                            output.middle.z = 0.0;
                        }

                        if(use_completed_map_ == 0)
                        {
                            double distance = sqrt(pow((double(reference_x) - double(wx)), 2.0) +
                                pow((double(reference_y) - double(wy)), 2.0));
                                if (distance < output.min_distance) {
                                output.min_distance = distance;
                                output.middle.x = wx;
                                output.middle.y = wy;
                            }
                            output.too_close_to_obstacle = false;
                        }

                        bfs.push(nbr);
                    }
                }
            }
        } catch (const std::exception& e) {
            ROS_ERROR("Exception in buildNewFrontier: %s", e.what());
            return {};
        }

        if (output.size == 0) return {};

        // Orta noktayı hesapla
        const double size_d = static_cast<double>(output.size);
        const double cx = output.centroid.x / size_d;
        const double cy = output.centroid.y / size_d;
        
        if (!std::isfinite(cx) || !std::isfinite(cy)) return {};

        if(use_completed_map_ == 0)
        {
            // Standart mod: Ortalama centroid'i ata
            output.centroid.x /= output.size;
            output.centroid.y /= output.size;
            output.safest_point = output.centroid;
        }
        else {
            // Map Completion Modu: Ortalama noktaya en yakın gerçek frontier hücresini bul (snap)
            geometry_msgs::Point nearest_to_mean;
            double best_mean_d2 = std::numeric_limits<double>::infinity();
            
            for (const auto& point : output.points) {
                const double dx = point.x - cx;
                const double dy = point.y - cy;
                const double d2 = dx * dx + dy * dy;
                
                if (d2 < best_mean_d2) {
                    best_mean_d2 = d2;
                    nearest_to_mean = point;
                }
            }
            
            // // Centroid değerini gerçek bir hücreye sabitliyoruz
            // output.centroid = nearest_to_mean;
            // // ✅ KRİTİK: isFrontierTooCloseToObstacle ve RVIZ görselleştirmesi için safest_point'i centroid yapıyoruz
            // output.safest_point = output.centroid; 


            // Orta noktayı hesapla
            const double size_d = static_cast<double>(output.size);
            const double true_mean_x = output.centroid.x / size_d;
            const double true_mean_y = output.centroid.y / size_d;

            if (!std::isfinite(true_mean_x) || !std::isfinite(true_mean_y)) return {};

            if(use_completed_map_ == 0) {
                output.centroid.x = true_mean_x;
                output.centroid.y = true_mean_y;
                output.safest_point = output.centroid;
            }
            else {
                // Map Completion Modu:
                geometry_msgs::Point nearest_to_mean;
                double best_mean_d2 = std::numeric_limits<double>::infinity();
                
                for (const auto& point : output.points) {
                    const double dx = point.x - true_mean_x;
                    const double dy = point.y - true_mean_y;
                    const double d2 = dx * dx + dy * dy;
                    if (d2 < best_mean_d2) {
                        best_mean_d2 = d2;
                        nearest_to_mean = point;
                    }
                }
                
                // 1. TAHMİN NOKTASI (f.centroid): Modelin patch alacağı yer (gerçek hücre)
                output.centroid = nearest_to_mean;
                
                // 2. NAVİGASYON HEDEFİ (f.safest_point): Matematiksel orta nokta
                output.safest_point.x = true_mean_x;
                output.safest_point.y = true_mean_y;
                output.safest_point.z = 0.0;
            }
        }
        
        // Middle point kontrolü
        if (!std::isfinite(output.middle.x) || !std::isfinite(output.middle.y)) {
            output.middle = output.centroid;
        }

        return output;
    }

  


    double FrontierSearch::getWallProximityPenalty(const Frontier& f) const
    {
        unsigned int mx, my;
        if (!costmap_->worldToMap(f.safest_point.x, f.safest_point.y, mx, my)) {
            return 0.0;  // Harita dışı → ceza yok
        }

        double total_cost = 0.0;
        int count = 0;

        // Merkez + 8 komşu (3x3 alan)
        for (int dy = -1; dy <= 1; ++dy) {
            for (int dx = -1; dx <= 1; ++dx) {
                unsigned int nx = mx + dx;
                unsigned int ny = my + dy;

                if (nx < costmap_->getSizeInCellsX() && ny < costmap_->getSizeInCellsY()) {
                    unsigned char c = costmap_->getCost(nx, ny);
                    if (c >= 253) c = 255;  // Lethal/inflated → max ceza
                    total_cost += static_cast<double>(c);
                    count++;
                }
            }
        }

        if (count == 0) return 0.0;

        // Ortalama maliyet (0-255 arası) → 0-10 ceza aralığına ölçekle
        double avg_cost = total_cost / count;
        double penalty = (avg_cost / 255.0) * 10.0;  // 0-10 arası

        

        return penalty;
    }

    double FrontierSearch::getMinDistanceToWall(const Frontier& f) const
    {
        unsigned int mx, my;
        if (!costmap_->worldToMap(f.safest_point.x, f.safest_point.y, mx, my)) {
            return obstacle_distance_threshold_;  // Harita dışı → uzak say
        }

        const double res = costmap_->getResolution();
        double min_dist = obstacle_distance_threshold_ + 1.0;  // Başlangıçta büyük değer

        // Sadece 5x5 alan tarıyoruz (yaklaşık 1 m çap, çok hızlı)
        const int radius_cells = 5;
        for (int dy = -radius_cells; dy <= radius_cells; ++dy) {
            for (int dx = -radius_cells; dx <= radius_cells; ++dx) {
                unsigned int nx = mx + dx;
                unsigned int ny = my + dy;

                if (nx < costmap_->getSizeInCellsX() && ny < costmap_->getSizeInCellsY()) {
                    unsigned char cost = costmap_->getCost(nx, ny);
                    if (cost >= 253) {  // Engelli hücre
                        double dist = std::hypot(static_cast<double>(dx), static_cast<double>(dy)) * res;
                        if (dist < min_dist) {
                            min_dist = dist;
                        }
                    }
                }
            }
        }

        return min_dist;
    }

    /**
    * Frontier'ın safest_point'inden completed_map'teki en yakın ENGEL pikseline (val == 0) olan mesafeyi döndürür.
    * Eğer engel yoksa threshold döndürür (ceza 0 olur).
    */
    // double FrontierSearch::getMinDistanceToCompletedMapObstacle(const Frontier& f) const
    // {
    //     if (completed_map_.empty()) {
    //         ROS_WARN_ONCE("completed_map_ empty - no wall penalty calculated");
    //         return obstacle_distance_threshold_;  // Ceza 0 olsun
    //     }

    //     unsigned int mx, my;
    //     if (!costmap_->worldToMap(f.safest_point.x, f.safest_point.y, mx, my)) {
    //         return obstacle_distance_threshold_;
    //     }

    //     const double res = costmap_->getResolution();
    //     double min_dist = obstacle_distance_threshold_ + 1.0;  // Başlangıç büyük değer

    //     // Tarama yarıçapı: max 1 m + tampon (hızlı olsun diye 20 hücre sınırlı)
    //     const int max_radius_cells = static_cast<int>(std::ceil(1.0 / res)) + 5;  // ~25 hücre
    //     int checked_cells = 0;
    //     int obstacle_cells = 0;

    //     int closest_dx = 0, closest_dy = 0;

    //     for (int dy = -max_radius_cells; dy <= max_radius_cells; ++dy) {
    //         for (int dx = -max_radius_cells; dx <= max_radius_cells; ++dx) {
    //             int nx = static_cast<int>(mx) + dx;
    //             int ny = static_cast<int>(my) + dy;

    //             // OpenCV koordinat dönüşümü (top-left origin)
    //             int cv_x = nx;
    //             int cv_y = completed_map_.rows - 1 - ny;

    //             if (cv_x >= 0 && cv_x < completed_map_.cols && cv_y >= 0 && cv_y < completed_map_.rows) {
    //                 checked_cells++;
    //                 unsigned char val = completed_map_.at<uchar>(cv_y, cv_x);

    //                 if (val == 0) {  // Engel pikseli
    //                     obstacle_cells++;
    //                     double dist = std::hypot(static_cast<double>(dx), static_cast<double>(dy)) * res;
    //                     if (dist < min_dist) {
    //                         min_dist = dist;
    //                         closest_dx = dx;
    //                         closest_dy = dy;
    //                     }
    //                 }
    //             }
    //         }
    //     }

    //     ROS_DEBUG("Completed map distance calc: frontier=(%.2f, %.2f), checked=%d cells, obstacles=%d, min_dist=%.3fm (closest offset=%d,%d)",
    //             f.safest_point.x, f.safest_point.y, checked_cells, obstacle_cells, min_dist, closest_dx, closest_dy);

    //     return min_dist;
    // }

    double FrontierSearch::getMinDistanceToCompletedMapObstacle(const Frontier& f) const
    {
        if (completed_map_.empty()) return obstacle_distance_threshold_;

        unsigned int mx, my;
        if (!costmap_->worldToMap(f.safest_point.x, f.safest_point.y, mx, my))
            return obstacle_distance_threshold_;

        const double res = costmap_->getResolution();
        const int max_r = static_cast<int>(std::ceil(1.0 / res)) + 5;
        
        // ✅ Squared distance kullan → sqrt YOK iç döngüde!
        double min_dist_sq = std::numeric_limits<double>::max();

        for (int dy = -max_r; dy <= max_r; ++dy) {
            for (int dx = -max_r; dx <= max_r; ++dx) {
                
                // ✅ Early exit: Bu hücre zaten min_dist'ten uzaksa atla
                double dist_sq = static_cast<double>(dx*dx + dy*dy);
                if (dist_sq >= min_dist_sq) continue;
                
                int nx = static_cast<int>(mx) + dx;
                int ny = static_cast<int>(my) + dy;
                int cv_x = nx;
                int cv_y = completed_map_.rows - 1 - ny;

                if (cv_x < 0 || cv_x >= completed_map_.cols || 
                    cv_y < 0 || cv_y >= completed_map_.rows) continue;

                if (completed_map_.at<uchar>(cv_y, cv_x) == 0) {
                    min_dist_sq = dist_sq;
                }
            }
        }

        // ✅ Sadece 1 kez sqrt!
        if (min_dist_sq == std::numeric_limits<double>::max())
            return obstacle_distance_threshold_ + 1.0;
        
        return std::sqrt(min_dist_sq) * res;
    }

    double FrontierSearch::frontierCost(const Frontier& f)
    {
        // ═══════════════════════════════════════════════════════════
        // 0. DEBUG MAP COST (Noktanın haritadaki maliyetini gör)
        // ═══════════════════════════════════════════════════════════
        unsigned int mx, my;
        if (costmap_->worldToMap(f.centroid.x, f.centroid.y, mx, my)) {
            unsigned char map_cost = costmap_->getCost(mx, my);
            // ROS_DEBUG("Frontier at (%.2f, %.2f) -> Map Cost: %d", 
            //         f.centroid.x, f.centroid.y, (int)map_cost);
            
            // Eğer harita maliyeti 253 (INSCRIBED), 254 (LETHAL) veya 255 (NO_INFORMATION) ise
            // navigasyon planlayıcısı buraya asla yol çizemez.
        }
        
        // ═══════════════════════════════════════════════════════════
        // SAFETY CHECKS
        // ═══════════════════════════════════════════════════════════
        if (!std::isfinite(f.min_distance)) {
            // ROS_WARN("Frontier at (%.2f, %.2f) has invalid distance",
            //         f.centroid.x, f.centroid.y);
            return std::numeric_limits<double>::infinity();
        }

        const double distance_m = f.min_distance;
        const double size_m = f.size * costmap_->getResolution();

        // ═══════════════════════════════════════════════════════════
        // 1. BASE COST (always active)
        // ═══════════════════════════════════════════════════════════
        const double distance_cost = potential_scale_ * distance_m; 
        // if(use_completed_map_ != 1)
        // {
        //     distance_cost = potential_scale_ * distance_m; // original
        // }
        // else{
        //     // Mesafeyi lineer değil, karesel olarak cezalandıralım. 
        //     // Bu, robotun "yol üstündeki" yakın frontier'ları toplamasını sağlar.
        //     distance_cost = potential_scale_ * std::pow(distance_m, 1.5); // 1.5 kuvveti dengeleyicidir
        // }
        
        
        const double size_reward = gain_scale_ * size_m;
        double cost = distance_cost - size_reward;;
         
        
        // ROS_DEBUG("=== Frontier (%.2f, %.2f) ===", f.centroid.x, f.centroid.y);
        // ROS_DEBUG("├─ Distance: %.2fm → cost: +%.2f", distance_m, distance_cost);
        // ROS_DEBUG("├─ Size: %.2fm → reward: -%.2f", size_m, size_reward);
        // ROS_DEBUG("└─ Base cost: %.2f", cost);

        // Navigation-only mode or completion disabled
        if (navigation_only_mode_ || use_completed_map_ != 1) {
            //ROS_DEBUG("Final cost (no completion): %.2f", cost);
            return cost;
        }

        // B. Ceza: Tahmin edilen engel yoğunluğu (Obstacle Density Penalty)
        // Patch içinde ne kadar çok duvar varsa o kadar az tercih et.
        //const double obstacle_penalty = completion_obstacle_scale_ * f.completion_obstacle_score;
        
        
        // C. Ekstra Ceza: Tam merkez duvar mı? (On-Wall Penalty)
        // Eğer model frontier'ın tam üstünde duvar görüyorsa, bu büyük ihtimalle 
        // ulaşılamaz bir noktadır veya SLAM gürültüsüdür.
        //double wall_bias = completion_obstacle_scale_ * f.center_wall_density ;
        double wall_bias = 0;
        // cost+=wall_bias;
        double free_ratio = f.completion_free_score;
        double free_reward = 0;
        if (f.predicted_on_wall) {
            wall_bias = 100.0; // Sabit yüksek bir ceza puanı (ayarlanabilir)
            cost+=wall_bias;
        }
        else
        {
             // ═══════════════════════════════════════════════════════════
            // 2. FREE SPACE REWARD (how much new area?)
            // Range: 0 to -10 (more free space = lower cost)
            // ═══════════════════════════════════════════════════════════
            
            free_reward = completion_known_scale_ * free_ratio;
            cost -= free_reward;

        }


      
        // ═══════════════════════════════════════════════════════════
        // FINAL SUMMARY (Simplified)
        // ═══════════════════════════════════════════════════════════
        ROS_DEBUG("Final Calculation for (%.2f, %.2f):", f.centroid.x, f.centroid.y);
        ROS_DEBUG("  [+] Dist Cost: %.2f", distance_cost);
        ROS_DEBUG("  [-] Size Reward: %.2f", size_reward);
        ROS_DEBUG("  [-] Free Reward: %.2f", free_reward);
        ROS_DEBUG("  [-] Wall Penalty : %.2f", wall_bias);
        ROS_DEBUG("  [=] TOTAL COST: %.2f", cost);

        return cost;
    }

    
    // ✅ YENİ: Küçük kayma içinde GT'de duvar var mı kontrol et
    bool FrontierSearch::hasWallNearby(const cv::Mat& gt_patch, int x, int y, int tolerance) {
        // tolerance: kaç piksel yakınlığa bakalım (1 veya 2 önerilir)
        
        for (int dy = -tolerance; dy <= tolerance; dy++) {
            for (int dx = -tolerance; dx <= tolerance; dx++) {
                int nx = x + dx;
                int ny = y + dy;
                
                // Sınır kontrolü
                if (nx < 0 || nx >= gt_patch.cols || ny < 0 || ny >= gt_patch.rows) {
                    continue;
                }
                
                // GT'de duvar var mı?
                if (gt_patch.at<uchar>(ny, nx) == OBSTACLE_U8) {
                    return true;  // Yakında duvar var!
                }
            }
        }
        
        return false;  // Yakında duvar yok
    }

   

    // 1. ÖNCE: searchFrom içinde tek bir live_cm oluşturup tüm alt fonksiyonlara paslayacağız.
    // getCompletedRegionAroundFrontier metodunu bu şekilde güncelleyin:

    bool FrontierSearch::getCompletedRegionAroundFrontier(double frontier_x, double frontier_y,
                                                       cv::Mat& out_gt, cv::Mat& out_cur)
    {
        if (!costmap_ || rect_size_ <= 0) return false;

        // 1. Mevcut (canlı) yamayı DOĞRUDAN costmap'ten kes (Çok hızlıdır)
        // Global matris döngüsüne gerek kalmadı.
        if (!cropFromCostmap(frontier_x, frontier_y, rect_size_, out_cur)) {
            return false;
        }

        // 2. Cache'den (modelin tahmininden) ara
        std::lock_guard<std::recursive_mutex> lock(data_mutex_);
        FrontierKey key = getFrontierKey(frontier_x, frontier_y);
        auto cache_it = completed_patch_cache_.find(key);
        
        if (cache_it != completed_patch_cache_.end() && cache_it->second.valid) {
            ros::Duration age = ros::Time::now() - cache_it->second.timestamp;
            if (age.toSec() < 30.0) {
                out_gt = cache_it->second.patch.clone();  // Tahmini ver
                return true;
            }
        }

        // 3. Tahmin yoksa mecburen canlı veriyi döndür
        out_gt = out_cur.clone(); 
        return true;    
    }

    // ✅ BASİT VE ETKİLİ 5 YÖNLÜ ALIGNMENT
    bool FrontierSearch::performAdvancedAlignment(const cv::Mat& live_cm, const cv::Rect& roi_cm, cv::Mat& out_aligned_gt) {
        const int W = live_cm.cols;
        const int H = live_cm.rows;
        
        // 1. ORJİNAL LOCAL PATCH
        cv::Mat local_gt_patch = gt_map_(roi_cm).clone();
        cv::Mat local_live_patch = live_cm(roi_cm).clone();
        
        double original_score = computeSimpleAlignmentScore(local_gt_patch, local_live_patch);
        //ROS_INFO("Original alignment score: %.3f", original_score);
        
        // 2. 5 YÖNLÜ ALIGNMENT DENEMELERİ
        std::vector<AlignmentCandidate> candidates;
        
        // A. ORJİNAL (0,0)
        candidates.push_back(AlignmentCandidate(roi_cm, "ORIGINAL", original_score, 0, 0));
        
        // B. 4 YÖNDE 16x16'LIK ALANLAR
        const int expansion = rect_size_ / 2; // 16 piksel
        
        // SOL - Batı (WEST)
        if (roi_cm.x - expansion >= 0) {
            cv::Rect west_roi(roi_cm.x - expansion, roi_cm.y, expansion, roi_cm.height);
            cv::Mat west_live = live_cm(west_roi).clone();
            
            if (checkAlignmentReference(west_live)) {
                testAlignmentCandidates(live_cm, west_roi, roi_cm, "WEST", expansion, candidates);
            }
        }
        
        // SAĞ - Doğu (EAST)  
        if (roi_cm.x + roi_cm.width + expansion <= W) {
            cv::Rect east_roi(roi_cm.x + roi_cm.width, roi_cm.y, expansion, roi_cm.height);
            cv::Mat east_live = live_cm(east_roi).clone();
            
            if (checkAlignmentReference(east_live)) {
                testAlignmentCandidates(live_cm, east_roi, roi_cm, "EAST", expansion, candidates);
            }
        }
        
        // ÜST - Kuzey (NORTH)
        if (roi_cm.y - expansion >= 0) {
            cv::Rect north_roi(roi_cm.x, roi_cm.y - expansion, roi_cm.width, expansion);
            cv::Mat north_live = live_cm(north_roi).clone();
            
            if (checkAlignmentReference(north_live)) {
                testAlignmentCandidates(live_cm, north_roi, roi_cm, "NORTH", expansion, candidates);
            }
        }
        
        // ALT - Güney (SOUTH)
        if (roi_cm.y + roi_cm.height + expansion <= H) {
            cv::Rect south_roi(roi_cm.x, roi_cm.y + roi_cm.height, roi_cm.width, expansion);
            cv::Mat south_live = live_cm(south_roi).clone();
            
            if (checkAlignmentReference(south_live)) {
                testAlignmentCandidates(live_cm, south_roi, roi_cm, "SOUTH", expansion, candidates);
            }
        }
        
        // 3. EN İYİ ADAYI SEÇ - ÖNEMLİ: SADECE BELİRGİN İYİLEŞME VARSA
        std::sort(candidates.begin(), candidates.end(), 
                [](const AlignmentCandidate& a, const AlignmentCandidate& b) { 
                    return a.score > b.score; 
                });
        
        //ROS_INFO("Alignment candidates:");
        for (size_t i = 0; i < candidates.size(); ++i) {
            const auto& cand = candidates[i];
            // ROS_INFO("  %s: score=%.3f, shift=(%d,%d)", 
            //          cand.name.c_str(), cand.score, cand.dx, cand.dy);
        }
        
        const AlignmentCandidate& best = candidates[0];
        //double alignment_threshold = 0.2; // %20'den fazla iyileşme
        //double alignment_threshold = std::max(0.15, original_score * 0.3);
        // ✅ DAHA DÜŞÜK THRESHOLD - küçük iyileşmeleri bile kabul et
        //double alignment_threshold = std::max(0.08, original_score * 0.15);  // 0.15 → 0.08
        double alignment_threshold = std::max(0.05, original_score * 0.1); // 0.15→0.05, 0.3→0.1

        // VEYA daha da agresif:
        //double alignment_threshold = 0.03; // Sabit düşük threshold
            
        // ✅ KRİTİK: SADECE BELİRGİN İYİLEŞME VARSA KABUL ET
        if (best.score > original_score + alignment_threshold) { 
            cv::Rect best_roi(roi_cm.x + best.dx, roi_cm.y + best.dy, roi_cm.width, roi_cm.height);
            
            if (best_roi.x >= 0 && best_roi.y >= 0 && 
                best_roi.x + best_roi.width <= W && 
                best_roi.y + best_roi.height <= H) {
                
                out_aligned_gt = gt_map_(best_roi).clone();
                // ROS_INFO("✅ BEST alignment: %s, shift=(%d,%d), score=%.3f (was %.3f)", 
                //          best.name.c_str(), best.dx, best.dy, best.score, original_score);
                return true;
            }
        }
        
        // 4. FALLBACK: Orjinal GT
        out_aligned_gt = local_gt_patch;
        // ROS_INFO("❌ No significant improvement (best: %.3f, original: %.3f), using original GT", 
        //          best.score, original_score);
        return false;
    }

    // ✅ YARDIMCI: Bir yöndeki alignment adaylarını test et
    void FrontierSearch::testAlignmentCandidates(const cv::Mat& live_cm, 
                                                const cv::Rect& search_roi,
                                                const cv::Rect& original_roi,
                                                const std::string& direction,
                                                int search_range,
                                                std::vector<AlignmentCandidate>& candidates) {
        const int W = live_cm.cols;
        const int H = live_cm.rows;
        
        cv::Mat search_live = live_cm(search_roi).clone();
        
        // Bu yöndeki farklı kaymaları dene
        for (int dy = -search_range; dy <= search_range; dy++) {
            for (int dx = -search_range; dx <= search_range; dx++) {
                // Sadece bu yöne uygun kaymaları dene (optimizasyon)
                if ((direction == "WEST" || direction == "EAST") && dx == 0) continue;
                if ((direction == "NORTH" || direction == "SOUTH") && dy == 0) continue;
                
                cv::Rect shifted_roi(original_roi.x + dx, original_roi.y + dy, 
                                    original_roi.width, original_roi.height);
                
                if (shifted_roi.x < 0 || shifted_roi.y < 0 || 
                    shifted_roi.x + shifted_roi.width > W || 
                    shifted_roi.y + shifted_roi.height > H) {
                    continue;
                }
                
                cv::Mat shifted_gt_patch = gt_map_(shifted_roi).clone();
                cv::Mat original_live_patch = live_cm(original_roi).clone();
                double score = computeSimpleAlignmentScore(shifted_gt_patch, original_live_patch);
                
                candidates.push_back(AlignmentCandidate(shifted_roi, direction, score, dx, dy));
            }
        }
    }

    // ✅ YENİ: HİZALANACAK REFERANS VAR MI?
    bool FrontierSearch::checkAlignmentReference(const cv::Mat& patch)
    {
        int significant_features = 0;
        
        for (int y = 0; y < patch.rows; y++) {
            for (int x = 0; x < patch.cols; x++) {
                uchar val = patch.at<uchar>(y, x);
                
                // Sadece obstacle'ları referans al (free space değişken olabilir)
                if (val == OBSTACLE_U8) {
                    significant_features++;
                }
            }
        }
        
        // En az 10 obstacle piksel varsa alignment yap
        bool has_reference = (significant_features >= 10);
        
        // ROS_DEBUG("Alignment reference: %d obstacle pixels -> %s", 
        //           significant_features, has_reference ? "ALIGN" : "NO ALIGN");
        
        return has_reference;
    }

    // ✅ BASİT ALIGNMENT SCORE (Aynı)
    double FrontierSearch::computeSimpleAlignmentScore(const cv::Mat& patch1, const cv::Mat& patch2)
    {
        if (patch1.size() != patch2.size() || patch1.empty()) {
            return 0.0;
        }
        
        int match_count = 0;
        int total_count = 0;
        
        for (int y = 0; y < patch1.rows; y++) {
            for (int x = 0; x < patch1.cols; x++) {
                uchar v1 = patch1.at<uchar>(y, x);
                uchar v2 = patch2.at<uchar>(y, x);
                
                // Sadece obstacle'ları karşılaştır (en güvenilir feature)
                if (v1 == OBSTACLE_U8 || v2 == OBSTACLE_U8) {
                    total_count++;
                    if (v1 == v2) {
                        match_count++;
                    }
                }
            }
        }
        
        if (total_count == 0) return 0.0;
        return static_cast<double>(match_count) / total_count;
    }

    double FrontierSearch::patchAgreementScore(const cv::Mat& completed, 
                                            const cv::Mat& cur,
                                            const cv::Mat& accessible_mask,  // ✅ YENİ
                                            double* out_known_score, 
                                            double* out_obst_score)
    {
        if (out_known_score) *out_known_score = 0.0;
        if (out_obst_score)  *out_obst_score  = 0.0;

        if (completed.empty() || cur.empty() || 
            completed.type()!=CV_8UC1 || cur.type()!=CV_8UC1 || 
            completed.size()!=cur.size())
            return 0.0;

        // Robot'un UNKNOWN dediği pikseller
        cv::Mat robot_unknown = (cur == UNKNOWN_U8);
        
        // ✅ YENİ: Sadece ERİŞİLEBİLİR unknown pikselleri say
        if (!accessible_mask.empty() && accessible_mask.size() == cur.size()) {
            robot_unknown = robot_unknown & accessible_mask;  // Sadece erişilebilir kısım
            //ROS_DEBUG("Using accessible mask: filtering unknown pixels");
        }
        
        const int N = cv::countNonZero(robot_unknown);
        
        if (N == 0) {
            //ROS_DEBUG("No accessible unknown pixels to score");
            return 0.0;
        }

        // completed_map, robot'un erişilebilir unknown alanlarında ne diyor?
        const int free_gain = cv::countNonZero((completed == KNOWN_U8) & robot_unknown);
        const int obst_gain = cv::countNonZero((completed == OBSTACLE_U8) & robot_unknown);
        
        const double s_free = double(free_gain) / N;
        const double s_obst = double(obst_gain) / N;

        if (out_known_score) *out_known_score = s_free;
        if (out_obst_score)  *out_obst_score  = s_obst;

        // ROS_DEBUG("Accessible completion score: unknown=%d px, free_gain=%d (%.1f%%), obst_gain=%d (%.1f%%)",
        //           N, free_gain, s_free*100, obst_gain, s_obst*100);

        return 0.5*(s_free + s_obst);
    }

    bool FrontierSearch::isNoisyInteriorFrontier(const Frontier& frontier, 
                                                int total_frontiers_count) const
    {
        if (!costmap_ || frontier.points.size() < 3) return false;
        
        // ========== SAFETY RULE #1: NEVER FILTER THE LAST FRONTIER ==========
        if (total_frontiers_count <= 1) {
            return false;  // Keep it - it's the only one!
        }
        
               
        // ✅ USE PARAMETERS
        const double min_frontier_length = interior_noise_min_length_;
        const double max_frontier_length = interior_noise_max_length_;
        const double very_short_check_distance = check_distance_;
        const double free_space_ratio = noise_in_room_threshold_;
        const double per_sample_ratio = interior_noise_agreement_ratio_;
        const int min_total_checks = 12;  // Keep hardcoded - statistical minimum
        const double max_obstacle_ratio = interior_noise_max_obstacle_ratio_;
        
        // Step 1: Check frontier size - only filter very small ones
        const auto& p_first = frontier.points.front();
        const auto& p_last = frontier.points.back();
        
        double dx = p_last.x - p_first.x;
        double dy = p_last.y - p_first.y;
        double length = std::sqrt(dx*dx + dy*dy);
        
        // Too small → might be noise, continue checking
        if (length < min_frontier_length) return false;
        
        // Too large → definitely keep it!
        //if (length > max_frontier_length) return false;
        
        // Unit vectors
        double tx = dx / length;
        double ty = dy / length;
        
        // Perpendicular vectors
        double nx1 = -ty, ny1 = tx;
        double nx2 = ty, ny2 = -tx;
        
        const double res = costmap_->getResolution();
        const int steps = static_cast<int>(very_short_check_distance / res);  // Short distance!
        
        // Good sampling
        const int samples = std::min(std::max(5, (int)(length / 0.08)), 
                                    (int)frontier.points.size());
        
        // Step 2: Check both sides - require VERY high free space
        auto checkSide = [&](double nx, double ny) -> std::tuple<bool, int, int, int, int> {
            int free_count = 0;
            int obstacle_count = 0;
            int unknown_count = 0;
            int total_checks = 0;
            
            for (int i = 0; i < samples; ++i) {
                int idx = (i * frontier.points.size()) / samples;
                const auto& pt = frontier.points[idx];
                
                // Cast ray perpendicular to frontier (SHORT DISTANCE!)
                for (int step = 1; step <= steps; ++step) {
                    double wx = pt.x + step * res * nx;
                    double wy = pt.y + step * res * ny;
                    
                    unsigned int mx, my;
                    if (!costmap_->worldToMap(wx, wy, mx, my)) continue;
                    
                    total_checks++;
                    unsigned char cost = costmap_->getCost(mx, my);
                    
                    if (cost == costmap_2d::FREE_SPACE) {
                        free_count++;
                    } else if (cost == costmap_2d::NO_INFORMATION) {
                        unknown_count++;
                    } else if (cost >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                        obstacle_count++;
                    }
                }
            }
            
            // Need sufficient data
            if (total_checks < min_total_checks) {
                return std::make_tuple(false, free_count, obstacle_count, unknown_count, total_checks);
            }
            
            // ANY obstacles nearby? Probably real wall → keep it!
            double obstacle_ratio = static_cast<double>(obstacle_count) / total_checks;
            if (obstacle_ratio > max_obstacle_ratio) {
                return std::make_tuple(false, free_count, obstacle_count, unknown_count, total_checks);
            }
            
            // Require VERY HIGH free space (ignore unknown - treat as not-free for safety)
            double pure_free_ratio = static_cast<double>(free_count) / total_checks;
            bool is_very_free = pure_free_ratio > free_space_ratio;
            
            return std::make_tuple(is_very_free, free_count, obstacle_count, unknown_count, total_checks);
        };
        
        bool side1_very_free;
        int free1, obs1, unk1, total1;
        std::tie(side1_very_free, free1, obs1, unk1, total1) = checkSide(nx1, ny1);

        bool side2_very_free;
        int free2, obs2, unk2, total2;
        std::tie(side2_very_free, free2, obs2, unk2, total2) = checkSide(nx2, ny2);
        
        // Step 3: Per-sample agreement check (must be very consistent)
        auto checkPerSampleAgreement = [&](double nx, double ny) -> bool {
            int agreeing_samples = 0;
            
            for (int i = 0; i < samples; ++i) {
                int idx = (i * frontier.points.size()) / samples;
                const auto& pt = frontier.points[idx];
                
                int sample_free = 0;
                int sample_total = 0;
                
                for (int step = 1; step <= steps; ++step) {
                    double wx = pt.x + step * res * nx;
                    double wy = pt.y + step * res * ny;
                    
                    unsigned int mx, my;
                    if (!costmap_->worldToMap(wx, wy, mx, my)) continue;
                    
                    sample_total++;
                    unsigned char cost = costmap_->getCost(mx, my);
                    
                    // Only count pure free space
                    if (cost == costmap_2d::FREE_SPACE) {
                        sample_free++;
                    }
                }
                
                // Require high ratio for each sample
                if (sample_total > 0 && (double)sample_free / sample_total > 0.75) {
                    agreeing_samples++;
                }
            }
            
            return (double)agreeing_samples / samples >= per_sample_ratio;
        };
        
        bool side1_agreement = checkPerSampleAgreement(nx1, ny1);
        bool side2_agreement = checkPerSampleAgreement(nx2, ny2);
        
        // ========== ULTRA-CONSERVATIVE DECISION ==========
        // Filter ONLY if:
        // 1. BOTH sides have VERY HIGH free space (85%+)
        // 2. BOTH sides have HIGH per-sample agreement (80%+)
        // 3. Almost NO obstacles nearby (<8%)
        // 4. Small size (0.15-0.4m)
        // 5. Not the last frontier
        // 6. Far from robot (>1.5m)
        
        if (side1_very_free && side2_very_free && side1_agreement && side2_agreement) {
            ROS_INFO("🗑️ Filtered interior noise at (%.2f, %.2f): "
                "len=%.3fm, side1[free=%d/%d=%.1f%%] side2[free=%d/%d=%.1f%%]",
                frontier.centroid.x, frontier.centroid.y, length,
                free1, total1, 100.0*free1/total1,
                free2, total2, 100.0*free2/total2);
            return true;
        }
        
        return false;
    }

    // Yeni overload - özel origin ve resolution için
    bool FrontierSearch::buildGridFromMat(const cv::Mat& img_mat,
                                        nav_msgs::OccupancyGrid& out_grid,
                                        const std::string& frame_id,
                                        double origin_x,
                                        double origin_y,
                                        double resolution) const
    {
        if (img_mat.empty() || img_mat.type() != CV_8UC1) {
            return false;
        }

        const unsigned int W_map = img_mat.cols;
        const unsigned int H_map = img_mat.rows;

        // OccupancyGrid meta
        out_grid = nav_msgs::OccupancyGrid();
        out_grid.header.frame_id = frame_id;
        out_grid.header.stamp = ros::Time::now();

        out_grid.info.resolution = resolution;
        out_grid.info.width  = W_map;
        out_grid.info.height = H_map;
        out_grid.info.origin.position.x = origin_x;
        out_grid.info.origin.position.y = origin_y;
        out_grid.info.origin.position.z = 0.0;
        out_grid.info.origin.orientation.x = 0.0;
        out_grid.info.origin.orientation.y = 0.0;
        out_grid.info.origin.orientation.z = 0.0;
        out_grid.info.origin.orientation.w = 1.0;

        // OpenCV -> OccupancyGrid dönüşümü
        out_grid.data.resize(W_map * H_map);
        for (unsigned int i = 0; i < H_map; ++i) {
            for (unsigned int j = 0; j < W_map; ++j) {
                const unsigned char v = img_mat.at<unsigned char>(H_map - 1 - i, j);
                int8_t occ = -1;
                if (v == 0)        occ = 100;  // obstacle
                else if (v == 254) occ = 0;    // free
                else               occ = -1;   // unknown
                out_grid.data[i * W_map + j] = occ;
            }
        }

        return true;
    }

    // publishMap için de overload
    void FrontierSearch::publishMap(const cv::Mat& img_mat,
                                ros::Publisher& pub,
                                const std::string& frame_id,
                                double origin_x,
                                double origin_y,
                                double resolution) const
    {
        nav_msgs::OccupancyGrid grid;
        if (!buildGridFromMat(img_mat, grid, frame_id, origin_x, origin_y, resolution)) {
            return;
        }
        pub.publish(grid);
    }

    AlignmentResult FrontierSearch::findAlignmentUsingFrontierKnownRegion(
    const cv::Mat& costmap_patch,    // Costmap'ten alınan patch
    const cv::Mat& gt_patch,         // GT'den alınan patch
    int cx, int cy,                  // Frontier merkezi (piksel)
    int search_radius)           // Arama yarıçapı (piksel)
    {
        AlignmentResult best_result;
        best_result.dx = 0;
        best_result.dy = 0;
        best_result.score = 0.0;
        best_result.valid = false;

        if (costmap_patch.empty() || gt_patch.empty() || 
            costmap_patch.size() != gt_patch.size()) {
            return best_result;
        }

        const int patch_size = costmap_patch.cols;
        const int half = patch_size / 2;

        // 1. Costmap patch'inde known (obstacle veya free) olan pikselleri bul
        // Bunlar frontier'ın "bilinen tarafı"
        cv::Mat known_mask = (costmap_patch != UNKNOWN_U8);
        int known_count = cv::countNonZero(known_mask);

        // Known bölge çok az ise hizalama yapılamaz
        if (known_count < 20) {
            //ROS_DEBUG("Too few known pixels (%d) for alignment", known_count);
            return best_result;
        }

        //ROS_INFO("Alignment search: %d known pixels in costmap patch", known_count);

        // 2. Farklı kaydırma değerlerini dene
        for (int dy = -search_radius; dy <= search_radius; dy++) {
            for (int dx = -search_radius; dx <= search_radius; dx++) {
                
                int match_count = 0;
                int compare_count = 0;

                // Her piksel için karşılaştır
                for (int y = 0; y < patch_size; y++) {
                    for (int x = 0; x < patch_size; x++) {
                        // Costmap'te bu piksel known mi?
                        if (!known_mask.at<uchar>(y, x)) continue;

                        uchar costmap_val = costmap_patch.at<uchar>(y, x);

                        // GT'den kaydırılmış değeri al
                        int gt_x = x + dx;
                        int gt_y = y + dy;

                        // Sınır kontrolü
                        if (gt_x < 0 || gt_x >= patch_size || 
                            gt_y < 0 || gt_y >= patch_size) continue;

                        uchar gt_val = gt_patch.at<uchar>(gt_y, gt_x);

                        // GT'de unknown değilse karşılaştır
                        if (gt_val == UNKNOWN_U8) continue;

                        compare_count++;

                        // Değerler uyuşuyor mu?
                        bool costmap_is_obstacle = (costmap_val == OBSTACLE_U8);
                        bool gt_is_obstacle = (gt_val == OBSTACLE_U8);

                        if (costmap_is_obstacle == gt_is_obstacle) {
                            match_count++;
                        }
                    }
                }

                // Skor hesapla
                if (compare_count > 10) {  // En az 10 piksel karşılaştırılmalı
                    double score = static_cast<double>(match_count) / compare_count;
                    
                    if (score > best_result.score) {
                        best_result.dx = dx;
                        best_result.dy = dy;
                        best_result.score = score;
                        best_result.valid = true;
                    }
                }
            }
        }

        if (best_result.valid) {
            // ROS_INFO("✅ Best alignment found: shift=(%d,%d), score=%.3f", 
            //          best_result.dx, best_result.dy, best_result.score);
        } else {
            ROS_WARN("❌ No valid alignment found");
        }

        return best_result;
    }

    // ✅ YENİ: İyileştirilmiş patch merge - history ve hizalama ile
    void FrontierSearch::mergeGTPatchToCompletedMap(
        const cv::Mat& gt_patch,
        const cv::Mat& costmap_patch, 
        const cv::Rect& roi,
        int alignment_dx,
        int alignment_dy,
        bool force_gt_walls)  // GT'deki duvarları zorla kullan
    {
        std::lock_guard<std::recursive_mutex> lock(data_mutex_);
        
        if (completed_map_.empty() || gt_patch.empty() || costmap_patch.empty()) {
            return;
        }

        const int W = completed_map_.cols;
        const int H = completed_map_.rows;

        // ROI sınır kontrolü
        if (roi.x < 0 || roi.y < 0 || 
            roi.x + roi.width > W || roi.y + roi.height > H) {
            ROS_WARN("ROI out of bounds");
            return;
        }

        int merged_from_gt = 0;
        int kept_costmap = 0;
        int gt_walls_merged = 0;

        // Her piksel için akıllı merge
        for (int py = 0; py < roi.height && py < gt_patch.rows && py < costmap_patch.rows; py++) {
            for (int px = 0; px < roi.width && px < gt_patch.cols && px < costmap_patch.cols; px++) {
                
                int cm_x = roi.x + px;
                int cm_y = roi.y + py;

                // Completed map'teki mevcut değer
                uchar& cm_pixel = completed_map_.at<uchar>(cm_y, cm_x);

                // Costmap patch'ten değer
                uchar costmap_val = costmap_patch.at<uchar>(py, px);

                // GT patch'ten değer (hizalama kaydırması ile)
                int gt_px = px + alignment_dx;
                int gt_py = py + alignment_dy;

                uchar gt_val = UNKNOWN_U8;
                if (gt_px >= 0 && gt_px < gt_patch.cols && 
                    gt_py >= 0 && gt_py < gt_patch.rows) {
                    gt_val = gt_patch.at<uchar>(gt_py, gt_px);
                }

                // ===== MERGE KURALLARI =====
                
                // Kural 1: Costmap'te unknown ise GT'dan al
                if (costmap_val == UNKNOWN_U8) {
                    if (gt_val != UNKNOWN_U8) {
                        cm_pixel = gt_val;
                        merged_from_gt++;
                    }
                }
                // Kural 2: Costmap'te free ama GT'da duvar ise GT'yı kullan
                else if (force_gt_walls && costmap_val == KNOWN_U8 && gt_val == OBSTACLE_U8) {
                    // GT'de duvar görünüyor - kontrol et: bu gerçekten duvar mı?
                    // Komşularını kontrol et
                    int wall_neighbors = 0;
                    for (int ny = std::max(0, gt_py-1); ny <= std::min(gt_patch.rows-1, gt_py+1); ny++) {
                        for (int nx = std::max(0, gt_px-1); nx <= std::min(gt_patch.cols-1, gt_px+1); nx++) {
                            if (gt_patch.at<uchar>(ny, nx) == OBSTACLE_U8) {
                                wall_neighbors++;
                            }
                        }
                    }
                    
                    // En az 3 komşusu duvar ise bu gerçek bir duvar
                    if (wall_neighbors >= 3) {
                        cm_pixel = gt_val;
                        gt_walls_merged++;
                    }
                }
                // Kural 3: Costmap'te bilgi varsa onu kullan
                else if (costmap_val != UNKNOWN_U8) {
                    cm_pixel = costmap_val;
                    kept_costmap++;
                }
            }
        }
    }

  

    void FrontierSearch::seedCompletedMapFromCostmap() 
    {
        std::lock_guard<std::recursive_mutex> lock(data_mutex_);
        if (!costmap_) return;
        
        const unsigned int W = costmap_->getSizeInCellsX();
        const unsigned int H = costmap_->getSizeInCellsY();
        
        // ═══════════════════════════════════════════════════════════
        // RESET FLAGS ONLY WHEN MAP SIZE CHANGES (new environment)
        // ═══════════════════════════════════════════════════════════
        if (completed_map_.empty() || completed_map_.cols != (int)W || completed_map_.rows != (int)H) {
            completed_map_.create(H, W, CV_8UC1);
            completed_map_.setTo(UNKNOWN_U8);
            ROS_INFO("📐 Completed_map initialized to %dx%d", W, H);
            
            
            ROS_INFO("✅ Gap closing flags reset (new map size)");
        }
        
        // ═══════════════════════════════════════════════════════════
        // UPDATE FROM COSTMAP (your original logic preserved)
        // ═══════════════════════════════════════════════════════════
        const unsigned char* raw = costmap_->getCharMap();
        for (unsigned int y = 0; y < H; ++y) {
            for (unsigned int x = 0; x < W; ++x) {
                const unsigned char c = raw[y*W + x];
                const int img_y = H - 1 - y;
                
                unsigned char v;
                if (c == costmap_2d::NO_INFORMATION)      v = UNKNOWN_U8;
                else if (c == costmap_2d::FREE_SPACE)     v = KNOWN_U8;
                else                                      v = OBSTACLE_U8;
                completed_map_.at<uchar>(img_y, x) = v;
            }
        }
        
        
        
        ROS_DEBUG("Completed_map seeded from costmap");
    }

  

    void FrontierSearch::seedClosedLiveMapFromCostmap() 
    {
        std::lock_guard<std::recursive_mutex> lock(data_mutex_);
        if (!costmap_) return;
        
        const unsigned int W = costmap_->getSizeInCellsX();
        const unsigned int H = costmap_->getSizeInCellsY();
        
        // ═══════════════════════════════════════════════════════════
        // Initialize maps when size changes
        // ═══════════════════════════════════════════════════════════
        if (closed_live_.empty() || closed_live_.cols != (int)W || closed_live_.rows != (int)H) {
            closed_live_.create(H, W, CV_8UC1);
            closed_live_.setTo(UNKNOWN_U8);
            
            
            
            ROS_INFO("✅ New closed_live_ map created (size: %dx%d)", W, H);
        }
        
        // ═══════════════════════════════════════════════════════════
        // UPDATE FROM COSTMAP (always fresh from SLAM)
        // ═══════════════════════════════════════════════════════════
        const unsigned char* raw = costmap_->getCharMap();
        
        for (unsigned int y = 0; y < H; ++y) {
            for (unsigned int x = 0; x < W; ++x) {
                const unsigned char c = raw[y*W + x];
                const int img_y = H - 1 - y;
                
                unsigned char v;
                if (c == costmap_2d::NO_INFORMATION)      v = UNKNOWN_U8;
                else if (c == costmap_2d::FREE_SPACE)     v = KNOWN_U8;
                else                                      v = OBSTACLE_U8;
                
                closed_live_.at<uchar>(img_y, x) = v;
            }
        }
        
        
        
        ROS_DEBUG("closed_live_ map seeded from costmap");
    }
    
    void FrontierSearch::validateAndCleanPatches() 
    {
        if (!costmap_) return;
        
        std::lock_guard<std::recursive_mutex> lock(data_mutex_);
        
        const int W = (int)costmap_->getSizeInCellsX();
        const int H = (int)costmap_->getSizeInCellsY();
        
        auto it = active_frontier_patches_.begin();
        int removed_count = 0;
        
        while (it != active_frontier_patches_.end()) {
            const FrontierPatchInfo& patch_info = it->second;
            
            // Sadece 2 basit kural:
            bool remove = false;
            
            // 1. Çok eski patch'leri temizle (120 saniye)
            ros::Duration age = ros::Time::now() - patch_info.timestamp;
            if (age.toSec() > 120.0) {
                remove = true;
            }
            
            // 2. ROI sınırlar dışındaysa temizle
            cv::Rect roi = patch_info.roi;
            if (roi.x < 0 || roi.y < 0 || 
                roi.x + roi.width > W || roi.y + roi.height > H) {
                remove = true;
            }
            
            if (remove) {
                it = active_frontier_patches_.erase(it);
                removed_count++;
            } else {
                ++it;
            }
        }
        
        if (removed_count > 0) {
            //ROS_DEBUG("Cleaned %d patches, %zu remain", removed_count, active_frontier_patches_.size());
        }
    }      
    
    void FrontierSearch::seedGT() 
    {
        std::lock_guard<std::recursive_mutex> lock(data_mutex_);
        ROS_INFO(">>> seedGT START");

        if (!costmap_) {
            ROS_WARN(">>> FAIL: costmap NULL");
            return;
        }

        if (gt_image_.empty()) {
            ROS_WARN(">>> FAIL: gt_image EMPTY");
            return;
        }
        
        if (yaml_res_ <= 0.0 || map_res_ <= 0.0) {
            ROS_WARN("seedGT: invalid resolutions (yaml_res=%.6f, map_res=%.6f)", yaml_res_, map_res_);
            return;
        }

        const unsigned int W = costmap_->getSizeInCellsX();
        const unsigned int H = costmap_->getSizeInCellsY();
        gt_map_.create(H, W, CV_8UC1);

        ROS_INFO(">>> Creating gt_map %ux%u", W, H);

        const int gt_w = gt_image_.cols;
        const int gt_h = gt_image_.rows;
        
        // ========== DEBUG: Parametreler ==========
        ROS_INFO("DEBUG seedGT: GT image size %dx%d", gt_w, gt_h);
        ROS_INFO("DEBUG seedGT: Costmap origin (%.2f, %.2f) res=%.4f", 
                map_org_x_, map_org_y_, map_res_);
        ROS_INFO("DEBUG seedGT: GT yaml origin (%.2f, %.2f) res=%.4f",
                yaml_x_, yaml_y_, yaml_res_);
        // =========================================

        int inside_bounds = 0;
        int outside_bounds = 0;
        
        for (unsigned int y = 0; y < H; ++y) {
            for (unsigned int x = 0; x < W; ++x) {
                const double wx = map_org_x_ + (static_cast<double>(x) + 0.5) * map_res_;
                const double wy = map_org_y_ + (static_cast<double>(y) + 0.5) * map_res_;

                const int gi = static_cast<int>( (wx - yaml_x_) / yaml_res_ );
                const int gj_from_bottom = static_cast<int>( (wy - yaml_y_) / yaml_res_ );
                const int gj = gt_h - 1 - gj_from_bottom;
                
                // ========== DEBUG: İlk birkaç sample ==========
                if (inside_bounds + outside_bounds < 10) {
                    ROS_INFO("  Sample[%d,%d]: world(%.2f,%.2f) -> gi=%d,gj=%d (bounds: 0-%d, 0-%d)",
                            x, y, wx, wy, gi, gj, gt_w-1, gt_h-1);
                }
                // ===============================================

                unsigned char v = UNKNOWN_U8;
                if (gi >= 0 && gi < gt_w && gj >= 0 && gj < gt_h) {
                    inside_bounds++;
                    unsigned char src = gt_image_.at<unsigned char>(gj, gi);
                    if      (src == 0)   v = OBSTACLE_U8;
                    else if (src == 205) v = UNKNOWN_U8;
                    else if (src == 254) v = KNOWN_U8;
                    else {
                        if (src < 50)       v = OBSTACLE_U8;
                        else if (src > 200) v = KNOWN_U8;
                        else                v = UNKNOWN_U8;
                    }
                } else {
                    outside_bounds++;
                }

                gt_map_.at<unsigned char>(H - 1 - y, x) = v;
            }
        }

        ROS_INFO(">>> seedGT: inside=%d, outside=%d (total=%d)", 
                inside_bounds, outside_bounds, inside_bounds + outside_bounds);
        ROS_INFO(">>> SUCCESS: %dx%d", gt_map_.cols, gt_map_.rows);
    }

    bool FrontierSearch::batchCompleteFrontierPatches(std::vector<Frontier>& frontiers) 
    {
        if (frontiers.empty()) return true;
        
        const int P = rect_size_;
        // Not: costmap_ pointer olduğu için -> operatörü ile boyutları alıyoruz
        const int W = static_cast<int>(costmap_->getSizeInCellsX());
        const int H = static_cast<int>(costmap_->getSizeInCellsY());

        // ═══════════════════════════════════════════════════════════════
        // BRANCH 1: MODEL-based completion (with_map_completion_ == 1)
        // ═══════════════════════════════════════════════════════════════
        if (with_map_completion_ == 1) {
            auto start = std::chrono::high_resolution_clock::now();
            
            std::vector<cv::Mat> partial_patches;
            std::vector<int> valid_indices;
            
            // 1. ADIM: Sadece cache'de olmayanlar için ham yamaları topla
            for (size_t i = 0; i < frontiers.size(); ++i) {
                FrontierKey key = getFrontierKey(frontiers[i].centroid.x, frontiers[i].centroid.y);
                
                {
                    std::lock_guard<std::recursive_mutex> lock(data_mutex_);
                    auto cache_it = completed_patch_cache_.find(key);
                    // Eğer son 30 saniye içinde taze bir tahmin yapılmışsa tekrar sorma
                    if (cache_it != completed_patch_cache_.end() && cache_it->second.valid) {
                        ros::Duration age = ros::Time::now() - cache_it->second.timestamp;
                        if (age.toSec() < 30.0) continue; 
                    }
                }
                
                // ✅ DOĞRU: global_live_cm yerine doğrudan costmap'ten ham veri kes
                cv::Mat partial_patch;
                if (cropFromCostmap(frontiers[i].centroid.x, frontiers[i].centroid.y, P, partial_patch)) {
                    partial_patches.push_back(partial_patch);
                    valid_indices.push_back(i);
                }
            }
            
            if (partial_patches.empty()) return true; 

            // 2. ADIM: Servis isteğini hazırla
            explore_lite::MapCompletionBatch srv;
            srv.request.patch_size = P;
            srv.request.num_patches = partial_patches.size();
            
            for (size_t i = 0; i < partial_patches.size(); ++i) {
                int idx = valid_indices[i];
                srv.request.frontier_x.push_back(frontiers[idx].centroid.x);
                srv.request.frontier_y.push_back(frontiers[idx].centroid.y);
                
                const cv::Mat& p = partial_patches[i];
                // Matrisi düzleştirerek srv paketine koy
                for (int r = 0; r < P; ++r) {
                    for (int c = 0; c < P; ++c) {
                        srv.request.patches.push_back(p.at<uchar>(r, c));
                    }
                }
            }
            
            // 3. ADIM: Ctor'da tanımlı olan client'ı çağır ve tahminleri cache'e yaz
            if (map_completion_batch_client_.call(srv) && srv.response.success) {
                std::lock_guard<std::recursive_mutex> lock(data_mutex_);
                for (size_t i = 0; i < valid_indices.size(); ++i) {
                    cv::Mat completed_patch(P, P, CV_8UC1);
                    size_t offset = i * P * P;
                    
                    int predicted_free = 0;
                    for (int r = 0; r < P; ++r) {
                        for (int c = 0; c < P; ++c) {
                            uchar v = srv.response.completed_patches[offset + r * P + c];
                            completed_patch.at<uchar>(r, c) = v;
                            // Pikselleri burada bir kez sayıyoruz (Threshold kullanarak)
                            if (v > 200 && v != 205) predicted_free++;
                        }
                    }

                    // Mevcut (canlı) durumdaki boş alan sayısını da bir kez hesapla
                    cv::Mat current_patch = partial_patches[i];
                    int current_free = 0;
                    for(int k=0; k < P*P; ++k) {
                        uchar v = current_patch.at<uchar>(k);
                        if (v > 200 && v != 205) current_free++;
                    }

                    FrontierKey key = getFrontierKey(frontiers[valid_indices[i]].centroid.x, 
                                                    frontiers[valid_indices[i]].centroid.y);
                    
                    CompletedPatchCache cache_entry;
                    cache_entry.patch = completed_patch.clone();
                    cache_entry.predicted_free_count = predicted_free; // ✅ ÖN HESAPLANMIŞ
                    cache_entry.current_free_count = current_free;     // ✅ ÖN HESAPLANMIŞ
                    cache_entry.timestamp = ros::Time::now();
                    cache_entry.valid = true;
                    completed_patch_cache_[key] = cache_entry;
                }
            }
            return true;
        }
        
        // ═══════════════════════════════════════════════════════════════
        // BRANCH 2: GT-based oracle (Önceki mantıkla aynı, temizlendi)
        // ═══════════════════════════════════════════════════════════════
        else if (with_map_completion_ == 0 && !gt_image_.empty() && yaml_res_ > 0.0) {
            std::lock_guard<std::recursive_mutex> lock(data_mutex_);
            for (const auto& frontier : frontiers) {
                FrontierKey key = getFrontierKey(frontier.centroid.x, frontier.centroid.y);
                if (completed_patch_cache_.count(key)) continue;

                int gx, gy;
                if (worldToImagePxPy(frontier.centroid.x, frontier.centroid.y, yaml_x_, yaml_y_, yaml_res_,
                                    gt_image_.cols, gt_image_.rows, gx, gy, true)) {
                    cv::Mat gt_patch;
                    if (cropWithPad(gt_image_, gx, gy, P, UNKNOWN_U8, gt_patch)) {
                        CompletedPatchCache entry;
                        entry.patch = gt_patch.clone();
                        entry.timestamp = ros::Time::now();
                        entry.valid = true;
                        completed_patch_cache_[key] = entry;
                    }
                }
            }
        }
        return true;
    }

    // Add periodic cache cleanup to avoid memory growth
    void FrontierSearch::cleanCompletedPatchCache() {
        std::lock_guard<std::recursive_mutex> lock(data_mutex_);
        
        ros::Time now = ros::Time::now();
        auto it = completed_patch_cache_.begin();
        int removed = 0;
        
        while (it != completed_patch_cache_.end()) {
            ros::Duration age = now - it->second.timestamp;
            if (age.toSec() > 60.0) {  // Remove patches older than 1 minute
                it = completed_patch_cache_.erase(it);
                removed++;
            } else {
                ++it;
            }
        }
        
        if (removed > 0) {
            //ROS_DEBUG("Cleaned %d old cached patches", removed);
        }
    }


    void FrontierSearch::logProfilingStats() const
    {
        std::lock_guard<std::mutex> lock(profiling_mutex_);
        
        if (profiling_times_.empty()) return;
        
        // ROS_INFO("═══════════════════════════════════════════════════════");
        // ROS_INFO("FRONTIER SEARCH PROFILING STATISTICS");
        // ROS_INFO("═══════════════════════════════════════════════════════");
        
        for (const auto& entry : profiling_times_) {
            const std::string& operation = entry.first;
            const std::vector<double>& times = entry.second;
            if (times.empty()) continue;
            
            double total = std::accumulate(times.begin(), times.end(), 0.0);
            double avg = total / times.size();
            double min = *std::min_element(times.begin(), times.end());
            double max = *std::max_element(times.begin(), times.end());
            
            // Calculate median
            std::vector<double> sorted_times = times;
            std::sort(sorted_times.begin(), sorted_times.end());
            double median = sorted_times[sorted_times.size() / 2];
            
            // ROS_INFO("  %-30s: count=%4zu, avg=%6.2fms, med=%6.2fms, min=%6.2fms, max=%6.2fms, total=%8.1fms",
            //         operation.c_str(), times.size(), avg, median, min, max, total);
        }
        
        //ROS_INFO("═══════════════════════════════════════════════════════");
    }

} // namespace frontier_exploration
