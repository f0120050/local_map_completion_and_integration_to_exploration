#include <ros/ros.h>
#include <nav_msgs/GetPlan.h>
#include <costmap_2d/costmap_2d_ros.h>
#include <tf2_ros/transform_listener.h>
#include <nav_core/base_global_planner.h>
#include <pluginlib/class_loader.h>
#include <memory>
#include <boost/shared_ptr.hpp>

class PlannerService {
public:
    PlannerService() : tf_buffer_(ros::Duration(10.0)) {
        ros::NodeHandle private_nh("~");
        
        std::string planner_type;
        std::string planner_name;
        private_nh.param("planner_type", planner_type, std::string("navfn/NavfnROS"));
        private_nh.param("planner_name", planner_name, std::string("navfn"));
        
        try {
            planner_loader_ = std::make_unique<pluginlib::ClassLoader<nav_core::BaseGlobalPlanner>>(
                "nav_core", "nav_core::BaseGlobalPlanner"
            );
            
            planner_ = planner_loader_->createInstance(planner_type);
            
            global_costmap_ = std::make_unique<costmap_2d::Costmap2DROS>(
                "global_costmap", tf_buffer_
            );
            
            planner_->initialize(planner_name, global_costmap_.get());
            
            service_ = nh_.advertiseService("make_plan", &PlannerService::makePlanCallback, this);
            ROS_INFO("Planner service %s is ready.", service_.getService().c_str());
        } catch (pluginlib::PluginlibException& ex) {
            ROS_ERROR("Failed to load planner plugin: %s", ex.what());
        }
    }

private:
    bool makePlanCallback(nav_msgs::GetPlan::Request& req, nav_msgs::GetPlan::Response& res) {
        std::vector<geometry_msgs::PoseStamped> plan;
        bool success = planner_->makePlan(req.start, req.goal, plan);

        if (success) {
            ROS_INFO("Planner service successfully found a path.");
            res.plan.poses = plan;
            return true;
        } else {
            ROS_WARN("Planner service failed to find a path.");
            return false;
        }
    }

    ros::NodeHandle nh_;
    std::unique_ptr<pluginlib::ClassLoader<nav_core::BaseGlobalPlanner>> planner_loader_;
    boost::shared_ptr<nav_core::BaseGlobalPlanner> planner_;
    std::unique_ptr<costmap_2d::Costmap2DROS> global_costmap_;
    tf2_ros::Buffer tf_buffer_;
    tf2_ros::TransformListener tf_listener_{tf_buffer_};
    ros::ServiceServer service_;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "planner_service_node");
    PlannerService ps;
    ros::spin();
    return 0;
}