#include <explore/distance_calculator.h>
#include <costmap_2d/cost_values.h>
#include <geometry_msgs/PoseStamped.h>
#include <queue>
#include <unordered_map>
#include <cmath>
#include <mutex>   // for std::lock_guard
#include <opencv2/core.hpp>
#include <limits>
#include <opencv2/imgproc.hpp>   // for cv::integral
#include <vector>



namespace {
constexpr unsigned char OBST_U8 = 0;
constexpr unsigned char UNK_U8  = 205;
constexpr unsigned char FREE_U8 = 254;

template<typename T> inline T clamp(T v, T lo, T hi){ return std::max(lo, std::min(v,hi)); }
}

using namespace costmap_2d;

namespace frontier_exploration
{


    bool DistanceCalculator::blocked(int x, int y, bool allow_unknown) const
    {
        // Sınır: harita dışını engel kabul et (A* sınırları zorlamasın)
        const int W = (int)cm_->getSizeInCellsX();
        const int H = (int)cm_->getSizeInCellsY();
        if (x < 0 || y < 0 || x >= W || y >= H) {
            return true;
        }

        const unsigned char c = cm_->getCost(x, y);

        // Yalnızca enflasyonlu/öldürücü engeller "sert" engel
        if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
            return true;
        }

        // Unknown: allow_unknown==true ise engel sayma
        if (c == costmap_2d::NO_INFORMATION) {
            return !allow_unknown;
        }

        // Diğer tüm durumlarda geçilebilir
        return false;
    }

    void DistanceCalculator::initMakePlanClient() 
    {
        if (!make_plan_client_.isValid()) {
        // 1. Change the default service name to "make_plan"
        //    We will let ROS's namespace resolution handle the rest.
        nh_.param<std::string>("makeplan_service", makeplan_service_,
                                std::string("make_plan"));
        nh_.param<double>("makeplan_tolerance", makeplan_tolerance_, 0.1);
        
        // 2. Use a private NodeHandle to ensure the client is created in the correct namespace.
        //    Or, if using a public NodeHandle, ensure the name is fully resolved.
        //    The simplest fix is to use the same logic as the service server.
        //    (assuming this method is called by the exploration node).
        //    In this case, a fully resolved name is best to be explicit.
        //    Since your planner service is named `planner_service_node`,
        //    the full name is `/planner_service_node/make_plan`.
        make_plan_client_ = nh_.serviceClient<nav_msgs::GetPlan>(makeplan_service_, /*persistent=*/true);

        // An alternative (if `initMakePlanClient` is called from a node that has a
        // private NodeHandle `private_nh_`) would be:
        // make_plan_client_ = private_nh_.serviceClient<nav_msgs::GetPlan>("make_plan", true);
        
        make_plan_client_.waitForExistence(ros::Duration(5.0));
        }
    }


  // double DistanceCalculator::computeDistanceUsingMakePlan(double sx, double sy, double gx, double gy) {

  //   // Ensure the client exists and is healthy
  //   if (!make_plan_client_.isValid()) {
  //     initMakePlanClient();
  //   }


  //   nav_msgs::GetPlan srv;
  //   srv.request.start.header.frame_id = global_frame_;
  //   srv.request.goal.header.frame_id  = global_frame_;
  //   const ros::Time stamp = ros::Time::now();
  //   srv.request.start.header.stamp = stamp;
  //   srv.request.goal.header.stamp  = stamp;

  //   srv.request.start.pose.position.x = sx;
  //   srv.request.start.pose.position.y = sy;
  //   srv.request.start.pose.orientation.w = 1.0;

  //   srv.request.goal.pose.position.x = gx;
  //   srv.request.goal.pose.position.y = gy;
  //   srv.request.goal.pose.orientation.w = 1.0;

  //   srv.request.tolerance = makeplan_tolerance_;

    
  //   if (!make_plan_client_.call(srv)) {
  //     ROS_WARN_THROTTLE(2.0, "make_plan call failed (service: %s)", makeplan_service_.c_str());
  //     return std::numeric_limits<double>::infinity();
  //   }
  //   else{
  //     ROS_INFO("make_plan service has called successfully.");
  //   }

  //   const auto& poses = srv.response.plan.poses;
  //   if (poses.size() < 2) {
  //     //ROS_WARN_THROTTLE(2.0, "make_plan returned no path (poses=%zu)", poses.size());
  //     return std::numeric_limits<double>::infinity();
  //     if (poses.size() == 1) return 0.0;  // start≈goal within tolerance
  //   }

  //   double L = 0.0;
  //   // Optional: cap to avoid excessive work if you only need up to some length
  //   // const double kMaxLen = 1e6; // meters (set if desired)

  //   for (size_t i = 1; i < poses.size(); ++i) {
  //     const auto& a = poses[i-1].pose.position;
  //     const auto& b = poses[i].pose.position;

  //     // Guard against NaNs or identical points
  //     if (!std::isfinite(a.x) || !std::isfinite(a.y) ||
  //         !std::isfinite(b.x) || !std::isfinite(b.y)) {
  //       ROS_WARN_THROTTLE(2.0, "make_plan produced non-finite coordinates; aborting length sum");
  //       return std::numeric_limits<double>::infinity();
  //     }

  //     const double dx = b.x - a.x;
  //     const double dy = b.y - a.y;
  //     L += std::hypot(dx, dy);

  //     // if (L > kMaxLen) return L; // optional early exit
  //   }

  //   return L; // meters
  // }

  double DistanceCalculator::computeDistanceUsingMakePlan(double sx, double sy, double gx, double gy)
  {
    // (1) Ensure client exists and is connected
    if (!make_plan_client_.isValid()) {
      ROS_DEBUG("make_plan client invalid -> initializing (service param: %s)", makeplan_service_.c_str());
      initMakePlanClient();
    }

    // Try to (re)connect if needed
    if (!make_plan_client_.exists()) {
      ROS_DEBUG("Waiting for make_plan service to exist: %s", makeplan_service_.c_str());
      if (!make_plan_client_.waitForExistence(ros::Duration(3.0))) {
        ROS_WARN_THROTTLE(2.0, "make_plan service not available at '%s' (resolved: '%s')",
                          makeplan_service_.c_str(), make_plan_client_.getService().c_str());
        return std::numeric_limits<double>::infinity();
      }
    }

    // (2) Build request
    nav_msgs::GetPlan srv;
    const ros::Time stamp = ros::Time::now();

    srv.request.start.header.frame_id = global_frame_;
    srv.request.start.header.stamp    = stamp;
    srv.request.start.pose.position.x = sx;
    srv.request.start.pose.position.y = sy;
    srv.request.start.pose.orientation.w = 1.0;

    srv.request.goal.header.frame_id = global_frame_;
    srv.request.goal.header.stamp    = stamp;
    srv.request.goal.pose.position.x = gx;
    srv.request.goal.pose.position.y = gy;
    srv.request.goal.pose.orientation.w = 1.0;

    srv.request.tolerance = makeplan_tolerance_;

    ROS_DEBUG("Calling make_plan @ '%s' (resolved: '%s'), frame='%s', start=(%.3f,%.3f), goal=(%.3f,%.3f), tol=%.2f",
              makeplan_service_.c_str(),
              make_plan_client_.getService().c_str(),
              global_frame_.c_str(), sx, sy, gx, gy, makeplan_tolerance_);

    // (3) Call service
    if (!make_plan_client_.call(srv)) {
      ROS_WARN_THROTTLE(2.0, "make_plan call FAILED (service: %s | resolved: %s)",
                        makeplan_service_.c_str(), make_plan_client_.getService().c_str());
      return std::numeric_limits<double>::infinity();
    }

    // (4) Inspect response
    const auto& poses = srv.response.plan.poses;
    ROS_DEBUG("make_plan call SUCCEEDED: %zu poses returned (service: %s | resolved: %s)",
              poses.size(), makeplan_service_.c_str(), make_plan_client_.getService().c_str());

    if (poses.empty()) {
      // If you’re using a wrapper configured with `return_empty_on_failure: true`, this is the “no path” case.
      ROS_WARN_THROTTLE(2.0, "make_plan returned an EMPTY path (no valid plan).");
      return std::numeric_limits<double>::infinity();
    }
    if (poses.size() == 1) {
      // start ≈ goal within tolerance
      ROS_DEBUG("make_plan returned a single pose (start≈goal) -> length=0.0 m");
      return 0.0;
    }

    // Optional: frame sanity
    const std::string resp_frame = poses.front().header.frame_id;
    if (!resp_frame.empty() && resp_frame != global_frame_) {
      ROS_WARN_THROTTLE(2.0, "make_plan path frame ('%s') != expected global frame ('%s')",
                        resp_frame.c_str(), global_frame_.c_str());
    }

    // (5) Sum length in METERS (straight segments between successive poses)
    double L = 0.0;
    for (size_t i = 1; i < poses.size(); ++i) {
      const auto& a = poses[i-1].pose.position;
      const auto& b = poses[i].pose.position;

      if (!std::isfinite(a.x) || !std::isfinite(a.y) ||
          !std::isfinite(b.x) || !std::isfinite(b.y)) {
        ROS_WARN_THROTTLE(2.0, "make_plan produced non-finite coordinates at segment %zu; aborting length sum", i);
        return std::numeric_limits<double>::infinity();
      }
      L += std::hypot(b.x - a.x, b.y - a.y);
    }

    ROS_DEBUG("make_plan total length: %.3f m over %zu segments", L, poses.size()-1);
    return L;
  }

  // Fixed multiGoalDijkstra with better bounds checking and error handling
  void DistanceCalculator::multiGoalDijkstra(
      int sx, int sy,
      const std::vector<std::pair<int,int>>& goals_xy,
      std::vector<double>& out_dist,
      bool allow_unknown)
  {
      const double INF = std::numeric_limits<double>::infinity();
      out_dist.assign(goals_xy.size(), INF);
      
      if (!cm_ || goals_xy.empty()) {
          return;
      }

      std::lock_guard<costmap_2d::Costmap2D::mutex_t> lk(*cm_->getMutex());

      const int cols = static_cast<int>(cm_->getSizeInCellsX());
      const int rows = static_cast<int>(cm_->getSizeInCellsY());
      
      if (cols <= 0 || rows <= 0) {
          ROS_ERROR("Invalid costmap dimensions in multiGoalDijkstra");
          return;
      }

      auto inb = [&](int x, int y) { return x >= 0 && x < cols && y >= 0 && y < rows; };
      auto toIdx = [&](int x, int y) { return y * cols + x; };

      if (!inb(sx, sy) || blocked(sx, sy, allow_unknown)) {
          return;
      }

      // Build goal map with validation
      std::unordered_map<int, std::vector<int>> goal_map;
      goal_map.reserve(goals_xy.size() * 2);
      
      for (size_t i = 0; i < goals_xy.size(); ++i) {
          const int gx = goals_xy[i].first;
          const int gy = goals_xy[i].second;
          
          if (!inb(gx, gy) || blocked(gx, gy, allow_unknown)) {
              continue;
          }
          
          goal_map[toIdx(gx, gy)].push_back(static_cast<int>(i));
      }
      
      if (goal_map.empty()) {
          return;
      }

      // Dijkstra implementation with bounds checking
      static const int DX[8] = { 1, 1, 0, -1, -1, -1,  0,  1};
      static const int DY[8] = { 0, 1, 1,  1,  0, -1, -1, -1};
      static const double STEP[8] = {
          1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0),
          1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0)
      };

      const size_t N = static_cast<size_t>(cols) * static_cast<size_t>(rows);
      std::vector<double> g;
      std::vector<uint8_t> closed;
      
      try {
          g.assign(N, INF);
          closed.assign(N, 0);
      } catch (const std::bad_alloc& e) {
          ROS_ERROR("Memory allocation failed in multiGoalDijkstra: %s", e.what());
          return;
      }

      struct Node { 
          int idx; 
          double g; 
          bool operator<(const Node& o) const { return g > o.g; } 
      };
      std::priority_queue<Node> pq;

      const int sidx = toIdx(sx, sy);
      g[sidx] = 0.0;
      pq.push({sidx, 0.0});
      
      size_t remaining = goal_map.size();
      size_t processed = 0;
      const size_t max_iterations = N * 2;

      while (!pq.empty() && remaining > 0 && processed < max_iterations) {
          auto cur = pq.top();
          pq.pop();
          processed++;

          if (closed[cur.idx]) continue;
          closed[cur.idx] = 1;

          auto it = goal_map.find(cur.idx);
          if (it != goal_map.end()) {
              for (int gid : it->second) {
                  if (gid >= 0 && gid < static_cast<int>(out_dist.size())) {
                      out_dist[gid] = cur.g;
                  }
              }
              goal_map.erase(it);
              if (--remaining == 0) break;
          }

          const int cx = cur.idx % cols;
          const int cy = cur.idx / cols;
          
          for (int k = 0; k < 8; ++k) {
              const int nx = cx + DX[k];
              const int ny = cy + DY[k];
              
              if (!inb(nx, ny)) continue;
              
              // Check diagonal corner cutting
              if (DX[k] != 0 && DY[k] != 0) {
                  if (blocked(cx + DX[k], cy, allow_unknown) || 
                      blocked(cx, cy + DY[k], allow_unknown)) {
                      continue;
                  }
              }
              
              if (blocked(nx, ny, allow_unknown)) continue;

              const int nidx = toIdx(nx, ny);
              const double ng = cur.g + STEP[k];
              
              if (ng < g[nidx]) {
                  g[nidx] = ng;
                  pq.push({nidx, ng});
              }
          }
      }

      if (processed >= max_iterations) {
          ROS_WARN("multiGoalDijkstra hit iteration limit");
      }
  }

  // ---------- Multi-goal Dijkstra (8-connected, corner-safe) ----------
  // void DistanceCalculator::multiGoalDijkstra(
  //     int sx, int sy,
  //     const std::vector<std::pair<int,int>>& goals_xy,
  //     std::vector<double>& out_dist,
  //     bool allow_unknown)
  // {
  //   const double INF = std::numeric_limits<double>::infinity();
  //   out_dist.assign(goals_xy.size(), INF);
  //   if (!cm_ || !inb(sx,sy) || goals_xy.empty()) return;
  //   if (blocked(sx,sy,allow_unknown)) return;

  //   const int cols = (int)cm_->getSizeInCellsX();
  //   const int rows = (int)cm_->getSizeInCellsY();
  //   auto toIdx=[&](int x,int y){ return y*cols + x; };

  //   std::unordered_map<int,std::vector<int>> goal_map;
  //   goal_map.reserve(goals_xy.size()*2);
  //   for (size_t i=0;i<goals_xy.size();++i){
  //     int gx=goals_xy[i].first, gy=goals_xy[i].second;
  //     if (!inb(gx,gy) || blocked(gx,gy,allow_unknown)) continue;
  //     goal_map[toIdx(gx,gy)].push_back((int)i);
  //   }
  //   if (goal_map.empty()) return;

  //   static const int DX[8]={ 1, 1, 0,-1,-1,-1, 0, 1};
  //   static const int DY[8]={ 0, 1, 1, 1, 0,-1,-1,-1};
  //   static const double STEP[8]={1.0,std::sqrt(2.0),1.0,std::sqrt(2.0),
  //                               1.0,std::sqrt(2.0),1.0,std::sqrt(2.0)};

  //   const size_t N = (size_t)cols*rows;
  //   std::vector<double> g(N, INF);
  //   std::vector<uint8_t> closed(N,0);

  //   struct Node { int idx; double g; bool operator<(const Node& o)const{return g>o.g;} };
  //   std::priority_queue<Node> pq;

  //   int sidx = toIdx(sx,sy);
  //   g[sidx]=0.0; pq.push({sidx,0.0});
  //   size_t remaining = goal_map.size();

  //   while(!pq.empty() && remaining>0){
  //     auto cur = pq.top(); pq.pop();
  //     if (closed[cur.idx]) continue;
  //     closed[cur.idx]=1;

  //     auto it = goal_map.find(cur.idx);
  //     if (it!=goal_map.end()){
  //       for (int gid : it->second) out_dist[gid]=cur.g;
  //       goal_map.erase(it);
  //       --remaining;
  //       if (remaining==0) break;
  //     }

  //     int cx = cur.idx % cols, cy = cur.idx / cols;
  //     for (int k=0;k<8;++k){
  //       int nx=cx+DX[k], ny=cy+DY[k];
  //       if (!inb(nx,ny)) continue;
  //       if (DX[k]!=0 && DY[k]!=0){ // no corner-cut
  //         if (blocked(cx+DX[k],cy,allow_unknown) || blocked(cx,cy+DY[k],allow_unknown)) continue;
  //       }
  //       if (blocked(nx,ny,allow_unknown)) continue;

  //       int nidx = toIdx(nx,ny);
  //       double ng = cur.g + STEP[k];
  //       if (ng < g[nidx]) { g[nidx]=ng; pq.push({nidx,ng}); }
  //     }
  //   }
  // }

  // ---------- Multi-goal A* (octile heuristic, weighted) ----------
  // void DistanceCalculator::multiGoalAstar(
  //     int sx, int sy,
  //     const std::vector<std::pair<int,int>>& goals_xy,
  //     std::vector<double>& out_dist,
  //     bool allow_unknown,
  //     double w)
  // {
  //   const double INF = std::numeric_limits<double>::infinity();
  //   out_dist.assign(goals_xy.size(), INF);
  //   if (!cm_ || !inb(sx,sy) || goals_xy.empty()) return;
  //   if (blocked(sx,sy,allow_unknown)) return;

  //   const int cols = (int)cm_->getSizeInCellsX();
  //   const int rows = (int)cm_->getSizeInCellsY();
  //   auto toIdx=[&](int x,int y){ return y*cols + x; };

  //   std::unordered_map<int,std::vector<int>> goal_map;
  //   goal_map.reserve(goals_xy.size()*2);
  //   std::vector<std::pair<int,int>> goals;
  //   goals.reserve(goals_xy.size());
  //   for (size_t i=0;i<goals_xy.size();++i){
  //     int gx=goals_xy[i].first, gy=goals_xy[i].second;
  //     if (!inb(gx,gy) || blocked(gx,gy,allow_unknown)) continue;
  //     goal_map[toIdx(gx,gy)].push_back((int)i);
  //     goals.emplace_back(gx,gy);
  //   }
  //   if (goal_map.empty()) return;

  //   auto h_oct = [](int x1,int y1,int x2,int y2){
  //     double dx = std::abs(x1-x2), dy = std::abs(y1-y2);
  //     return (dx+dy) + (std::sqrt(2.0)-2.0)*std::min(dx,dy);
  //   };
  //   auto h_min_to_any = [&](int x,int y){
  //     double best=INF;
  //     for (auto& gxy : goals) {
  //       double h = h_oct(x,y,gxy.first,gxy.second);
  //       if (h<best) best=h;
  //     }
  //     return best;
  //   };

  //   static const int DX[8]={ 1, 1, 0,-1,-1,-1, 0, 1};
  //   static const int DY[8]={ 0, 1, 1, 1, 0,-1,-1,-1};
  //   static const double STEP[8]={1.0,std::sqrt(2.0),1.0,std::sqrt(2.0),
  //                               1.0,std::sqrt(2.0),1.0,std::sqrt(2.0)};

  //   const size_t N = (size_t)cols*rows;
  //   std::vector<double> g(N, INF);
  //   std::vector<uint8_t> closed(N,0);

  //   struct QN{ int idx; double g; double f; bool operator<(const QN& o)const{return f>o.f;} };
  //   std::priority_queue<QN> open;

  //   int sidx = toIdx(sx,sy);
  //   double h0 = h_min_to_any(sx,sy);
  //   g[sidx]=0.0; open.push({sidx,0.0, 0.0 + w*h0});

  //   size_t remaining = goal_map.size();

  //   while(!open.empty() && remaining>0){
  //     auto cur = open.top(); open.pop();
  //     if (closed[cur.idx]) continue;
  //     closed[cur.idx]=1;

  //     auto it = goal_map.find(cur.idx);
  //     if (it!=goal_map.end()){
  //       for (int gid : it->second) out_dist[gid]=cur.g;
  //       goal_map.erase(it);
  //       --remaining;
  //       if (remaining==0) break;
  //     }

  //     int cx = cur.idx % cols, cy = cur.idx / cols;
  //     for (int k=0;k<8;++k){
  //       int nx=cx+DX[k], ny=cy+DY[k];
  //       if (!inb(nx,ny)) continue;
  //       if (DX[k]!=0 && DY[k]!=0){ // no corner-cut
  //         if (blocked(cx+DX[k],cy,allow_unknown) || blocked(cx,cy+DY[k],allow_unknown)) continue;
  //       }
  //       if (blocked(nx,ny,allow_unknown)) continue;

  //       int nidx = toIdx(nx,ny);
  //       double ng = cur.g + STEP[k];
  //       if (ng < g[nidx]){
  //         g[nidx]=ng;
  //         double h = h_min_to_any(nx,ny);
  //         open.push({nidx, ng, ng + w*h});
  //       }
  //     }
  //   }
  // }

  // We want to measure how far (shortest walking distance) from the robot (sx,sy)
  // to each "frontier tile" in goals_xy. We don't draw paths, just distances.
  // We explore the grid like a treasure hunt: keep a basket (open set) of places
  // to check next, and a stamp (closed set) for places we've already checked.

    void DistanceCalculator::multiGoalAstar(
      int sx, int sy,                                   // robot start tile
      const std::vector<std::pair<int,int>>& goals_xy,  // many frontier tiles (goals)
      std::vector<double>& out_dist,                    // answers: distance to each goal
      bool allow_unknown,                               // can we step on unknown tiles?
      double w)                                         // how much to trust the guess (heuristic weight)
    {
        const double INF = std::numeric_limits<double>::infinity();
        out_dist.assign(goals_xy.size(), INF);              // fill answers with ∞ first (unknown)
        if (!cm_ || goals_xy.empty()) return;              // if no map or no goals, go home.

        // Hold the map still so nobody changes it while we search.
        std::lock_guard<costmap_2d::Costmap2D::mutex_t> lk(*cm_->getMutex());

        // If the robot starts outside the map or on a blocked tile, we can't move.
        if (!inb(sx,sy) || blocked(sx,sy,allow_unknown)) return;

        // Map width/height and a helper to turn (x,y) into a single number (index).
        const int cols = (int)cm_->getSizeInCellsX();
        const int rows = (int)cm_->getSizeInCellsY();
        auto toIdx=[&](int x,int y){ return y*cols + x; };

        // Keep only the good goals: inside the map and not blocked.
        // goal_map: index -> which entries in out_dist this tile corresponds to.
        std::unordered_map<int,std::vector<int>> goal_map;
        goal_map.reserve(goals_xy.size()*2);
        std::vector<std::pair<int,int>> goals; goals.reserve(goals_xy.size());
        for (size_t i=0;i<goals_xy.size();++i){
        int gx=goals_xy[i].first, gy=goals_xy[i].second;
        if (!inb(gx,gy) || blocked(gx,gy,allow_unknown)) continue;
        goal_map[toIdx(gx,gy)].push_back((int)i);
        goals.emplace_back(gx,gy);
        }
        if (goal_map.empty()) return; // no reachable goals

        // Heuristic (h): a quick guess of how far a tile is to a goal if we can walk diagonally.
        auto h_oct = [](int x1,int y1,int x2,int y2){
        double dx = std::abs(x1-x2), dy = std::abs(y1-y2);
        return (dx+dy) + (std::sqrt(2.0)-2.0)*std::min(dx,dy); // "octile distance"
        };
        // For many goals, we guess distance to the *closest* goal.
        auto h_min_to_any = [&](int x,int y){
        double best=INF;
        for (auto& gxy : goals) {
            double h = h_oct(x,y,gxy.first,gxy.second);
            if (h<best) best=h;
        }
        return best;
        };

        // Moves we can make: 8 directions (N, NE, E, SE, S, SW, W, NW).
        static const int DX[8]={ 1, 1, 0,-1,-1,-1, 0, 1};
        static const int DY[8]={ 0, 1, 1, 1, 0,-1,-1,-1};
        static const double STEP[8]={ 1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0),
                                    1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0)};

        // One g-cost per tile (how far we've walked so far), and a "closed" stamp.
        const size_t N = (size_t)cols*rows;
        std::vector<double> g(N, INF);      // start as ∞ steps away
        std::vector<uint8_t> closed(N,0);   // 0 = not stamped, 1 = stamped (done)

        // The "open set" = our basket of places to check soon, ordered by f = g + w*h.
        struct QN{
        int idx; double g; double f;
        bool operator<(const QN& o)const{ return f>o.f; } // smallest f comes out first
        };
        std::priority_queue<QN> open;

        // Put the start tile into the basket.
        int sidx = toIdx(sx,sy);
        double h0 = h_min_to_any(sx,sy);
        g[sidx]=0.0;                          // we stand here: 0 steps so far
        open.push({sidx,0.0, 0.0 + w*h0});    // score f = g + w*h

        size_t remaining = goal_map.size();   // how many different goal tiles are left

        // Treasure hunt!
        while(!open.empty() && remaining>0){
        auto cur = open.top(); open.pop();  // pick the tile with best (smallest) score
        if (closed[cur.idx]) continue;      // if we already stamped it, skip
        closed[cur.idx]=1;                  // stamp it: we're done with this tile

        // Did we land on a goal tile?
        auto it = goal_map.find(cur.idx);
        if (it!=goal_map.end()){
            // Yes! Its g is the shortest distance from start to this goal.
            for (int gid : it->second) out_dist[gid]=cur.g;
            goal_map.erase(it);
            if (--remaining==0) break;        // found all goals—stop early!
        }

        // Try to step to all neighbors (8 directions).
        int cx = cur.idx % cols, cy = cur.idx / cols;
        for (int k=0;k<8;++k){
            int nx=cx+DX[k], ny=cy+DY[k];
            if (!inb(nx,ny)) continue;        // stay inside the map

            // If stepping diagonally, don't cut corners through walls.
            if (DX[k]!=0 && DY[k]!=0){
            if (blocked(cx+DX[k],cy,allow_unknown) || blocked(cx,cy+DY[k],allow_unknown)) continue;
            }
            if (blocked(nx,ny,allow_unknown)) continue; // can't step onto blocked tile

            int nidx = toIdx(nx,ny);
            double ng = cur.g + STEP[k];      // new g = steps so far + cost of this step
            if (ng < g[nidx]){                // if this is a better way to reach that tile
            g[nidx]=ng;
            double h = h_min_to_any(nx,ny); // guess how far left to the nearest goal
            open.push({nidx, ng, ng + w*h}); // put into basket with its new score
            }
        }
        }
    }



    void DistanceCalculator::multiGoalAstarCompletionHeuristic(
        int sx, int sy,
        const std::vector<std::pair<int,int>>& goals_xy,
        std::vector<double>& out_dist,
        bool allow_unknown,
        double w,
        const cv::Mat& gt_map_aligned,   // CV_8UC1 0/205/254
        int patch,                       // patch size
        double meters_per_cell,          // resolution
        double bias_k,                   // bias factor (0.5-2.0)
        double free_weight,              // completion free weight
        double obst_weight)              // completion obstacle weight
    {
        // FIXED: Robust input validation
        if (!cm_) {
            ROS_ERROR("Costmap is null in completion heuristic");
            out_dist.assign(goals_xy.size(), std::numeric_limits<double>::infinity());
            return;
        }

        if (gt_map_aligned.empty() || gt_map_aligned.type() != CV_8UC1) {
            ROS_WARN("GT map invalid - falling back to standard A*");
            // Fallback to regular multi-goal A*
            multiGoalAstar(sx, sy, goals_xy, out_dist, allow_unknown, w);
            // Convert cells to meters
            for (double& d : out_dist) {
                if (std::isfinite(d)) {
                    d *= meters_per_cell;
                }
            }
            return;
        }

        // Get costmap dimensions
        const int W = static_cast<int>(cm_->getSizeInCellsX());
        const int H = static_cast<int>(cm_->getSizeInCellsY());

        // FIXED: More tolerant size validation
        if (gt_map_aligned.cols != W || gt_map_aligned.rows != H) {
            ROS_WARN("GT map size mismatch: GT=%dx%d vs costmap=%dx%d - using fallback", 
                    gt_map_aligned.cols, gt_map_aligned.rows, W, H);
            
            // Don't fail completely - use fallback
            multiGoalAstar(sx, sy, goals_xy, out_dist, allow_unknown, w);
            for (double& d : out_dist) {
                if (std::isfinite(d)) {
                    d *= meters_per_cell;
                }
            }
            return;
        }

        // Validate other parameters
        if (!(meters_per_cell > 0.0) || patch <= 0) {
            ROS_ERROR("Invalid parameters: resolution=%.6f, patch=%d", meters_per_cell, patch);
            out_dist.assign(goals_xy.size(), std::numeric_limits<double>::infinity());
            return;
        }

        auto inb = [&](int x, int y) { return (0 <= x && x < W && 0 <= y && y < H); };
        auto toIdx = [&](int x, int y) { return y * W + x; };

        out_dist.assign(goals_xy.size(), std::numeric_limits<double>::infinity());

        // Build goal map with better validation
        std::unordered_map<int, std::vector<int>> goal_map;
        goal_map.reserve(goals_xy.size());
        for (size_t i = 0; i < goals_xy.size(); ++i) {
            const int gx = goals_xy[i].first;
            const int gy = goals_xy[i].second;
            if (!inb(gx, gy)) {
                ROS_DEBUG("Goal %zu at (%d,%d) outside bounds (%dx%d)", i, gx, gy, W, H);
                continue;
            }
            if (blocked(gx, gy, allow_unknown)) {
                ROS_DEBUG("Goal %zu at (%d,%d) is blocked", i, gx, gy);
                continue;
            }
            goal_map[toIdx(gx, gy)].push_back(static_cast<int>(i));
        }
        if (goal_map.empty()) {
            ROS_ERROR("No valid goals for A* completion");
            return;
        }

        // FIXED: Stable completion heuristic calculation
        auto completion_h = [&](int x, int y) -> double {
            // FIXED: Safer patch bounds calculation
            const int half = std::max(1, patch / 2);
            const int x0 = std::max(0, x - half);
            const int y0 = std::max(0, y - half);
            const int x1 = std::min(W, x + half);
            const int y1 = std::min(H, y + half);

            if (x1 <= x0 || y1 <= y0) {
                return 0.0; // Invalid patch
            }

            int cnt = 0, c_free = 0, c_unk = 0, c_obst = 0;

            // FIXED: Safe patch analysis with bounds checking
            for (int yy = y0; yy < y1; ++yy) {
                if (yy < 0 || yy >= gt_map_aligned.rows) continue;
                
                const uchar* row = gt_map_aligned.ptr<uchar>(yy);
                for (int xx = x0; xx < x1; ++xx) {
                    if (xx < 0 || xx >= gt_map_aligned.cols) continue;
                    
                    const uchar v = row[xx];
                    ++cnt;
                    if (v < 5)                 ++c_free;
                    else if (v >= 250)         ++c_obst;  // More tolerant threshold
                    else                       ++c_unk;
                }
            }

            if (cnt == 0) return 0.0;

            const double f_free = static_cast<double>(c_free) / cnt;
            const double f_unk  = static_cast<double>(c_unk)  / cnt;
            const double f_obst = static_cast<double>(c_obst) / cnt;

            // FIXED: More conservative completion bias
            const double unk_w = allow_unknown ? (0.3 * free_weight) : (0.6 * obst_weight);
            double risk = obst_weight * f_obst + unk_w * f_unk;
            risk *= (1.0 - 0.1 * f_free);  // Reduced free space bonus
            risk = std::max(0.0, risk);

            // FIXED: Clamp completion bias to prevent extreme values
            double h = w * bias_k * risk;
            h = std::min(h, 10.0);  // Reduced max bias
            return h;
        };

        // A* algorithm with completion heuristic
        const int N = W * H;
        std::vector<uint8_t> closed(N, 0);
        std::vector<double>  g(N, std::numeric_limits<double>::infinity());

        struct Node {
            int idx; double g; double f;
            bool operator<(const Node& o) const { return f > o.f; }
        };
        std::priority_queue<Node> open;

        // 8-direction movement
        static const int DX[8]   = { 1, 1, 0,-1,-1,-1, 0, 1};
        static const int DY[8]   = { 0, 1, 1, 1, 0,-1,-1,-1};
        static const double STEP[8] = {1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0),
                                    1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0)};

        const int sidx = toIdx(sx, sy);
        if (sidx < 0 || sidx >= N) {
            ROS_ERROR("Invalid start index: %d (bounds: 0-%d), start coords: (%d,%d)", sidx, N-1, sx, sy);
            return;
        }

        // Validate start position
        if (blocked(sx, sy, allow_unknown)) {
            ROS_ERROR("Start position (%d,%d) is blocked", sx, sy);
            return;
        }

        g[sidx] = 0.0;
        
        // FIXED: Safe completion heuristic calculation for start
        double start_h = 0.0;
        try {
            start_h = completion_h(sx, sy);
        } catch (const std::exception& e) {
            ROS_WARN("Exception in start heuristic: %s", e.what());
            start_h = 0.0;
        }
        
        open.push({sidx, 0.0, start_h});

        size_t remaining = goal_map.size();
        size_t iterations = 0;
        const size_t max_iterations = static_cast<size_t>(N) * 2;

        // Main A* loop
        while (!open.empty() && remaining > 0 && iterations < max_iterations) {
            Node cur = open.top(); 
            open.pop();
            ++iterations;

            if (closed[cur.idx]) continue;
            closed[cur.idx] = 1;

            // Check if reached a goal
            auto it = goal_map.find(cur.idx);
            if (it != goal_map.end()) {
                for (int goal_id : it->second) {
                    if (goal_id >= 0 && goal_id < static_cast<int>(out_dist.size())) {
                        // FIXED: Ensure distance is finite before conversion
                        if (std::isfinite(cur.g) && cur.g >= 0.0) {
                            out_dist[goal_id] = cur.g * meters_per_cell;  // Convert to meters
                            ROS_DEBUG("Goal %d reached: g=%.3f cells, distance=%.3f meters", 
                                    goal_id, cur.g, out_dist[goal_id]);
                        } else {
                            ROS_WARN("Invalid g value for goal %d: %.6f", goal_id, cur.g);
                            out_dist[goal_id] = std::numeric_limits<double>::infinity();
                        }
                    }
                }
                goal_map.erase(it);
                --remaining;
                if (remaining == 0) break;
            }

            const int cx = cur.idx % W;
            const int cy = cur.idx / W;

            // Expand neighbors
            for (int k = 0; k < 8; ++k) {
                const int nx = cx + DX[k];
                const int ny = cy + DY[k];
                if (!inb(nx, ny)) continue;

                // Prevent corner cutting
                if (DX[k] != 0 && DY[k] != 0) {
                    if (blocked(cx + DX[k], cy, allow_unknown) ||
                        blocked(cx, cy + DY[k], allow_unknown))
                        continue;
                }

                if (blocked(nx, ny, allow_unknown)) continue;

                const int nidx = toIdx(nx, ny);
                if (nidx < 0 || nidx >= N) continue;

                // FIXED: Safe step cost calculation
                double step = STEP[k];
                
                // Add small cost for unknown cells to encourage exploration
                const unsigned char c = cm_->getCost(nx, ny);
                if (c == costmap_2d::NO_INFORMATION) {
                    step += 0.1;  // Small unknown penalty
                }

                const double tentative_g = cur.g + step;

                // FIXED: Safe heuristic calculation
                double hn = 0.0;
                try {
                    hn = completion_h(nx, ny);
                } catch (const std::exception& e) {
                    // Use zero heuristic on error
                    hn = 0.0;
                }
                
                const double nf = tentative_g + hn;

                if (!closed[nidx] && tentative_g < g[nidx]) {
                    g[nidx] = tentative_g;
                    open.push({nidx, tentative_g, nf});
                }
            }
        }

        if (iterations >= max_iterations) {
            ROS_WARN("A* completion heuristic hit iteration limit");
        }

        ROS_DEBUG("A* completion completed: %zu iterations, %zu goals remaining", 
                iterations, remaining);

        // ADDED: Debug the final results
        int valid_results = 0;
        int infinite_results = 0;
        for (size_t i = 0; i < out_dist.size(); ++i) {
            if (std::isfinite(out_dist[i])) {
                valid_results++;
                ROS_DEBUG("Goal %zu: distance = %.3f meters", i, out_dist[i]);
            } else {
                infinite_results++;
                ROS_DEBUG("Goal %zu: INFINITE distance", i);
            }
        }
        
        ROS_INFO("A* completion results: %d valid, %d infinite out of %zu goals", 
                valid_results, infinite_results, out_dist.size());
        
        if (valid_results == 0) {
            ROS_ERROR("A* completion failed: all distances are infinite!");
            ROS_ERROR("Start: (%d,%d), Goals: %zu, Map: %dx%d", sx, sy, goals_xy.size(), W, H);
        }
    }

    bool DistanceCalculator::preflightAstarReachable(int sx, int sy, int gx, int gy,
                               bool allow_unknown,
                               int max_expansions,
                               int max_runtime_ms,
                               int goal_tol)
    {
    // In-process A*; move_base/make_plan kullanılmaz.
    if (!cm_ || !inb(sx,sy)) return false;
    if (!inb(gx,gy)) return false;
    if (blocked(sx,sy,allow_unknown)) return false;

    const int cols = (int)cm_->getSizeInCellsX();
    const int rows = (int)cm_->getSizeInCellsY();
    auto toIdx=[&](int x,int y){ return y*cols + x; };
    auto inB =[&](int x,int y){ return 0<=x && x<cols && 0<=y && y<rows; };

    auto h_octile = [&](int x,int y){
        int dx = std::abs(x-gx), dy = std::abs(y-gy);
        int mx = dx>dy?dx:dy, mn = dx>dy?dy:dx;
        return (mx - mn) + 1.41421356237 * mn; // octile
    };

    struct Node { double f,g; int x,y; };
    struct Cmp  { bool operator()(const Node&a,const Node&b) const { return a.f>b.f; } };

    std::vector<float>   gscore(cols*rows, std::numeric_limits<float>::infinity());
    std::vector<uint8_t> closed(cols*rows, 0);
    std::priority_queue<Node, std::vector<Node>, Cmp> open;

    auto push = [&](int x,int y,float ng){
        int id = toIdx(x,y);
        if (ng < gscore[id]) {
        gscore[id] = ng;
        double f = ng + h_octile(x,y) * 1.0001; // küçük tie-break
        open.push(Node{f, ng, x, y});
        }
    };

    push(sx,sy,0.0f);
    const int dxs[8]={1,1,0,-1,-1,-1,0,1};
    const int dys[8]={0,1,1,1,0,-1,-1,-1};

    auto t0 = ros::Time::now();
    int expansions=0;

    while(!open.empty()){
        Node n = open.top(); open.pop();
        int id = toIdx(n.x,n.y);
        if (closed[id]) continue;
        closed[id] = 1;
        ++expansions;

        if (expansions > max_expansions) return false;
        if ((ros::Time::now() - t0).toSec()*1000.0 > max_runtime_ms) return false;

        if (std::abs(n.x-gx) <= goal_tol && std::abs(n.y-gy) <= goal_tol) {
        return true; // bulundu
        }

        for(int k=0;k<8;k++){
        int nx=n.x+dxs[k], ny=n.y+dys[k];
        if (!inB(nx,ny)) continue;
        if (blocked(nx,ny,allow_unknown)) continue;
        float step = (k%2==0)?1.0f:1.41421356f;
        float ng = n.g + step;
        if (ng < gscore[toIdx(nx,ny)]) push(nx,ny,ng);
        }
    }
    return false;
    }


    double DistanceCalculator::euclideanDistance(double x1, double y1, double x2, double y2) {
    return std::hypot(x1 - x2, y1 - y2);
    }

    double DistanceCalculator::manhattanDistance(double x1, double y1, double x2, double y2) {
        return std::abs(x1 - x2) + std::abs(y1 - y2);
    }

    double DistanceCalculator::chebyshevDistance(double x1, double y1, double x2, double y2) {
        return std::max(std::abs(x1 - x2), std::abs(y1 - y2));
    }

    double DistanceCalculator::squaredEuclideanDistance(double x1, double y1, double x2, double y2) {
        double dx = x1 - x2, dy = y1 - y2;
        return dx*dx + dy*dy;
    }

    // Fixed ensureDistanceField with better memory management and error handling
    void DistanceCalculator::ensureDistanceField(int sx, int sy, bool allow_unknown)
    {
        if (!cm_) {
            field_valid_ = false;
            return;
        }

        std::lock_guard<costmap_2d::Costmap2D::mutex_t> lk(*cm_->getMutex());

        const int cols = static_cast<int>(cm_->getSizeInCellsX());
        const int rows = static_cast<int>(cm_->getSizeInCellsY());
        
        if (cols <= 0 || rows <= 0) {
            ROS_ERROR("Invalid costmap dimensions: %dx%d", cols, rows);
            field_valid_ = false;
            return;
        }

        auto inb_local = [&](int x, int y) { 
            return x >= 0 && x < cols && y >= 0 && y < rows; 
        };
        auto toIdx = [&](int x, int y) { return y * cols + x; };

        // Check if we can reuse cached field
        if (field_valid_ &&
            field_cols_ == cols && 
            field_rows_ == rows &&
            field_start_idx_ == toIdx(sx, sy) &&
            field_allow_unknown_ == allow_unknown) {
            return; // Cache hit
        }

        // Validate start position
        if (!inb_local(sx, sy) || blocked(sx, sy, allow_unknown)) {
            field_valid_ = false;
            return;
        }

        // Update cache parameters
        field_cols_ = cols;
        field_rows_ = rows;
        field_start_idx_ = toIdx(sx, sy);
        field_allow_unknown_ = allow_unknown;

        const size_t N = static_cast<size_t>(cols) * static_cast<size_t>(rows);
        const double INF = std::numeric_limits<double>::infinity();

        // Efficient memory allocation - reserve if needed, otherwise reuse
        if (dist_field_.size() != N) {
            try {
                dist_field_.assign(N, INF);
            } catch (const std::bad_alloc& e) {
                ROS_ERROR("Failed to allocate distance field: %s", e.what());
                field_valid_ = false;
                return;
            }
        } else {
            std::fill(dist_field_.begin(), dist_field_.end(), INF);
        }

        // Dijkstra's algorithm with proper bounds checking
        struct Node { 
            int idx; 
            double g; 
            bool operator<(const Node& o) const { return g > o.g; } 
        };
        std::priority_queue<Node> pq;

        static const int DX[8] = { 1, 1, 0, -1, -1, -1,  0,  1};
        static const int DY[8] = { 0, 1, 1,  1,  0, -1, -1, -1};
        static const double STEP[8] = {
            1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0),
            1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0)
        };

        const int start_idx = field_start_idx_;
        dist_field_[start_idx] = 0.0;
        pq.push({start_idx, 0.0});

        size_t processed = 0;
        const size_t max_iterations = N * 2; // Prevent infinite loops

        while (!pq.empty() && processed < max_iterations) {
            auto cur = pq.top();
            pq.pop();
            processed++;

            // Skip outdated entries
            if (cur.g > dist_field_[cur.idx] + 1e-9) {
                continue;
            }

            const int cx = cur.idx % cols;
            const int cy = cur.idx / cols;

            for (int k = 0; k < 8; ++k) {
                const int nx = cx + DX[k];
                const int ny = cy + DY[k];

                if (!inb_local(nx, ny)) continue;

                // Prevent diagonal corner cutting
                if (DX[k] != 0 && DY[k] != 0) {
                    if (blocked(cx + DX[k], cy, allow_unknown) || 
                        blocked(cx, cy + DY[k], allow_unknown)) {
                        continue;
                    }
                }

                if (blocked(nx, ny, allow_unknown)) continue;

                const int nidx = toIdx(nx, ny);
                const double ng = cur.g + STEP[k];
                
                if (ng < dist_field_[nidx]) {
                    dist_field_[nidx] = ng;
                    pq.push({nidx, ng});
                }
            }
        }

        if (processed >= max_iterations) {
            ROS_WARN("Distance field computation hit iteration limit");
        }

        field_valid_ = true;
    }

    // Add to distance_calculator.cpp - optimized distance field with early termination
    void DistanceCalculator::ensureDistanceFieldOptimized(int sx, int sy, bool allow_unknown,double max_distance)
    {
        if (!cm_) {
            field_valid_ = false;
            return;
        }

        std::lock_guard<costmap_2d::Costmap2D::mutex_t> lk(*cm_->getMutex());

        const int cols = static_cast<int>(cm_->getSizeInCellsX());
        const int rows = static_cast<int>(cm_->getSizeInCellsY());
        
        if (cols <= 0 || rows <= 0) {
            field_valid_ = false;
            return;
        }

        // Check cache validity
        auto toIdx = [&](int x, int y) { return y * cols + x; };

        if (field_valid_ &&
            field_cols_ == cols && field_rows_ == rows &&
            field_start_idx_ == toIdx(sx, sy) &&
            field_allow_unknown_ == allow_unknown) {
            return; // Cache hit
        }

        if (!inb(sx, sy) || blocked(sx, sy, allow_unknown)) {
            field_valid_ = false;
            return;
        }

        // Update cache parameters
        field_cols_ = cols;
        field_rows_ = rows;
        field_start_idx_ = toIdx(sx, sy);
        field_allow_unknown_ = allow_unknown;

        const size_t N = static_cast<size_t>(cols) * static_cast<size_t>(rows);
        const double INF = std::numeric_limits<double>::infinity();

        // Efficient memory management
        if (dist_field_.size() != N) {
            try {
                dist_field_.assign(N, INF);
            } catch (const std::bad_alloc& e) {
                ROS_ERROR("Memory allocation failed: %s", e.what());
                field_valid_ = false;
                return;
            }
        } else {
            std::fill(dist_field_.begin(), dist_field_.end(), INF);
        }

        // Dijkstra with early termination option
        struct Node { 
            int idx; 
            double g; 
            bool operator<(const Node& o) const { return g > o.g; } 
        };
        std::priority_queue<Node> pq;

        static const int DX[8] = { 1, 1, 0, -1, -1, -1,  0,  1};
        static const int DY[8] = { 0, 1, 1,  1,  0, -1, -1, -1};
        static const double STEP[8] = {
            1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0),
            1.0, std::sqrt(2.0), 1.0, std::sqrt(2.0)
        };

        const int start_idx = field_start_idx_;
        dist_field_[start_idx] = 0.0;
        pq.push({start_idx, 0.0});

        size_t processed = 0;
        const size_t max_iterations = N * 2;
        const double max_dist = (max_distance > 0) ? max_distance : std::numeric_limits<double>::infinity();

        while (!pq.empty() && processed < max_iterations) {
            auto cur = pq.top();
            pq.pop();
            processed++;

            // Early termination if we've exceeded max distance
            if (cur.g > max_dist) {
                break;
            }

            // Skip outdated entries
            if (cur.g > dist_field_[cur.idx] + 1e-9) {
                continue;
            }

            const int cx = cur.idx % cols;
            const int cy = cur.idx / cols;

            for (int k = 0; k < 8; ++k) {
                const int nx = cx + DX[k];
                const int ny = cy + DY[k];

                if (!inb(nx, ny)) continue;

                // Prevent diagonal corner cutting
                if (DX[k] != 0 && DY[k] != 0) {
                    if (blocked(cx + DX[k], cy, allow_unknown) || 
                        blocked(cx, cy + DY[k], allow_unknown)) {
                        continue;
                    }
                }

                if (blocked(nx, ny, allow_unknown)) continue;

                const int nidx = toIdx(nx, ny);
                const double ng = cur.g + STEP[k];
                
                if (ng < dist_field_[nidx] && ng <= max_dist) {
                    dist_field_[nidx] = ng;
                    pq.push({nidx, ng});
                }
            }
        }

        field_valid_ = true;
    }


    double DistanceCalculator::computeDistanceUsingMakePlanSafe(double sx, double sy, double gx, double gy)
    {
        const double INF = std::numeric_limits<double>::infinity();
        
        // Input validation
        if (!std::isfinite(sx) || !std::isfinite(sy) || !std::isfinite(gx) || !std::isfinite(gy)) {
            ROS_WARN("Invalid coordinates for make_plan: start(%.3f,%.3f) goal(%.3f,%.3f)", sx, sy, gx, gy);
            return INF;
        }

        // Service availability check with timeout
        if (!make_plan_client_.isValid()) {
            initMakePlanClient();
        }

        if (!make_plan_client_.exists()) {
            if (!make_plan_client_.waitForExistence(ros::Duration(3.0))) {
                ROS_WARN_THROTTLE(5.0, "make_plan service not available: %s", makeplan_service_.c_str());
                return INF;
            }
        }

        // Build service request with validation
        nav_msgs::GetPlan srv;
        const ros::Time stamp = ros::Time::now();

        srv.request.start.header.frame_id = global_frame_;
        srv.request.start.header.stamp = stamp;
        srv.request.start.pose.position.x = sx;
        srv.request.start.pose.position.y = sy;
        srv.request.start.pose.position.z = 0.0;
        srv.request.start.pose.orientation.x = 0.0;
        srv.request.start.pose.orientation.y = 0.0;
        srv.request.start.pose.orientation.z = 0.0;
        srv.request.start.pose.orientation.w = 1.0;

        srv.request.goal.header.frame_id = global_frame_;
        srv.request.goal.header.stamp = stamp;
        srv.request.goal.pose.position.x = gx;
        srv.request.goal.pose.position.y = gy;
        srv.request.goal.pose.position.z = 0.0;
        srv.request.goal.pose.orientation.x = 0.0;
        srv.request.goal.pose.orientation.y = 0.0;
        srv.request.goal.pose.orientation.z = 0.0;
        srv.request.goal.pose.orientation.w = 1.0;

        srv.request.tolerance = std::max(0.01, std::min(makeplan_tolerance_, 1.0)); // Clamp tolerance

        // Service call with retry (ROS ServiceClient doesn't support timeout in call())
        bool call_success = false;
        int retry_count = 0;
        const int max_retries = 2;
        
        while (!call_success && retry_count < max_retries) {
            try {
                // Simple call without timeout - ROS will use default timeout
                call_success = make_plan_client_.call(srv);
            } catch (const std::exception& e) {
                ROS_WARN("Exception in make_plan service call (attempt %d): %s", retry_count + 1, e.what());
            }
            
            if (!call_success) {
                retry_count++;
                if (retry_count < max_retries) {
                    ros::Duration(0.1).sleep(); // Brief delay before retry
                }
            }
        }

        if (!call_success) {
            ROS_WARN_THROTTLE(2.0, "make_plan call failed after %d attempts (service: %s)", 
                            max_retries, makeplan_service_.c_str());
            return INF;
        }

        // Validate response
        const auto& poses = srv.response.plan.poses;
        if (poses.empty()) {
            ROS_DEBUG("make_plan returned empty path");
            return INF;
        }

        if (poses.size() == 1) {
            ROS_DEBUG("make_plan: start ≈ goal within tolerance");
            return 0.0;
        }

        // Validate path and compute length
        double total_length = 0.0;
        const size_t max_poses = 10000; // Prevent excessive computation
        const size_t actual_poses = std::min(poses.size(), max_poses);
        
        for (size_t i = 1; i < actual_poses; ++i) {
            const auto& a = poses[i-1].pose.position;
            const auto& b = poses[i].pose.position;

            // Validate coordinates
            if (!std::isfinite(a.x) || !std::isfinite(a.y) || !std::isfinite(a.z) ||
                !std::isfinite(b.x) || !std::isfinite(b.y) || !std::isfinite(b.z)) {
                ROS_WARN("make_plan returned path with invalid coordinates at segment %zu", i);
                return INF;
            }

            const double dx = b.x - a.x;
            const double dy = b.y - a.y;
            const double segment_length = std::hypot(dx, dy);
            
            // Sanity check segment length
            if (!std::isfinite(segment_length) || segment_length < 0.0 || segment_length > 100.0) {
                ROS_WARN("Invalid segment length %.3f at segment %zu", segment_length, i);
                return INF;
            }
            
            total_length += segment_length;
            
            // Prevent excessive path lengths
            if (total_length > 1000.0) {
                ROS_WARN("Path length exceeds reasonable limit: %.3f m", total_length);
                return INF;
            }
        }

        if (actual_poses < poses.size()) {
            ROS_WARN("Path truncated due to length limit: %zu/%zu poses processed", 
                    actual_poses, poses.size());
        }

        ROS_DEBUG("make_plan success: %.3f m over %zu segments", total_length, actual_poses - 1);
        return total_length;
    }

}

