/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2008, Robert Bosch LLC.
 *  Copyright (c) 2015-2016, Jiri Horner.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of the Jiri Horner nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 *********************************************************************/

#include <explore/explore.h>



#include <thread>
#include <iostream> 
#include <opencv2/opencv.hpp> 
#include <ctime>
#include <iostream>
#include <fstream>
#include <std_msgs/Int32.h>
#include <chrono>
#include <geometry_msgs/PoseArray.h>
#include <cmath>




using namespace cv; 
using namespace std; 

#include <ctime>

clock_t beginClock, endClock;



inline static bool operator==(const geometry_msgs::Point& one,
                              const geometry_msgs::Point& two)
{
  double dx = one.x - two.x;
  double dy = one.y - two.y;
  double dist = sqrt(dx * dx + dy * dy);
  return dist < 0.01;
}

namespace explore
{
    Explore::Explore()
        : private_nh_("~")
        , tf_listener_(ros::Duration(10.0))
        , costmap_client_(private_nh_, relative_nh_, &tf_listener_)  
        , move_base_client_("move_base")  // Initialize here with hardcoded name
        , prev_distance_(std::numeric_limits<double>::max()) // 0 idi
        , last_markers_count_(0)
    {
        
        private_nh_.param("planner_frequency", planner_frequency_, 1.0);
        private_nh_.param("progress_timeout", timeout, 100.0); // default = 30.0
        progress_timeout_ = ros::Duration(timeout);
        private_nh_.param("visualize", visualize_, true);
        private_nh_.param("potential_scale", potential_scale_, 1e-3);
        private_nh_.param("orientation_scale", orientation_scale_, 0.0);
        private_nh_.param("gain_scale", gain_scale_, 1.0);
        private_nh_.param("min_frontier_size", min_frontier_size, 0.5);
        private_nh_.param("with_map_completion", with_map_completion, 0);
        private_nh_.param<std::string>("distance_method", distance_method, std::string("euclidean"));
        private_nh_.param("validate_with_makeplan", validate_with_makeplan_, false);
        private_nh_.param("publish_completed_map", publish_completed_map_, false);
        private_nh_.param("gt_image_path", gt_image_path_, std::string(""));

        // ---- GT görüntü & referans koordinatları ----  
        
        private_nh_.param("gt_origin_x", gt_origin_x_, -26.0);     
        private_nh_.param("gt_origin_y", gt_origin_y_, -42.0);     
        private_nh_.param("gt_resolution", gt_resolution_, 0.1);  
        private_nh_.param("rect_size", rect_size_, 32);  
        private_nh_.param("completion_known_scale", completion_known_scale_, 1.0);  
        private_nh_.param("completion_obstacle_scale", completion_obstacle_scale_, 0.5);
        private_nh_.param("prefer_preflight_astar", prefer_preflight_astar_, true);


        
        search_ = frontier_exploration::FrontierSearch(costmap_client_.getCostmap(),
                                                    potential_scale_, gain_scale_,
                                                    min_frontier_size,
                                                    distance_method,
                                                    rect_size_,
                                                    completion_known_scale_,
                                                    completion_obstacle_scale_
                                                    );

        last_roi_markers_count_=0;

        if (!gt_image_path_.empty()) {
        cv::Mat gt = cv::imread(gt_image_path_, cv::IMREAD_GRAYSCALE);
        if (gt.empty()) {
            ROS_WARN("gt_image_path='%s' could not be read. GT-based comparisons disabled.",
                    gt_image_path_.c_str());
        } else {
            search_.setGtImage(gt);
            search_.setYamlOriginRes(gt_origin_x_, gt_origin_y_, gt_resolution_);
            ROS_INFO("GT image loaded: %dx%d, origin=(%.3f, %.3f), res=%.3f",
                    gt.cols, gt.rows, gt_origin_x_, gt_origin_y_, gt_resolution_);
        }
        }
        else{
        ROS_WARN("gt_image_path is empty");
        }



        dc_.setCostmap(costmap_client_.getCostmap());                 
        dc_.setGlobalFrame(costmap_client_.getGlobalFrameID());   
        
        odom_sub_ = private_nh_.subscribe<nav_msgs::Odometry>(
        "odom",   // topic name (check if your robot publishes under "odom" or something like "/odom")
        10, 
        &Explore::odomCallback, 
        this
        );


        if (visualize_) {
        marker_array_publisher_ =
            private_nh_.advertise<visualization_msgs::MarkerArray>("frontiers", 10);
        }


        // Use a stringstream to build the filename
        std::stringstream filename_ss;
        filename_ss << "/home/selma/exploration_" << distance_method << "_log.csv";

        // Use the resulting string to initialize the logger
        logger_ = std::make_unique<ExperimentLogger>(filename_ss.str());


        selected_frontier_pub_ = private_nh_.advertise<explore_lite::FrontierMsg>("selected_frontier", 10);
        exploration_finished_pub_ = private_nh_.advertise<std_msgs::Int32>("exploration_finished", 10);
        frontiers_pub_ = private_nh_.advertise<explore_lite::FrontierArray>("all_frontiers", 10);
        
        if(with_map_completion == 1){
        ROS_INFO("with_map_completion: %d ", with_map_completion);
        target_frontier_sub_ = private_nh_.subscribe("/target_frontier", 10, &Explore::targetFrontierCallback, this);
        }
        

        completed_pub_ = private_nh_.advertise<nav_msgs::OccupancyGrid>("/completed_map", 1, /*latch=*/true);
        gt_map_pub_ = private_nh_.advertise<nav_msgs::OccupancyGrid>("/gt_map", 1, /*latch=*/true);

        
        ROS_INFO("Waiting to connect to move_base server");
        move_base_client_.waitForServer();
        ROS_INFO("Connected to move_base server");

        // In the Explore constructor and makePlan(), add:
        const unsigned int W = costmap_client_.getCostmap()->getSizeInCellsX();
        const unsigned int H = costmap_client_.getCostmap()->getSizeInCellsY();
        ROS_INFO_THROTTLE(5.0, "Current costmap size: %ux%u", W, H);

        exploring_timer_ =
            relative_nh_.createTimer(ros::Duration(1. / planner_frequency_),
                                    [this](const ros::TimerEvent&) { 
                                    makePlan(); 
                                    });
    }


    Explore::~Explore()
    {
        try {
            stop();
            
            // Clean up timers
            oneshot_.stop();
            exploring_timer_.stop();
            
            // Clear blacklist to free memory
            frontier_blacklist_.clear();
            frontier_blacklist_.shrink_to_fit();
            
            // Reset logger
            logger_.reset();
            
        } catch (const std::exception& e) {
            ROS_ERROR("Exception in Explore destructor: %s", e.what());
        } catch (...) {
            ROS_ERROR("Unknown exception in Explore destructor");
        }
    }


    bool isSamePoint(const geometry_msgs::Point& p1, const geometry_msgs::Point& p2, double tolerance = 1e-3) 
    {
        return (std::abs(p1.x - p2.x) < tolerance &&
                std::abs(p1.y - p2.y) < tolerance &&
                std::abs(p1.z - p2.z) < tolerance);
    }


    void Explore::visualizeFrontiers(
        const std::vector<frontier_exploration::Frontier>& frontiers, 
        geometry_msgs::Point target_position)
    {
        // FIXED: Add safety checks
        if (!visualize_ || frontiers.empty()) {
            return;
        }

        std_msgs::ColorRGBA blue;   blue.r = 0;   blue.g = 0;   blue.b = 1.0; blue.a = 1.0;
        std_msgs::ColorRGBA red;    red.r = 1.0; red.g = 0;    red.b = 0;    red.a = 1.0;
        std_msgs::ColorRGBA green;  green.r = 0;  green.g = 1.0; green.b = 0.0; green.a = 1.0;

        visualization_msgs::MarkerArray markers_msg;
        std::vector<visualization_msgs::Marker>& markers = markers_msg.markers;

        visualization_msgs::Marker m;
        m.header.frame_id = costmap_client_.getGlobalFrameID();
        m.header.stamp    = ros::Time::now();
        m.ns              = "frontiers";
        m.scale.x = 1.0; m.scale.y = 1.0; m.scale.z = 1.0;
        m.color   = blue;
        m.lifetime = ros::Duration(5.0);  // FIXED: Give markers longer lifetime
        m.frame_locked = true;

        // Find the lowest finite cost for scaling
        double min_cost = std::numeric_limits<double>::infinity();
        for (const auto& frontier : frontiers) {
            if (std::isfinite(frontier.cost) && frontier.cost < min_cost) {
                min_cost = frontier.cost;
            }
        }

        // FIXED: If no finite cost found, use a default
        if (!std::isfinite(min_cost)) {
            min_cost = 1.0;
        }

        m.action = visualization_msgs::Marker::ADD;
        size_t id = 0;

        // Draw frontier cells and centroids
        for (const auto& frontier : frontiers) {
            // FIXED: Skip invalid frontiers
            if (!std::isfinite(frontier.centroid.x) || !std::isfinite(frontier.centroid.y)) {
                continue;
            }

            // Frontier cells as POINTS
            m.type = visualization_msgs::Marker::POINTS;
            m.id   = static_cast<int>(id);
            m.pose.position = geometry_msgs::Point();
            m.scale.x = 0.1; m.scale.y = 0.1; m.scale.z = 0.1;
            m.points = frontier.points;
            m.color  = goalOnBlacklist(frontier.centroid) ? red : blue;
            markers.push_back(m);
            ++id;

            // Centroid as SPHERE
            m.type = visualization_msgs::Marker::SPHERE;
            m.id   = static_cast<int>(id);
            m.points.clear();
            m.pose.position = frontier.centroid;

            // FIXED: Safer scale calculation
            double scale = 0.3; // Default scale
            if (std::isfinite(frontier.cost) && std::isfinite(min_cost) && min_cost > 0) {
                double denom = std::max(std::abs(frontier.cost), 1e-6);
                scale = std::min(std::abs(min_cost * 0.4 / denom), 0.5);
                scale = std::max(scale, 0.1); // Minimum size
            }
            m.scale.x = scale; m.scale.y = scale; m.scale.z = scale;

            std_msgs::ColorRGBA orange; orange.r = 1.0; orange.g = 0.5; orange.b = 0.0; orange.a = 1.0;
            m.color = isSamePoint(frontier.centroid, target_position) ? orange : green;

            markers.push_back(m);
            ++id;
        }

        // FIXED: Simplified ROI drawing - only draw if not too many frontiers
        if (frontiers.size() <= 20) {  // Avoid clutter with too many ROIs
            const double res = costmap_client_.getCostmap()->getResolution();
            const int rect_cells = std::max(1, rect_size_);
            const double half_m = 0.5 * static_cast<double>(rect_cells) * res;

            size_t roi_id = 0;
            for (const auto& frontier : frontiers) {
                // Skip invalid frontiers
                if (!std::isfinite(frontier.centroid.x) || !std::isfinite(frontier.centroid.y)) {
                    continue;
                }

                visualization_msgs::Marker r;
                r.header.frame_id = costmap_client_.getGlobalFrameID();
                r.header.stamp    = ros::Time::now();
                r.ns   = "frontier_rois";
                r.id   = static_cast<int>(roi_id++);
                r.type = visualization_msgs::Marker::LINE_STRIP;
                r.action = visualization_msgs::Marker::ADD;
                r.lifetime = ros::Duration(5.0);  // FIXED: Longer lifetime
                r.frame_locked = true;

                r.scale.x = 0.03;
                r.color.r = 1.0; r.color.g = 0.0; r.color.b = 1.0; r.color.a = 0.7; // Slightly transparent

                // Rectangle corners
                geometry_msgs::Point p; p.z = 0.0;
                p.x = frontier.centroid.x - half_m; p.y = frontier.centroid.y - half_m; r.points.push_back(p);
                p.x = frontier.centroid.x + half_m; p.y = frontier.centroid.y - half_m; r.points.push_back(p);
                p.x = frontier.centroid.x + half_m; p.y = frontier.centroid.y + half_m; r.points.push_back(p);
                p.x = frontier.centroid.x - half_m; p.y = frontier.centroid.y + half_m; r.points.push_back(p);
                p.x = frontier.centroid.x - half_m; p.y = frontier.centroid.y - half_m; r.points.push_back(p);

                markers.push_back(r);
            }
            last_roi_markers_count_ = roi_id;
        } else {
            last_roi_markers_count_ = 0;
        }

        // FIXED: Conservative cleanup - only delete if we have fewer markers now
        size_t current_markers_count = id;
        if (current_markers_count < last_markers_count_) {
            visualization_msgs::Marker del;
            del.header.frame_id = costmap_client_.getGlobalFrameID();
            del.header.stamp    = ros::Time::now();
            del.ns = "frontiers";
            del.action = visualization_msgs::Marker::DELETE;
            for (size_t i = current_markers_count; i < last_markers_count_; ++i) {
                del.id = static_cast<int>(i);
                markers.push_back(del);
            }
        }

        // Cleanup old ROI markers if needed
        if (frontiers.size() > 20 && last_roi_markers_count_ > 0) {
            visualization_msgs::Marker del;
            del.header.frame_id = costmap_client_.getGlobalFrameID();
            del.header.stamp    = ros::Time::now();
            del.ns = "frontier_rois";
            del.action = visualization_msgs::Marker::DELETE;
            for (size_t i = 0; i < last_roi_markers_count_; ++i) {
                del.id = static_cast<int>(i);
                markers.push_back(del);
            }
            last_roi_markers_count_ = 0;
        }

        last_markers_count_ = current_markers_count;
        
        // FIXED: Only publish if we have valid markers
        if (!markers.empty()) {
            marker_array_publisher_.publish(markers_msg);
        }
    }


    void Explore::targetFrontierCallback(const explore_lite::FrontierMsg::ConstPtr& msg)
    {

        if (!msg) 
        {
            ROS_WARN("Received null frontier message");
            return;
        }
        

        // Validate input before any locking
        if (!std::isfinite(msg->centroid.x) || !std::isfinite(msg->centroid.y)) {
            ROS_WARN_THROTTLE(1.0, "Invalid frontier coordinates (inf/nan). Ignoring.");
            return;
        }

        std::lock_guard<std::mutex> lock(target_mutex_);
        received_target_frontier = *msg;  // Copy while holding lock
        use_external_target = true;
        
        // Cancel any pending replan outside the lock
        oneshot_.stop();

        // Schedule replan with proper error handling
        oneshot_ = relative_nh_.createTimer(
            ros::Duration(0), 
            [this](const ros::TimerEvent&) {
                try {
                    makePlan();
                } catch (const std::exception& e) {
                    ROS_ERROR("Exception in makePlan: %s", e.what());
                }
            },
            true  // oneshot
        );
    }


    // Fixed makePlan function - restore stability
    void Explore::makePlan()
    {
        try {
            if (with_map_completion == 1) {
                ros::spinOnce();
            }

            // Validate costmap early
            auto* cm = costmap_client_.getCostmap();
            if (!cm) {
                ROS_ERROR("Costmap pointer is null");
                return;
            }

            const unsigned int W = cm->getSizeInCellsX();
            const unsigned int H = cm->getSizeInCellsY();
            const double res = cm->getResolution();

            if (W == 0 || H == 0 || res <= 0.0) {
                ROS_ERROR("Invalid costmap dimensions: %ux%u, res=%.6f", W, H, res);
                return;
            }

            // FIXED: Only initialize completed map ONCE and handle epoch changes more carefully
            static bool completed_map_initialized = false;
            
            if (!completed_map_initialized) {
                search_.setMapSaverOriginRes(cm->getOriginX(), cm->getOriginY(), res, 
                                        static_cast<int>(W), static_cast<int>(H));
                
                if (search_.completedMapMat().empty()) {
                    search_.seedCompletedMapFromCostmap();
                    search_.seedCompletedMapFromGT();
                }
                completed_map_initialized = true;
            }

            // FIXED: Less aggressive cache invalidation - only on significant changes
            const uint64_t epoch = costmap_client_.getMapEpoch();
            static uint64_t last_significant_epoch = 0;
            
            // Only invalidate if epoch changed significantly (not every small change)
            if (epoch != last_map_epoch_ && (epoch - last_significant_epoch) > 5) {
                ROS_DEBUG("Significant map epoch change, invalidating caches");
                search_.invalidateDistanceField();
                last_significant_epoch = epoch;
            }
            last_map_epoch_ = epoch;

            auto start_time = std::chrono::high_resolution_clock::now();

            // Get robot pose with validation
            auto pose = costmap_client_.getRobotPose();
            unsigned int mx, my;
            if (!cm->worldToMap(pose.position.x, pose.position.y, mx, my)) {
                ROS_ERROR("Robot position out of costmap bounds (x:%.2f y:%.2f)",
                        pose.position.x, pose.position.y);
                return;
            }

            // Find frontiers
            auto frontiers = search_.searchFrom(pose.position);
            if (frontiers.empty()) {
                ROS_INFO("No explorable frontiers remaining");
                stop();
                return;
            }

            publishCompletionMetrics(frontiers);

            // FIXED: Simplified blacklist check - avoid excessive filtering
            auto valid_frontier = std::find_if(frontiers.begin(), frontiers.end(),
                                            [this](const frontier_exploration::Frontier& f) {
                                                return !goalOnBlacklist(f.centroid);
                                            });

            if (valid_frontier == frontiers.end()) {
                ROS_INFO("All remaining frontiers are blacklisted. Exploration complete.");
                stop();
                return;
            }

            ROS_INFO("Found %zu frontiers. Best cost: %.3f", frontiers.size(), frontiers.front().cost);

            // Process frontiers for publishing
            std::vector<explore_lite::FrontierMsg> frontiers_msg;
            geometry_msgs::Point target_position;
            frontier_exploration::Frontier target_frontier;
            bool found_target = false;

            for (auto& frontier : frontiers) {
                explore_lite::FrontierMsg frontier_msg;
                frontier_msg.size = frontier.size;
                frontier_msg.min_distance = frontier.min_distance;
                frontier_msg.cost = frontier.cost;
                frontier_msg.initial = frontier.initial;
                frontier_msg.centroid = frontier.centroid;
                frontier_msg.middle = frontier.middle;
                frontier_msg.points = frontier.points;
                frontier_msg.map_resolution = frontier.map_resolution;
                frontier_msg.is_in_blacklist = goalOnBlacklist(frontier.centroid);
                frontier_msg.is_target = false;

                if (!found_target && !frontier_msg.is_in_blacklist) {
                    target_position = frontier.centroid;
                    target_frontier = frontier;
                    frontier_msg.is_target = true;
                    found_target = true;
                    selected_frontier_pub_.publish(frontier_msg);
                }

                if (!frontier_msg.is_in_blacklist) {
                    frontiers_msg.push_back(std::move(frontier_msg));
                }
            }

            // Handle external target selection with atomic access
            double min_distance;
            bool use_ext = false;
            explore_lite::FrontierMsg ext_copy;
            
            {
                std::lock_guard<std::mutex> lock(target_mutex_);
                use_ext = use_external_target;
                if (use_ext) {
                    ext_copy = received_target_frontier;
                    use_external_target = false;  // Reset immediately
                }
            }

            if (with_map_completion == 1 && use_ext && !goalOnBlacklist(ext_copy.centroid)) {
                target_position = ext_copy.centroid;
                
                // Recompute distance
                dc_.ensureDistanceField(static_cast<int>(mx), static_cast<int>(my), false);
                unsigned int gx, gy;
                if (cm->worldToMap(target_position.x, target_position.y, gx, gy)) {
                    double d_cells = dc_.distToCell(static_cast<int>(gx), static_cast<int>(gy));
                    min_distance = std::isfinite(d_cells) ? d_cells * res : 
                                std::numeric_limits<double>::infinity();
                } else {
                    min_distance = std::numeric_limits<double>::infinity();
                }
                
                ROS_INFO("Using external target at (%.2f, %.2f)", target_position.x, target_position.y);
            } else {
                min_distance = target_frontier.min_distance;
            }

            // Publish frontiers
            if (with_map_completion == 1) {
                explore_lite::FrontierArray frontier_array_msg;
                frontier_array_msg.frontiers = frontiers_msg;
                frontiers_pub_.publish(frontier_array_msg);
            }

            // FIXED: Only visualize if we have valid frontiers and target
            if (visualize_ && found_target) {
                visualizeFrontiers(frontiers, target_position);
            }

            // PREFLIGHT VALIDATION: Use in-process A* for reachability checking
            if (validate_with_makeplan_ && shouldValidateTarget(min_distance)) {
                // Use preflight A* instead of service call
                if (!preFlightCheckWithAstar(pose.position, target_position, min_distance)) {
                    return; // Validation failed, target blacklisted, replan scheduled
                }
            }

            // Publish completed maps less frequently
            static int publish_counter = 0;
            if (publish_completed_map_ && (++publish_counter % 10) == 0) {
                publishCompletedMaps();
            }

            // Send navigation goal
            if (!sendNavigationGoal(target_position, min_distance)) {
                ROS_ERROR("Failed to send navigation goal");
                return;
            }

            // Log timing
            auto duration = std::chrono::duration<double, std::milli>(
                std::chrono::high_resolution_clock::now() - start_time);
            ROS_DEBUG("Planning cycle took %.2f ms", duration.count());

            if (logger_) {
                logger_->logTarget(target_position, distance_method);
            }

        } catch (const std::exception& e) {
            ROS_ERROR("Exception in makePlan: %s", e.what());
        } catch (...) {
            ROS_ERROR("Unknown exception in makePlan");
        }
    }

    void Explore::odomCallback(const nav_msgs::Odometry::ConstPtr& msg) {
        geometry_msgs::Point p;
        p.x = msg->pose.pose.position.x;
        p.y = msg->pose.pose.position.y;
        if (logger_) logger_->logTrajectoryPoint(p, msg->header.stamp.toSec());
    }

  

    void Explore::reachedGoal(const actionlib::SimpleClientGoalState& status,
                            const move_base_msgs::MoveBaseResultConstPtr& result,
                            const geometry_msgs::Point& frontier_goal)
    {
        ROS_INFO("Reached goal with status: %s at (%.2f, %.2f)", 
                status.toString().c_str(), frontier_goal.x, frontier_goal.y);
        
        // Enhanced debugging for failed goals
        if (status == actionlib::SimpleClientGoalState::ABORTED) {
            ROS_WARN("Goal ABORTED - analyzing failure reason:");
            
            // Check if goal is in free space according to costmap
            unsigned int gx, gy;
            auto* costmap = costmap_client_.getCostmap();
            if (costmap && costmap->worldToMap(frontier_goal.x, frontier_goal.y, gx, gy)) {
                unsigned char cost = costmap->getCost(gx, gy);
                ROS_WARN("Goal costmap value: %u (0=lethal, 253=neutral, 254=free, 255=unknown)", cost);
                
                // Check surrounding area
                int free_neighbors = 0, total_neighbors = 0;
                for (int dx = -2; dx <= 2; dx++) {
                    for (int dy = -2; dy <= 2; dy++) {
                        if (costmap->worldToMap(frontier_goal.x + dx*0.1, frontier_goal.y + dy*0.1, gx, gy)) {
                            total_neighbors++;
                            if (costmap->getCost(gx, gy) >= costmap_2d::FREE_SPACE) {
                                free_neighbors++;
                            }
                        }
                    }
                }
                ROS_WARN("Goal neighborhood: %d/%d cells are free", free_neighbors, total_neighbors);
            }
            
            // Test if make_plan can find a path to this goal
            if (validate_with_makeplan_) {
                auto robot_pose = costmap_client_.getRobotPose();
                double path_length = dc_.computeDistanceUsingMakePlan(
                    robot_pose.position.x, robot_pose.position.y,
                    frontier_goal.x, frontier_goal.y);
                
                if (std::isfinite(path_length)) {
                    ROS_WARN("make_plan found path of %.2f m - move_base issue", path_length);
                } else {
                    ROS_WARN("make_plan also failed - no valid path exists");
                }
            }
            
            //frontier_blacklist_.push_back(frontier_goal);
            addToBlacklist(frontier_goal, BlacklistReason::GOAL_ABORTED, 0.7); 
            ROS_WARN("Added goal (%.2f, %.2f) to blacklist (total: %zu)", 
                    frontier_goal.x, frontier_goal.y, frontier_blacklist_.size());
        }
        
        scheduleReplan();
    }
    
    void Explore::start()
    {
        exploring_timer_.start();
        beginClock = clock();
        ROS_INFO("Start time: %s", to_string(beginClock).c_str());
    }

    void Explore::stop()
    {
        move_base_client_.cancelAllGoals();
        exploring_timer_.stop();
        endClock = clock();

        double elapsed_secs = double(endClock - beginClock) / CLOCKS_PER_SEC;
        ROS_INFO("Elapsed time: %s", to_string(elapsed_secs).c_str());

        // Save elapsed time to a file
        // std::ofstream outfile;
        // outfile.open("/home/user/exploration_time.txt", std::ios::out | std::ios::app); // Append mode
        // if (outfile.is_open()) {
        //   outfile << "Elapsed time: " << elapsed_secs << " seconds\n";
        //   outfile.close();
        //   ROS_INFO("Elapsed time saved to /home/user/exploration_time.txt");
        // } else {
        //   ROS_ERROR("Failed to open file for writing elapsed time.");
        // }
        
        
        // Publish exploration completion message
        std_msgs::Int32 msg;
        msg.data = 1; // 1 indicates completion
        exploration_finished_pub_.publish(msg);

        ROS_INFO("Exploration finished.");

        // Shut down the ROS node
        ros::shutdown();

    }

  // === Approach-point picker: sample a ring around target and choose the safest reachable point ===
    bool Explore::pickApproachPoint(const geometry_msgs::Point& target_pos,
                                    geometry_msgs::Point& out_approach,
                                    double radius_m,
                                    int samples) const
    {
        auto* cm = costmap_client_.getCostmap();
        if (!cm) return false;

        const double res = cm->getResolution();
        if (radius_m < 2*res) radius_m = 2*res;
        if (samples < 8) samples = 8;

        unsigned int gx, gy;
        if (!cm->worldToMap(target_pos.x, target_pos.y, gx, gy)) return false;

        double best_score = -1.0;
        geometry_msgs::Point best;
        for (int i=0; i<samples; ++i) {
            const double th = (2.0*M_PI * i) / samples;
            const double wx = target_pos.x + radius_m * std::cos(th);
            const double wy = target_pos.y + radius_m * std::sin(th);
            unsigned int x, y;
            if (!cm->worldToMap(wx, wy, x, y)) continue;

            unsigned char c = cm->getCost(x,y);
            if (c >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE && c != costmap_2d::NO_INFORMATION) continue;

            int free_cnt = 0;
            for (int dx=-1; dx<=1; ++dx)
            for (int dy=-1; dy<=1; ++dy) {
                int nx = (int)x+dx, ny = (int)y+dy;
                if (nx<0||ny<0||nx>=(int)cm->getSizeInCellsX()||ny>=(int)cm->getSizeInCellsY()) continue;
                unsigned char cc = cm->getCost(nx,ny);
                if (cc < costmap_2d::INSCRIBED_INFLATED_OBSTACLE || cc == costmap_2d::NO_INFORMATION) free_cnt++;
            }

            double score = free_cnt;
            if (score > best_score) { best_score = score; best = target_pos; best.x = wx; best.y = wy; }
        }
        if (best_score < 0) return false;
        out_approach = best;
        return true;
    }



    // Helper function to check if target should be validated
    bool Explore::shouldValidateTarget(double grid_len_m) const
    {
        // Check move_base state
        auto state = move_base_client_.getState();
        bool client_ready = (state == actionlib::SimpleClientGoalState::SUCCEEDED ||
                            state == actionlib::SimpleClientGoalState::ABORTED ||
                            state == actionlib::SimpleClientGoalState::RECALLED ||
                            state == actionlib::SimpleClientGoalState::PREEMPTED ||
                            state == actionlib::SimpleClientGoalState::LOST ||
                            state == actionlib::SimpleClientGoalState::PENDING);
        
        constexpr double kShortMeters = 0.3;
        return client_ready && std::isfinite(grid_len_m) && grid_len_m > kShortMeters;
    }

    bool Explore::preFlightCheckWithAstar(const geometry_msgs::Point& robot_pos,
                                     const geometry_msgs::Point& target_pos,
                                     double grid_len_m)
    {
        if (!std::isfinite(robot_pos.x) || !std::isfinite(robot_pos.y) ||
            !std::isfinite(target_pos.x) || !std::isfinite(target_pos.y)) {
            return false;
        }

        auto* cm = costmap_client_.getCostmap();
        if (!cm) {
            ROS_ERROR("Costmap is null in preFlightCheckWithAstar");
            return false;
        }

        unsigned int sx, sy, gx, gy;
        if (!cm->worldToMap(robot_pos.x, robot_pos.y, sx, sy)) {
            ROS_WARN("Robot position outside costmap bounds");
            return false;
        }
        if (!cm->worldToMap(target_pos.x, target_pos.y, gx, gy)) {
            ROS_WARN("Target position outside costmap bounds");
            // SPECIFIC REASON: Outside map bounds
            addToBlacklist(target_pos, BlacklistReason::OUTSIDE_MAP_BOUNDS, 1.0);
            scheduleReplan();
            return false;
        }

        // 1. Target wall check
        unsigned char target_cost = cm->getCost(gx, gy);
        if (target_cost >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
            ROS_WARN("Target is ON/NEAR wall (cost: %d >= %d) at (%u,%u)", 
                    target_cost, costmap_2d::INSCRIBED_INFLATED_OBSTACLE, gx, gy);
            
            if (!isNearPotentialDoorway(gx, gy, cm)) {
                ROS_WARN("Target blacklisted: on wall and not near doorway");
                // SPECIFIC REASON: Target on wall, not a doorway
                addToBlacklist(target_pos, BlacklistReason::TARGET_ON_WALL, 0.9);
                scheduleReplan();
                return false;
            } else {
                ROS_INFO("Target on wall but near potential doorway - allowing");
            }
        }

        // 2. A* pathfinding check
        const int max_exp = 75000;
        const int max_ms = 150;
        const int tol = 1;
        const bool allow_unknown = true;

        const bool ok = dc_.preflightAstarReachable((int)sx, (int)sy, (int)gx, (int)gy,
                                                allow_unknown, max_exp, max_ms, tol);
        
        if (!ok) {
            ROS_WARN("Pre-flight A* FAILED: (%u,%u) -> (%u,%u)", sx, sy, gx, gy);
            ROS_WARN("  Robot cost: %u, Target cost: %u", 
                    cm->getCost(sx, sy), cm->getCost(gx, gy));
            
            debugPathPoints(sx, sy, gx, gy, cm);
            
            // SPECIFIC REASON: A* pathfinding failed
            addToBlacklist(target_pos, BlacklistReason::PATHFINDING_FAILED, 0.8);
            scheduleReplan();
            return false;
        }
        
        ROS_DEBUG("Pre-flight A* SUCCESS: path found from (%u,%u) to (%u,%u)", 
                sx, sy, gx, gy);
        return true;
    }

    bool Explore::isNearPotentialDoorway(unsigned int gx, unsigned int gy, 
                                        costmap_2d::Costmap2D* cm) const
    {
        const int radius = 3;  // 3 hücre çapta kontrol
        int unknown_count = 0;
        int total_count = 0;
        
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                int nx = (int)gx + dx;
                int ny = (int)gy + dy;
                
                if (nx >= 0 && nx < (int)cm->getSizeInCellsX() && 
                    ny >= 0 && ny < (int)cm->getSizeInCellsY()) {
                    total_count++;
                    if (cm->getCost(nx, ny) == costmap_2d::NO_INFORMATION) {
                        unknown_count++;
                    }
                }
            }
        }
        
        // %25'ten fazla unknown varsa potansiyel kapı
        double unknown_ratio = (double)unknown_count / total_count;
        bool is_doorway = unknown_ratio > 0.25;
        
        ROS_DEBUG("Doorway check at (%u,%u): %d/%d unknown (%.1f%%) -> %s",
                gx, gy, unknown_count, total_count, unknown_ratio*100.0,
                is_doorway ? "DOORWAY" : "WALL");
        
        return is_doorway;
    }

    void Explore::debugPathPoints(unsigned int sx, unsigned int sy, 
                                unsigned int gx, unsigned int gy,
                                costmap_2d::Costmap2D* cm) const
    {
        // Düz çizgi üzerinde birkaç nokta kontrol et
        for (int i = 1; i <= 4; i++) {
            double t = (double)i / 5.0;  // 0.2, 0.4, 0.6, 0.8
            int mx = (int)(sx + t * (gx - sx));
            int my = (int)(sy + t * (gy - sy));
            
            if (mx >= 0 && mx < (int)cm->getSizeInCellsX() && 
                my >= 0 && my < (int)cm->getSizeInCellsY()) {
                unsigned char cost = cm->getCost(mx, my);
                ROS_WARN("  Path point %d/5: (%d,%d) cost=%u %s", 
                        i, mx, my, cost,
                        cost >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE ? "BLOCKED" : "ok");
            }
        }
    }

    // Helper function to validate target with make_plan
    bool Explore::validateTargetWithMakePlan(const geometry_msgs::Point& robot_pos,
                                            const geometry_msgs::Point& target_pos,
                                            double grid_len_m)
    {
        // Throttle repeated checks
        static geometry_msgs::Point last_checked_goal;
        static ros::Time last_checked_ts(0);
        
        const bool same_goal = (std::fabs(last_checked_goal.x - target_pos.x) < 1e-3) &&
                                (std::fabs(last_checked_goal.y - target_pos.y) < 1e-3);
        const bool throttle_ok = (ros::Time::now() - last_checked_ts) > ros::Duration(1.5);
        
        if (same_goal && !throttle_ok) {
            return true; // Skip validation, assume OK
        }
        
        last_checked_goal = target_pos;
        last_checked_ts = ros::Time::now();
        
        double plan_length = dc_.computeDistanceUsingMakePlan(
        robot_pos.x, robot_pos.y, target_pos.x, target_pos.y);
    
        if (!std::isfinite(plan_length)) {
            ROS_WARN("Blacklisting target: make_plan service failed");
            // SPECIFIC: Service call failed - no path found
            addToBlacklist(target_pos, BlacklistReason::MAKEPLAN_SERVICE_FAILED, 0.9);
            scheduleReplan();
            return false;
        }
        
        // Check for excessive detour
        constexpr double kRatioMax = 1.8;
        constexpr double kEps = 0.05;
        if (grid_len_m > kEps && plan_length > kRatioMax * grid_len_m + kEps) {
            ROS_WARN("Blacklisting target: excessive detour (%.2fm vs grid %.2fm)",
                    plan_length, grid_len_m);
            // SPECIFIC: Path exists but too long - inefficient route
            addToBlacklist(target_pos, BlacklistReason::EXCESSIVE_DETOUR, 0.7);
            scheduleReplan();
            return false;
        }
        
        return true;
    }

    // Helper function to send navigation goal
    bool Explore::sendNavigationGoal(const geometry_msgs::Point& target_position, double min_distance)
    {
        move_base_msgs::MoveBaseGoal goal;
        goal.target_pose.pose.position = target_position;
        goal.target_pose.pose.orientation.w = 1.0;
        goal.target_pose.header.frame_id = costmap_client_.getGlobalFrameID();
        goal.target_pose.header.stamp = ros::Time::now();

        // Progress tracking
        bool same_goal = (prev_goal_ == target_position);
        prev_goal_ = target_position;

        if (!same_goal || prev_distance_ > min_distance) {
            last_progress_ = ros::Time::now();
            prev_distance_ = min_distance;
        } else if (ros::Time::now() - last_progress_ > progress_timeout_) {
            //frontier_blacklist_.push_back(target_position);
            addToBlacklist(target_position, BlacklistReason::PROGRESS_TIMEOUT, 0.6); 
            ROS_DEBUG("Adding stalled goal to blacklist");
            scheduleReplan();
            return false;
        }

        // Send goal with callback
        move_base_client_.sendGoal(
            goal,
            [this, target_position](const actionlib::SimpleClientGoalState& status,
                                    const move_base_msgs::MoveBaseResultConstPtr& result) {
                reachedGoal(status, result, target_position);
            }
        );

        ROS_INFO("Sent goal (%.3f, %.3f), estimated distance: %.3f m",
                target_position.x, target_position.y, min_distance);
        
        return true;
    }

    // Helper function to schedule replanning
    void Explore::scheduleReplan()
    {
        oneshot_ = relative_nh_.createTimer(
            ros::Duration(0,0),
            [this](const ros::TimerEvent&) {
                try {
                    makePlan();
                } catch (const std::exception& e) {
                    ROS_ERROR("Exception in replan: %s", e.what());
                }
            },
            true);
    }

    // Helper function to publish completed maps
    void Explore::publishCompletedMaps()
    {
        const cv::Mat& cmat = search_.completedMapMat();
        const cv::Mat& gt_mat = search_.gtMapMat();
        
        if (!cmat.empty()) {
            search_.publishCompletedMap(cmat, completed_pub_, costmap_client_.getGlobalFrameID());
        }
        if (!gt_mat.empty()) {
            search_.publishCompletedMap(gt_mat, gt_map_pub_, costmap_client_.getGlobalFrameID());
        }
    }

    // Add parameter validation in Explore constructor
    bool Explore::validateParameters()
    {
        bool valid = true;
        
        // Validate numeric parameters
        if (planner_frequency_ <= 0.0 || planner_frequency_ > 10.0) {
            ROS_ERROR("Invalid planner_frequency: %.2f (should be 0.1-10.0)", planner_frequency_);
            planner_frequency_ = std::max(0.1, std::min(planner_frequency_, 10.0));  // Fixed
            valid = false;
        }
        
        if (timeout <= 0.0 || timeout > 3600.0) {
            ROS_ERROR("Invalid progress_timeout: %.2f (should be 1.0-3600.0)", timeout);
            timeout = std::max(1.0, std::min(timeout, 3600.0));  // Fixed
            valid = false;
        }
        
        if (potential_scale_ < 0.0) {
            ROS_ERROR("Invalid potential_scale: %.6f (should be >= 0)", potential_scale_);
            potential_scale_ = std::abs(potential_scale_);
            valid = false;
        }
        
        if (gain_scale_ < 0.0) {
            ROS_ERROR("Invalid gain_scale: %.6f (should be >= 0)", gain_scale_);
            gain_scale_ = std::abs(gain_scale_);
            valid = false;
        }
        
        if (min_frontier_size < 0.01 || min_frontier_size > 100.0) {
            ROS_ERROR("Invalid min_frontier_size: %.3f (should be 0.01-100.0)", min_frontier_size);
            min_frontier_size = std::max(0.01, std::min(min_frontier_size, 100.0));  // Fixed
            valid = false;
        }
        
        // Validate GT parameters if GT is enabled
        if (!gt_image_path_.empty()) {
            if (gt_resolution_ <= 0.0) {
                ROS_ERROR("Invalid gt_resolution: %.6f (should be > 0)", gt_resolution_);
                gt_resolution_ = 0.1; // Reasonable default
                valid = false;
            }
        }
        
        // Validate completion parameters
        if (rect_size_ <= 0 || rect_size_ > 500) {
            ROS_ERROR("Invalid rect_size: %d (should be 1-500)", rect_size_);
            rect_size_ = std::max(1, std::min(rect_size_, 500));  // Fixed
            valid = false;
        }
        
        return valid;
    }


    void Explore::addToBlacklist(const geometry_msgs::Point& goal, 
                            BlacklistReason reason, 
                            double confidence)
    {
        // Zaten blacklist'te var mı kontrol et
        for (auto& entry : frontier_blacklist_) {
            double distance = std::hypot(goal.x - entry.position.x, 
                                    goal.y - entry.position.y);
            if (distance < 0.8) {
                // Aynı goal, sadece retry sayısını artır ve sebep güncelle
                entry.retry_count++;
                entry.reason = reason;  // En son sebep
                entry.timestamp = ros::Time::now();
                entry.confidence = std::max(entry.confidence, confidence);
                
                ROS_WARN("Updated blacklist entry: (%.2f,%.2f) reason=%s retries=%d confidence=%.2f",
                        goal.x, goal.y, reasonToString(reason).c_str(), 
                        entry.retry_count, entry.confidence);
                return;
            }
        }
        
        // Yeni entry ekle
        frontier_blacklist_.emplace_back(goal, reason, confidence);
        ROS_WARN("Added to blacklist: (%.2f,%.2f) reason=%s confidence=%.2f",
                goal.x, goal.y, reasonToString(reason).c_str(), confidence);
    }

    bool Explore::goalOnBlacklist(const geometry_msgs::Point& goal)
    {
        const double tolerance_m = 0.8;
        
        for (const auto& entry : frontier_blacklist_) {
            if (!std::isfinite(entry.position.x) || !std::isfinite(entry.position.y)) {
                continue;
            }
            
            double distance = std::hypot(goal.x - entry.position.x, 
                                    goal.y - entry.position.y);
            if (distance < tolerance_m) {
                ROS_DEBUG("Goal (%.3f, %.3f) matches blacklisted goal, reason=%s, confidence=%.2f",
                        goal.x, goal.y, reasonToString(entry.reason).c_str(), entry.confidence);
                return true;
            }
        }
        
        return false;
    }

    // Sebep tabanlı akıllı temizleme
    bool Explore::shouldRetryBasedOnReason(const BlacklistEntry& entry) const
    {
        ros::Duration age = ros::Time::now() - entry.timestamp;
        
        switch (entry.reason) {
            case BlacklistReason::PATHFINDING_FAILED:
                return age.toSec() > 120.0;  // Path might change - retry soon
            case BlacklistReason::TARGET_ON_WALL:
                return age.toSec() > 300.0;  // Wall detection - medium confidence

            case BlacklistReason::OUTSIDE_MAP_BOUNDS:
                return age.toSec() > 600.0;  // Map might expand - wait longer
            case BlacklistReason::MAKEPLAN_SERVICE_FAILED:
                return age.toSec() > 150.0;  // Service issue - retry moderately soon

            case BlacklistReason::EXCESSIVE_DETOUR:
                return age.toSec() > 300.0;  // Inefficient path - wait longer for map changes
                            
            case BlacklistReason::PROGRESS_TIMEOUT:
                // İlerleme yok - robot sıkışmış olabilir, şimdi farklı olabilir
                return age.toSec() > 300.0;  // 5 dakika sonra tekrar dene
                
            case BlacklistReason::GOAL_ABORTED:
                // move_base abort - geçici problem olabilir
                return age.toSec() > 240.0;  // 4 dakika sonra tekrar dene
                
            case BlacklistReason::NEAR_WALL:
                // Duvar yakınında - düşük güvenilirlik, erken tekrar dene
                if (entry.confidence < 0.7) {
                    return age.toSec() > 120.0;  // Belirsizse 2 dakika
                }
                return age.toSec() > 600.0;  // Eminse 10 dakika
                
            case BlacklistReason::BEYOND_WALL_ARTIFACT:
                // Duvar ötesi - yüksek güvenilirlik, nadir tekrar dene
                return age.toSec() > 900.0;  // 15 dakika
                
            case BlacklistReason::ARTIFICIAL_AREA:
                // Completed map mismatch - çok nadir tekrar dene
                return age.toSec() > 1200.0; // 20 dakika
                
            case BlacklistReason::USER_DEFINED:
                // Kullanıcı tanımlı - konservatif
                return age.toSec() > 600.0;  // 10 dakika
                
            default:
                return age.toSec() > 300.0;  // Default 5 dakika
        }
    }

    void Explore::smartBlacklistCleanup()
    {
        if (frontier_blacklist_.empty()) return;
        
        auto it = frontier_blacklist_.begin();
        size_t removed_count = 0;
        
        while (it != frontier_blacklist_.end()) {
            if (shouldRetryBasedOnReason(*it)) {
                ROS_INFO("Removing from blacklist: (%.2f,%.2f) reason=%s age=%.1fs retries=%d",
                        it->position.x, it->position.y, 
                        reasonToString(it->reason).c_str(),
                        (ros::Time::now() - it->timestamp).toSec(),
                        it->retry_count);
                it = frontier_blacklist_.erase(it);
                removed_count++;
            } else {
                ++it;
            }
        }
        
        if (removed_count > 0) {
            ROS_INFO("Smart cleanup removed %zu entries from blacklist", removed_count);
        }
    }

    std::string Explore::reasonToString(BlacklistReason reason) const
    {
        switch (reason) {
            // Path planning failures
            case BlacklistReason::PREFLIGHT_FAILED: return "PREFLIGHT_FAILED";
            case BlacklistReason::PATHFINDING_FAILED: return "PATHFINDING_FAILED";
            case BlacklistReason::MAKEPLAN_SERVICE_FAILED: return "MAKEPLAN_SERVICE_FAILED";
            case BlacklistReason::EXCESSIVE_DETOUR: return "EXCESSIVE_DETOUR";
            
            // Goal location issues
            case BlacklistReason::TARGET_ON_WALL: return "TARGET_ON_WALL";
            case BlacklistReason::OUTSIDE_MAP_BOUNDS: return "OUTSIDE_MAP_BOUNDS";
            case BlacklistReason::BEYOND_WALL_ARTIFACT: return "BEYOND_WALL_ARTIFACT";
            case BlacklistReason::ARTIFICIAL_AREA: return "ARTIFICIAL_AREA";
            
            // Navigation failures
            case BlacklistReason::GOAL_ABORTED: return "GOAL_ABORTED";
            case BlacklistReason::PROGRESS_TIMEOUT: return "PROGRESS_TIMEOUT";
            
            // Quality filters
            case BlacklistReason::NEAR_WALL: return "NEAR_WALL";
            case BlacklistReason::TOO_SMALL: return "TOO_SMALL";
            
            case BlacklistReason::USER_DEFINED: return "USER_DEFINED";
            default: return "UNKNOWN";
        }
    }

    void Explore::publishCompletionMetrics(const std::vector<frontier_exploration::Frontier>& frontiers)
    {
        if (frontiers.empty()) return;
        
        // Create metrics message
        explore_lite::CompletionMetrics metrics;
        metrics.header.stamp = ros::Time::now();
        metrics.header.frame_id = costmap_client_.getGlobalFrameID();
        
        // Selected frontier (first one after sorting)
        const auto& selected = frontiers.front();
        metrics.selected_frontier_completion_known = selected.completion_known_score;
        metrics.selected_frontier_completion_obstacle = selected.completion_obstacle_score;
        metrics.selected_frontier_distance = selected.min_distance;
        metrics.selected_frontier_size = selected.size * costmap_client_.getCostmap()->getResolution();
        metrics.selected_frontier_final_cost = selected.cost;
        metrics.selected_frontier_position = selected.centroid;
        
        // Overall statistics
        metrics.total_frontiers_evaluated = static_cast<int32_t>(frontiers.size());
        
        double sum_known = 0.0, sum_obstacle = 0.0;
        for (const auto& f : frontiers) {
            sum_known += f.completion_known_score;
            sum_obstacle += f.completion_obstacle_score;
        }
        metrics.avg_completion_known_score = sum_known / frontiers.size();
        metrics.avg_completion_obstacle_score = sum_obstacle / frontiers.size();
        
        completion_metrics_pub_.publish(metrics);
    }

    SafeExperimentLogger::SafeExperimentLogger(const std::string& filename) {
        try {
            logger_ = std::make_unique<ExperimentLogger>(filename);
        } catch (const std::exception& e) {
            ROS_ERROR("Failed to create logger: %s", e.what());
        }
    }

    void SafeExperimentLogger::logTarget(const geometry_msgs::Point& target, const std::string& method) {
        std::lock_guard<std::mutex> lock(logger_mutex_);
        if (logger_) {
            try {
                logger_->logTarget(target, method);
            } catch (const std::exception& e) {
                ROS_WARN("Logging failed: %s", e.what());
            }
        }
    }

    void SafeExperimentLogger::logTrajectoryPoint(const geometry_msgs::Point& point, double timestamp) {
        std::lock_guard<std::mutex> lock(logger_mutex_);
        if (logger_) {
            try {
                logger_->logTrajectoryPoint(point, timestamp);
            } catch (const std::exception& e) {
                ROS_WARN("Trajectory logging failed: %s", e.what());
            }
        }
    }

    SafeExperimentLogger::~SafeExperimentLogger() {
        std::lock_guard<std::mutex> lock(logger_mutex_);
        logger_.reset();
    }


    


}  // namespace explore

int main(int argc, char** argv)
{
  ros::init(argc, argv, "explore");
  if (ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME,
                                     ros::console::levels::Debug)) {
    ros::console::notifyLoggerLevelsChanged();
  }
  explore::Explore explore;
  ros::spin();

  return 0;
}
