#include <explore/frontier_search.h>

#include <mutex>
#include <cmath>
#include <algorithm>

#include <costmap_2d/costmap_2d.h>
#include <geometry_msgs/Point.h>
#include <costmap_2d/cost_values.h>
#include <opencv2/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>
#include <tf2/LinearMath/Quaternion.h>

#include <explore/costmap_tools.h>   // nhood4, nhood8, nearestCell
#include <queue>




namespace frontier_exploration
{
    using costmap_2d::FREE_SPACE;
    using costmap_2d::NO_INFORMATION;

    static constexpr unsigned char OBSTACLE_U8 = 0;   // OpenCV mat
    static constexpr unsigned char UNKNOWN_U8  = 205;
    static constexpr unsigned char KNOWN_U8    = 254;




    // frontier_search.cpp (üst kısımlar)
    static inline int clampInt(int v, int lo, int hi) { return std::max(lo, std::min(v, hi)); }

    // Dünya -> resim pikseli (üstten sayan OpenCV satır dizini için flipY=true)
    static inline bool worldToImagePxPy(double wx, double wy,
                                        double origin_x, double origin_y, double res,
                                        int img_w, int img_h,
                                        int& px, int& py, bool flipY = true)
    {
    if (!(res > 0.0) || img_w <= 0 || img_h <= 0) return false;
    // Kolon (x): soldan sağa
    px = static_cast<int>( std::floor((wx - origin_x) / res) );
    // Satır (y): OpenCV yukarıdan aşağı saydığı için, haritanın alt kökenini üstten sayana çevirmek:
    if (flipY) {
        py = img_h - 1 - static_cast<int>( std::floor((wy - origin_y) / res) );
    } else {
        py = static_cast<int>( std::floor((wy - origin_y) / res) );
    }
    return true;
    }

    // Resimden merkez (cx,cy) etrafında patch_size x patch_size yama çıkar.
    // Resmin dışına taşan kısımlar UNKNOWN_U8 ile pad edilir.
    // dst her zaman patch_size x patch_size olarak döner. Mevcut veri hiç kesilemiyorsa yine pad döner (true).
    static inline bool cropWithPad(const cv::Mat& src,
                                int cx, int cy, int patch_size,
                                unsigned char pad_value,
                                cv::Mat& dst)
    {
    if (src.empty() || src.type() != CV_8UC1 || patch_size <= 0) return false;

    dst = cv::Mat(patch_size, patch_size, CV_8UC1, cv::Scalar(pad_value));

    const int half = patch_size / 2;
    const int x0 = cx - half;
    const int y0 = cy - half;
    const int x1 = x0 + patch_size;
    const int y1 = y0 + patch_size;

    // Kaynaktaki geçerli (kesişen) dikdörtgen
    const int sx0 = clampInt(x0, 0, src.cols);
    const int sy0 = clampInt(y0, 0, src.rows);
    const int sx1 = clampInt(x1, 0, src.cols);
    const int sy1 = clampInt(y1, 0, src.rows);

    const int copy_w = sx1 - sx0;
    const int copy_h = sy1 - sy0;
    if (copy_w <= 0 || copy_h <= 0) {
        // Tümü dışarıdaysa: tamamen pad’li yama döndür (geçerli ama boş kopya)
        return true;
    }

    cv::Rect roi_src(sx0, sy0, copy_w, copy_h);
    // Hedefte nereye yapıştıracağız?
    const int dx0 = sx0 - x0;
    const int dy0 = sy0 - y0;
    cv::Rect roi_dst(dx0, dy0, copy_w, copy_h);

    src(roi_src).copyTo(dst(roi_dst));
    return true;
    }



    FrontierSearch::FrontierSearch(costmap_2d::Costmap2D* costmap,
                                double potential_scale,
                                double gain_scale,
                                double min_frontier_size,
                                std::string distance_method,
                                int rect_size,
                                double completion_known_scale,
                                double completion_obstacle_scale)
    : costmap_(costmap)
    , potential_scale_(potential_scale)
    , gain_scale_(gain_scale)
    , min_frontier_size_(min_frontier_size)
    , distance_method_(std::move(distance_method))
    , rect_size_(rect_size)
    , completion_known_scale_(completion_known_scale)
    , completion_obstacle_scale_(completion_obstacle_scale)
    , base_min_frontier_size_(min_frontier_size)
    {
    
    distance_calculator_.setCostmap(costmap_);
    

    }



    bool FrontierSearch::isNewFrontierCell(unsigned int idx,
                                        const std::vector<bool>& frontier_flag)
    {
    // Check if cell is within map bounds and is not already marked.
    // We can combine these with an early return.
    if (idx >= size_x_ * size_y_ || frontier_flag[idx]) {
        return false;
    }

    // A frontier cell must be an unknown space.
    if (map_[idx] != NO_INFORMATION) {
        return false;
    }

    // It must be adjacent to a free space.
    // The loop returns true immediately upon finding a free neighbor.
    for (unsigned nbr : nhood4(idx, *costmap_)) {
        // Check if neighbor is within bounds and is a free space.
        if (nbr < size_x_ * size_y_ && map_[nbr] == FREE_SPACE) {
        return true;
        }
    }

    // If the loop finishes without finding a free neighbor, it's not a frontier.
    return false;
    }

    void FrontierSearch::setGtImage(const cv::Mat& gt) { gt_image_ = gt.clone(); }
    void FrontierSearch::setCompletedMap(const cv::Mat& cm) { completed_map_ = cm.clone(); }
    void FrontierSearch::setYamlOriginRes(double yaml_x, double yaml_y, double yaml_res) {
        yaml_x_ = yaml_x; yaml_y_ = yaml_y; yaml_res_ = yaml_res;
    }
    void FrontierSearch::setMapSaverOriginRes(double org_x, double org_y, double res,
                                int pgm_w, int pgm_h) {
    map_org_x_ = org_x; map_org_y_ = org_y; map_res_ = res;
    pgm_w_ = pgm_w; pgm_h_ = pgm_h;
    }
    void FrontierSearch::setRectangleSize(int r) { rect_size_ = std::max(1, r); }
    void FrontierSearch::setUseCompletedMap(int flag) { use_completed_map_ = flag; }
    void FrontierSearch::setCompletionScales(double known_scale, double obstacle_scale) { 
    completion_known_scale_ = known_scale; 
    completion_obstacle_scale_ = obstacle_scale;
    } 

    

    double FrontierSearch::calculateWallRatio(const geometry_msgs::Point& frontier_pos) const
    {
        if (!costmap_) return 1.0; // Safe default
        
        unsigned int fx, fy;
        if (!costmap_->worldToMap(frontier_pos.x, frontier_pos.y, fx, fy)) {
            return 1.0; // Outside map = treat as wall
        }
        
        const int check_radius = 2; // Check 2 cells around
        int wall_cells = 0;
        int total_cells = 0;
        
        for (int dx = -check_radius; dx <= check_radius; dx++) {
            for (int dy = -check_radius; dy <= check_radius; dy++) {
                int nx = (int)fx + dx;
                int ny = (int)fy + dy;
                
                if (nx >= 0 && nx < (int)costmap_->getSizeInCellsX() && 
                    ny >= 0 && ny < (int)costmap_->getSizeInCellsY()) {
                    
                    total_cells++;
                    unsigned char cost = costmap_->getCost(nx, ny);
                    
                    // Wall/obstacle check
                    if (cost >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                        wall_cells++;
                    }
                }
            }
        }
        
        if (total_cells == 0) return 1.0;
        return (double)wall_cells / total_cells;
    }


    bool FrontierSearch::isFrontierNearWall(const geometry_msgs::Point& frontier_pos) const
    {
        double wall_ratio = calculateWallRatio(frontier_pos);
        
        // Sert filtreleme: Çok yoğun duvar alanı
        if (wall_ratio > 0.6) {
            ROS_DEBUG("Hard filter: wall_ratio=%.2f > 0.6", wall_ratio);
            return true;
        }
        
        return false; // Penalty sistemi frontierCost()'ta halleder
    }


    std::vector<Frontier> FrontierSearch::searchFrom(geometry_msgs::Point position)
    {
        std::vector<Frontier> frontier_list;

        // Validate input position
        if (!std::isfinite(position.x) || !std::isfinite(position.y)) {
            ROS_ERROR("Robot position has invalid coordinates: (%.6f, %.6f)", 
                    position.x, position.y);
            return frontier_list;
        }

        if (!costmap_) {
            ROS_ERROR("Costmap is null in searchFrom");
            return frontier_list;
        }

        // Check if robot is within costmap bounds
        unsigned int mx_robot, my_robot;
        if (!costmap_->worldToMap(position.x, position.y, mx_robot, my_robot)) {
            ROS_ERROR("Robot out of costmap bounds (%.2f, %.2f)", position.x, position.y);
            return frontier_list;
        }

        ROS_DEBUG("Robot in map coords: (%u, %u)", mx_robot, my_robot);

        // Lock costmap for the entire search operation
        std::lock_guard<costmap_2d::Costmap2D::mutex_t> lock(*(costmap_->getMutex()));

        try {
            map_ = costmap_->getCharMap();
            size_x_ = costmap_->getSizeInCellsX();
            size_y_ = costmap_->getSizeInCellsY();

            if (size_x_ == 0 || size_y_ == 0 || !map_) {
                ROS_ERROR("Invalid costmap data: size=%ux%u, map_ptr=%p", 
                        size_x_, size_y_, static_cast<const void*>(map_));
                return frontier_list;
            }

            ROS_DEBUG("Map size: %u x %u", size_x_, size_y_);

            // FIXED: Less aggressive cache invalidation
            static unsigned int last_size_x = 0, last_size_y = 0;
            static bool first_run = true;
            
            if (last_size_x != size_x_ || last_size_y != size_y_) {
                if (!first_run) {
                    ROS_INFO("Costmap size changed: %ux%u -> %ux%u", last_size_x, last_size_y, size_x_, size_y_);
                    completed_map_ = cv::Mat();
                    distance_calculator_.invalidateDistanceField();
                }
                last_size_x = size_x_;
                last_size_y = size_y_;
                first_run = false;
            }

            // FIXED: Only initialize maps if really needed
            if (completed_map_.empty()) {
                seedCompletedMapFromCostmap();
                // Only seed from GT once
                static bool gt_seeded = false;
                if (!gt_seeded && !gt_image_.empty()) {
                    seedCompletedMapFromGT();
                    gt_seeded = true;
                }
            }

            const size_t map_size = static_cast<size_t>(size_x_) * static_cast<size_t>(size_y_);
            std::vector<bool> frontier_flag, visited_flag;
            
            try {
                frontier_flag.assign(map_size, false);
                visited_flag.assign(map_size, false);
            } catch (const std::bad_alloc& e) {
                ROS_ERROR("Failed to allocate search flags for %zu cells: %s", map_size, e.what());
                return frontier_list;
            }

            // Find starting position for BFS
            std::queue<unsigned int> bfs;
            unsigned int clear, pos = costmap_->getIndex(mx_robot, my_robot);
            
            if (pos >= map_size) {
                ROS_ERROR("Robot position index out of bounds: %u >= %zu", pos, map_size);
                return frontier_list;
            }

            if (nearestCell(clear, pos, FREE_SPACE, *costmap_)) {
                if (clear >= map_size) {
                    clear = pos;
                }
                bfs.push(clear);
            } else {
                bfs.push(pos);
            }
            
            visited_flag[bfs.front()] = true;

            // BFS exploration
            size_t expansions = 0;
            const size_t max_expansions = map_size * 2;
            const size_t max_frontiers = 500;  // FIXED: Reduced limit

            // FIXED: Collect frontiers with minimal filtering during BFS
            while (!bfs.empty() && expansions < max_expansions && frontier_list.size() < max_frontiers) {
                unsigned int idx = bfs.front();
                bfs.pop();
                ++expansions;

                if (idx >= map_size) continue;

                for (unsigned nbr : nhood4(idx, *costmap_)) {
                    if (nbr >= map_size) continue;

                    // Explore free neighbors
                    if (!visited_flag[nbr] && map_[nbr] == FREE_SPACE) {
                        visited_flag[nbr] = true;
                        bfs.push(nbr);
                    }
                    // Detect frontier cells
                    else if (isNewFrontierCell(nbr, frontier_flag)) {
                        frontier_flag[nbr] = true;
                        Frontier f = buildNewFrontier(nbr, pos, frontier_flag);

                        if (f.size == 0) continue;

                        const double frontier_size_m = f.size * costmap_->getResolution();

                        // FIXED: Only check size requirement during BFS
                        if (frontier_size_m >= min_frontier_size_) {
                            frontier_list.push_back(f);
                            ROS_DEBUG("Found frontier %zu: size=%.2f m, centroid=(%.2f, %.2f)",
                                    frontier_list.size(), frontier_size_m,
                                    f.centroid.x, f.centroid.y);
                        }
                    }
                }
            }

            ROS_INFO("BFS completed: %zu frontiers found", frontier_list.size());

        } catch (const std::exception& e) {
            ROS_ERROR("Exception in frontier search: %s", e.what());
            return std::vector<Frontier>{};
        }

        if (frontier_list.empty()) {
            ROS_WARN("No frontiers found");
            return frontier_list;
        }

        // FIXED: MINIMAL post-processing - only apply basic filters
        std::vector<Frontier> filtered_frontiers;
        
        for (const auto& f : frontier_list) {
            bool accept = true;
            
            // FIXED: Only apply wall filter if very strict (>80% walls)
            double wall_ratio = calculateWallRatio(f.centroid);
            if (wall_ratio > 0.8) {
                ROS_DEBUG("Filtered high-wall frontier (%.1f%% walls)", wall_ratio * 100);
                accept = false;
            }
            
            // FIXED: Skip other aggressive filters that cause instability
            
            if (accept) {
                filtered_frontiers.push_back(f);
            }
        }

        if (filtered_frontiers.empty()) {
            // FIXED: If all filtered, return some frontiers anyway
            ROS_WARN("All frontiers filtered - returning best candidates");
            
            // Return up to 5 best frontiers by size
            std::partial_sort(frontier_list.begin(), 
                            frontier_list.begin() + std::min<size_t>(5, frontier_list.size()),
                            frontier_list.end(),
                            [](const Frontier& a, const Frontier& b) {
                                return a.size > b.size;  // Larger frontiers first
                            });
            
            filtered_frontiers.assign(frontier_list.begin(), 
                                    frontier_list.begin() + std::min<size_t>(5, frontier_list.size()));
        }

        ROS_INFO("After filtering: %zu frontiers remain", filtered_frontiers.size());

        // Process completion scores safely
        try {
            processCompletionScores(filtered_frontiers);
        } catch (const std::exception& e) {
            ROS_WARN("Completion score processing failed: %s", e.what());
            for (auto& f : filtered_frontiers) {
                f.completion_known_score = 0.0;
                f.completion_obstacle_score = 0.0;
            }
        }

        // Distance calculations
        if (!calculateFrontierDistances(filtered_frontiers, mx_robot, my_robot)) {
            ROS_WARN("Distance calculation failed - using fallback");
            for (auto& f : filtered_frontiers) {
                if (!std::isfinite(f.min_distance)) {
                    // FIXED: Fallback to Euclidean distance
                    double robot_x, robot_y;
                    costmap_->mapToWorld(mx_robot, my_robot, robot_x, robot_y);
                    f.min_distance = distance_calculator_.euclideanDistance(
                        f.centroid.x, f.centroid.y, robot_x, robot_y);
                }
            }
        }

        // Final scoring and sorting
        try {
            for (auto& f : filtered_frontiers) {
                f.cost = frontierCost(f);
                if (!std::isfinite(f.cost)) {
                    f.cost = std::numeric_limits<double>::infinity();
                }
            }

            std::sort(filtered_frontiers.begin(), filtered_frontiers.end(),
                    [](const Frontier& a, const Frontier& b) { 
                        return a.cost < b.cost; 
                    });
                    
        } catch (const std::exception& e) {
            ROS_ERROR("Exception in frontier sorting: %s", e.what());
        }

        ROS_INFO("FrontierSearch completed: %zu frontiers returned", filtered_frontiers.size());
        return filtered_frontiers;
    }

    bool FrontierSearch::isGoalReachable(const geometry_msgs::Point& goal, 
                                        const geometry_msgs::Point& start) const
    {
        if (!costmap_) {
            ROS_WARN("isGoalReachable: costmap is null");
            return false;
        }
        
        unsigned int gx, gy, sx, sy;
        if (!costmap_->worldToMap(goal.x, goal.y, gx, gy)) {
            ROS_WARN("Goal (%.2f, %.2f) is outside costmap bounds", goal.x, goal.y);
            return false;
        }
        if (!costmap_->worldToMap(start.x, start.y, sx, sy)) {
            ROS_WARN("Start (%.2f, %.2f) is outside costmap bounds", start.x, start.y);
            return false;
        }
        
        // Check if goal itself is in free space
        unsigned char goal_cost = costmap_->getCost(gx, gy);
        if (goal_cost >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
            ROS_WARN("Goal (%.2f, %.2f) has cost %u >= %u (blocked)", 
                    goal.x, goal.y, goal_cost, costmap_2d::INSCRIBED_INFLATED_OBSTACLE);
            return false;
        }
        
        // REDUCED clearance check - was too strict
        const int clearance_cells = 1; // Reduced from 3 to 1
        int blocked_cells = 0, total_cells = 0;
        
        for (int dx = -clearance_cells; dx <= clearance_cells; dx++) {
            for (int dy = -clearance_cells; dy <= clearance_cells; dy++) {
                int cx = (int)gx + dx;
                int cy = (int)gy + dy;
                
                // Skip out of bounds cells instead of rejecting entire goal
                if (cx < 0 || cx >= (int)costmap_->getSizeInCellsX() || 
                    cy < 0 || cy >= (int)costmap_->getSizeInCellsY()) {
                    continue; 
                }
                
                total_cells++;
                unsigned char cost = costmap_->getCost((unsigned int)cx, (unsigned int)cy);
                if (cost >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                    blocked_cells++;
                }
            }
        }
        
        // Allow goal if majority of surrounding cells are free
        double blocked_ratio = total_cells > 0 ? (double)blocked_cells / total_cells : 0.0;
        bool reachable = (blocked_ratio < 0.5); // Allow if less than 50% of area is blocked
        
        ROS_WARN("Goal (%.2f, %.2f): %d/%d cells blocked (%.1f%%) - %s", 
                goal.x, goal.y, blocked_cells, total_cells, blocked_ratio*100.0,
                reachable ? "REACHABLE" : "BLOCKED");
        
        return reachable;
    }

    // Helper function to process completion scores
    void FrontierSearch::processCompletionScores(std::vector<Frontier>& frontier_list)
    {
        if (completion_known_scale_ <= 0.0 && completion_obstacle_scale_ <= 0.0 && use_completed_map_ != 1) {
            // Skip processing if not needed
            for (auto& f : frontier_list) {
                f.completion_known_score = 0.0;
                f.completion_obstacle_score = 0.0;
            }
            return;
        }

        for (auto& f : frontier_list) {
            f.completion_known_score = 0.0;
            f.completion_obstacle_score = 0.0;

            try {
                cv::Mat gt_patch, cur_patch;
                bool res = getCompletedRegionAroundFrontier(f.centroid.x, f.centroid.y, gt_patch, cur_patch);

                if (res && (completion_known_scale_ > 0.0 || completion_obstacle_scale_ > 0.0)) {
                    patchAgreementScore(gt_patch, cur_patch, 
                                    &f.completion_known_score, 
                                    &f.completion_obstacle_score);
                }
            } catch (const std::exception& e) {
                ROS_WARN("Exception processing completion scores for frontier at (%.2f, %.2f): %s",
                        f.centroid.x, f.centroid.y, e.what());
            }
        }
    }

    // Helper function to calculate frontier distances
    bool FrontierSearch::calculateFrontierDistances(std::vector<Frontier>& frontier_list,
                                                unsigned int mx_robot, unsigned int my_robot)
    {
        const bool use_dfield = (distance_method_ == "dfield");
        const bool use_mga = (distance_method_ == "multi_astar" || 
                            distance_method_ == "astar_completion" ||
                            distance_method_ == "dijkstra");

        try {
            if (use_dfield) {
                return calculateDistancesUsingField(frontier_list, mx_robot, my_robot);
            } else if (use_mga) {
                return calculateDistancesUsingMultiGoal(frontier_list, mx_robot, my_robot);
            } else if (distance_method_ == "euclidean") {
                return calculateDistancesEuclidean(frontier_list, mx_robot, my_robot);
            } else {
                ROS_ERROR("Unknown distance method: %s", distance_method_.c_str());
                return false;
            }
        } catch (const std::exception& e) {
            ROS_ERROR("Exception in distance calculation: %s", e.what());
            return false;
        }
    }

    bool FrontierSearch::calculateDistancesEuclidean(std::vector<Frontier>& frontier_list,
                                                unsigned int mx_robot, unsigned int my_robot)
    {
        double robot_x, robot_y;
        costmap_->mapToWorld(mx_robot, my_robot, robot_x, robot_y);
        
        for (auto& f : frontier_list) {
            f.min_distance = distance_calculator_.euclideanDistance(
                f.centroid.x, f.centroid.y, robot_x, robot_y);
            
            if (!std::isfinite(f.min_distance) || f.min_distance < 0.0) {
                ROS_WARN("Invalid Euclidean distance computed for frontier at (%.2f, %.2f)",
                        f.centroid.x, f.centroid.y);
                f.min_distance = std::numeric_limits<double>::infinity();
            }
        }
        return true;
    }

    bool FrontierSearch::calculateDistancesUsingMultiGoal(std::vector<Frontier>& frontier_list,
                                                        unsigned int mx_robot, unsigned int my_robot)
    {
        // Build goal positions with validation
        std::vector<std::pair<int,int>> goals_xy;
        goals_xy.reserve(frontier_list.size());
        
        for (const auto& frontier : frontier_list) {
            unsigned int gx, gy;
            if (costmap_->worldToMap(frontier.centroid.x, frontier.centroid.y, gx, gy)) {
                goals_xy.emplace_back(static_cast<int>(gx), static_cast<int>(gy));
            } else {
                goals_xy.emplace_back(-1, -1); // Invalid marker
            }
        }

        const double resolution = costmap_->getResolution();
        if (resolution <= 0.0) {
            ROS_ERROR("Invalid costmap resolution: %.6f", resolution);
            return false;
        }

        try {
            if (distance_method_ == "astar_completion") {
                return calculateDistancesAstarCompletion(frontier_list, goals_xy, mx_robot, my_robot, resolution);
            } else {
                std::vector<double> distances;
                
                if (distance_method_ == "multi_astar") {
                    distance_calculator_.multiGoalAstar(static_cast<int>(mx_robot), static_cast<int>(my_robot),
                                                    goals_xy, distances, true, 1.0);
                } else {
                    distance_calculator_.multiGoalDijkstra(static_cast<int>(mx_robot), static_cast<int>(my_robot),
                                                        goals_xy, distances, true);
                }

                // Convert to meters and assign
                for (size_t i = 0; i < frontier_list.size(); ++i) {
                    if (i < distances.size() && std::isfinite(distances[i]) && distances[i] >= 0.0) {
                        frontier_list[i].min_distance = distances[i] * resolution;
                    } else {
                        frontier_list[i].min_distance = std::numeric_limits<double>::infinity();
                    }
                }
                return true;
            }
        } catch (const std::exception& e) {
            ROS_ERROR("Exception in multi-goal distance calculation: %s", e.what());
            return false;
        }
    }


    bool FrontierSearch::calculateDistancesAstarCompletion(
        std::vector<Frontier>& frontier_list,
        const std::vector<std::pair<int,int>>& goals_xy,
        unsigned int mx_robot, unsigned int my_robot,
        double resolution)
    {
        // EMERGENCY FIX: Always try Dijkstra fallback first
        ROS_WARN("Using Dijkstra fallback for distance calculation due to A* completion issues");
        
        std::vector<std::pair<int,int>> goals_valid;
        std::vector<size_t> map_back;
        
        for (size_t i = 0; i < goals_xy.size(); ++i) {
            if (goals_xy[i].first >= 0 && goals_xy[i].second >= 0) {
                goals_valid.push_back(goals_xy[i]);
                map_back.push_back(i);
            }
        }

        if (goals_valid.empty()) {
            ROS_ERROR("No valid goals for distance calculation");
            return false;
        }

        std::vector<double> distances_tmp(goals_valid.size(), std::numeric_limits<double>::infinity());

        try {
            // Use reliable Dijkstra instead of problematic A* completion
            distance_calculator_.multiGoalDijkstra(
                static_cast<int>(mx_robot), static_cast<int>(my_robot),
                goals_valid, distances_tmp, true);
            
            // Convert cells to meters and write back
            for (size_t j = 0; j < map_back.size(); ++j) {
                if (j < distances_tmp.size() && map_back[j] < frontier_list.size()) {
                    double distance_meters = distances_tmp[j] * resolution;
                    if (std::isfinite(distance_meters) && distance_meters >= 0.0) {
                        frontier_list[map_back[j]].min_distance = distance_meters;
                    } else {
                        // Final fallback: Euclidean distance
                        double robot_x, robot_y;
                        costmap_->mapToWorld(mx_robot, my_robot, robot_x, robot_y);
                        frontier_list[map_back[j]].min_distance = distance_calculator_.euclideanDistance(
                            frontier_list[map_back[j]].centroid.x, frontier_list[map_back[j]].centroid.y,
                            robot_x, robot_y);
                    }
                }
            }
            
            ROS_INFO("Dijkstra fallback successful for %zu frontiers", frontier_list.size());
            return true;
            
        } catch (const std::exception& e) {
            ROS_ERROR("Dijkstra fallback also failed: %s", e.what());
            
            // Ultimate fallback: Euclidean distances
            double robot_x, robot_y;
            costmap_->mapToWorld(mx_robot, my_robot, robot_x, robot_y);
            
            for (auto& f : frontier_list) {
                f.min_distance = distance_calculator_.euclideanDistance(
                    f.centroid.x, f.centroid.y, robot_x, robot_y);
            }
            
            ROS_WARN("Using Euclidean distances as final fallback");
            return true;
        }
    }

    // Helper functions for different distance calculation methods
    bool FrontierSearch::calculateDistancesUsingField(std::vector<Frontier>& frontier_list,
                                                    unsigned int mx_robot, unsigned int my_robot)
    {
        ROS_DEBUG("Using distance field method");
        
        try {
            distance_calculator_.ensureDistanceField(static_cast<int>(mx_robot), 
                                                static_cast<int>(my_robot), true);

            const double resolution = costmap_->getResolution();
            if (resolution <= 0.0) {
                ROS_ERROR("Invalid costmap resolution: %.6f", resolution);
                return false;
            }

            for (auto& f : frontier_list) {
                f.min_distance = std::numeric_limits<double>::infinity();
                
                // Try centroid first
                unsigned int gx, gy;
                if (costmap_->worldToMap(f.centroid.x, f.centroid.y, gx, gy)) {
                    double d_cells = distance_calculator_.distToCell(static_cast<int>(gx), static_cast<int>(gy));
                    if (std::isfinite(d_cells) && d_cells >= 0.0) {
                        f.min_distance = d_cells * resolution;
                        continue;
                    }
                }

                // Fallback to checking all frontier points
                for (const auto& point : f.points) {
                    if (costmap_->worldToMap(point.x, point.y, gx, gy)) {
                        double d_cells = distance_calculator_.distToCell(static_cast<int>(gx), static_cast<int>(gy));
                        if (std::isfinite(d_cells) && d_cells >= 0.0) {
                            double d_meters = d_cells * resolution;
                            if (d_meters < f.min_distance) {
                                f.min_distance = d_meters;
                            }
                        }
                    }
                }
            }
            return true;
        } catch (const std::exception& e) {
            ROS_ERROR("Exception in distance field calculation: %s", e.what());
            return false;
        }
    }

   
    Frontier FrontierSearch::buildNewFrontier(unsigned int initial_cell,
                                            unsigned int reference,
                                            std::vector<bool>& frontier_flag)
    {
        const size_t map_size = size_x_ * size_y_;
        
        // Comprehensive input validation
        if (initial_cell >= map_size || reference >= map_size) {
            ROS_WARN("Invalid cell indices: initial=%u, reference=%u, map_size=%zu", 
                    initial_cell, reference, map_size);
            return {};
        }

        if (!costmap_) {
            ROS_ERROR("Costmap is null in buildNewFrontier");
            return {};
        }

        Frontier output;
        output.size = 0;
        output.min_distance = std::numeric_limits<double>::infinity();
        output.map_resolution = costmap_->getResolution();
        output.centroid.x = 0.0;
        output.centroid.y = 0.0;
        output.completion_known_score = 0.0;
        output.completion_obstacle_score = 0.0;

        // Validate resolution
        if (output.map_resolution <= 0.0) {
            ROS_ERROR("Invalid map resolution: %.6f", output.map_resolution);
            return {};
        }

        // Record initial contact point
        unsigned int ix, iy;
        costmap_->indexToCells(initial_cell, ix, iy);
        costmap_->mapToWorld(ix, iy, output.initial.x, output.initial.y);

        // Get reference position
        unsigned int rx, ry;
        double reference_x, reference_y;
        costmap_->indexToCells(reference, rx, ry);
        costmap_->mapToWorld(rx, ry, reference_x, reference_y);

        // BFS to collect frontier region
        std::queue<unsigned int> bfs;
        bfs.push(initial_cell);

        double best_middle_d2 = std::numeric_limits<double>::infinity();
        const size_t max_frontier_size = 10000; // Prevent excessive memory usage

        try {
            while (!bfs.empty() && output.size < max_frontier_size) {
                unsigned int idx = bfs.front();
                bfs.pop();

                for (unsigned int nbr : nhood8(idx, *costmap_)) {
                    if (nbr >= map_size) {
                        ROS_WARN("Neighbor index out of bounds: %u >= %zu", nbr, map_size);
                        continue;
                    }

                    if (isNewFrontierCell(nbr, frontier_flag)) {
                        frontier_flag[nbr] = true;

                        unsigned int mx, my;
                        double wx, wy;
                        costmap_->indexToCells(nbr, mx, my);
                        costmap_->mapToWorld(mx, my, wx, wy);

                        // Validate world coordinates
                        if (!std::isfinite(wx) || !std::isfinite(wy)) {
                            ROS_WARN("Invalid world coordinates: (%.6f, %.6f)", wx, wy);
                            continue;
                        }

                        // Add point to frontier
                        geometry_msgs::Point p;
                        p.x = wx;
                        p.y = wy;
                        p.z = 0.0;
                        output.points.push_back(p);
                        output.size++;

                        // Update centroid accumulation
                        output.centroid.x += wx;
                        output.centroid.y += wy;

                        // Update middle point (closest to reference)
                        const double dx = wx - reference_x;
                        const double dy = wy - reference_y;
                        const double d2 = dx * dx + dy * dy;
                        
                        if (d2 < best_middle_d2) {
                            best_middle_d2 = d2;
                            output.middle.x = wx;
                            output.middle.y = wy;
                            output.middle.z = 0.0;
                        }

                        bfs.push(nbr);
                    }
                }
            }
        } catch (const std::exception& e) {
            ROS_ERROR("Exception in buildNewFrontier: %s", e.what());
            return {};
        }

        // Validate collected frontier
        if (output.size == 0) {
            ROS_DEBUG("No frontier points collected");
            return {};
        }

        if (output.size >= max_frontier_size) {
            ROS_WARN("Frontier size limit reached: %zu", max_frontier_size);
        }

        // Compute and validate centroid
        const double size_d = static_cast<double>(output.size);
        const double cx = output.centroid.x / size_d;
        const double cy = output.centroid.y / size_d;
        
        if (!std::isfinite(cx) || !std::isfinite(cy)) {
            ROS_WARN("Invalid centroid computed: (%.6f, %.6f)", cx, cy);
            return {};
        }

        // Snap centroid to nearest actual frontier point
        geometry_msgs::Point nearest_to_mean;
        double best_mean_d2 = std::numeric_limits<double>::infinity();
        
        for (const auto& point : output.points) {
            const double dx = point.x - cx;
            const double dy = point.y - cy;
            const double d2 = dx * dx + dy * dy;
            
            if (d2 < best_mean_d2) {
                best_mean_d2 = d2;
                nearest_to_mean = point;
            }
        }
        
        output.centroid = nearest_to_mean;
        
        // Ensure middle point is valid
        if (!std::isfinite(output.middle.x) || !std::isfinite(output.middle.y)) {
            output.middle = output.centroid; // Fallback to centroid
        }

        return output;
    }



    double FrontierSearch::frontierCost(const Frontier& f)
    {
        if (!std::isfinite(f.min_distance)) {
            ROS_WARN("Frontier at (%.2f, %.2f) has invalid distance → ignoring",
                    f.centroid.x, f.centroid.y);
        return std::numeric_limits<double>::infinity();
        }

        const double distance_m = f.min_distance;                        // meters
        const double size_m     = f.size * costmap_->getResolution();    // meters

        // base: + distance − size
        double cost = (potential_scale_ * distance_m) - (gain_scale_ * size_m);

        // --- scale completion by physical patch side length (meters) ---
        const double patch_side_m = static_cast<double>(rect_size_) * map_res_;
        const double known_term   = completion_known_scale_    * f.completion_known_score;
        const double obst_term    = completion_obstacle_scale_ * f.completion_obstacle_score;

        cost -= known_term;  // reward: more “correct-known” lowers cost
        cost += obst_term;   // penalty: more “correct-obstacle” raises cost

        ROS_WARN("distance_m=%.2f, potential_scale_=%.2f, potential_scale_ * distance_m=%.2f",
                    distance_m, potential_scale_, potential_scale_ * distance_m);
        
        ROS_WARN("size_m=%.2f, gain_scale_=%.2f, gain_scale_ * size_m=%.2f",
                    size_m, gain_scale_, gain_scale_ * size_m);
        
        ROS_WARN("f.completion_known_score=%.2f, completion_known_scale_=%.2f,known_term=%.2f",
                    f.completion_known_score, completion_known_scale_, known_term);

        ROS_WARN("f.completion_obstacle_score=%.2f, completion_obstacle_scale_=%.2f, obst_term=%.2f",
                    f.completion_obstacle_score, completion_obstacle_scale_, obst_term);

        double wall_ratio = calculateWallRatio(f.centroid);
        if (wall_ratio > 0.3) {
            double penalty = 20.0 * (wall_ratio - 0.3); // 0.3 üstü için penalty
            cost += penalty;
        }

        return cost;
    }

    bool FrontierSearch::getCompletedRegionAroundFrontier(double frontier_x,
                                                        double frontier_y,
                                                        cv::Mat& out_gt,
                                                        cv::Mat& out_cur)
    {
        if (!costmap_ || rect_size_ <= 0) return false;

        // --- Build a live costmap image (0/205/254) in OpenCV coords (top-left origin)
        const int W = (int)costmap_->getSizeInCellsX();
        const int H = (int)costmap_->getSizeInCellsY();
        cv::Mat live_cm(H, W, CV_8UC1, cv::Scalar(UNKNOWN_U8));   // current map (for UNKNOWN mask)

        {
            const unsigned char* raw = costmap_->getCharMap();
            for (int y = 0; y < H; ++y) {
            for (int x = 0; x < W; ++x) {
                const unsigned char c = raw[y*W + x];
                unsigned char v = UNKNOWN_U8;
                if      (c == costmap_2d::FREE_SPACE)     v = KNOWN_U8;
                else if (c != costmap_2d::NO_INFORMATION) v = OBSTACLE_U8;
                live_cm.at<uchar>(H - 1 - y, x) = v;  // flip into image coords
            }
            }
        }

        // world -> image helper (OpenCV top-left origin, vertical flip)
        auto w2i = [](double wx, double wy, double ox, double oy, double res,
                        int W, int H, int& px, int& py)->bool {
            if (!(res > 0.0) || W<=0 || H<=0) return false;
            px = (int)std::floor((wx - ox) / res);
            py = H - 1 - (int)std::floor((wy - oy) / res);
            return true;
        };

        const int P    = rect_size_;
        const int half = P/2;

        // ---- Center pixels in *image coords* for GT and for costmap/completed_map_
        int cx=0, cy=0; // costmap/completed_map_ center (they share grid)
        if (!w2i(frontier_x, frontier_y, map_org_x_, map_org_y_, map_res_, W, H, cx, cy)) return false;

        int gx=0, gy=0; // GT image center (its own origin/res)
        bool have_gt = (!gt_image_.empty() && yaml_res_ > 0.0 &&
                        w2i(frontier_x, frontier_y, yaml_x_, yaml_y_, yaml_res_,
                            gt_image_.cols, gt_image_.rows, gx, gy));

        // ---- Build ROIs (intersection with image bounds) on costmap grid
        int x0_cm = std::max(0, cx - half);
        int y0_cm = std::max(0, cy - half);
        int x1_cm = std::min(W, cx + half);
        int y1_cm = std::min(H, cy + half);
        if (x1_cm <= x0_cm || y1_cm <= y0_cm) return false;
        cv::Rect roi_cm(x0_cm, y0_cm, x1_cm - x0_cm, y1_cm - y0_cm);

        // ---- GT ROI (may be smaller if GT doesn’t fully cover)
        cv::Rect roi_gt; bool roi_gt_ok = false;
        if (have_gt) {
            int x0_gt = std::max(0, gx - half);
            int y0_gt = std::max(0, gy - half);
            int x1_gt = std::min(gt_image_.cols, gx + half);
            int y1_gt = std::min(gt_image_.rows, gy + half);
            if (x1_gt > x0_gt && y1_gt > y0_gt) {
            roi_gt = cv::Rect(x0_gt, y0_gt, x1_gt - x0_gt, y1_gt - y0_gt);
            roi_gt_ok = true;
            }
        }

        // ---- Force both ROIs to the same width/height
        if (!roi_gt_ok) {
            // No GT → just synthesize an UNKNOWN patch of the same size as roi_cm
            out_gt = cv::Mat(roi_cm.height, roi_cm.width, CV_8UC1, cv::Scalar(UNKNOWN_U8));
        } else {
            // match common size
            int w = std::min(roi_cm.width,  roi_gt.width);
            int h = std::min(roi_cm.height, roi_gt.height);
            if (w <= 0 || h <= 0) return false;

            roi_cm.width = w; roi_cm.height = h;
            roi_gt.width = w; roi_gt.height = h;

            out_gt = gt_image_(roi_gt).clone();
        }

        // Current patch from *live* costmap for UNKNOWN mask (same size as roi_cm)
        out_cur = live_cm(roi_cm).clone();

        // ---- Paste into completed_map_ (masked by UNKNOWN in *current* map)
        if (use_completed_map_ == 1 && !completed_map_.empty()) {
            if (roi_cm.x >= 0 && roi_cm.y >= 0 &&
                roi_cm.x + roi_cm.width  <= completed_map_.cols &&
                roi_cm.y + roi_cm.height <= completed_map_.rows &&
                out_gt.size() == roi_cm.size() && out_cur.size() == roi_cm.size() &&
                out_gt.type() == CV_8UC1 && out_cur.type() == CV_8UC1)
            {
            // 255 where current map is UNKNOWN
            cv::Mat mask = (out_cur == UNKNOWN_U8);
            const int pasted = cv::countNonZero(mask);
            if (pasted > 0) {
                out_gt.copyTo(completed_map_(roi_cm), mask);  // masked paste
                ROS_DEBUG("completed_map_: pasted %d px at ROI x=%d y=%d w=%d h=%d",
                        pasted, roi_cm.x, roi_cm.y, roi_cm.width, roi_cm.height);
            } else {
                ROS_DEBUG("completed_map_: ROI had 0 unknown px, paste skipped.");
            }
            } else {
            ROS_DEBUG("completed_map_ paste skipped (shape/type mismatch).");
            }
        }

        return true;
    }


    double FrontierSearch::patchAgreementScore(const cv::Mat& gt, const cv::Mat& cur,
                                            double* out_known_score, double* out_obst_score)
    {
        if (out_known_score) *out_known_score = 0.0;
        if (out_obst_score)  *out_obst_score  = 0.0;

        if (gt.empty() || cur.empty() || gt.type()!=CV_8UC1 || cur.type()!=CV_8UC1 || gt.size()!=cur.size())
            return 0.0;

        // Enhanced debug analysis
        cv::Mat unk = (cur == UNKNOWN_U8);
        const int N = cv::countNonZero(unk);
        
        if (N == 0) {
            ROS_WARN("Patch fully known - no completion potential");
            return 0.0;
        }

        const int free_gain = cv::countNonZero((gt == KNOWN_U8) & unk);
        const int obst_gain = cv::countNonZero((gt == OBSTACLE_U8) & unk);
        const int total_pixels = gt.rows * gt.cols;
        
        // Analyze what's currently known vs unknown
        const int currently_free = cv::countNonZero(cur == KNOWN_U8);
        const int currently_obst = cv::countNonZero(cur == OBSTACLE_U8);
        const int currently_unk = cv::countNonZero(cur == UNKNOWN_U8);
        
        // Analyze GT content
        const int gt_free_total = cv::countNonZero(gt == KNOWN_U8);
        const int gt_obst_total = cv::countNonZero(gt == OBSTACLE_U8);
        const int gt_unk_total = cv::countNonZero(gt == UNKNOWN_U8);

        static int patch_debug_count = 0;
        if (patch_debug_count < 5) {  // Debug first 5 patches
            patch_debug_count++;
            ROS_WARN("=== PATCH ANALYSIS %d ===", patch_debug_count);
            ROS_WARN("Patch size: %dx%d (%d pixels)", gt.cols, gt.rows, total_pixels);
            ROS_WARN("Current map: free=%d (%.1f%%), obst=%d (%.1f%%), unk=%d (%.1f%%)",
                    currently_free, 100.0*currently_free/total_pixels,
                    currently_obst, 100.0*currently_obst/total_pixels,
                    currently_unk, 100.0*currently_unk/total_pixels);
            ROS_WARN("GT content: free=%d (%.1f%%), obst=%d (%.1f%%), unk=%d (%.1f%%)",
                    gt_free_total, 100.0*gt_free_total/total_pixels,
                    gt_obst_total, 100.0*gt_obst_total/total_pixels,
                    gt_unk_total, 100.0*gt_unk_total/total_pixels);
            ROS_WARN("Completion potential: unknown_px=%d, would_be_free=%d (%.1f%%), would_be_obst=%d (%.1f%%)",
                    N, free_gain, 100.0*free_gain/N, obst_gain, 100.0*obst_gain/N);
        }

        const double s_free = double(free_gain) / N;
        const double s_obst = double(obst_gain) / N;

        if (out_known_score) *out_known_score = s_free;
        if (out_obst_score)  *out_obst_score  = s_obst;

        return 0.5*(s_free + s_obst);
    }

    bool FrontierSearch::buildCompletedGridFromMat(const cv::Mat& img_mat,
                                                nav_msgs::OccupancyGrid& out_grid,
                                                const std::string& frame_id) const
    {
        if (!costmap_) {
            ROS_ERROR("buildCompletedGridFromMat: costmap_ is null");
            return false;
        }
        if (img_mat.empty() || img_mat.type() != CV_8UC1) {
            ROS_ERROR("buildCompletedGridFromMat: img_mat must be CV_8UC1 and non-empty");
            return false;
        }

        const unsigned int W_map = costmap_->getSizeInCellsX();
        const unsigned int H_map = costmap_->getSizeInCellsY();
        const double res = costmap_->getResolution();
        const double ox  = costmap_->getOriginX();
        const double oy  = costmap_->getOriginY();

        cv::Mat src = img_mat;

        // Boyut uyuşmazlığı varsa UNKNOWN ile pad/crop yap
        if (static_cast<unsigned int>(src.cols) != W_map ||
            static_cast<unsigned int>(src.rows) != H_map) {
            cv::Mat padded(H_map, W_map, CV_8UC1, cv::Scalar(UNKNOWN_U8));
            const int copy_w = std::min<int>(src.cols, W_map);
            const int copy_h = std::min<int>(src.rows, H_map);
            // sol-üst hizalı kopyalıyoruz (isterseniz ortalayabilirsiniz)
            src(cv::Rect(0, 0, copy_w, copy_h)).copyTo(padded(cv::Rect(0, 0, copy_w, copy_h)));
            src = std::move(padded);
        }

        // OccupancyGrid meta
        out_grid = nav_msgs::OccupancyGrid(); // reset
        out_grid.header.frame_id = frame_id;
        out_grid.header.stamp = ros::Time::now();

        out_grid.info.resolution = res;
        out_grid.info.width  = W_map;
        out_grid.info.height = H_map;
        out_grid.info.origin.position.x = ox;
        out_grid.info.origin.position.y = oy;
        out_grid.info.origin.position.z = 0.0;
        // yaw=0
        out_grid.info.origin.orientation.x = 0.0;
        out_grid.info.origin.orientation.y = 0.0;
        out_grid.info.origin.orientation.z = 0.0;
        out_grid.info.origin.orientation.w = 1.0;

        // OpenCV (üstten sayar) -> OccupancyGrid (alttan sayar):
        // sadece dikey flip; sonra 0/205/254 -> 100/-1/0 eşlemeleri.
        out_grid.data.resize(W_map * H_map);
        for (unsigned int i = 0; i < H_map; ++i) {
            for (unsigned int j = 0; j < W_map; ++j) {
            // OpenCV row (top) -> Occupancy row (bottom): vertical flip ONLY
            const unsigned char v = src.at<unsigned char>(H_map - 1 - i, j);  // <-- keep this
            int8_t occ = -1;
            if (v == 0)      occ = 100;  // obstacle
            else if (v == 254) occ = 0;  // free
            else               occ = -1; // unknown
            out_grid.data[i * W_map + j] = occ;
            }
        }

        return true;
        }

        void FrontierSearch::publishCompletedMap(const cv::Mat& img_mat,
                                                ros::Publisher& pub,
                                                const std::string& frame_id) const
        {
        nav_msgs::OccupancyGrid grid;
        if (!buildCompletedGridFromMat(img_mat, grid, frame_id)) {
            ROS_WARN("publishCompletedMap: buildCompletedGridFromMat failed");
            return;
        }
        pub.publish(grid);
        }

        // frontier_search.cpp
        void FrontierSearch::seedCompletedMapFromCostmap() {
        if (!costmap_) return;
        const unsigned int W = costmap_->getSizeInCellsX();
        const unsigned int H = costmap_->getSizeInCellsY();
        completed_map_.create(H, W, CV_8UC1);

        const unsigned char* raw = costmap_->getCharMap();
        for (unsigned int y = 0; y < H; ++y) {
            for (unsigned int x = 0; x < W; ++x) {
            const unsigned char c = raw[y*W + x];
            unsigned char v;
            if (c == costmap_2d::NO_INFORMATION)      v = 205; // UNKNOWN
            else if (c == costmap_2d::FREE_SPACE)     v = 254; // KNOWN
            else                                      v = 0;   // OBSTACLE (incl. inflation)
            // write in OpenCV image coords (top-left origin)
            completed_map_.at<unsigned char>(H - 1 - y, x) = v;   // <-- NOTE the H-1-y
            }
        }
        }

        void FrontierSearch::seedCompletedMapFromGT() {
        if (!costmap_) {
            ROS_WARN("seedCompletedMapFromGT: costmap_ is null");
            return;
        }
        if (gt_image_.empty()) {
            ROS_WARN("seedCompletedMapFromGT: gt_image_ is empty");
            return;
        }
        if (yaml_res_ <= 0.0 || map_res_ <= 0.0) {
            ROS_WARN("seedCompletedMapFromGT: invalid resolutions (yaml_res=%.6f, map_res=%.6f)", yaml_res_, map_res_);
            return;
        }

        const unsigned int W = costmap_->getSizeInCellsX();
        const unsigned int H = costmap_->getSizeInCellsY();
        gt_map_.create(H, W, CV_8UC1);

        const int gt_w = gt_image_.cols;
        const int gt_h = gt_image_.rows;

        for (unsigned int y = 0; y < H; ++y) {
            for (unsigned int x = 0; x < W; ++x) {
            // Bu costmap hücresinin dünya koordinatı (hücre merkezi)
            const double wx = map_org_x_ + (static_cast<double>(x) + 0.5) * map_res_;
            const double wy = map_org_y_ + (static_cast<double>(y) + 0.5) * map_res_;

            // Dünya -> GT piksel (GT: alt-sol orijin, OpenCV: üst-sol)
            const int gi = static_cast<int>( (wx - yaml_x_) / yaml_res_ );
            const int gj_from_bottom = static_cast<int>( (wy - yaml_y_) / yaml_res_ );
            const int gj = gt_h - 1 - gj_from_bottom;

            unsigned char v = UNKNOWN_U8; // dışarıdaysa UNKNOWN
            if (gi >= 0 && gi < gt_w && gj >= 0 && gj < gt_h) {
                unsigned char src = gt_image_.at<unsigned char>(gj, gi);
                // Beklenen sözleşme: 0=engel, 205=bilinmeyen, 254=serbest
                if      (src == 0)   v = OBSTACLE_U8;
                else if (src == 205) v = UNKNOWN_U8;
                else if (src == 254) v = KNOWN_U8;
                else {
                // Map_saver varyasyonlarına karşı kaba sınıflama
                if (src < 50)       v = OBSTACLE_U8;
                else if (src > 200) v = KNOWN_U8;
                else                v = UNKNOWN_U8;
                }
            }

            // gt_map_ OpenCV dizininde üstten sayar → costmap satırı y’yi ters çevir
            gt_map_.at<unsigned char>(H - 1 - y, x) = v;
            }
        }

        ROS_INFO("seedCompletedMapFromGT: gt_map_ filled from GT (%ux%u <- %dx%d)",
                W, H, gt_w, gt_h);
    }


    // Adaptif minimum size hesaplama
    double FrontierSearch::calculateAdaptiveMinSize(size_t total_frontiers, double exploration_progress) const
    {
        // Çok frontier varsa (>20) daha seçici ol
        if (total_frontiers > 20) {
            return base_min_frontier_size_ * 2.0;  // 2x daha büyük frontier iste
        }
        
        // Az frontier varsa (<5) daha toleranslı ol
        if (total_frontiers < 5) {
            return base_min_frontier_size_ * 0.5;  // Yarısı kadar küçük frontier kabul et
        }
        
        // Exploration ilerledikçe (map %80+ dolu) küçük frontierları da kabul et
        if (exploration_progress > 0.8) {
            return base_min_frontier_size_ * 0.3;  // Çok küçük detayları da keşfet
        }
        
        return base_min_frontier_size_;  // Normal durum
    }

    // Gürültü frontier tespiti
    bool FrontierSearch::isNoiseFrontier(const Frontier& frontier, size_t total_frontiers) const
    {
        const double frontier_size_m = frontier.size * costmap_->getResolution();
        
        // Çok küçük ve izole frontierler gürültü olabilir
        if (frontier_size_m < 0.2 && total_frontiers > 10) {  // 20cm'den küçük ve çok frontier var
            
            // Eğer completion score çok düşükse (belirsizlik az) gürültü olabilir
            if (frontier.completion_known_score < 0.1 && frontier.completion_obstacle_score < 0.1) {
                ROS_DEBUG("Noise frontier detected: size=%.2f, completion scores very low", frontier_size_m);
                return true;
            }
        }
        
        return false;
    }

    // Add this complete implementation to frontier_search.cpp

    bool FrontierSearch::isBeyondWallArtifact(const geometry_msgs::Point& frontier_pos, 
                                            const geometry_msgs::Point& robot_pos) const
    {
        if (!costmap_) return false;
        
        unsigned int fx, fy;
        if (!costmap_->worldToMap(frontier_pos.x, frontier_pos.y, fx, fy)) {
            return true; // Outside map bounds
        }
        
        // Convert robot position to map coordinates
        unsigned int rx, ry;
        if (!costmap_->worldToMap(robot_pos.x, robot_pos.y, rx, ry)) {
            return false; // Can't get robot position, be safe
        }
        
        // Cast ray from robot to frontier and check for wall barrier
        return checkRayForWallBarrier(rx, ry, fx, fy, frontier_pos);
    }

    // Robot'tan frontier'e ışın çizerek duvar bariyeri kontrol et
    bool FrontierSearch::checkRayForWallBarrier(int rx, int ry, int fx, int fy, const geometry_msgs::Point& frontier_pos) const
    {
        // Bresenham line algorithm ile robot'tan frontier'e ışın çiz
        int dx = abs(fx - rx);
        int dy = abs(fy - ry);
        int x = rx, y = ry;
        int x_inc = (fx > rx) ? 1 : -1;
        int y_inc = (fy > ry) ? 1 : -1;
        int error = dx - dy;
        
        int wall_thickness = 0;
        bool passed_through_wall = false;
        const int min_wall_thickness = 2; // En az 2 hücre kalınlığında duvar
        
        while (x != fx || y != fy) {
            // Bounds check
            if (x < 0 || x >= (int)costmap_->getSizeInCellsX() || 
                y < 0 || y >= (int)costmap_->getSizeInCellsY()) {
                break;
            }
            
            unsigned char cost = costmap_->getCost(x, y);
            
            if (cost >= costmap_2d::INSCRIBED_INFLATED_OBSTACLE) {
                wall_thickness++;
                if (wall_thickness >= min_wall_thickness) {
                    passed_through_wall = true;
                }
            } else {
                // Duvardan çıktık
                if (passed_through_wall && wall_thickness >= min_wall_thickness) {
                    // Kalın bir duvardan geçtikten sonra frontier'e ulaştık
                    // Bu frontier duvar ötesinde - muhtemelen haritalama hatası
                    ROS_DEBUG("Frontier (%.2f,%.2f) is beyond wall barrier (thickness=%d)", 
                            frontier_pos.x, frontier_pos.y, wall_thickness);
                    return true;
                }
                wall_thickness = 0;
            }
            
            // Bresenham step
            int error2 = 2 * error;
            if (error2 > -dy) {
                error -= dy;
                x += x_inc;
            }
            if (error2 < dx) {
                error += dx;
                y += y_inc;
            }
        }
        
        return false; // No wall barrier detected
    }

    // Completed map ile çapraz kontrol - sahte alan tespiti
    bool FrontierSearch::isArtificialArea(const geometry_msgs::Point& frontier_pos) const
    {
        if (completed_map_.empty()) return false; // Completed map yoksa kontrol edemeyiz
        
        // Frontier pozisyonunu completed map'te kontrol et
        int gx, gy;
        if (!worldToImagePxPy(frontier_pos.x, frontier_pos.y,
                            map_org_x_, map_org_y_, map_res_,
                            completed_map_.cols, completed_map_.rows, gx, gy)) {
            return true; // Completed map dışındaysa sahte olabilir
        }
        
        // Completed map'te bu bölge ne diyor?
        unsigned char completed_value = completed_map_.at<unsigned char>(gy, gx);
        
        // Completed map'te duvar/engel tahmin ediliyor ama costmap'te unknown/free görünüyor
        if (completed_value == OBSTACLE_U8) {
            unsigned int cx, cy;
            if (costmap_->worldToMap(frontier_pos.x, frontier_pos.y, cx, cy)) {
                unsigned char cost = costmap_->getCost(cx, cy);
                if (cost == costmap_2d::NO_INFORMATION || cost == costmap_2d::FREE_SPACE) {
                    ROS_DEBUG("Completed-Costmap mismatch: completed says obstacle, costmap says free/unknown at (%.2f,%.2f)",
                            frontier_pos.x, frontier_pos.y);
                    return true; // Muhtemelen haritalama hatası veya tahmin hatası
                }
            }
        }
        
        // Ek kontrol: Completed map'te known area olarak tahmin edilmiş ama costmap'te unknown
        // Bu durumda frontier muhtemelen gereksiz (tahmin zaten bu alanı biliyor)
        if (completed_value == KNOWN_U8) {
            unsigned int cx, cy;
            if (costmap_->worldToMap(frontier_pos.x, frontier_pos.y, cx, cy)) {
                unsigned char cost = costmap_->getCost(cx, cy);
                if (cost == costmap_2d::NO_INFORMATION) {
                    ROS_DEBUG("Redundant frontier: completed map predicts free space at unknown area (%.2f,%.2f)",
                            frontier_pos.x, frontier_pos.y);
                    return true; // Tahmin zaten bu alanı biliyor, frontier gereksiz
                }
            }
        }
        
        return false;
    }


    // New progressive filtering function
    std::vector<Frontier> FrontierSearch::applyProgressiveFiltering(
        const std::vector<Frontier>& candidates, 
        const geometry_msgs::Point& robot_pos)
    {
        std::vector<Frontier> result;
        
        // Level 1: Strict filtering (current rules)
        result = applyStrictFiltering(candidates, robot_pos);
        if (!result.empty()) {
            ROS_INFO("Level 1 (strict): %zu/%zu frontiers passed", result.size(), candidates.size());
            return result;
        }
        
        // Level 2: Relaxed wall filtering (higher wall tolerance)
        result = applyRelaxedFiltering(candidates, robot_pos);
        if (!result.empty()) {
            ROS_WARN("Level 2 (relaxed): %zu/%zu frontiers passed - strict filters too aggressive", 
                    result.size(), candidates.size());
            return result;
        }
        
        // Level 3: Size-only filtering (emergency fallback)
        result = applyEmergencyFiltering(candidates, robot_pos);
        if (!result.empty()) {
            ROS_WARN("Level 3 (emergency): %zu/%zu frontiers passed - using size-only filter", 
                    result.size(), candidates.size());
            return result;
        }
        
        ROS_ERROR("All filtering levels failed - no valid frontiers found");
        return std::vector<Frontier>{};
    }

    // Level 1: Current strict rules
    std::vector<Frontier> FrontierSearch::applyStrictFiltering(
        const std::vector<Frontier>& candidates,
        const geometry_msgs::Point& robot_pos)
    {
        std::vector<Frontier> result;
        
        for (const auto& f : candidates) {
            // Current strict rules
            if (isFrontierNearWall(f.centroid)) continue;
            if (isBeyondWallArtifact(f.centroid, robot_pos)) continue;
            if (isArtificialArea(f.centroid)) continue;
            if (isNoiseFrontier(f, candidates.size())) continue;
            
            result.push_back(f);
        }
        
        return result;
    }

    // Level 2: Relaxed rules
    std::vector<Frontier> FrontierSearch::applyRelaxedFiltering(
        const std::vector<Frontier>& candidates,
        const geometry_msgs::Point& robot_pos)
    {
        std::vector<Frontier> result;
        
        for (const auto& f : candidates) {
            // Relaxed wall check (higher threshold)
            double wall_ratio = calculateWallRatio(f.centroid);
            if (wall_ratio > 0.8) continue;  // Was 0.6, now 0.8
            
            // Keep beyond wall check but make it less strict
            if (isBeyondWallArtifactRelaxed(f.centroid, robot_pos)) continue;
            
            // Skip artificial area check (too strict)
            // Skip noise check (too strict)
            
            result.push_back(f);
        }
        
        return result;
    }

    // Level 3: Emergency - only basic checks
    std::vector<Frontier> FrontierSearch::applyEmergencyFiltering(
        const std::vector<Frontier>& candidates,
        const geometry_msgs::Point& robot_pos)
    {
        std::vector<Frontier> result;
        
        for (const auto& f : candidates) {
            // Only check if frontier is completely surrounded by walls
            double wall_ratio = calculateWallRatio(f.centroid);
            if (wall_ratio > 0.95) continue;  // Only reject if 95%+ walls
            
            result.push_back(f);
        }
        
        // If still nothing, return the best candidate anyway
        if (result.empty() && !candidates.empty()) {
            ROS_WARN("Emergency fallback: returning best frontier despite filters");
            
            // Find frontier with lowest wall ratio
            auto best_it = std::min_element(candidates.begin(), candidates.end(),
                [this](const Frontier& a, const Frontier& b) {
                    return calculateWallRatio(a.centroid) < calculateWallRatio(b.centroid);
                });
            
            result.push_back(*best_it);
        }
        
        return result;
    }

    // Relaxed version of beyond wall check
    bool FrontierSearch::isBeyondWallArtifactRelaxed(
        const geometry_msgs::Point& frontier_pos, 
        const geometry_msgs::Point& robot_pos) const
    {
        if (!costmap_) return false;
        
        unsigned int fx, fy, rx, ry;
        if (!costmap_->worldToMap(frontier_pos.x, frontier_pos.y, fx, fy)) return true;
        if (!costmap_->worldToMap(robot_pos.x, robot_pos.y, rx, ry)) return false;
        
        // More relaxed wall barrier check
        return checkRayForWallBarrierRelaxed(rx, ry, fx, fy, frontier_pos);
    }

    bool FrontierSearch::checkRayForWallBarrierRelaxed(
        int rx, int ry, int fx, int fy, 
        const geometry_msgs::Point& frontier_pos) const
    {
        // Same Bresenham algorithm but require thicker walls
        int dx = abs(fx - rx);
        int dy = abs(fy - ry);
        int x = rx, y = ry;
        int x_inc = (fx > rx) ? 1 : -1;
        int y_inc = (fy > ry) ? 1 : -1;
        int error = dx - dy;
        
        int wall_thickness = 0;
        bool passed_through_wall = false;
        const int min_wall_thickness = 4; // Was 2, now 4 (require thicker walls)
        
        while (x != fx || y != fy) {
            if (x < 0 || x >= (int)costmap_->getSizeInCellsX() || 
                y < 0 || y >= (int)costmap_->getSizeInCellsY()) {
                break;
            }
            
            unsigned char cost = costmap_->getCost(x, y);
            
            if (cost >= costmap_2d::LETHAL_OBSTACLE) {  // Only count lethal, not inflated
                wall_thickness++;
                if (wall_thickness >= min_wall_thickness) {
                    passed_through_wall = true;
                }
            } else {
                if (passed_through_wall && wall_thickness >= min_wall_thickness) {
                    return true;
                }
                wall_thickness = 0;
            }
            
            // Bresenham step
            int error2 = 2 * error;
            if (error2 > -dy) { error -= dy; x += x_inc; }
            if (error2 < dx) { error += dx; y += y_inc; }
        }
        
        return false;
    }

} // namespace frontier_exploration



