bool FrontierSearch::getCompletedRegionAroundFrontier(double frontier_x,
                                                      double frontier_y,
                                                      cv::Mat& out_gt,
                                                      cv::Mat& out_cur)
{
    if (!costmap_ || rect_size_ <= 0) return false;

    // Lock for thread safety
    std::lock_guard<std::recursive_mutex> lock(data_mutex_);

    // ====== 0) Sabitler / Kısa adlar
    const int W = static_cast<int>(costmap_->getSizeInCellsX());
    const int H = static_cast<int>(costmap_->getSizeInCellsY());
    const double org_x = costmap_->getOriginX();
    const double org_y = costmap_->getOriginY();
    const double res   = costmap_->getResolution();
    const int P        = rect_size_;
    const int half     = P / 2;

    // ====== 1) CANLI COSTMAP'i OpenCV formatına çevir
    cv::Mat live_cm(H, W, CV_8UC1, cv::Scalar(UNKNOWN_U8));
    {
        const unsigned char* raw = costmap_->getCharMap();
        for (int y = 0; y < H; ++y) {
            const int src_row_off = y * W;
            uchar* dst = live_cm.ptr<uchar>(H - 1 - y);
            for (int x = 0; x < W; ++x) {
                const unsigned char c = raw[src_row_off + x];
                uchar v;
                if (c == costmap_2d::NO_INFORMATION)      v = UNKNOWN_U8;
                else if (c == costmap_2d::FREE_SPACE)     v = KNOWN_U8;
                else                                      v = OBSTACLE_U8;
                dst[x] = v;
            }
        }
    }

    // ====== 2) Frontier (dünya) -> piksel (OpenCV) dönüşümü
    int cx = 0, cy = 0;
    if (!worldToImagePxPy(frontier_x, frontier_y,
                          org_x, org_y, res,
                          W, H, cx, cy, /*flipY=*/true))
    {
        return false;
    }

    // ====== 3) ROI dikdörtgenini hesapla
    const int x0 = std::max(0, cx - half);
    const int y0 = std::max(0, cy - half);
    const int x1 = std::min(W,  cx + half);
    const int y1 = std::min(H,  cy + half);
    if (x1 <= x0 || y1 <= y0) return false;
    cv::Rect roi_cm(x0, y0, x1 - x0, y1 - y0);

    // ====== 4) PATCH ÇIKAR — current costmap'ten
    if (!cropWithPad(live_cm, cx, cy, P, UNKNOWN_U8, out_cur)) {
        return false;
    }

    // ====== 5) ✅ YENİ: FRONTIER HISTORY KONTROLÜ
    FrontierKey fkey = getFrontierKey(frontier_x, frontier_y);
    auto history_it = active_frontier_patches_.find(fkey);
    
    bool have_gt = false;
    bool use_history_patch = false;

    // ====== 5a) History'de bu frontier için patch var mı?
    if (history_it != active_frontier_patches_.end()) {
        const FrontierPatchInfo& patch_info = history_it->second;
        
        // Timestamp kontrolü - çok eski patch'leri kullanma (örn: 60 saniye)
        ros::Duration age = ros::Time::now() - patch_info.timestamp;
        if (age.toSec() < 60.0) {  // 60 saniye içindeki patch'ler geçerli
            // ✅ History'den patch kullan
            out_gt = patch_info.gt_patch.clone();
            have_gt = true;
            use_history_patch = true;
            
            ROS_INFO("✅ Using cached patch for frontier at (%.2f, %.2f), age: %.1f sec", 
                     frontier_x, frontier_y, age.toSec());
        } else {
            // Eski patch - history'den sil
            active_frontier_patches_.erase(history_it);
            ROS_INFO("Removed stale patch for frontier at (%.2f, %.2f), age: %.1f sec",
                     frontier_x, frontier_y, age.toSec());
        }
    }

    // ====== 5b) History'de yoksa veya çok eskiyse: GT'dan yeni patch al
    if (!have_gt) {
        // GT dünya -> piksel
        if (!gt_image_.empty() && yaml_res_ > 0.0) {
            int gx = 0, gy = 0;
            if (worldToImagePxPy(frontier_x, frontier_y,
                                yaml_x_, yaml_y_, yaml_res_,
                                gt_image_.cols, gt_image_.rows, gx, gy, /*flipY=*/true))
            {
                cv::Mat gt_u8;
                if (gt_image_.type() == CV_8UC1) gt_u8 = gt_image_;
                else                             gt_image_.convertTo(gt_u8, CV_8UC1);

                if (cropWithPad(gt_u8, gx, gy, P, UNKNOWN_U8, out_gt)) {
                    have_gt = true;
                    
                    // ✅ YENİ PATCH'İ HISTORY'E EKLE
                    FrontierPatchInfo new_patch_info;
                    new_patch_info.roi = roi_cm;
                    new_patch_info.gt_patch = out_gt.clone();
                    new_patch_info.timestamp = ros::Time::now();
                    
                    active_frontier_patches_[fkey] = new_patch_info;
                    
                    ROS_INFO("✅ Added new patch to history for frontier at (%.2f, %.2f)", 
                            frontier_x, frontier_y);
                    
                    // ✅ KRİTİK DÜZELTME: completed_map'e uygulama KALDIRILDI
                    // Bu işlem artık seedCompletedMapFromCostmap() içinde yapılıyor
                    // Burada yapılan uygulama orijin kaymasına neden oluyordu
                }
            }
        }
        // Fallback: completed_map_'den al
        if (!have_gt && !completed_map_.empty()
            && completed_map_.cols == W && completed_map_.rows == H)
        {
            cv::Mat tmp = completed_map_(roi_cm).clone();
            if (tmp.type() != CV_8UC1) tmp.convertTo(tmp, CV_8UC1);
            out_gt = cv::Mat(P, P, CV_8UC1, cv::Scalar(UNKNOWN_U8));
            tmp.copyTo(out_gt(cv::Rect(0,0,tmp.cols, tmp.rows)));
            have_gt = true;
        }
    }

    // Fallback: GT bulunamadı
    if (!have_gt) {
        out_gt = out_cur.clone();
    }

    // ====== 6) ✅ ARTIK PATCH'İ BURADA completed_map_'e UYGULAMIYORUZ
    // Tüm patch uygulamaları seedCompletedMapFromCostmap() içinde yapılıyor
    // Bu, orijin kayması sorununu çözecek

    // ====== 7) ✅ YENİ: HİZALAMA KONTROLÜ (opsiyonel - performans için kapatılabilir)
    if (have_gt && !use_history_patch && !completed_map_.empty()) {
        // Yeni patch alındı - hizalama kontrolü yap
        double conflict_ratio = checkPatchConflict(out_cur, out_gt, roi_cm);
        
        if (conflict_ratio > 0.3) {  // %30'dan fazla çakışma
            ROS_WARN("High conflict ratio (%.2f%%) for frontier at (%.2f, %.2f) - patch may need alignment",
                     conflict_ratio * 100.0, frontier_x, frontier_y);
            
            // Hizalama dene ...
            cv::Mat aligned_gt;
            if (performAdvancedAlignment(live_cm, roi_cm, aligned_gt)) {
                out_gt = aligned_gt;
                ROS_INFO("Applied alignment correction for frontier at (%.2f, %.2f)",
                         frontier_x, frontier_y);
            }
        }
    }

    return true;
}
